import js from '@eslint/js';
import globals from 'globals';
import tseslint from 'typescript-eslint';
import reactHooks from 'eslint-plugin-react-hooks';
import reactRefresh from 'eslint-plugin-react-refresh';

export default tseslint.config(
  { ignores: ['dist', 'node_modules'] },
  {
    extends: [js.configs.recommended, ...tseslint.configs.recommended],
    files: ['**/*.{ts,tsx}'],
    languageOptions: {
      ecmaVersion: 2022,
      globals: globals.browser,
    },
    plugins: {
      'react-hooks': reactHooks,
      'react-refresh': reactRefresh,
    },
    rules: {
      ...reactHooks.configs.recommended.rules,
      'react-refresh/only-export-components': ['warn', { allowConstantExport: true }],
      // Warn in UI code; escalated to error on the persistence path below.
      '@typescript-eslint/no-explicit-any': 'warn',
      '@typescript-eslint/no-unused-vars': ['warn', { argsIgnorePattern: '^_' }],
    },
  },
  {
    // The persistence path. An `any` here is how categoryOverrides, categoryAges and
    // pre65AcaBridgeSurcharge got written to the plan but stripped on every read.
    // Anything crossing the storage boundary must be fully typed.
    files: [
      'src/types.ts',
      'src/schemas/**/*.ts',
      'src/store/**/*.ts',
      'src/utils/**/*.ts',
      'src/services/**/*.ts',
      'src/domain/**/*.ts',
    ],
    rules: {
      '@typescript-eslint/no-explicit-any': 'error',
    },
  },
  {
    // Architectural Boundaries: domain/kernel
    files: ['src/domain/kernel/**/*.ts'],
    ignores: ['**/*.test.ts'],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          paths: [
            { name: 'react', message: 'domain/kernel may not import React.' },
            { name: 'react-dom', message: 'domain/kernel may not import React.' },
            { name: 'zustand', message: 'domain/kernel may not import Zustand/store.' },
            { name: 'firebase', message: 'domain/kernel may not import Firebase.' },
            { name: 'firebase/app', message: 'domain/kernel may not import Firebase.' },
            { name: 'firebase/firestore', message: 'domain/kernel may not import Firebase.' },
            { name: 'firebase/auth', message: 'domain/kernel may not import Firebase.' },
          ],
          patterns: [
            { group: ['*components*', '**/components/**', '../components/**', '../../components/**'], message: 'domain/kernel may not import components.' },
            { group: ['*store*', '**/store/**', '../store/**', '../../store/**'], message: 'domain/kernel may not import store.' },
            { group: ['*services*', '**/services/**', '../services/**', '../../services/**'], message: 'domain/kernel may not import services.' },
          ],
        },
      ],
      'no-restricted-globals': [
        'error',
        { name: 'localStorage', message: 'domain/kernel may not use localStorage.' },
        { name: 'sessionStorage', message: 'domain/kernel may not use sessionStorage.' },
      ],
    },
  },
  {
    // Architectural Boundaries: domain/registry
    files: ['src/domain/registry/**/*.ts'],
    ignores: ['**/*.test.ts'],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          paths: [
            { name: 'react', message: 'domain/registry may not import React.' },
            { name: 'react-dom', message: 'domain/registry may not import React.' },
            { name: 'zustand', message: 'domain/registry may not import Zustand/store.' },
            { name: 'firebase', message: 'domain/registry may not import Firebase.' },
            { name: 'firebase/app', message: 'domain/registry may not import Firebase.' },
            { name: 'firebase/firestore', message: 'domain/registry may not import Firebase.' },
            { name: 'firebase/auth', message: 'domain/registry may not import Firebase.' },
          ],
          patterns: [
            { group: ['*components*', '**/components/**', '../components/**', '../../components/**'], message: 'domain/registry may not import components.' },
            { group: ['*store*', '**/store/**', '../store/**', '../../store/**'], message: 'domain/registry may not import store.' },
            { group: ['*simulation*', '**/simulation/**', '../simulation/**', '../../simulation/**'], message: 'domain/registry may not depend on simulation.' },
            { group: ['*analysis*', '**/analysis/**', '../analysis/**', '../../analysis/**'], message: 'domain/registry may not depend on analysis.' },
          ],
        },
      ],
    },
  },
  {
    // Architectural Boundaries: domain/analysis
    files: ['src/domain/analysis/**/*.ts'],
    ignores: ['**/*.test.ts'],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          paths: [
            { name: 'react', message: 'domain/analysis may not import React.' },
            { name: 'react-dom', message: 'domain/analysis may not import React.' },
            { name: 'zustand', message: 'domain/analysis may not import Zustand/store.' },
            { name: 'firebase', message: 'domain/analysis may not import Firebase.' },
            { name: 'firebase/app', message: 'domain/analysis may not import Firebase.' },
            { name: 'firebase/firestore', message: 'domain/analysis may not import Firebase.' },
            { name: 'firebase/auth', message: 'domain/analysis may not import Firebase.' },
          ],
          patterns: [
            { group: ['*components*', '**/components/**', '../components/**', '../../components/**'], message: 'domain/analysis may not import components.' },
            { group: ['*services*', '**/services/**', '../services/**', '../../services/**'], message: 'domain/analysis may not import services.' },
            { group: ['*store*', '**/store/**', '../store/**', '../../store/**'], message: 'domain/analysis may not import store.' },
          ],
        },
      ],
    },
  },
  {
    // Architectural Boundaries: domain/simulation & domain/projection
    files: ['src/domain/simulation/**/*.ts', 'src/domain/projection/**/*.ts'],
    ignores: ['**/*.test.ts'],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          paths: [
            { name: 'react', message: 'domain/simulation/projection may not import React.' },
            { name: 'react-dom', message: 'domain/simulation/projection may not import React.' },
            { name: 'firebase', message: 'domain/simulation/projection may not import Firebase.' },
            { name: 'firebase/app', message: 'domain/simulation/projection may not import Firebase.' },
            { name: 'firebase/firestore', message: 'domain/simulation/projection may not import Firebase.' },
            { name: 'firebase/auth', message: 'domain/simulation/projection may not import Firebase.' },
          ],
          patterns: [
            { group: ['*components*', '**/components/**', '../components/**', '../../components/**'], message: 'domain/simulation/projection may not import components.' },
          ],
        },
      ],
    },
  }
);
