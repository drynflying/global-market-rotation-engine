# Project Custom Instructions

## Scope & Feature Constraints
- **Strict Scope Discipline**: Never add unsolicited features, unrequested navigation buttons, extra UI controls, or decorative tabs that were not specifically requested by the user.
- **No Unrequested Navigation Controls**: Keep header action bars and section layouts focused strictly on the controls requested. Do not insert extra step transition buttons or model presets unless specifically asked.

## Engine & Domain Logic Protection
- **Protect Engine Logic**: During UI/styling tasks, never modify files inside `/src/domain/` or `/src/schemas/` (e.g. `simulationEngine.ts`, `taxConstants.ts`, `rowReconciliation.ts`, `planSchema.ts`).
- **Separation of Concerns**: Treat `/src/domain/` as read-only code during front-end styling and layout adjustments. Only update calculations or domain models when the request explicitly asks for changes to the simulation engine or financial rules.

## System Architecture & Layer Boundaries (Phase 1 Contract)
1. **Financial Engine Independence**:
   - Code inside `/src/domain/` MUST remain pure and completely free of infrastructure imports (Firebase, Firestore, Auth, React, Zustand, UI services).
   - Engine input: Pure `Plan` + explicit parameters.
   - Engine output: Pure deterministic projection structures and ledger rows.
2. **Persistence & Identity Boundary**:
   - Firebase Auth handles identity and per-user scope (`users/{uid}/plans/{planId}`).
   - `planRepository.ts` isolates local storage cache and Firestore synchronization.
   - User profile data vs Plan state: Household identity is anchored to the profile, while financial scenarios are saved in individual plans.
3. **Data & Default Precedence**:
   - Level 1: Schema Defaults (`planSchema.ts`) — populates missing field values.
   - Level 2: New Plan Template (`DEFAULT_PLAN`) — creates a full baseline household scenario.
   - Level 3: Saved User Plan (`planStorage.ts` / Firestore) — authoritative user scenario state once saved.
   - Level 4: Statutory Registry / Overrides — official tax/benefit rates with support for user scenario overrides.
4. **Refactoring Roadmap**:
   - Phase 1: Architecture & Boundary Contracts (Active)
   - Phase 2: Statutory & Assumption Registry Extraction
   - Phase 3: Engine Determinism (removing wall-clock `new Date()` dependencies from calculations)
   - Phase 4: Incremental Layered Engine Decomposition (Registry -> Kernel -> Projection -> Strategy -> Analysis)

