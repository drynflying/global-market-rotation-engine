/**
 * Domain types.
 *
 * Everything describing the shape of a saved Plan is DERIVED from the zod schemas in
 * `schemas/planSchema.ts` via `z.infer`. Do not hand-write those interfaces here.
 *
 * Previously this file and planSchema.ts were two independent descriptions of the same
 * data, which meant a field could exist in one and not the other. That is exactly how
 * `categoryOverrides`, `categoryAges` and `pre65AcaBridgeSurcharge` ended up being
 * written to the plan but silently stripped on every read. With `z.infer` that class of
 * bug becomes a compile error instead of silent data loss.
 *
 * To add a field to the plan: add it to the schema in planSchema.ts. It appears here
 * automatically.
 *
 * Types that are NOT persisted (validation results) stay hand-written below, since they
 * never round-trip through storage.
 */
import { z } from 'zod';
import type { TabId } from './constants/tabs';
import type {
  OwnerTypeSchema,
  AccountTypeSchema,
  IncomeTypeSchema,
  IncomeStreamSchema,
  UserProfileSchema,
  PlanAssumptionResourceSchema,
  AccountAllocationSchema,
  AccountItemSchema,
  AssetClassCMASchema,
  CapitalMarketAssumptionsSchema,
  AssetAllocationTargetSchema,
  MacroeconomicAssumptionsSchema,
  StatutoryParametersSchema,
  AcaAssumptionsSchema,
  SpecialExpenseSchema,
  SpendingAssumptionsSchema,
  PlanSchema,
} from './schemas/planSchema';

// --- Persisted plan shapes (derived - edit planSchema.ts, not this file) ---

export type OwnerType = z.infer<typeof OwnerTypeSchema>;
export type AccountType = z.infer<typeof AccountTypeSchema>;
export type IncomeType = z.infer<typeof IncomeTypeSchema>;

export type IncomeStream = z.infer<typeof IncomeStreamSchema>;
export type UserProfile = z.infer<typeof UserProfileSchema>;
export type PlanAssumptionResource = z.infer<typeof PlanAssumptionResourceSchema>;
export type AccountAllocation = z.infer<typeof AccountAllocationSchema>;
export type AccountItem = z.infer<typeof AccountItemSchema>;
export type AssetClassCMA = z.infer<typeof AssetClassCMASchema>;
export type CapitalMarketAssumptions = z.infer<typeof CapitalMarketAssumptionsSchema>;
export type AssetAllocationTarget = z.infer<typeof AssetAllocationTargetSchema>;
export type MacroeconomicAssumptions = z.infer<typeof MacroeconomicAssumptionsSchema>;
export type StatutoryParameters = z.infer<typeof StatutoryParametersSchema>;
export type AcaAssumptions = z.infer<typeof AcaAssumptionsSchema>;
export type SpecialExpense = z.infer<typeof SpecialExpenseSchema>;
export type SpendingAssumptions = z.infer<typeof SpendingAssumptionsSchema>;
export type Plan = z.infer<typeof PlanSchema>;

// --- Non-persisted types (hand-written; these never round-trip through storage) ---

export type ValidationStatus = 'pass' | 'warning' | 'fail';

export interface ValidationResult {
  id: string;
  step: number;
  stepName: string;
  title: string;
  category: 'Profile' | 'Accounts' | 'Contributions' | 'Liabilities' | 'Tax & Compliance';
  status: ValidationStatus;
  description: string;
  recommendation?: string;
  targetTab?: TabId;
}

/**
 * Input-side plan shape: fields carrying a zod `.default()` are optional here but
 * guaranteed present on `Plan` (the parsed output). Use this when constructing a plan
 * literal by hand; use `Plan` when consuming one that has been through the schema.
 */
export type PlanInput = z.input<typeof PlanSchema>;
