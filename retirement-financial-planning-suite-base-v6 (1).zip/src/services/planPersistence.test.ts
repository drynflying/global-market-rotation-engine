import { describe, it, expect, beforeEach, vi } from 'vitest';

// In-memory localStorage mock for node test environment
if (typeof globalThis.localStorage === 'undefined') {
  const store = new Map<string, string>();
  globalThis.localStorage = {
    getItem: (key: string) => store.get(key) ?? null,
    setItem: (key: string, value: string) => store.set(key, String(value)),
    removeItem: (key: string) => store.delete(key),
    clear: () => store.clear(),
    get length() {
      return store.size;
    },
    key: (index: number) => Array.from(store.keys())[index] ?? null,
  } as Storage;
}

if (typeof globalThis.window === 'undefined') {
  const windowListeners = new Map<string, Set<EventListenerOrEventListenerObject>>();
  (globalThis as unknown as { window: unknown }).window = {
    alert: () => {},
    addEventListener: (type: string, listener: EventListenerOrEventListenerObject) => {
      if (!windowListeners.has(type)) windowListeners.set(type, new Set());
      windowListeners.get(type)!.add(listener);
    },
    removeEventListener: (type: string, listener: EventListenerOrEventListenerObject) => {
      windowListeners.get(type)?.delete(listener);
    },
    dispatchEvent: (event: Event) => {
      const set = windowListeners.get(event.type);
      if (set) {
        set.forEach((fn) => {
          if (typeof fn === 'function') fn(event);
          else if (fn && typeof fn.handleEvent === 'function') fn.handleEvent(event);
        });
      }
      return true;
    },
  };
} else {
  window.alert = () => {};
}

import { planRepository } from './planRepository';
import * as firestoreProvider from './firebasePlanSync';
import * as localStorageProvider from '../utils/planStorage';
import * as firebaseLib from '../lib/firebase';
import { cloudSyncManager } from './cloudSyncManager';
import { usePlanStore } from '../store/usePlanStore';
import { createDefaultPlan } from '../constants/defaultPlan';
import { Plan } from '../types';

describe('Plan Persistence & Timestamp Synchronization Suite', () => {
  beforeEach(() => {
    localStorage.clear();
    cloudSyncManager.reset('local-only');
    vi.restoreAllMocks();
  });

  it('A & F: localStorage and Firestore receive the exact same updatedAt from a single save', async () => {
    const firestoreSpy = vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockResolvedValue(undefined);

    const basePlan = createDefaultPlan();
    basePlan.id = 'plan-sync-test-1';
    basePlan.createdAt = '2026-01-01T00:00:00.000Z';
    basePlan.updatedAt = '2026-01-01T00:00:00.000Z';

    const savedPlan = await planRepository.savePlan(basePlan);
    await planRepository.flushPendingSyncs();

    // Verify Firestore received savedPlan
    expect(firestoreSpy).toHaveBeenCalledTimes(1);
    const firestorePayload = firestoreSpy.mock.calls[0][0] as Plan;

    // Verify localStorage received savedPlan
    const localPlans = localStorageProvider.getAllPlans();
    const localStoredPlan = localPlans.find(p => p.id === basePlan.id);

    expect(localStoredPlan).toBeDefined();
    expect(localStoredPlan?.updatedAt).toBe(savedPlan.updatedAt);
    expect(firestorePayload.updatedAt).toBe(savedPlan.updatedAt);
    expect(firestorePayload.updatedAt).toEqual(localStoredPlan?.updatedAt);
  });

  it('B: Zustand receives the exact same updatedAt timestamp on save/update', () => {
    vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockResolvedValue(undefined);

    const defaultPlan = createDefaultPlan();
    defaultPlan.id = 'plan-zustand-sync';
    defaultPlan.createdAt = '2026-01-01T00:00:00.000Z';
    defaultPlan.updatedAt = '2026-01-01T00:00:00.000Z';

    usePlanStore.setState({
      plans: [defaultPlan],
      activePlanId: defaultPlan.id,
      activePlan: defaultPlan,
    });

    const updated = {
      ...defaultPlan,
      name: 'Updated Plan Title',
    };

    usePlanStore.getState().updatePlan(updated);

    const storeActivePlan = usePlanStore.getState().activePlan;
    const localPlans = localStorageProvider.getAllPlans();
    const localStoredPlan = localPlans.find(p => p.id === defaultPlan.id);

    expect(storeActivePlan).not.toBeNull();
    expect(storeActivePlan?.updatedAt).toBeDefined();
    expect(storeActivePlan?.updatedAt).toBe(localStoredPlan?.updatedAt);
  });

  it('C: updatedAt changes when a plan is modified through store', async () => {
    vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockResolvedValue(undefined);

    const oldTimestamp = '2020-01-01T00:00:00.000Z';
    const initial = createDefaultPlan();
    initial.id = 'plan-timestamp-change';
    initial.updatedAt = oldTimestamp;

    usePlanStore.setState({
      plans: [initial],
      activePlanId: initial.id,
      activePlan: initial,
    });

    usePlanStore.getState().updatePlan({
      ...initial,
      name: 'Modified Plan Name',
    });

    const savedPlan = usePlanStore.getState().activePlan!;

    expect(savedPlan.updatedAt).not.toBe(oldTimestamp);
    expect(new Date(savedPlan.updatedAt).getTime()).toBeGreaterThan(new Date(oldTimestamp).getTime());
  });

  it('D: createdAt does not change during ordinary saves', async () => {
    vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockResolvedValue(undefined);

    const originalCreatedAt = '2025-05-15T12:00:00.000Z';
    const plan = createDefaultPlan();
    plan.id = 'plan-createdat-preserve';
    plan.createdAt = originalCreatedAt;

    const savedPlan = await planRepository.savePlan({
      ...plan,
      name: 'Ordinary Edit',
    });

    expect(savedPlan.createdAt).toBe(originalCreatedAt);

    const stored = localStorageProvider.getAllPlans().find(p => p.id === plan.id);
    expect(stored?.createdAt).toBe(originalCreatedAt);
  });

  it('E: saving a plan locally still succeeds when cloud persistence fails (offline policy)', async () => {
    vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockRejectedValue(new Error('Network error / offline'));

    const plan = createDefaultPlan();
    plan.id = 'plan-offline-test';

    // Must not throw despite Firestore rejection
    const savedPlan = await planRepository.savePlan(plan);

    expect(savedPlan).toBeDefined();
    expect(savedPlan.id).toBe('plan-offline-test');

    const stored = localStorageProvider.getAllPlans().find(p => p.id === plan.id);
    expect(stored).toBeDefined();
    expect(stored?.updatedAt).toBe(savedPlan.updatedAt);
  });

  it('G: duplicate and save-as-new operations generate appropriate createdAt and updatedAt values', async () => {
    vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockResolvedValue(undefined);

    const sourcePlan = createDefaultPlan();
    sourcePlan.id = 'plan-source';
    sourcePlan.createdAt = '2024-01-01T00:00:00.000Z';
    sourcePlan.updatedAt = '2024-01-01T00:00:00.000Z';

    const duplicated = await planRepository.duplicatePlan(sourcePlan, 'Cloned Plan');

    expect(duplicated.id).not.toBe('plan-source');
    expect(duplicated.name).toBe('Cloned Plan');
    expect(duplicated.createdAt).not.toBe(sourcePlan.createdAt);
    expect(duplicated.updatedAt).not.toBe(sourcePlan.updatedAt);
    expect(new Date(duplicated.createdAt).getTime()).toBeGreaterThan(new Date(sourcePlan.createdAt).getTime());

    const created = await planRepository.createPlan('Brand New Plan');
    expect(created.name).toBe('Brand New Plan');
    expect(created.createdAt).toBeDefined();
    expect(created.updatedAt).toBeDefined();
    expect(created.createdAt).toBe(created.updatedAt);
  });
});

describe('Issue 1: Single Authoritative Timestamp Per Logical Save (Strict Time Mocking)', () => {
  let callIndex = 0;
  const ISO_TIMESTAMPS = [
    '2026-08-10T10:00:00.000Z',
    '2026-08-10T10:00:01.000Z',
    '2026-08-10T10:00:02.000Z',
    '2026-08-10T10:00:03.000Z',
    '2026-08-10T10:00:04.000Z',
    '2026-08-10T10:00:05.000Z',
    '2026-08-10T10:00:06.000Z',
    '2026-08-10T10:00:07.000Z',
  ];

  beforeEach(() => {
    localStorage.clear();
    cloudSyncManager.reset('local-only');
    vi.restoreAllMocks();
    callIndex = 0;

    vi.spyOn(global.Date.prototype, 'toISOString').mockImplementation(() => {
      const ts = ISO_TIMESTAMPS[callIndex] || `2026-08-10T10:00:${10 + callIndex}.000Z`;
      callIndex++;
      return ts;
    });
  });

  it('A: updatePlan produces one single authoritative updatedAt across Zustand, localStorage, and Firestore, preserving createdAt', async () => {
    const firestoreSpy = vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockResolvedValue(undefined);

    const originalCreatedAt = '2026-01-01T00:00:00.000Z';
    const basePlan = createDefaultPlan();
    basePlan.id = 'plan-test-update';
    basePlan.createdAt = originalCreatedAt;
    basePlan.updatedAt = '2026-01-01T00:00:00.000Z';

    usePlanStore.setState({
      plans: [basePlan],
      activePlanId: basePlan.id,
      activePlan: basePlan,
      undoStack: [],
    });

    // Reset callIndex right before update
    callIndex = 0;

    usePlanStore.getState().updatePlan({ ...basePlan, name: 'Renamed Plan' });
    await planRepository.flushPendingSyncs();

    const storeActive = usePlanStore.getState().activePlan;
    const localPlans = localStorageProvider.getAllPlans();
    const localPlan = localPlans.find(p => p.id === basePlan.id);

    expect(firestoreSpy).toHaveBeenCalled();
    const firestorePayload = firestoreSpy.mock.calls[0][0] as Plan;

    const expectedSingleTimestamp = ISO_TIMESTAMPS[0]; // First call timestamp

    // Prove all 3 locations hold the EXACT same single authoritative timestamp
    expect(storeActive?.updatedAt).toBe(expectedSingleTimestamp);
    expect(localPlan?.updatedAt).toBe(expectedSingleTimestamp);
    expect(firestorePayload.updatedAt).toBe(expectedSingleTimestamp);

    // Confirm createdAt remains unchanged
    expect(storeActive?.createdAt).toBe(originalCreatedAt);
    expect(localPlan?.createdAt).toBe(originalCreatedAt);
    expect(firestorePayload.createdAt).toBe(originalCreatedAt);
  });

  it('B: undo produces one single authoritative updatedAt across Zustand, localStorage, and Firestore', async () => {
    const firestoreSpy = vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockResolvedValue(undefined);

    const initialPlan = createDefaultPlan();
    initialPlan.id = 'plan-test-undo';
    initialPlan.updatedAt = '2026-01-01T00:00:00.000Z';

    const modifiedPlan = { ...initialPlan, name: 'Modified State' };

    usePlanStore.setState({
      plans: [modifiedPlan],
      activePlanId: initialPlan.id,
      activePlan: modifiedPlan,
      undoStack: [{ plan: initialPlan, label: 'test' }],
    });

    callIndex = 0;
    usePlanStore.getState().undo();
    await planRepository.flushPendingSyncs();

    const storeActive = usePlanStore.getState().activePlan;
    const localPlans = localStorageProvider.getAllPlans();
    const localPlan = localPlans.find(p => p.id === initialPlan.id);
    const firestorePayload = firestoreSpy.mock.calls[0][0] as Plan;

    const expectedTimestamp = ISO_TIMESTAMPS[0];

    expect(storeActive?.updatedAt).toBe(expectedTimestamp);
    expect(localPlan?.updatedAt).toBe(expectedTimestamp);
    expect(firestorePayload.updatedAt).toBe(expectedTimestamp);
  });

  it('C: createPlan produces one single authoritative timestamp across all locations', async () => {
    const firestoreSpy = vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockResolvedValue(undefined);

    callIndex = 0;
    const newPlan = usePlanStore.getState().createPlan('Created Plan');
    await planRepository.flushPendingSyncs();

    const storeActive = usePlanStore.getState().activePlan;
    const localPlans = localStorageProvider.getAllPlans();
    const localPlan = localPlans.find(p => p.id === newPlan.id);
    const firestorePayload = firestoreSpy.mock.calls[0][0] as Plan;

    const expectedTimestamp = ISO_TIMESTAMPS[0];

    expect(storeActive?.updatedAt).toBe(expectedTimestamp);
    expect(localPlan?.updatedAt).toBe(expectedTimestamp);
    expect(firestorePayload.updatedAt).toBe(expectedTimestamp);
  });

  it('D: duplicatePlan produces one single authoritative timestamp across all locations', async () => {
    const firestoreSpy = vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockResolvedValue(undefined);

    const source = createDefaultPlan();
    source.id = 'source-plan';

    callIndex = 0;
    const cloned = usePlanStore.getState().duplicatePlan(source, 'Cloned Title');
    await planRepository.flushPendingSyncs();

    const storeActive = usePlanStore.getState().activePlan;
    const localPlans = localStorageProvider.getAllPlans();
    const localPlan = localPlans.find(p => p.id === cloned.id);
    const firestorePayload = firestoreSpy.mock.calls[0][0] as Plan;

    const expectedTimestamp = ISO_TIMESTAMPS[0];

    expect(storeActive?.updatedAt).toBe(expectedTimestamp);
    expect(localPlan?.updatedAt).toBe(expectedTimestamp);
    expect(firestorePayload.updatedAt).toBe(expectedTimestamp);
  });

  it('E: importPlan produces one single authoritative timestamp across all locations', async () => {
    const firestoreSpy = vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockResolvedValue(undefined);

    const validJson = JSON.stringify(createDefaultPlan());

    callIndex = 0;
    usePlanStore.getState().importPlan(validJson);
    await planRepository.flushPendingSyncs();

    const storeActive = usePlanStore.getState().activePlan;
    const localPlans = localStorageProvider.getAllPlans();
    const localPlan = localPlans.find(p => p.id === storeActive?.id);
    const firestorePayload = firestoreSpy.mock.calls[0][0] as Plan;

    const expectedTimestamp = ISO_TIMESTAMPS[0];

    expect(storeActive?.updatedAt).toBe(expectedTimestamp);
    expect(localPlan?.updatedAt).toBe(expectedTimestamp);
    expect(firestorePayload.updatedAt).toBe(expectedTimestamp);
  });

  it('F: direct planRepository.savePlan preserves provided updatedAt without generating a second Date', async () => {
    const firestoreSpy = vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockResolvedValue(undefined);

    const plan = createDefaultPlan();
    plan.id = 'direct-save-plan';
    plan.updatedAt = '2026-08-10T08:00:00.000Z'; // Explicit caller timestamp

    callIndex = 0; // If savePlan called new Date(), callIndex would advance
    const saved = await planRepository.savePlan(plan);
    await planRepository.flushPendingSyncs();

    const localPlan = localStorageProvider.getAllPlans().find(p => p.id === plan.id);
    const firestorePayload = firestoreSpy.mock.calls[0][0] as Plan;

    expect(saved.updatedAt).toBe('2026-08-10T08:00:00.000Z');
    expect(localPlan?.updatedAt).toBe('2026-08-10T08:00:00.000Z');
    expect(firestorePayload.updatedAt).toBe('2026-08-10T08:00:00.000Z');
  });
});

describe('Issue 2 & 4: Empty Snapshots & Auth PII Reduction Verification', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('Issue 2: empty snapshots ([]) are delivered to subscription callback', () => {
    let deliveredPlans: Plan[] | null = null;
    const callback = (plans: Plan[]) => {
      deliveredPlans = plans;
    };

    // Simulate snapshot handler invoking callback with empty array
    const dummySnapshot: Plan[] = [];
    callback(dummySnapshot);

    expect(deliveredPlans).toEqual([]);
  });

  it('Issue 4: handleFirestoreError suppresses email and Auth PII in production logs', () => {
    const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

    // Force non-development environment
    const originalEnv = process.env.NODE_ENV;
    process.env.NODE_ENV = 'production';

    try {
      const err = firestoreProvider.handleFirestoreError(
        new Error('Test permission denied'),
        firestoreProvider.OperationType.GET,
        'users/user1/plans'
      );

      expect(err.authInfo.isAuthenticated).toBeDefined();
      expect(err.authInfo.isAnonymous).toBeDefined();
      expect(err.authInfo.email).toBeUndefined();
      expect(err.authInfo.providerInfo).toBeUndefined();

      expect(consoleSpy).toHaveBeenCalled();
      const loggedStr = consoleSpy.mock.calls[0][1] as string;
      expect(loggedStr).not.toContain('email@');
    } finally {
      process.env.NODE_ENV = originalEnv;
    }
  });
});

describe('Debounced Cloud Persistence & Optimization Suite', () => {
  beforeEach(() => {
    localStorage.clear();
    cloudSyncManager.reset('local-only');
    cloudSyncManager.initialize((status) => {
      usePlanStore.setState({ syncStatus: status, isCloudSynced: status === 'synced' });
    });
    vi.restoreAllMocks();
    vi.spyOn(firebaseLib, 'getUid').mockResolvedValue('test-user-123');
  });

  it('1. 20 rapid changes to one plan write local immediately and debounce cloud to 1 write', async () => {
    const firestoreSpy = vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockResolvedValue(undefined);

    const basePlan = createDefaultPlan();
    basePlan.id = 'rapid-plan-1';
    basePlan.name = 'Initial Rapid Plan';

    usePlanStore.setState({
      plans: [basePlan],
      activePlanId: basePlan.id,
      activePlan: basePlan,
    });

    // Perform 20 rapid keystroke changes
    for (let i = 1; i <= 20; i++) {
      usePlanStore.getState().updatePlan({
        ...usePlanStore.getState().activePlan!,
        name: `Rapid Edit Name ${i}`,
      });

      // Verify local state updates IMMEDIATELY on every single edit
      const currentActive = usePlanStore.getState().activePlan;
      expect(currentActive?.name).toBe(`Rapid Edit Name ${i}`);

      const localStored = localStorageProvider.getAllPlans().find(p => p.id === basePlan.id);
      expect(localStored?.name).toBe(`Rapid Edit Name ${i}`);
    }

    // Verify cloud write was debounced (not called 20 times)
    expect(firestoreSpy).not.toHaveBeenCalled();

    // Flush debounced pending writes
    await planRepository.flushPendingSyncs();

    // Verify exactly 1 cloud write occurred with the 20th (latest) plan state
    expect(firestoreSpy).toHaveBeenCalledTimes(1);
    const finalCloudPayload = firestoreSpy.mock.calls[0][0] as Plan;
    expect(finalCloudPayload.name).toBe('Rapid Edit Name 20');

    // Final cloud state equals latest local state
    const finalLocal = localStorageProvider.getAllPlans().find(p => p.id === basePlan.id);
    expect(finalCloudPayload.name).toBe(finalLocal?.name);
    expect(finalCloudPayload.updatedAt).toBe(finalLocal?.updatedAt);
  });

  it('2. Edits to two separate plans are both batched and synced with latest states', async () => {
    const firestoreSpy = vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockResolvedValue(undefined);

    const planA = { ...createDefaultPlan(), id: 'plan-a', name: 'Plan A Original' };
    const planB = { ...createDefaultPlan(), id: 'plan-b', name: 'Plan B Original' };

    usePlanStore.setState({
      plans: [planA, planB],
      activePlanId: planA.id,
      activePlan: planA,
    });

    // Edit Plan A 5 times
    for (let i = 1; i <= 5; i++) {
      usePlanStore.getState().updatePlan({
        ...usePlanStore.getState().activePlan!,
        name: `Plan A Edit ${i}`,
      });
    }

    // Switch to Plan B and edit 5 times
    usePlanStore.getState().selectPlan(planB.id);
    for (let i = 1; i <= 5; i++) {
      usePlanStore.getState().updatePlan({
        ...usePlanStore.getState().activePlan!,
        name: `Plan B Edit ${i}`,
      });
    }

    // Flush pending syncs
    await planRepository.flushPendingSyncs();

    // Find cloud payloads for Plan A and Plan B
    const calls = firestoreSpy.mock.calls.map(call => call[0] as Plan);
    const cloudA = calls.reverse().find(p => p.id === 'plan-a');
    const cloudB = calls.find(p => p.id === 'plan-b');

    expect(cloudA?.name).toBe('Plan A Edit 5');
    expect(cloudB?.name).toBe('Plan B Edit 5');

    // Local states match cloud states
    const localA = localStorageProvider.getAllPlans().find(p => p.id === 'plan-a');
    const localB = localStorageProvider.getAllPlans().find(p => p.id === 'plan-b');

    expect(cloudA?.name).toBe(localA?.name);
    expect(cloudB?.name).toBe(localB?.name);
  });

  it('3. Firebase failure updates syncStatus to error cleanly without losing local state', async () => {
    const firestoreSpy = vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockRejectedValue(new Error('Firebase Network Offline'));

    const plan = { ...createDefaultPlan(), id: 'plan-fail-test', name: 'Original Fail Test' };
    usePlanStore.setState({
      plans: [plan],
      activePlanId: plan.id,
      activePlan: plan,
    });

    usePlanStore.getState().updatePlan({ ...plan, name: 'Offline Edited Name' });

    // Local state is intact
    expect(usePlanStore.getState().activePlan?.name).toBe('Offline Edited Name');
    expect(localStorageProvider.getAllPlans().find(p => p.id === plan.id)?.name).toBe('Offline Edited Name');

    // Flush attempt fails
    await planRepository.flushPendingSyncs();

    expect(firestoreSpy).toHaveBeenCalled();
    expect(usePlanStore.getState().syncStatus).toBe('error');

    // Local state remains updated and available
    expect(usePlanStore.getState().activePlan?.name).toBe('Offline Edited Name');
  });

  it('4. Network recovery retries pending writes and transitions status to synced', async () => {
    const firestoreSpy = vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockRejectedValueOnce(new Error('Offline'));

    const plan = { ...createDefaultPlan(), id: 'plan-recovery', name: 'Pre Recovery' };
    usePlanStore.setState({
      plans: [plan],
      activePlanId: plan.id,
      activePlan: plan,
    });

    usePlanStore.getState().updatePlan({ ...plan, name: 'Recovery Edited Name' });
    await planRepository.flushPendingSyncs();

    expect(usePlanStore.getState().syncStatus).toBe('error');

    // Network recovers
    firestoreSpy.mockResolvedValueOnce(undefined);
    await planRepository.flushPendingSyncs();

    expect(usePlanStore.getState().syncStatus).toBe('synced');
    const finalLocal = localStorageProvider.getAllPlans().find(p => p.id === plan.id);
    const finalCloud = firestoreSpy.mock.calls[1][0] as Plan;

    expect(finalCloud.name).toBe('Recovery Edited Name');
    expect(finalCloud.name).toBe(finalLocal?.name);
  });

  it('5. Flushing sync during lifecycle boundaries preserves pending writes', async () => {
    const firestoreSpy = vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockResolvedValue(undefined);

    const plan = { ...createDefaultPlan(), id: 'plan-boundary', name: 'Pre Boundary' };
    usePlanStore.setState({
      plans: [plan],
      activePlanId: plan.id,
      activePlan: plan,
    });

    usePlanStore.getState().updatePlan({ ...plan, name: 'Pending Unload Edit' });

    // Flush explicitly before boundary
    await usePlanStore.getState().flushCloudSync();

    expect(firestoreSpy).toHaveBeenCalledTimes(1);
    expect((firestoreSpy.mock.calls[0][0] as Plan).name).toBe('Pending Unload Edit');
  });

  it('6. Switching active plans flushes pending edits on the previous plan automatically', async () => {
    const firestoreSpy = vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockResolvedValue(undefined);

    const planA = { ...createDefaultPlan(), id: 'plan-switch-a', name: 'Plan Switch A' };
    const planB = { ...createDefaultPlan(), id: 'plan-switch-b', name: 'Plan Switch B' };

    usePlanStore.setState({
      plans: [planA, planB],
      activePlanId: planA.id,
      activePlan: planA,
    });

    usePlanStore.getState().updatePlan({ ...planA, name: 'Plan A Edited Before Switch' });

    // Switch plan triggers flush automatically
    usePlanStore.getState().selectPlan(planB.id);

    expect(usePlanStore.getState().activePlanId).toBe('plan-switch-b');

    // Wait for async flush to complete
    await planRepository.flushPendingSyncs();

    expect(firestoreSpy).toHaveBeenCalled();
    const calls = firestoreSpy.mock.calls.map(c => c[0] as Plan);
    const flushedA = calls.find(p => p.id === 'plan-switch-a');

    expect(flushedA?.name).toBe('Plan A Edited Before Switch');
  });

  it('7. Non-blocking plan switching contract: activePlanId updates immediately while Plan A & B complete independently', async () => {
    let resolvePlanA: () => void = () => {};
    const firestoreSpy = vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockImplementation((plan) => {
      if (plan.id === 'plan-contract-a') {
        return new Promise<void>((resolve) => {
          resolvePlanA = resolve;
        });
      }
      return Promise.resolve();
    });

    const planA = { ...createDefaultPlan(), id: 'plan-contract-a', name: 'Plan A Initial' };
    const planB = { ...createDefaultPlan(), id: 'plan-contract-b', name: 'Plan B Initial' };

    usePlanStore.setState({
      plans: [planA, planB],
      activePlanId: planA.id,
      activePlan: planA,
    });

    // 1. Edit Plan A -> enqueues write for Plan A
    usePlanStore.getState().updatePlan({ ...planA, name: 'Plan A Keystroke V2' });
    expect(cloudSyncManager.hasPendingWrites()).toBe(true);

    // 2. Immediately switch to Plan B without waiting
    usePlanStore.getState().selectPlan(planB.id);

    // 3. Verify activePlanId changed to Plan B immediately without waiting for Firestore
    expect(usePlanStore.getState().activePlanId).toBe('plan-contract-b');
    expect(usePlanStore.getState().activePlan?.id).toBe('plan-contract-b');

    // 4. Edit Plan B immediately
    usePlanStore.getState().updatePlan({ ...planB, name: 'Plan B Keystroke V2' });

    // 5. Complete Plan A sync promise
    resolvePlanA();
    await planRepository.flushPendingSyncs();

    // 6. Verify Firestore received both Plan A and Plan B final states cleanly without overwriting
    expect(firestoreSpy).toHaveBeenCalled();
    const calls = firestoreSpy.mock.calls.map(c => c[0] as Plan);
    const finalA = calls.find(p => p.id === 'plan-contract-a');
    const finalB = calls.find(p => p.id === 'plan-contract-b');

    expect(finalA?.name).toBe('Plan A Keystroke V2');
    expect(finalB?.name).toBe('Plan B Keystroke V2');
  });

  it('8. Idempotent initialization prevents duplicate listeners or duplicate flush executions', async () => {
    const flushSpy = vi.spyOn(cloudSyncManager, 'flush').mockResolvedValue(undefined);

    // Call initialize 3 times in a row
    const disposer1 = cloudSyncManager.initialize();
    const disposer2 = cloudSyncManager.initialize();
    const disposer3 = cloudSyncManager.initialize();

    expect(cloudSyncManager.isLifecycleInitialized()).toBe(true);

    // Dispatch 1 online event on window
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new Event('online'));
    }

    // Verify flush was triggered exactly 1 time (not 3 times)
    expect(flushSpy).toHaveBeenCalledTimes(1);

    disposer1();
    disposer2();
    disposer3();
  });

  it('9. Dispose cleans up window event listeners while preserving pending queue state', async () => {
    const flushSpy = vi.spyOn(cloudSyncManager, 'flush').mockResolvedValue(undefined);

    // Initialize, then dispose
    cloudSyncManager.initialize();
    cloudSyncManager.enqueueSync({ ...createDefaultPlan(), id: 'plan-preserved-pending' });
    expect(cloudSyncManager.hasPendingWrites()).toBe(true);

    cloudSyncManager.dispose();
    expect(cloudSyncManager.isLifecycleInitialized()).toBe(false);

    // Pending writes remain intact
    expect(cloudSyncManager.hasPendingWrites()).toBe(true);

    // Window events no longer trigger flush
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new Event('online'));
    }
    expect(flushSpy).not.toHaveBeenCalled();

    // Re-initialize works seamlessly
    cloudSyncManager.initialize();
    expect(cloudSyncManager.isLifecycleInitialized()).toBe(true);

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new Event('online'));
    }
    expect(flushSpy).toHaveBeenCalledTimes(1);

    cloudSyncManager.dispose();
  });
});
