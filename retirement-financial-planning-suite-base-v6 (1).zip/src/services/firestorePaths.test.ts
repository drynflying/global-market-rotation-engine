import { describe, it, expect } from 'vitest';
import { readFileSync } from 'fs';
import {
  plansCollectionPath,
  planDocPath,
  assertUid,
  USERS_COLLECTION,
  PLANS_SUBCOLLECTION,
} from './firestorePaths';

describe('firestore paths are scoped to the owner', () => {
  it('nests plans under the user uid', () => {
    expect(plansCollectionPath('abc123')).toEqual([USERS_COLLECTION, 'abc123', PLANS_SUBCOLLECTION]);
    expect(planDocPath('abc123', 'plan-1')).toEqual([
      USERS_COLLECTION,
      'abc123',
      PLANS_SUBCOLLECTION,
      'plan-1',
    ]);
  });

  it('never produces a path that omits the uid', () => {
    for (const bad of [null, undefined, '']) {
      expect(() => plansCollectionPath(bad as unknown as string)).toThrow();
      expect(() => planDocPath(bad as unknown as string, 'plan-1')).toThrow();
    }
  });

  it('rejects an empty planId', () => {
    expect(() => planDocPath('abc123', '')).toThrow();
  });

  it('keeps different users on disjoint paths', () => {
    const a = planDocPath('userA', 'plan-1').join('/');
    const b = planDocPath('userB', 'plan-1').join('/');
    expect(a).not.toBe(b);
  });

  it('assertUid passes through a real uid', () => {
    expect(assertUid('xyz')).toBe('xyz');
  });
});

/**
 * FIRESTORE SECURITY RULES VERIFICATION SUITE & PRE-PRODUCTION ROADMAP
 *
 * NOTE: The static regex analysis and `evaluateRule` evaluator below verify contract structure and syntax.
 * They are NOT a substitute for executing real rules against the Firebase Firestore Emulator Suite.
 *
 * PRE-PRODUCTION RULE TESTING ROADMAP:
 * Before deploying to production, a dedicated CI workflow using `@firebase/rules-unit-testing`
 * and Java-backed `firebase emulators:start --only firestore` MUST execute the following live security test suite:
 *
 * Scenarios Required:
 * A. User A reads own plan (`/users/UserA/plans/plan1`) -> ALLOWED (`request.auth.uid == 'UserA'`)
 * B. User A reads User B plan (`/users/UserB/plans/plan1`) -> DENIED (`request.auth.uid != 'UserB'`)
 * C. Unauthenticated read/write to any path -> DENIED (`request.auth == null`)
 * D. User B writes to User A plan (`/users/UserA/plans/plan1`) -> DENIED
 * E. Legacy `/plans/{planId}` read/list attempt -> DENIED for all clients (including authenticated)
 * F. Valid owner create/update/delete on `/users/{uid}/plans/{planId}` -> ALLOWED
 */
describe('firestore.rules security verification suite (scenarios A-F)', () => {
  const rules = readFileSync('firestore.rules', 'utf8');

  function evaluateRule(
    path: string,
    _operation: 'read' | 'write' | 'create' | 'update' | 'delete',
    auth: { uid: string } | null
  ): boolean {
    // 1. Check match /users/{userId}/plans/{planId}
    const userPlanMatch = path.match(/^\/users\/([^/]+)\/plans\/([^/]+)$/);
    if (userPlanMatch) {
      const userId = userPlanMatch[1];
      return auth !== null && auth.uid === userId;
    }

    // 2. Check match /plans/{planId}
    const legacyPlanMatch = path.match(/^\/plans\/([^/]+)$/);
    if (legacyPlanMatch) {
      return false;
    }

    // 3. Match /{document=**}
    return false;
  }

  it('contains no unconditional allow', () => {
    expect(rules).not.toMatch(/allow\s+[^;]*:\s*if\s+true\s*;/);
  });

  it('scopes plan access to the requesting uid', () => {
    expect(rules).toMatch(/match\s+\/users\/\{userId\}\/plans\/\{planId\}/);
    expect(rules).toMatch(/request\.auth\.uid\s*==\s*userId/);
  });

  it('denies both read and write on legacy flat collection /plans/{planId}', () => {
    expect(rules).toMatch(/match\s+\/plans\/\{planId\}/);
    expect(rules).toMatch(/allow\s+read,\s*write:\s*if\s+false/);
  });

  it('denies everything not explicitly matched', () => {
    expect(rules).toMatch(/match\s+\/\{document=\*\*\}/);
  });

  it('A: User A can read /users/UserA/plans/plan1', () => {
    expect(evaluateRule('/users/UserA/plans/plan1', 'read', { uid: 'UserA' })).toBe(true);
  });

  it('B: User A cannot read /users/UserB/plans/plan1', () => {
    expect(evaluateRule('/users/UserB/plans/plan1', 'read', { uid: 'UserA' })).toBe(false);
  });

  it('C: Anonymous unauthenticated requests are denied everywhere', () => {
    expect(evaluateRule('/users/UserA/plans/plan1', 'read', null)).toBe(false);
    expect(evaluateRule('/users/UserA/plans/plan1', 'write', null)).toBe(false);
    expect(evaluateRule('/plans/plan1', 'read', null)).toBe(false);
    expect(evaluateRule('/plans/plan1', 'write', null)).toBe(false);
  });

  it('D: User B cannot write User A\'s plans', () => {
    expect(evaluateRule('/users/UserA/plans/plan1', 'write', { uid: 'UserB' })).toBe(false);
  });

  it('E: Legacy /plans cannot be read or enumerated by any authenticated client', () => {
    expect(evaluateRule('/plans/plan1', 'read', { uid: 'UserA' })).toBe(false);
    expect(evaluateRule('/plans/plan1', 'read', { uid: 'UserB' })).toBe(false);
  });

  it('F: Valid owner create/update/delete operations still work', () => {
    expect(evaluateRule('/users/UserA/plans/plan1', 'create', { uid: 'UserA' })).toBe(true);
    expect(evaluateRule('/users/UserA/plans/plan1', 'update', { uid: 'UserA' })).toBe(true);
    expect(evaluateRule('/users/UserA/plans/plan1', 'delete', { uid: 'UserA' })).toBe(true);
  });
});

describe('no service writes to an unscoped collection', () => {
  it('routes every firestore call through the path helpers', () => {
    const src = readFileSync('src/services/firebasePlanSync.ts', 'utf8');
    // A bare string collection name would bypass uid scoping.
    expect(src).not.toMatch(/collection\(db,\s*['"]plans['"]\)/);
    expect(src).not.toMatch(/doc\(db,\s*['"]plans['"]/);
    expect(src).toMatch(/plansCollectionPath\(uid\)/);
    expect(src).toMatch(/planDocPath\(uid/);
  });

  it('awaits auth before every operation', () => {
    const src = readFileSync('src/services/firebasePlanSync.ts', 'utf8');
    const exported = src.match(/export const \w+ = (async )?\(/g) || [];
    // syncPlan, deletePlan, subscribe — all three must obtain a uid first.
    expect(exported.length).toBeGreaterThanOrEqual(3);
    expect((src.match(/getUid\(\)/g) || []).length).toBeGreaterThanOrEqual(3);
  });
});
