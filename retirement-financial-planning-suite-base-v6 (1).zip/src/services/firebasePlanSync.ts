import { collection, doc, setDoc, deleteDoc, onSnapshot } from 'firebase/firestore';
import { db, auth, getUid } from '../lib/firebase';
import { plansCollectionPath, planDocPath } from './firestorePaths';
import { Plan } from '../types';
import { migratePlan } from '../utils/planMigration';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    isAuthenticated: boolean;
    isAnonymous: boolean;
    userId?: string | null;
    email?: string | null;
    providerInfo?: {
      providerId?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const isDev = typeof process !== 'undefined' && process.env?.NODE_ENV !== 'production';
  const currentUser = auth.currentUser;

  const authInfo: FirestoreErrorInfo['authInfo'] = {
    isAuthenticated: Boolean(currentUser),
    isAnonymous: Boolean(currentUser?.isAnonymous),
    userId: currentUser?.uid,
  };

  if (isDev && currentUser) {
    authInfo.email = currentUser.email;
    authInfo.providerInfo = currentUser.providerData?.map(provider => ({
      providerId: provider.providerId,
    }));
  }

  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    operationType,
    path,
    authInfo,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  return errInfo;
}

export const syncPlanToFirestore = async (plan: Plan): Promise<void> => {
  const uid = await getUid();
  if (!uid) return; // Auth unavailable: local storage remains the source of truth.
  try {
    const planRef = doc(db, ...planDocPath(uid, plan.id));
    // Stamp ownership so the document is self-describing even outside its path.
    const cleanPlan = JSON.parse(JSON.stringify({ ...plan, userId: uid }));
    await setDoc(planRef, cleanPlan, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, planDocPath(uid, plan.id).join('/'));
  }
};

export const deletePlanFromFirestore = async (planId: string): Promise<void> => {
  const uid = await getUid();
  if (!uid) return;
  try {
    await deleteDoc(doc(db, ...planDocPath(uid, planId)));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, planDocPath(uid, planId).join('/'));
  }
};

export const subscribeToFirestorePlans = (onUpdate: (plans: Plan[]) => void) => {
  let unsubscribe: (() => void) | null = null;
  let cancelled = false;

  // Auth must resolve before a listener can be attached, so the caller receives a
  // teardown function immediately and the real listener is wired up once the uid
  // exists. Previously this subscribed to the ENTIRE plans collection, delivering
  // every user's plans to every client.
  void getUid().then((uid) => {
    if (!uid || cancelled) return;
    try {
      unsubscribe = onSnapshot(
        collection(db, ...plansCollectionPath(uid)),
        (snapshot) => {
          const plans: Plan[] = [];
          snapshot.forEach((docSnap) => {
            try {
              const plan = migratePlan(docSnap.data());
              plans.push(plan);
            } catch (err) {
              console.warn('Skipping unrecoverable plan in Firestore snapshot:', docSnap.id, err);
            }
          });
          onUpdate(plans);
        },
        (err) => {
          handleFirestoreError(err, OperationType.GET, plansCollectionPath(uid).join('/'));
        },
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, plansCollectionPath(uid).join('/'));
    }
  });

  return () => {
    cancelled = true;
    if (unsubscribe) unsubscribe();
  };
};
