import { Plan } from '../types';
import * as localStorageProvider from '../utils/planStorage';
import * as firestoreProvider from './firebasePlanSync';

export type PlanSyncActionType =
  | 'NO_ACTION'
  | 'SAVE_CLOUD_TO_LOCAL'
  | 'UPLOAD_LOCAL_TO_CLOUD'
  | 'RESOLVE_TIMESTAMP_TIE_LOCAL_WINS';

export interface PlanSyncResolutionItem {
  planId: string;
  action: PlanSyncActionType;
  winningPlan: Plan;
  localPlan?: Plan;
  cloudPlan?: Plan;
  reason: string;
}

export interface PlanSyncResult {
  mergedPlans: Plan[];
  actions: PlanSyncResolutionItem[];
  hasChanges: boolean;
  activePlanIdToKeep: string;
}

/**
  * Safely parses an ISO date string to milliseconds since epoch.
  */
export function parseTimestamp(ts?: string): number {
  if (!ts) return 0;
  const t = new Date(ts).getTime();
  return Number.isNaN(t) ? 0 : t;
}

/**
  * Checks whether two plans are structurally identical, ignoring ephemeral fields like userId.
  */
export function arePlansIdentical(p1: Plan, p2: Plan): boolean {
  const clean1 = { ...p1, userId: undefined };
  const clean2 = { ...p2, userId: undefined };
  return JSON.stringify(clean1) === JSON.stringify(clean2);
}

/**
 * Pure deterministic resolution engine comparing local plans and cloud snapshot plans.
 *
 * DELETION SYNC LIMITATION & TARGET ARCHITECTURE:
 *
 * Current Limitation:
 * `resolvePlanSync` currently evaluates `local exists && !cloud` as Rule 1 (`UPLOAD_LOCAL_TO_CLOUD`).
 * Consequently, if Plan X is deleted on Device B (removing it from Firestore), Device A (which still has Plan X locally)
 * cannot distinguish whether Plan X is a newly created local plan or a plan deleted on Device B.
 * Under automated merge, Device A would upload Plan X back to Firestore, resurrecting the deleted plan.
 *
 * Target Architecture:
 * Multi-device sync requires explicit deletion tombstones (e.g. `deletedAt?: string` or a `/users/{uid}/tombstones/{planId}` record).
 * When a plan is deleted, instead of hard-deleting the record immediately without trace, a tombstone with a `deletedAt` timestamp is created.
 * The sync resolver then compares `local.deletedAt` vs `cloud.updatedAt` to reliably propagate deletions across devices.
 *
 * CRITICAL: `ENABLE_CLOUD_MERGE` MUST remain `false` in production until deletion tombstones are fully implemented.
 *
 * Rules:
 * 1. Local-only plan -> upload local to cloud (Limitation: treats remote deletion as missing local upload)
 * 2. Cloud-only plan -> save cloud plan locally
 * 3. Identical local & cloud -> NO_ACTION
 * 4. Local newer (updatedAt > cloud) -> local wins, upload local to cloud
 * 5. Cloud newer (updatedAt > local) -> cloud wins, save cloud locally
 * 6. Same timestamp with different contents -> conflict detected! Deterministic resolution: local wins, upload local to cloud.
 */
export function resolvePlanSync(
  localPlans: Plan[],
  cloudPlans: Plan[],
  currentActiveId?: string
): PlanSyncResult {
  const allIds = new Set<string>([
    ...localPlans.map(p => p.id),
    ...cloudPlans.map(p => p.id),
  ]);

  const localMap = new Map<string, Plan>(localPlans.map(p => [p.id, p]));
  const cloudMap = new Map<string, Plan>(cloudPlans.map(p => [p.id, p]));

  const actions: PlanSyncResolutionItem[] = [];
  const mergedPlansMap = new Map<string, Plan>();
  let hasChanges = false;

  for (const id of allIds) {
    const local = localMap.get(id);
    const cloud = cloudMap.get(id);

    if (local && !cloud) {
      // Rule 1: Local only -> upload local to cloud
      actions.push({
        planId: id,
        action: 'UPLOAD_LOCAL_TO_CLOUD',
        winningPlan: local,
        localPlan: local,
        reason: 'Local-only plan: needs uploading to cloud',
      });
      mergedPlansMap.set(id, local);
      hasChanges = true;
    } else if (!local && cloud) {
      // Rule 2: Cloud only -> save cloud plan locally
      actions.push({
        planId: id,
        action: 'SAVE_CLOUD_TO_LOCAL',
        winningPlan: cloud,
        cloudPlan: cloud,
        reason: 'Cloud-only plan: needs saving locally',
      });
      mergedPlansMap.set(id, cloud);
      hasChanges = true;
    } else if (local && cloud) {
      if (arePlansIdentical(local, cloud)) {
        // Rule 3: Identical -> no action
        actions.push({
          planId: id,
          action: 'NO_ACTION',
          winningPlan: local,
          localPlan: local,
          cloudPlan: cloud,
          reason: 'Local and cloud plans are identical',
        });
        mergedPlansMap.set(id, local);
      } else {
        const localTime = parseTimestamp(local.updatedAt);
        const cloudTime = parseTimestamp(cloud.updatedAt);

        if (localTime > cloudTime) {
          // Rule 4: Local newer -> local wins, upload local to cloud
          actions.push({
            planId: id,
            action: 'UPLOAD_LOCAL_TO_CLOUD',
            winningPlan: local,
            localPlan: local,
            cloudPlan: cloud,
            reason: 'Local plan is newer than cloud version',
          });
          mergedPlansMap.set(id, local);
          hasChanges = true;
        } else if (cloudTime > localTime) {
          // Rule 5: Cloud newer -> cloud wins, save cloud locally
          actions.push({
            planId: id,
            action: 'SAVE_CLOUD_TO_LOCAL',
            winningPlan: cloud,
            localPlan: local,
            cloudPlan: cloud,
            reason: 'Cloud plan is newer than local version',
          });
          mergedPlansMap.set(id, cloud);
          hasChanges = true;
        } else {
          // Rule 6: Exact timestamp tie with differing content -> explicit conflict resolution (local wins)
          actions.push({
            planId: id,
            action: 'RESOLVE_TIMESTAMP_TIE_LOCAL_WINS',
            winningPlan: local,
            localPlan: local,
            cloudPlan: cloud,
            reason: 'Conflict: exact timestamp tie with differing content. Preserved local version.',
          });
          mergedPlansMap.set(id, local);
          hasChanges = true;
        }
      }
    }
  }

  const mergedPlans = Array.from(mergedPlansMap.values());

  // Determine active plan ID to keep without resetting context unexpectedly
  let activePlanIdToKeep = currentActiveId || '';
  if (!activePlanIdToKeep || !mergedPlansMap.has(activePlanIdToKeep)) {
    activePlanIdToKeep = mergedPlans[0]?.id || '';
  }

  return {
    mergedPlans,
    actions,
    hasChanges,
    activePlanIdToKeep,
  };
}

/**
  * Applies the resolution actions to localStorage and Firestore async side-effects safely.
  * incoming cloud plans DO NOT touch localStorage until this function processes SAVE_CLOUD_TO_LOCAL.
  */
export async function applySyncResolution(result: PlanSyncResult): Promise<void> {
  for (const item of result.actions) {
    if (item.action === 'SAVE_CLOUD_TO_LOCAL') {
      localStorageProvider.savePlan(item.winningPlan);
    } else if (
      item.action === 'UPLOAD_LOCAL_TO_CLOUD' ||
      item.action === 'RESOLVE_TIMESTAMP_TIE_LOCAL_WINS'
    ) {
      try {
        await firestoreProvider.syncPlanToFirestore(item.winningPlan);
      } catch {
        // Offline-first policy: cloud sync failure must not disrupt local experience
      }
    }
  }
}
