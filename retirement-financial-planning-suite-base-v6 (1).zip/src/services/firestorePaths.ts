/**
 * Firestore path construction, kept pure so it can be tested without a live backend.
 *
 * Plans live under /users/{uid}/plans/{planId} rather than a flat /plans collection.
 * The flat layout combined with `allow read, write: if true` meant every user of a
 * deployment could read and write every other user's retirement plan — names,
 * birthdates, balances, Social Security benefits. Nesting under the uid lets the
 * security rules express ownership structurally, so a rule cannot be satisfied by a
 * document that belongs to someone else.
 */

export const USERS_COLLECTION = 'users';
export const PLANS_SUBCOLLECTION = 'plans';

/** Legacy flat collection. Read-only, for one-time migration; never written to. */
export const LEGACY_PLANS_COLLECTION = 'plans';

export function assertUid(uid: string | null | undefined): string {
  if (!uid) {
    throw new Error('Firestore access attempted before authentication completed');
  }
  return uid;
}

export function plansCollectionPath(uid: string): [string, string, string] {
  return [USERS_COLLECTION, assertUid(uid), PLANS_SUBCOLLECTION];
}

export function planDocPath(uid: string, planId: string): [string, string, string, string] {
  if (!planId) throw new Error('planId is required');
  return [USERS_COLLECTION, assertUid(uid), PLANS_SUBCOLLECTION, planId];
}
