import { Plan } from '../types';
import * as localStorageProvider from '../utils/planStorage';
import * as firestoreProvider from './firebasePlanSync';
import { CURRENT_PLAN_SCHEMA_VERSION } from '../schemas/planSchema';
import { cloudSyncManager, SyncStatus } from './cloudSyncManager';

/**
 * Unified Repository Layer encapsulating Local Storage & Firestore Sync
 */
export const planRepository = {
  getPlans: (): Plan[] => {
    return localStorageProvider.getAllPlans();
  },

  getActivePlanId: (): string => {
    return localStorageProvider.getActivePlanId();
  },

  setActivePlanId: (id: string): void => {
    localStorageProvider.setActivePlanId(id);
  },

  savePlan: async (plan: Plan, options?: { immediate?: boolean }): Promise<Plan> => {
    const now = plan.updatedAt || new Date().toISOString();
    const savedPlan: Plan = {
      ...plan,
      schemaVersion: CURRENT_PLAN_SCHEMA_VERSION,
      createdAt: plan.createdAt || now,
      updatedAt: now,
    };
    // 1. Immediate local persistence
    localStorageProvider.savePlan(savedPlan);

    // 2. Queue for debounced cloud sync
    cloudSyncManager.enqueueSync(savedPlan, options?.immediate ? 0 : undefined);

    if (options?.immediate) {
      await cloudSyncManager.flush();
    }

    return savedPlan;
  },

  createPlan: async (name: string, description?: string, userId?: string, userDisplayName?: string): Promise<Plan> => {
    const newPlan = localStorageProvider.createNewPlan(name, description, userId, userDisplayName);
    cloudSyncManager.enqueueSync(newPlan);
    return newPlan;
  },

  duplicatePlan: async (sourcePlan: Plan, newName?: string): Promise<Plan> => {
    const cloned = localStorageProvider.clonePlan(sourcePlan, newName);
    cloudSyncManager.enqueueSync(cloned);
    return cloned;
  },

  deletePlan: async (id: string): Promise<Plan[]> => {
    const remaining = localStorageProvider.deletePlan(id);
    cloudSyncManager.enqueueDelete(id);
    return remaining;
  },

  resetSamplePlan: async (planId?: string): Promise<Plan> => {
    const sample = localStorageProvider.resetToSamplePlan(planId);
    cloudSyncManager.enqueueSync(sample);
    return sample;
  },

  subscribeToCloudPlans: (onUpdate: (plans: Plan[]) => void) => {
    return firestoreProvider.subscribeToFirestorePlans((cloudPlans) => {
      onUpdate(cloudPlans);
    });
  },

  flushPendingSyncs: async (): Promise<void> => {
    await cloudSyncManager.flush();
  },

  getSyncStatus: (): SyncStatus => {
    return cloudSyncManager.getStatus();
  },
};
