import { Plan } from '../types';
import { getUid } from '../lib/firebase';
import * as firestoreProvider from './firebasePlanSync';

export type SyncStatus = 'local-only' | 'pending' | 'syncing' | 'synced' | 'error';

export interface CloudSyncManagerConfig {
  defaultDebounceMs?: number;
}

/**
 * CloudSyncManager orchestrates Firestore persistence for financial scenarios.
 * Cloud changes are globally debounced while pending state is maintained independently for each plan.
 */
export class CloudSyncManager {
  private pendingWrites = new Map<string, Plan>();
  private pendingDeletions = new Set<string>();
  private syncStatus: SyncStatus = 'local-only';
  private debounceTimer: ReturnType<typeof setTimeout> | null = null;
  private debounceMs: number;
  private listeners = new Set<(status: SyncStatus) => void>();
  private activeSyncPromise: Promise<void> | null = null;

  private isInitialized = false;
  private unsubscribeStatus: (() => void) | null = null;
  private onlineHandler: (() => void) | null = null;
  private beforeUnloadHandler: (() => void) | null = null;
  private pageHideHandler: (() => void) | null = null;

  constructor(config: CloudSyncManagerConfig = {}) {
    this.debounceMs = config.defaultDebounceMs ?? 1000;
  }

  /**
   * Initialize browser window lifecycle listeners and status synchronization idempotently.
   * Repeated calls to initialize() will return the existing cleanup disposer without
   * accumulating duplicate window listeners or status subscriptions.
   *
   * @param onStatusChange Optional callback invoked whenever sync status changes.
   * @returns A cleanup disposer to remove all installed listeners and subscriptions.
   */
  public initialize(onStatusChange?: (status: SyncStatus) => void): () => void {
    if (this.isInitialized) {
      return () => this.dispose();
    }

    this.isInitialized = true;

    if (onStatusChange) {
      this.unsubscribeStatus = this.subscribeStatus(onStatusChange);
    }

    if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
      this.onlineHandler = () => {
        void this.flush();
      };
      /**
       * Note: beforeunload and pagehide initiate best-effort cloud flushes.
       * They do not guarantee remote persistence before browser termination.
       */
      this.beforeUnloadHandler = () => {
        void this.flush();
      };
      this.pageHideHandler = () => {
        void this.flush();
      };

      window.addEventListener('online', this.onlineHandler);
      window.addEventListener('beforeunload', this.beforeUnloadHandler);
      window.addEventListener('pagehide', this.pageHideHandler);
    }

    return () => this.dispose();
  }

  /**
   * Remove window lifecycle listeners and status subscriptions.
   * Preserves pending write/deletion queues and local state intact.
   */
  public dispose(): void {
    if (!this.isInitialized) return;

    if (this.unsubscribeStatus) {
      this.unsubscribeStatus();
      this.unsubscribeStatus = null;
    }

    if (typeof window !== 'undefined' && typeof window.removeEventListener === 'function') {
      if (this.onlineHandler) {
        window.removeEventListener('online', this.onlineHandler);
        this.onlineHandler = null;
      }
      if (this.beforeUnloadHandler) {
        window.removeEventListener('beforeunload', this.beforeUnloadHandler);
        this.beforeUnloadHandler = null;
      }
      if (this.pageHideHandler) {
        window.removeEventListener('pagehide', this.pageHideHandler);
        this.pageHideHandler = null;
      }
    }

    this.isInitialized = false;
  }

  public hasPendingWrites(): boolean {
    return this.pendingWrites.size > 0;
  }

  public isLifecycleInitialized(): boolean {
    return this.isInitialized;
  }

  public setDebounceMs(ms: number): void {
    this.debounceMs = ms;
  }

  public getDebounceMs(): number {
    return this.debounceMs;
  }

  public getStatus(): SyncStatus {
    return this.syncStatus;
  }

  public subscribeStatus(listener: (status: SyncStatus) => void): () => void {
    this.listeners.add(listener);
    listener(this.syncStatus);
    return () => {
      this.listeners.delete(listener);
    };
  }

  public setStatus(status: SyncStatus): void {
    if (this.syncStatus !== status) {
      this.syncStatus = status;
      this.listeners.forEach((fn) => fn(status));
    }
  }

  /**
   * Schedule a plan update for debounced cloud persistence.
   * Replaces any earlier pending cloud write for the same plan.
   */
  public enqueueSync(plan: Plan, overrideDebounceMs?: number): void {
    this.pendingDeletions.delete(plan.id);
    this.pendingWrites.set(plan.id, plan);

    this.setStatus('pending');

    const delay = overrideDebounceMs ?? this.debounceMs;

    if (delay <= 0) {
      void this.flush();
      return;
    }

    if (this.debounceTimer !== null) {
      clearTimeout(this.debounceTimer);
    }

    this.debounceTimer = setTimeout(() => {
      this.debounceTimer = null;
      void this.flush();
    }, delay);
  }

  /**
   * Schedule a plan deletion for cloud persistence.
   */
  public enqueueDelete(planId: string, overrideDebounceMs?: number): void {
    this.pendingWrites.delete(planId);
    this.pendingDeletions.add(planId);

    this.setStatus('pending');

    const delay = overrideDebounceMs ?? this.debounceMs;

    if (delay <= 0) {
      void this.flush();
      return;
    }

    if (this.debounceTimer !== null) {
      clearTimeout(this.debounceTimer);
    }

    this.debounceTimer = setTimeout(() => {
      this.debounceTimer = null;
      void this.flush();
    }, delay);
  }

  /**
   * Flush all pending writes and deletions to Firestore immediately.
   */
  public async flush(): Promise<void> {
    if (this.debounceTimer !== null) {
      clearTimeout(this.debounceTimer);
      this.debounceTimer = null;
    }

    // If a sync is already running, wait for it then flush remaining items
    if (this.activeSyncPromise) {
      await this.activeSyncPromise;
      if (this.pendingWrites.size === 0 && this.pendingDeletions.size === 0) {
        return;
      }
    }

    if (this.pendingWrites.size === 0 && this.pendingDeletions.size === 0) {
      const uid = await getUid();
      this.setStatus(uid ? 'synced' : 'local-only');
      return;
    }

    this.setStatus('syncing');

    const doSync = async () => {
      const writesToProcess = new Map(this.pendingWrites);
      const deletionsToProcess = new Set(this.pendingDeletions);

      let hasError = false;

      // Process writes
      for (const [planId, plan] of writesToProcess.entries()) {
        try {
          await firestoreProvider.syncPlanToFirestore(plan);
          // Only remove if it wasn't replaced by a newer edit during in-flight write
          if (this.pendingWrites.get(planId) === plan) {
            this.pendingWrites.delete(planId);
          }
        } catch {
          hasError = true;
        }
      }

      // Process deletions
      for (const planId of deletionsToProcess) {
        try {
          await firestoreProvider.deletePlanFromFirestore(planId);
          this.pendingDeletions.delete(planId);
        } catch {
          hasError = true;
        }
      }

      const uid = await getUid();

      if (hasError) {
        this.setStatus('error');
      } else if (this.pendingWrites.size > 0 || this.pendingDeletions.size > 0) {
        this.setStatus('pending');
      } else {
        this.setStatus(uid ? 'synced' : 'local-only');
      }
    };

    this.activeSyncPromise = doSync().finally(() => {
      this.activeSyncPromise = null;
    });

    await this.activeSyncPromise;
  }

  /**
   * Cancel and clear pending queues.
   */
  public reset(newStatus: SyncStatus = 'local-only'): void {
    if (this.debounceTimer !== null) {
      clearTimeout(this.debounceTimer);
      this.debounceTimer = null;
    }
    this.pendingWrites.clear();
    this.pendingDeletions.clear();
    this.setStatus(newStatus);
  }

  public getPendingWrites(): Map<string, Plan> {
    return new Map(this.pendingWrites);
  }

  public getPendingDeletions(): Set<string> {
    return new Set(this.pendingDeletions);
  }
}

export const cloudSyncManager = new CloudSyncManager();
