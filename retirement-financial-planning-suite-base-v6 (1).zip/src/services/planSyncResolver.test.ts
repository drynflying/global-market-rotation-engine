import { describe, it, expect, beforeEach, vi } from 'vitest';

// Setup node localStorage mock
if (typeof globalThis.localStorage === 'undefined') {
  const store = new Map<string, string>();
  globalThis.localStorage = {
    getItem: (key: string) => store.get(key) ?? null,
    setItem: (key: string, value: string) => store.set(key, String(value)),
    removeItem: (key: string) => store.delete(key),
    clear: () => store.clear(),
    get length() {
      return store.size;
    },
    key: (index: number) => Array.from(store.keys())[index] ?? null,
  } as Storage;
}

if (typeof globalThis.window === 'undefined') {
  (globalThis as unknown as { window: { alert: (msg?: string) => void } }).window = { alert: () => {} };
} else {
  window.alert = () => {};
}

import {
  resolvePlanSync,
  applySyncResolution,
} from './planSyncResolver';
import * as localStorageProvider from '../utils/planStorage';
import * as firestoreProvider from './firebasePlanSync';
import { createDefaultPlan } from '../constants/defaultPlan';

describe('Cloud Sync & Conflict Resolution Suite', () => {
  beforeEach(() => {
    localStorage.clear();
    localStorage.setItem('retirement_planner_plans_v1', JSON.stringify([]));
    vi.restoreAllMocks();
  });

  it('A: Local-only plan -> triggers upload to cloud, leaves local plan unchanged', async () => {
    const firestoreSpy = vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockResolvedValue(undefined);

    const localPlan = createDefaultPlan();
    localPlan.id = 'plan-local-only';
    localPlan.updatedAt = '2026-03-01T10:00:00.000Z';

    const result = resolvePlanSync([localPlan], []);

    expect(result.mergedPlans).toHaveLength(1);
    expect(result.mergedPlans[0].id).toBe('plan-local-only');

    const uploadAction = result.actions.find(a => a.planId === 'plan-local-only');
    expect(uploadAction?.action).toBe('UPLOAD_LOCAL_TO_CLOUD');
    expect(uploadAction?.winningPlan).toEqual(localPlan);

    await applySyncResolution(result);
    expect(firestoreSpy).toHaveBeenCalledWith(localPlan);
  });

  it('B: Cloud-only plan -> saves plan to localStorage and adds to merged state', async () => {
    const saveSpy = vi.spyOn(localStorageProvider, 'savePlan');

    const localPlan = createDefaultPlan();
    localPlan.id = 'plan-existing-local';

    const cloudPlan = createDefaultPlan();
    cloudPlan.id = 'plan-cloud-only';
    cloudPlan.name = 'Cloud Scenario';
    cloudPlan.updatedAt = '2026-03-01T12:00:00.000Z';

    const result = resolvePlanSync([localPlan], [localPlan, cloudPlan]);

    expect(result.mergedPlans).toHaveLength(2);

    const saveAction = result.actions.find(a => a.planId === 'plan-cloud-only');
    expect(saveAction?.action).toBe('SAVE_CLOUD_TO_LOCAL');

    // Verify localStorage side effects applied when requested
    await applySyncResolution(result);
    expect(saveSpy).toHaveBeenCalledWith(cloudPlan);
  });

  it('C: Identical local and cloud plan -> NO_ACTION taken', async () => {
    const firestoreSpy = vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockResolvedValue(undefined);
    const saveSpy = vi.spyOn(localStorageProvider, 'savePlan');

    const plan = createDefaultPlan();
    plan.id = 'plan-identical';
    plan.updatedAt = '2026-03-01T15:00:00.000Z';

    const localPlan = { ...plan };
    const cloudPlan = { ...plan };

    const result = resolvePlanSync([localPlan], [cloudPlan]);

    const action = result.actions.find(a => a.planId === 'plan-identical');
    expect(action?.action).toBe('NO_ACTION');

    await applySyncResolution(result);
    expect(firestoreSpy).not.toHaveBeenCalled();
    expect(saveSpy).not.toHaveBeenCalled();
  });

  it('D: Local newer than cloud -> local wins and uploads local to cloud', async () => {
    const firestoreSpy = vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockResolvedValue(undefined);

    const localPlan = createDefaultPlan();
    localPlan.id = 'plan-local-newer';
    localPlan.name = 'Local Edit Version';
    localPlan.updatedAt = '2026-03-02T10:00:00.000Z';

    const cloudPlan = createDefaultPlan();
    cloudPlan.id = 'plan-local-newer';
    cloudPlan.name = 'Old Cloud Version';
    cloudPlan.updatedAt = '2026-03-01T10:00:00.000Z';

    const result = resolvePlanSync([localPlan], [cloudPlan]);

    const action = result.actions.find(a => a.planId === 'plan-local-newer');
    expect(action?.action).toBe('UPLOAD_LOCAL_TO_CLOUD');
    expect(action?.winningPlan.name).toBe('Local Edit Version');

    await applySyncResolution(result);
    expect(firestoreSpy).toHaveBeenCalledWith(localPlan);
  });

  it('E: Cloud newer than local -> cloud wins and saves locally', async () => {
    const saveSpy = vi.spyOn(localStorageProvider, 'savePlan');

    const localPlan = createDefaultPlan();
    localPlan.id = 'plan-cloud-newer';
    localPlan.name = 'Old Local Version';
    localPlan.updatedAt = '2026-03-01T10:00:00.000Z';

    const cloudPlan = createDefaultPlan();
    cloudPlan.id = 'plan-cloud-newer';
    cloudPlan.name = 'New Cloud Version';
    cloudPlan.updatedAt = '2026-03-02T10:00:00.000Z';

    const result = resolvePlanSync([localPlan], [cloudPlan]);

    const action = result.actions.find(a => a.planId === 'plan-cloud-newer');
    expect(action?.action).toBe('SAVE_CLOUD_TO_LOCAL');
    expect(action?.winningPlan.name).toBe('New Cloud Version');

    await applySyncResolution(result);
    expect(saveSpy).toHaveBeenCalledWith(cloudPlan);
  });

  it('F: Same timestamp but different content -> explicit conflict tie-break preserving local', async () => {
    const firestoreSpy = vi.spyOn(firestoreProvider, 'syncPlanToFirestore').mockResolvedValue(undefined);

    const timestamp = '2026-03-05T12:00:00.000Z';

    const localPlan = createDefaultPlan();
    localPlan.id = 'plan-conflict-tie';
    localPlan.name = 'Local Version A';
    localPlan.updatedAt = timestamp;

    const cloudPlan = createDefaultPlan();
    cloudPlan.id = 'plan-conflict-tie';
    cloudPlan.name = 'Cloud Version B';
    cloudPlan.updatedAt = timestamp;

    const result = resolvePlanSync([localPlan], [cloudPlan]);

    const action = result.actions.find(a => a.planId === 'plan-conflict-tie');
    expect(action?.action).toBe('RESOLVE_TIMESTAMP_TIE_LOCAL_WINS');
    expect(action?.winningPlan.name).toBe('Local Version A');

    await applySyncResolution(result);
    expect(firestoreSpy).toHaveBeenCalledWith(localPlan);
  });

  it('G: Deleted/missing plan behavior -> local plans persist offline even if cloud snapshot is empty', () => {
    const local1 = createDefaultPlan();
    local1.id = 'p1';

    const local2 = createDefaultPlan();
    local2.id = 'p2';

    const result = resolvePlanSync([local1, local2], []);

    expect(result.mergedPlans).toHaveLength(2);
    expect(result.mergedPlans.map(p => p.id)).toEqual(['p1', 'p2']);
  });

  it('H: Multiple plans arriving in one cloud snapshot are correctly partitioned and resolved', async () => {
    const localOnly = createDefaultPlan();
    localOnly.id = 'p-local';
    localOnly.updatedAt = '2026-03-01T10:00:00.000Z';

    const cloudOnly = createDefaultPlan();
    cloudOnly.id = 'p-cloud';
    cloudOnly.updatedAt = '2026-03-01T10:00:00.000Z';

    const localNewer = createDefaultPlan();
    localNewer.id = 'p-shared';
    localNewer.name = 'New Local';
    localNewer.updatedAt = '2026-03-02T10:00:00.000Z';

    const cloudStale = createDefaultPlan();
    cloudStale.id = 'p-shared';
    cloudStale.name = 'Old Cloud';
    cloudStale.updatedAt = '2026-03-01T10:00:00.000Z';

    const result = resolvePlanSync(
      [localOnly, localNewer],
      [cloudOnly, cloudStale]
    );

    expect(result.mergedPlans).toHaveLength(3);
    const ids = result.mergedPlans.map(p => p.id).sort();
    expect(ids).toEqual(['p-cloud', 'p-local', 'p-shared']);

    const shared = result.mergedPlans.find(p => p.id === 'p-shared');
    expect(shared?.name).toBe('New Local');
  });

  it('I: Cloud unavailable -> local plans remain completely untouched and active', () => {
    const local = createDefaultPlan();
    local.id = 'offline-plan';

    const result = resolvePlanSync([local], []);
    expect(result.mergedPlans[0]).toEqual(local);
  });

  it('J: Active plan selection is preserved and never reset unexpectedly during snapshot sync', () => {
    const plan1 = createDefaultPlan();
    plan1.id = 'plan-1';

    const plan2 = createDefaultPlan();
    plan2.id = 'plan-2';

    const cloudSnapshot = [plan1, plan2];

    const result = resolvePlanSync([plan1, plan2], cloudSnapshot, 'plan-2');

    expect(result.activePlanIdToKeep).toBe('plan-2');
  });

  it('Verification: incoming cloud data never mutates localStorage prior to resolution', () => {
    const cloudPlan = createDefaultPlan();
    cloudPlan.id = 'p-unresolved';

    // Pure resolution call
    resolvePlanSync([], [cloudPlan]);

    // localStorage remains empty prior to applying side effects
    const storedRaw = localStorage.getItem('retirement_planner_plans_v1');
    const storedPlans = storedRaw ? JSON.parse(storedRaw) : [];
    expect(storedPlans).toHaveLength(0);
  });

  it('Limitation & Target Design: local-only vs remote-deleted cannot be distinguished without tombstones', () => {
    const deletedOnRemotePlan = createDefaultPlan();
    deletedOnRemotePlan.id = 'plan-deleted-on-device-b';

    // Device A still has local plan, but cloud snapshot is empty (e.g. Device B deleted it from cloud)
    const result = resolvePlanSync([deletedOnRemotePlan], []);

    // Documenting current behavior: without tombstone metadata (e.g. deletedAt), Rule 1 treats this as UPLOAD_LOCAL_TO_CLOUD
    expect(result.actions[0].action).toBe('UPLOAD_LOCAL_TO_CLOUD');
    // This demonstrates why ENABLE_CLOUD_MERGE must remain disabled until tombstone/deletedAt semantics are added.
  });
});
