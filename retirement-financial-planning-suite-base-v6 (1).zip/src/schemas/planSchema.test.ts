import { describe, it, expect } from 'vitest';
import { PlanSchema } from './planSchema';
import { DEFAULT_PLAN, createDefaultPlan } from '../constants/defaultPlan';
import { Plan } from '../types';

describe('Plan persistence round-trip', () => {
  it('preserves per-category essential overrides through a parse', () => {
    const plan: Plan = {
      ...createDefaultPlan(),
      spendingAssumptions: {
        ...createDefaultPlan().spendingAssumptions!,
        categoryOverrides: { food_home: 85, entertainment: 10 },
      },
    };
    const parsed = PlanSchema.safeParse(JSON.parse(JSON.stringify(plan)));
    expect(parsed.success).toBe(true);
    if (parsed.success) {
      expect(parsed.data.spendingAssumptions?.categoryOverrides).toEqual({
        food_home: 85,
        entertainment: 10,
      });
    }
  });

  it('preserves per-category age windows through a parse', () => {
    const plan: Plan = {
      ...createDefaultPlan(),
      spendingAssumptions: {
        ...createDefaultPlan().spendingAssumptions!,
        categoryAges: { travel: { startAge: 62, endAge: 78 } },
      },
    };
    const parsed = PlanSchema.safeParse(JSON.parse(JSON.stringify(plan)));
    expect(parsed.success).toBe(true);
    if (parsed.success) {
      expect(parsed.data.spendingAssumptions?.categoryAges?.travel).toEqual({
        startAge: 62,
        endAge: 78,
      });
    }
  });

  it('preserves the pre-65 healthcare bridge surcharge through a parse', () => {
    const plan: Plan = {
      ...createDefaultPlan(),
      spendingAssumptions: {
        ...createDefaultPlan().spendingAssumptions!,
        pre65AcaBridgeSurcharge: 21500,
      },
    };
    const parsed = PlanSchema.safeParse(JSON.parse(JSON.stringify(plan)));
    expect(parsed.success).toBe(true);
    if (parsed.success) {
      expect(parsed.data.spendingAssumptions?.pre65AcaBridgeSurcharge).toBe(21500);
    }
  });
});

describe('Default plan template immutability', () => {
  it('returns a distinct object on each call', () => {
    expect(createDefaultPlan()).not.toBe(createDefaultPlan());
    expect(createDefaultPlan()).not.toBe(DEFAULT_PLAN);
  });

  it('does not leak nested references into the template', () => {
    const copy = createDefaultPlan();
    copy.primaryPerson.currentAge = 99;
    copy.accounts[0].balance = 1;
    copy.assumptions![0].currentValue = 'mutated';
    expect(DEFAULT_PLAN.primaryPerson.currentAge).not.toBe(99);
    expect(DEFAULT_PLAN.accounts[0].balance).not.toBe(1);
    expect(DEFAULT_PLAN.assumptions![0].currentValue).not.toBe('mutated');
  });

  it('uses stable timestamps rather than import time', () => {
    expect(DEFAULT_PLAN.createdAt).toBe('2026-01-01T00:00:00.000Z');
    expect(DEFAULT_PLAN.updatedAt).toBe('2026-01-01T00:00:00.000Z');
  });
});
