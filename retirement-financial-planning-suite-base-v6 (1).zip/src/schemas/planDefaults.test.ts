import { describe, it, expect } from 'vitest';
import { readFileSync } from 'fs';
import { PlanSchema } from './planSchema';
import { DEFAULT_PLAN, createDefaultPlan } from '../constants/defaultPlan';
import { runSimulation } from '../domain/simulation/simulationEngine';

describe('PlanSchema defaults', () => {
  it('supplies defaults for spendingAssumptions when fields are omitted', () => {
    const minimalPlan = {
      ...DEFAULT_PLAN,
      spendingAssumptions: {
        desiredAnnualHealthcareExpenses: 15000,
        otherGuaranteedAnnualIncome: 0,
        annualRothConversionTarget: 25000,
        rothConversionStartAge: 60,
        rothConversionEndAge: 72,
      },
    };

    const parsed = PlanSchema.parse(minimalPlan);
    expect(parsed.spendingAssumptions!.specialExpenses).toEqual([]);
    expect(parsed.spendingAssumptions!.pre65AcaBridgeSurcharge).toBe(14000);
    expect(parsed.spendingAssumptions!.desiredAnnualLivingExpenses).toBe(60000);
  });
});

describe('pre-65 ACA bridge reaches the engine', () => {
  it('adds the stored surcharge to healthcare before Medicare', () => {
    // The field was stored and displayed but the engine used a hardcoded
    // `desiredAnnualHealthcareExpenses * 1.5`, so editing it changed nothing.
    const withBridge = createDefaultPlan();
    withBridge.acaAssumptions!.useSubsidyModel = false;
    withBridge.spendingAssumptions!.pre65AcaBridgeSurcharge = 14000;
    const without = createDefaultPlan();
    without.acaAssumptions!.useSubsidyModel = false;
    without.spendingAssumptions!.pre65AcaBridgeSurcharge = 0;

    const a = runSimulation(withBridge).rows.find(r => r.age === 61)!;
    const b = runSimulation(without).rows.find(r => r.age === 61)!;
    expect(a.healthExpense).toBeGreaterThan(b.healthExpense);
  });

  it('stops applying the surcharge at 65', () => {
    const plan = createDefaultPlan();
    plan.spendingAssumptions!.pre65AcaBridgeSurcharge = 14000;
    const rows = runSimulation(plan).rows;
    const at64 = rows.find(r => r.age === 64)!;
    const at65 = rows.find(r => r.age === 65)!;
    // Medical inflation would otherwise push 65 above 64; the bridge dropping off is
    // what makes healthcare fall at the Medicare boundary.
    expect(at65.healthExpense).toBeLessThan(at64.healthExpense);
  });

  it('uses no hardcoded multiplier', () => {
    const src = readFileSync('src/domain/simulation/simulationEngine.ts', 'utf8');
    // Medical inflation escalates the figure; a level multiplier was redundant.
    // Strip comments first — the explanation of the old behaviour quotes the code.
    const code = src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
    expect(code).not.toMatch(/desiredAnnualHealthcareExpenses\s*\*\s*1\.5/);
  });

  it('scales the surcharge by medical inflation, not general inflation', () => {
    const plan = createDefaultPlan();
    plan.acaAssumptions!.useSubsidyModel = false;
    plan.spendingAssumptions!.pre65AcaBridgeSurcharge = 10000;
    plan.spendingAssumptions!.desiredAnnualHealthcareExpenses = 10000;
    const r = runSimulation(plan).rows.find(x => x.age === 61)!;
    const years = 61 - plan.primaryPerson.currentAge;
    const expected = 20000 * Math.pow(1 + plan.macroAssumptions!.medicalInflation / 100, years);
    expect(Math.round(r.healthExpense)).toBe(Math.round(expected));
  });
});
