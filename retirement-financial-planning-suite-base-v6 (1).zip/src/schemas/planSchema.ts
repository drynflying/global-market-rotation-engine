import { z } from 'zod';

export const OwnerTypeSchema = z.enum(['primary', 'spouse', 'joint']);

export const IncomeTypeSchema = z.enum([
  'salary',
  'pension',
  'social_security',
  'rental',
  'business',
  'inheritance',
  'annuity',
  'other',
]);

export const IncomeStreamSchema = z.object({
  id: z.string(),
  name: z.string(),
  owner: OwnerTypeSchema,
  type: IncomeTypeSchema,
  amount: z.number().default(0),
  startAge: z.number().default(50),
  endAge: z.number().default(95),
  growthRatePct: z.number().optional().default(2.5),
  taxability: z.enum(['fully_taxable', 'partially_taxable', 'tax_exempt']).optional().default('fully_taxable'),
  notes: z.string().optional(),
});

export const AccountTypeSchema = z.enum(['taxable', 'pre-tax', 'post-tax', 'hsa', 'real-estate', 'cash']);

export const UserProfileSchema = z.object({
  name: z.string().default(''),
  birthDate: z.string().optional(),
  currentAge: z.number().default(50),
  retirementAge: z.number().default(65),
  lifeExpectancy: z.number().default(90),
  ssClaimAge: z.number().default(67),
  ssMonthlyBenefit: z.number().default(0),
  includeSsProjectedReduction: z.boolean().optional(),
  ssProjectedReductionPct: z.number().optional(),
  healthNotes: z.string().optional(),
});

export const PlanAssumptionResourceSchema = z.object({
  id: z.string(),
  category: z.string(),
  parameterName: z.string(),
  currentValue: z.string(),
  defaultValue: z.string().optional(),
  isManualOverride: z.boolean().optional(),
  sourceType: z.enum(['Industry', 'Manual']).optional(),
  refreshedValue: z.string().optional(),
  sourceName: z.string(),
  sourceUrl: z.string(),
  lastUpdated: z.string(),
  notes: z.string().optional(),
});

export const AccountAllocationSchema = z.object({
  usEquityPct: z.number().default(0),
  intlEquityPct: z.number().default(0),
  goldPct: z.number().default(0),
  bondsPct: z.number().default(0),
  cashPct: z.number().default(0),
});

export const AccountItemSchema = z.object({
  id: z.string(),
  name: z.string(),
  owner: OwnerTypeSchema,
  type: AccountTypeSchema,
  balance: z.number().default(0),
  annualContribution: z.number().default(0),
  employerMatchValue: z.number().optional(),
  employerMatchType: z.enum(['$', '%']).optional(),
  isCatchUpEligible: z.boolean().optional(),
  notes: z.string().optional(),
  allocationPresetId: z.string().optional(),
  allocation: AccountAllocationSchema.optional(),
});

export const AssetClassCMASchema = z.object({
  arithmeticReturn: z.number(),
  volatility: z.number(),
  volatilityDrag: z.number(),
  derivedGeometric: z.number(),
});

export const CapitalMarketAssumptionsSchema = z.object({
  usLargeEquity: AssetClassCMASchema,
  intlEquity: AssetClassCMASchema,
  gold: AssetClassCMASchema.optional().default({ arithmeticReturn: 6.50, volatility: 15.50, volatilityDrag: -1.20, derivedGeometric: 5.30 }),
  intermediateBonds: AssetClassCMASchema,
  cashEquivalents: AssetClassCMASchema,
  equityBondCorrelation: z.number(),
  inflationBondCorrelation: z.number(),
  annualPortfolioFeeDrag: z.number(),
  equityDividendYield: z.number(),
});

export const AssetAllocationTargetSchema = z.object({
  id: z.string(),
  name: z.string(),
  equityPctLabel: z.string(),
  description: z.string(),
  usEquityPct: z.number(),
  intlEquityPct: z.number(),
  goldPct: z.number().default(0),
  bondsPct: z.number(),
  cashPct: z.number(),
});

export const MacroeconomicAssumptionsSchema = z.object({
  generalInflation: z.number(),
  inflationVolatility: z.number(),
  medicalInflation: z.number(),
  medicalInflationFadeHorizonYears: z.number(),
  nationalWageGrowth: z.number(),
  piaBendPointIndexingMethod: z.enum(['wageGrowthIndex', 'cpiIndex', 'constant']),
  educationInflation: z.number(),
  realEstateAppreciation: z.number(),
  cashYield: z.number(),
  preRetirementEquityReturn: z.number(),
  postRetirementEquityReturn: z.number(),
  bondYield: z.number(),
});

export const StatutoryParametersSchema = z.object({
  standardDeductionJoint: z.number(),
  standardDeductionSingle: z.number(),
  deferralLimit401k: z.number(),
  catchUpLimit401k: z.number(),
  iraLimit: z.number(),
  iraCatchUpLimit: z.number(),
  hsaFamilyLimit: z.number(),
  hsaSingleLimit: z.number(),
  hsaCatchUpLimit: z.number(),
  rmdStartAge: z.number(),
  fullRetirementAge: z.number(),
  ssColaRate: z.number(),
});

export const AcaAssumptionsSchema = z.object({
  useSubsidyModel: z.boolean().default(true),
  baseMonthlyPremiumAge21: z.number().default(400),
  householdSize: z.number().default(2),
  premiumTrendPct: z.number().default(5.0),
  subsidyRegime: z.enum(['standard', 'enhanced']).default('standard'),
});

export const SpecialExpenseSchema = z.object({
  id: z.string(),
  name: z.string(),
  amount: z.number().default(0),
  startAge: z.number().default(65),
  endAge: z.number().default(65),
  category: z.enum(['travel', 'renovation', 'healthcare_shock', 'gift', 'vehicle', 'other']),
  isEssential: z.boolean().optional().default(false),
  notes: z.string().optional(),
});

export const SpendingAssumptionsSchema = z.object({
  desiredAnnualLivingExpenses: z.number().default(60000),
  desiredAnnualHealthcareExpenses: z.number(),
  otherGuaranteedAnnualIncome: z.number(),
  annualRothConversionTarget: z.number(),
  rothConversionStartAge: z.number(),
  rothConversionEndAge: z.number(),
  spendingModel: z.enum(['constant', 'blanchett_smile', 'declining_real']).optional(),
  essentialLivingPct: z.number().optional(),
  conversionStrategy: z.enum(['manual', 'fill_12', 'fill_22', 'fill_24', 'none']).optional(),
  taxPaymentSource: z.enum(['taxable_brokerage', 'conversion_proceeds']).optional(),
  withdrawalPolicy: z.enum(['taxable_first', 'pretax_first', 'roth_first']).optional(),
  /**
   * Defaults live HERE, not in components.
   *
   * SpendingStep previously rendered `spending.specialExpenses || [two hardcoded items]`,
   * so the tab displayed $15,000/yr of travel and a $35,000 renovation that were never
   * written to the plan and never reached the engine. Same class of bug as
   * essentialLivingPct: computed and shown in a component, invisible to the projection.
   *
   * An empty array is the honest default — the app should not invent expenses the user
   * did not enter.
   */
  specialExpenses: z.array(SpecialExpenseSchema).default([]),
  /**
   * Annual household spending during the WORKING years, in today's dollars.
   * When omitted the engine falls back to treating spending as the residual of income
   * minus tax minus savings, which can never show a surplus or deficit.
   */
  preRetirementAnnualSpending: z.number().optional(),
  /**
   * Flat pre-65 healthcare gap, added on top of the baseline healthcare budget for the
   * years between retirement and Medicare at 65.
   */
  pre65AcaBridgeSurcharge: z.number().default(14000),
  /**
   * Extras on top of a derived marketplace premium — dental, vision, and expected
   * out-of-pocket costs. Unused until the ACA subsidy model is wired in.
   */
  pre65AcaExtras: z.number().default(0),
  categoryOverrides: z.record(z.string(), z.number()).optional(),
  categoryAges: z
    .record(
      z.string(),
      z.object({
        startAge: z.number().optional(),
        endAge: z.number().optional(),
      }),
    )
    .optional(),
});

export const CURRENT_PLAN_SCHEMA_VERSION = 2;

export const PlanSchema = z.object({
  schemaVersion: z.number().int().positive().default(CURRENT_PLAN_SCHEMA_VERSION),
  planKind: z.enum(['sample', 'user']).default('user'),
  id: z.string(),
  name: z.string(),
  description: z.string().default(''),
  createdAt: z.string(),
  updatedAt: z.string(),
  userId: z.string().optional().default('user-default'),
  userDisplayName: z.string().optional().default('Profile'),
  filingStatus: z.enum(['joint', 'single']).default('joint'),
  hasSpouse: z.boolean().default(true),
  /**
   * State of residence for income tax. A household fact, sibling to filingStatus —
   * NOT a statutory parameter (those hold IRS constants like deduction amounts).
   * See domain/tax/stateTaxConstants.ts for the rule set.
   */
  stateOfResidence: z.string().default('CO'),
  /** Effective state rate used when stateOfResidence is 'CUSTOM'. */
  customStateRatePct: z.number().optional(),
  startCalendarYear: z.number().optional().default(2026),
  primaryPerson: UserProfileSchema,
  spousePerson: UserProfileSchema,
  incomeStreams: z.array(IncomeStreamSchema).optional(),
  accounts: z.array(AccountItemSchema).default([]),
  macroAssumptions: MacroeconomicAssumptionsSchema.optional(),
  cmaAssumptions: CapitalMarketAssumptionsSchema.optional(),
  allocationPresets: z.array(AssetAllocationTargetSchema).optional(),
  statutoryParams: StatutoryParametersSchema.optional(),
  acaAssumptions: AcaAssumptionsSchema.optional(),
  assumptions: z.array(PlanAssumptionResourceSchema).optional(),
  spendingAssumptions: SpendingAssumptionsSchema.optional(),
});

export const PlansArraySchema = z.array(PlanSchema);
