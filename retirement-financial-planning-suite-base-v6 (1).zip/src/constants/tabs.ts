/**
 * Tab registry — the single source of truth for navigation identity and order.
 *
 * IDENTITY AND ORDER ARE SEPARATE CONCERNS, deliberately.
 *
 * An `id` is stable identity. It persists in the store, appears in ValidationResult
 * `targetTab` fields, and would appear in URLs if routing is added. It must never change
 * once assigned, because everything pointing at a tab points at its id.
 *
 * `order` is presentation and changes freely. Values step by 10 so a tab can be inserted
 * anywhere without renumbering — see `strategy` at order 45 below.
 *
 * Four ids were previously positional (`step1`, `step2`, `step4`, `step5`), left over
 * from a linear wizard. The numbering had stopped matching display order entirely:
 * `step1` rendered third, `step2` seventh, `step4` fifth. Coupling identity to position
 * guarantees that drift the first time anything is reordered.
 *
 * Labels are free to be reworded, lengthened, or translated without touching identity.
 * The convention is that an id is the kebab-case of the label's primary noun with any
 * "& X" suffix dropped: "Investments & Savings" -> `investments`.
 */
import {
  LayoutDashboard,
  User,
  Layers,
  PieChart,
  SlidersHorizontal,
  DollarSign,
  Table,
  Sliders,
  Activity,
  ShieldCheck,
  FolderKanban,
  LucideIcon,
} from 'lucide-react';

/**
 * Every valid tab. Typed as a union rather than `string` so a typo is a compile error
 * instead of a silently blank screen.
 */
export type TabId =
  | 'dashboard'
  | 'profile'
  | 'investments'
  | 'spending'
  | 'strategy'
  | 'income-tax'
  | 'timeline'
  | 'assumptions'
  | 'simulations'
  | 'validations'
  | 'scenarios';

export interface TabDefinition {
  id: TabId;
  /** Sidebar text. Free to change; identity lives in `id`. */
  label: string;
  /** Collapsed-sidebar and mobile text. */
  shortLabel: string;
  icon: LucideIcon;
  /** Presentation order, stepping by 10 to leave room for insertions. */
  order: number;
}

export const TABS: readonly TabDefinition[] = [
  { id: 'dashboard',   label: 'Dashboard',                  shortLabel: 'Dashboard',   icon: LayoutDashboard, order: 10 },
  { id: 'profile',     label: 'Profile & Social Security',  shortLabel: 'Profile',     icon: User,            order: 20 },
  { id: 'investments', label: 'Investments & Savings',      shortLabel: 'Investments', icon: Layers,          order: 30 },
  { id: 'spending',    label: 'Spending & Healthcare',      shortLabel: 'Spending',    icon: PieChart,        order: 40 },
  // order 45 demonstrates the point of stepping by 10: a tab slots in between two
  // neighbours without renumbering anything or changing a single id.
  { id: 'strategy',    label: 'Strategy & Levers',          shortLabel: 'Strategy',    icon: SlidersHorizontal, order: 45 },
  { id: 'income-tax',  label: 'Cash Flow & Tax Analysis',   shortLabel: 'Cash Flow',   icon: DollarSign,      order: 50 },
  { id: 'timeline',    label: 'Yearly Timeline Table',      shortLabel: 'Timeline',    icon: Table,           order: 60 },
  { id: 'assumptions', label: 'Assumptions & Rates',        shortLabel: 'Assumptions', icon: Sliders,         order: 70 },
  { id: 'simulations', label: 'Simulations & Stress Tests', shortLabel: 'Simulations', icon: Activity,        order: 80 },
  { id: 'validations', label: 'Validations & Audit Log',    shortLabel: 'Validations', icon: ShieldCheck,     order: 90 },
  { id: 'scenarios',   label: 'Scenarios',                  shortLabel: 'Scenarios',   icon: FolderKanban,    order: 100 },
] as const;

export const DEFAULT_TAB: TabId = 'dashboard';

/** Tabs in presentation order. */
export function orderedTabs(): TabDefinition[] {
  return [...TABS].sort((a, b) => a.order - b.order);
}

export function isTabId(value: unknown): value is TabId {
  return typeof value === 'string' && TABS.some((t) => t.id === value);
}

/**
 * Renames applied when the positional ids were retired.
 *
 * `activeTab` persists, so anyone whose stored value predates the rename would land on
 * a blank screen. This maps the old ids forward on load. Safe to delete once no stored
 * state can plausibly still hold them.
 */
const LEGACY_TAB_IDS: Record<string, TabId> = {
  step1: 'investments',
  step2: 'assumptions',
  step4: 'income-tax',
  step5: 'simulations',
};

/** Coerce any stored value to a valid TabId, migrating legacy ids. */
export function resolveTabId(value: unknown): TabId {
  if (isTabId(value)) return value;
  if (typeof value === 'string' && LEGACY_TAB_IDS[value]) return LEGACY_TAB_IDS[value];
  return DEFAULT_TAB;
}
