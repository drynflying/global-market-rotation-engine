/**
 * Tab registry invariants.
 *
 * The point of the registry is that identity (`id`) and presentation (`order`, `label`)
 * are separate. These tests pin that separation, and guard against the positional ids
 * coming back.
 */
import { describe, it, expect } from 'vitest';
import { readFileSync, readdirSync, statSync } from 'fs';
import { join } from 'path';
import { TABS, orderedTabs, isTabId, resolveTabId, DEFAULT_TAB, TabId } from './tabs';

const walk = (dir: string): string[] =>
  readdirSync(dir).flatMap((entry) => {
    const full = join(dir, entry);
    if (statSync(full).isDirectory()) return walk(full);
    return /\.(ts|tsx)$/.test(entry) ? [full] : [];
  });

describe('tab registry', () => {
  it('has unique ids and unique order values', () => {
    const ids = TABS.map((t) => t.id);
    const orders = TABS.map((t) => t.order);
    expect(ids).toEqual([...new Set(ids)]);
    expect(orders).toEqual([...new Set(orders)]);
  });

  it('leaves room to insert without renumbering', () => {
    // Steps of 10 mean a new tab can slot between any two neighbours.
    const sorted = orderedTabs().map((t) => t.order);
    for (let i = 1; i < sorted.length; i++) {
      expect(sorted[i] - sorted[i - 1]).toBeGreaterThanOrEqual(2);
    }
  });

  it('orders by the order field, not array position', () => {
    const shuffled = [...TABS].reverse();
    const byOrder = [...shuffled].sort((a, b) => a.order - b.order);
    expect(orderedTabs().map((t) => t.id)).toEqual(byOrder.map((t) => t.id));
  });

  it('gives every tab a label and a short label', () => {
    for (const t of TABS) {
      expect(t.label.length).toBeGreaterThan(0);
      expect(t.shortLabel.length).toBeGreaterThan(0);
      expect(t.shortLabel.length).toBeLessThanOrEqual(t.label.length);
    }
  });
});

describe('id validation and migration', () => {
  it('recognises real ids and rejects anything else', () => {
    expect(isTabId('income-tax')).toBe(true);
    expect(isTabId('step4')).toBe(false);
    expect(isTabId('nonsense')).toBe(false);
    expect(isTabId(undefined)).toBe(false);
  });

  it('migrates the retired positional ids', () => {
    // activeTab persists, so a stored 'step4' must not land the user on a blank screen.
    expect(resolveTabId('step1')).toBe('investments');
    expect(resolveTabId('step2')).toBe('assumptions');
    expect(resolveTabId('step4')).toBe('income-tax');
    expect(resolveTabId('step5')).toBe('simulations');
  });

  it('falls back to the default for anything unrecognised', () => {
    expect(resolveTabId('deleted-tab')).toBe(DEFAULT_TAB);
    expect(resolveTabId(null)).toBe(DEFAULT_TAB);
    expect(resolveTabId(42)).toBe(DEFAULT_TAB);
  });

  it('passes valid ids through untouched', () => {
    for (const t of TABS) {
      expect(resolveTabId(t.id)).toBe(t.id);
    }
  });
});

describe('no positional ids remain', () => {
  it('uses no stepN identifier anywhere outside the migration map', () => {
    const offenders = walk('src')
      .filter((f) => !f.endsWith('tabs.ts') && !f.includes('.test.'))
      .filter((f) => {
        // Strip comments first — prose explaining the migration legitimately names the
        // retired ids, and matching that would make the guard unmaintainable.
        const code = readFileSync(f, 'utf8')
          .replace(/\/\*[\s\S]*?\*\//g, '')
          .replace(/\/\/.*$/gm, '');
        return /['"]step[0-9]['"]/.test(code);
      });
    expect(offenders).toEqual([]);
  });

  it('declares tabs only in the registry', () => {
    // The sidebar previously held its own literal array; drift between that and the
    // rest of the app is what let ids and order diverge in the first place.
    const src = readFileSync('src/components/SidebarNavigation.tsx', 'utf8');
    expect(src).toMatch(/orderedTabs\(\)/);
    expect(src).not.toMatch(/id:\s*['"]dashboard['"]/);
  });

  it('routes every registry tab in App', () => {
    const src = readFileSync('src/App.tsx', 'utf8');
    const unrouted = TABS.map((t) => t.id).filter(
      (id: TabId) => !src.includes(`activeTab === '${id}'`),
    );
    expect(unrouted).toEqual([]);
  });
});

describe('placeholder tabs are declared and routed', () => {
  it('places Strategy between Spending and Cash Flow without renumbering', () => {
    const ids = orderedTabs().map((t) => t.id);
    expect(ids.indexOf('strategy')).toBe(ids.indexOf('spending') + 1);
    expect(ids.indexOf('income-tax')).toBe(ids.indexOf('strategy') + 1);
    // Neighbours keep their original order values — that is the point of stepping by 10.
    expect(TABS.find((t) => t.id === 'spending')!.order).toBe(40);
    expect(TABS.find((t) => t.id === 'income-tax')!.order).toBe(50);
    expect(TABS.find((t) => t.id === 'strategy')!.order).toBe(45);
  });

  it('renames the Income & Tax label without changing its id', () => {
    // Identity is stable; the label is presentation. The 36 targetTab references in
    // validations.ts still point at 'income-tax'.
    const tab = TABS.find((t) => t.id === 'income-tax')!;
    expect(tab.label).toBe('Cash Flow & Tax Analysis');
  });

  it('retires the wizard-era placeholder component', async () => {
    const { existsSync } = await import('fs');
    // StepPlaceholder rendered a "Step N" badge — the same numbering the positional
    // tab ids were retired for.
    expect(existsSync('src/components/StepPlaceholder.tsx')).toBe(false);
    expect(existsSync('src/components/PlannedModule.tsx')).toBe(true);
  });

  it('uses no Step N wording in the planned-module placeholder', () => {
    const src = readFileSync('src/components/PlannedModule.tsx', 'utf8');
    expect(src).not.toMatch(/Step \{?\d/);
    expect(src).not.toMatch(/stepNumber/);
  });
});
