import { Plan } from '../types';
import { DEFAULT_PLAN, createDefaultPlan } from '../constants/defaultPlan';
import { CURRENT_PLAN_SCHEMA_VERSION } from '../schemas/planSchema';
import { migratePlan } from './planMigration';

const STORAGE_KEY = 'retirement_planner_plans_v1';
const ACTIVE_PLAN_KEY = 'retirement_planner_active_plan_id_v1';

function createQuarantineBackup(rawPayload: string, reason: string): void {
  try {
    // Prevent duplicate backups for identical raw payloads
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('retirement_planner_migration_backup_')) {
        const existingVal = localStorage.getItem(key);
        if (existingVal) {
          try {
            const parsed = JSON.parse(existingVal);
            if (parsed.rawPayload === rawPayload) {
              return; // Already backed up
            }
          } catch {
            // ignore malformed backup key
          }
        }
      }
    }

    const timestamp = Date.now();
    const backupKey = `retirement_planner_migration_backup_${timestamp}`;
    const backupData = {
      timestamp: new Date().toISOString(),
      reason,
      rawPayload,
    };
    localStorage.setItem(backupKey, JSON.stringify(backupData));
  } catch {
    // Ignore storage quota limits gracefully
  }
}

export function getAllPlans(): Plan[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const initial = [createDefaultPlan()];
      localStorage.setItem(STORAGE_KEY, JSON.stringify(initial));
      localStorage.setItem(ACTIVE_PLAN_KEY, DEFAULT_PLAN.id);
      return initial;
    }

    let unparsed: unknown;
    try {
      unparsed = JSON.parse(raw);
    } catch {
      createQuarantineBackup(raw, 'Corrupted JSON string in storage');
      return [createDefaultPlan()];
    }

    const validPlans: Plan[] = [];
    const failedItems: { item: unknown; error: string }[] = [];

    if (Array.isArray(unparsed)) {
      for (const item of unparsed) {
        try {
          const migrated = migratePlan(item);
          validPlans.push(migrated);
        } catch (err) {
          const errorMsg = err instanceof Error ? err.message : String(err);
          failedItems.push({ item, error: errorMsg });
        }
      }
    } else if (typeof unparsed === 'object' && unparsed !== null) {
      try {
        const migrated = migratePlan(unparsed);
        validPlans.push(migrated);
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : String(err);
        failedItems.push({ item: unparsed, error: errorMsg });
      }
    } else {
      createQuarantineBackup(raw, 'Invalid primitive payload in storage');
      return [createDefaultPlan()];
    }

    if (failedItems.length > 0) {
      const reasons = failedItems.map(f => f.error).join('; ');
      createQuarantineBackup(raw, `Migration failed for ${failedItems.length} record(s): ${reasons}`);
    }

    if (validPlans.length === 0) {
      return [createDefaultPlan()];
    }

    // Deduplicate valid plans by ID preserving newer updates
    const uniqueMap = new Map<string, Plan>();
    validPlans.forEach(p => {
      if (!uniqueMap.has(p.id)) {
        uniqueMap.set(p.id, p);
      } else {
        const existing = uniqueMap.get(p.id)!;
        if (new Date(p.updatedAt || 0) > new Date(existing.updatedAt || 0)) {
          uniqueMap.set(p.id, p);
        }
      }
    });

    const uniquePlans = Array.from(uniqueMap.values());

    // Only update primary storage if migration was 100% clean across all records
    if (failedItems.length === 0) {
      if (uniquePlans.length !== validPlans.length || JSON.stringify(uniquePlans) !== JSON.stringify(unparsed)) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(uniquePlans));
      }
    }

    return uniquePlans;
  } catch {
    return [createDefaultPlan()];
  }
}

export function getActivePlanId(): string {
  try {
    const active = localStorage.getItem(ACTIVE_PLAN_KEY);
    const plans = getAllPlans();
    if (active && plans.some(p => p.id === active)) {
      return active;
    }
    return plans[0]?.id || DEFAULT_PLAN.id;
  } catch {
    return DEFAULT_PLAN.id;
  }
}

export function savePlan(updatedPlan: Plan): Plan {
  const plans = getAllPlans();
  const index = plans.findIndex(p => p.id === updatedPlan.id);
  const now = updatedPlan.updatedAt || new Date().toISOString();
  const planToSave: Plan = {
    ...updatedPlan,
    schemaVersion: CURRENT_PLAN_SCHEMA_VERSION,
    createdAt: updatedPlan.createdAt || (index >= 0 ? plans[index].createdAt : now),
    updatedAt: now,
  };

  let newPlans: Plan[];
  if (index >= 0) {
    newPlans = [...plans];
    newPlans[index] = planToSave;
  } else {
    newPlans = [...plans, planToSave];
  }

  localStorage.setItem(STORAGE_KEY, JSON.stringify(newPlans));
  return planToSave;
}

export function setActivePlanId(id: string): void {
  localStorage.setItem(ACTIVE_PLAN_KEY, id);
}

export function createNewPlan(name: string, description?: string, userId: string = 'user-default', userDisplayName: string = 'Profile'): Plan {
  const template: Plan = createDefaultPlan();
  const newPlan: Plan = {
    ...template,
    id: `plan-${Date.now()}`,
    planKind: 'user',
    name: name || 'New Financial Plan',
    description: description || 'Custom retirement and wealth accumulation scenario',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    userId,
    userDisplayName,
  };

  savePlan(newPlan);
  setActivePlanId(newPlan.id);
  return newPlan;
}

export function clonePlan(sourcePlan: Plan, newName?: string): Plan {
  const cloned: Plan = {
    ...JSON.parse(JSON.stringify(sourcePlan)),
    id: `plan-${Date.now()}`,
    planKind: 'user',
    name: newName || `${sourcePlan.name} (Copy)`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  savePlan(cloned);
  setActivePlanId(cloned.id);
  return cloned;
}

export function deletePlan(planId: string): Plan[] {
  const plans = getAllPlans();
  if (plans.length <= 1) {
    // Keep at least one plan, reset to default if deleting last
    const resetPlans = [createDefaultPlan()];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(resetPlans));
    localStorage.setItem(ACTIVE_PLAN_KEY, DEFAULT_PLAN.id);
    return resetPlans;
  }

  const filtered = plans.filter(p => p.id !== planId);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));

  const currentActive = getActivePlanId();
  if (currentActive === planId) {
    localStorage.setItem(ACTIVE_PLAN_KEY, filtered[0].id);
  }

  return filtered;
}

export function resetToSamplePlan(planId?: string): Plan {
  const plans = getAllPlans();
  const sample = createDefaultPlan();
  const targetId = planId || getActivePlanId() || sample.id;
  const existingIdx = plans.findIndex(p => p.id === targetId);

  const resetPlan: Plan = {
    ...sample,
    id: targetId,
    name: existingIdx >= 0 ? plans[existingIdx].name : sample.name,
    description: existingIdx >= 0 ? plans[existingIdx].description : sample.description,
    createdAt: existingIdx >= 0 ? plans[existingIdx].createdAt : sample.createdAt,
    updatedAt: new Date().toISOString(),
  };

  if (existingIdx >= 0) {
    plans[existingIdx] = resetPlan;
  } else {
    plans.unshift(resetPlan);
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(plans));
  setActivePlanId(targetId);
  return resetPlan;
}
