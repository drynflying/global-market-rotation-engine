import { describe, it, expect, beforeEach } from 'vitest';
import { migratePlan, UnsupportedPlanVersionError } from './planMigration';
import { CURRENT_PLAN_SCHEMA_VERSION, PlanSchema } from '../schemas/planSchema';
import { createDefaultPlan, DEFAULT_PLAN } from '../constants/defaultPlan';
import { getAllPlans, savePlan, createNewPlan, clonePlan } from './planStorage';
import { usePlanStore } from '../store/usePlanStore';

if (typeof globalThis.localStorage === 'undefined') {
  const storageMap = new Map<string, string>();
  (globalThis as unknown as { localStorage: Storage }).localStorage = {
    getItem: (key: string) => storageMap.get(key) ?? null,
    setItem: (key: string, value: string) => { storageMap.set(key, String(value)); },
    removeItem: (key: string) => { storageMap.delete(key); },
    clear: () => { storageMap.clear(); },
    get length() { return storageMap.size; },
    key: (index: number) => Array.from(storageMap.keys())[index] ?? null,
  };
}

if (typeof globalThis.window === 'undefined') {
  (globalThis as unknown as { window: { alert: (msg?: string) => void } }).window = { alert: () => {} };
} else {
  window.alert = () => {};
}
globalThis.alert = () => {};

describe('Plan schema versioning and migration pipeline', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  // ==========================================
  // ISSUE 1: planKind assignment rules
  // ==========================================
  describe('Issue 1: planKind assignment', () => {
    it('1.1 DEFAULT_PLAN has planKind: "sample"', () => {
      const sample = createDefaultPlan();
      expect(sample.planKind).toBe('sample');
      expect(DEFAULT_PLAN.planKind).toBe('sample');
    });

    it('1.2 createNewPlan() explicitly sets planKind: "user"', () => {
      const newPlan = createNewPlan('New Plan');
      expect(newPlan.planKind).toBe('user');
    });

    it('1.3 clonePlan() sets planKind: "user" even when source plan is "sample"', () => {
      const sample = createDefaultPlan();
      const clonedFromSample = clonePlan(sample, 'Cloned Sample');
      expect(clonedFromSample.planKind).toBe('user');
    });

    it('1.4 clonePlan() sets planKind: "user" when source plan is "user"', () => {
      const userPlan = createNewPlan('User Plan');
      const clonedFromUser = clonePlan(userPlan, 'Cloned User');
      expect(clonedFromUser.planKind).toBe('user');
    });
  });

  // ==========================================
  // ISSUE 2: Remove destructive magic-ID sample inference
  // ==========================================
  describe('Issue 2: Safe legacy plan handling', () => {
    it('2.1 END-TO-END regression: legacy plan with id="plan-primary-1" and age=52 survives intact', () => {
      const legacyPrimaryPlan = createDefaultPlan() as Record<string, unknown>;
      legacyPrimaryPlan.id = 'plan-primary-1';
      legacyPrimaryPlan.name = 'Edited Primary Scenario';
      delete legacyPrimaryPlan.schemaVersion;
      delete legacyPrimaryPlan.planKind;

      const planObj = legacyPrimaryPlan as unknown as ReturnType<typeof createDefaultPlan>;
      planObj.primaryPerson.currentAge = 52;
      planObj.primaryPerson.name = 'Alice Primary 52';
      planObj.primaryPerson.retirementAge = 60;
      planObj.primaryPerson.ssClaimAge = 70;
      planObj.primaryPerson.ssMonthlyBenefit = 3500;
      planObj.accounts = [
        {
          id: 'acc-custom-1',
          name: 'Primary Taxable Brokerage',
          owner: 'primary',
          type: 'taxable',
          balance: 1250000,
          annualContribution: 30000,
        },
      ];
      planObj.incomeStreams = [
        {
          id: 'inc-1',
          name: 'Executive Consulting',
          owner: 'primary',
          type: 'business',
          amount: 150000,
          startAge: 52,
          endAge: 60,
          growthRatePct: 2.5,
          taxability: 'fully_taxable',
        },
      ];
      planObj.spendingAssumptions = {
        desiredAnnualLivingExpenses: 95000,
        desiredAnnualHealthcareExpenses: 15000,
        otherGuaranteedAnnualIncome: 0,
        annualRothConversionTarget: 40000,
        rothConversionStartAge: 60,
        rothConversionEndAge: 72,
        specialExpenses: [],
        pre65AcaBridgeSurcharge: 20000,
        pre65AcaExtras: 0,
      };

      // Store in localStorage without version/planKind
      localStorage.setItem('retirement_planner_plans_v1', JSON.stringify([planObj]));

      // Run getAllPlans()
      const loadedPlans = getAllPlans();
      expect(loadedPlans.length).toBe(1);

      const retrieved = loadedPlans[0];
      expect(retrieved.id).toBe('plan-primary-1');
      expect(retrieved.name).toBe('Edited Primary Scenario');
      expect(retrieved.planKind).toBe('user'); // Converted to user plan, not sample!
      expect(retrieved.primaryPerson.currentAge).toBe(52);
      expect(retrieved.primaryPerson.name).toBe('Alice Primary 52');
      expect(retrieved.primaryPerson.retirementAge).toBe(60);
      expect(retrieved.primaryPerson.ssClaimAge).toBe(70);
      expect(retrieved.primaryPerson.ssMonthlyBenefit).toBe(3500);
      expect(retrieved.accounts[0].balance).toBe(1250000);
      expect(retrieved.incomeStreams![0].amount).toBe(150000);
      expect(retrieved.spendingAssumptions?.desiredAnnualLivingExpenses).toBe(95000);

      // Save and reload again, confirm values remain unchanged
      savePlan(retrieved);
      const reloadedPlans = getAllPlans();
      expect(reloadedPlans[0].accounts[0].balance).toBe(1250000);
    });

    it('2.2 Age 52 has zero special logic in migration or storage', () => {
      const plan52 = createDefaultPlan() as Record<string, unknown>;
      plan52.id = 'plan-custom-52-test';
      (plan52 as unknown as ReturnType<typeof createDefaultPlan>).primaryPerson.currentAge = 52;
      delete plan52.schemaVersion;
      delete plan52.planKind;

      const migrated = migratePlan(plan52);
      expect(migrated.primaryPerson.currentAge).toBe(52);
      expect(migrated.planKind).toBe('user');
    });
  });

  // ==========================================
  // ISSUE 1 (TIGHTENED): Require valid positive integer schema versions
  // ==========================================
  describe('Integer schema version validation rules', () => {
    it('schemaVersion missing -> legacy migration', () => {
      const raw = createDefaultPlan() as Record<string, unknown>;
      delete raw.schemaVersion;
      const migrated = migratePlan(raw);
      expect(migrated.schemaVersion).toBe(CURRENT_PLAN_SCHEMA_VERSION);
    });

    it('schemaVersion 1 -> migration', () => {
      const raw = { ...createDefaultPlan(), schemaVersion: 1 };
      const migrated = migratePlan(raw);
      expect(migrated.schemaVersion).toBe(CURRENT_PLAN_SCHEMA_VERSION);
    });

    it('schemaVersion 2/current -> valid', () => {
      const raw = { ...createDefaultPlan(), schemaVersion: CURRENT_PLAN_SCHEMA_VERSION };
      const migrated = migratePlan(raw);
      expect(migrated.schemaVersion).toBe(CURRENT_PLAN_SCHEMA_VERSION);
    });

    it('schemaVersion current + 1 -> UnsupportedPlanVersionError', () => {
      const raw = { ...createDefaultPlan(), schemaVersion: CURRENT_PLAN_SCHEMA_VERSION + 1 };
      expect(() => migratePlan(raw)).toThrow(UnsupportedPlanVersionError);
    });

    it('schemaVersion 2.5 -> rejected', () => {
      const raw = { ...createDefaultPlan(), schemaVersion: 2.5 };
      expect(() => migratePlan(raw)).toThrow();
    });

    it('schemaVersion 0 -> rejected', () => {
      const raw = { ...createDefaultPlan(), schemaVersion: 0 };
      expect(() => migratePlan(raw)).toThrow();
    });

    it('schemaVersion -1 -> rejected', () => {
      const raw = { ...createDefaultPlan(), schemaVersion: -1 };
      expect(() => migratePlan(raw)).toThrow();
    });

    it('schemaVersion NaN -> rejected', () => {
      const raw = { ...createDefaultPlan(), schemaVersion: NaN };
      expect(() => migratePlan(raw)).toThrow();
    });

    it('3.2 Future-version plan throws without mutating raw object', () => {
      const futurePlan = {
        id: 'future-plan-2',
        schemaVersion: 99,
        name: 'Unchanged Future Plan',
      };

      const clone = structuredClone(futurePlan);
      try {
        migratePlan(futurePlan);
      } catch (err) {
        expect(err).toBeInstanceOf(UnsupportedPlanVersionError);
      }

      expect(futurePlan).toEqual(clone);
    });

    it('3.3 Future version plans in localStorage do NOT overwrite storage or downgrade', () => {
      const futurePlan = {
        ...createDefaultPlan(),
        schemaVersion: CURRENT_PLAN_SCHEMA_VERSION + 5,
        id: 'future-plan-in-storage',
      };

      const rawStorage = JSON.stringify([futurePlan]);
      localStorage.setItem('retirement_planner_plans_v1', rawStorage);

      const plans = getAllPlans();
      // Should fall back to in-memory default plan
      expect(plans.length).toBe(1);
      // Original storage should remain intact and untouched!
      expect(localStorage.getItem('retirement_planner_plans_v1')).toBe(rawStorage);
    });
  });

  // ==========================================
  // ISSUE 2 (REMAINING CLOUD MAGIC-ID): Cloud plan ID preservation
  // ==========================================
  describe('Cloud plan ID preservation', () => {
    it('Cloud plan ID plan-default-2026 is preserved and NOT silently transformed to plan-primary-1', () => {
      const cloudPlan = {
        ...createDefaultPlan(),
        id: 'plan-default-2026',
        name: 'Cloud Plan 2026',
        updatedAt: new Date().toISOString(),
      };

      // Verify ID is untouched
      expect(cloudPlan.id).toBe('plan-default-2026');
    });
  });

  // ==========================================
  // ISSUE 3 (IMPORT REGRESSION TEST): Plan import behavior
  // ==========================================
  describe('Plan import pipeline regression test', () => {
    it('Valid exported/sample plan imports: receives user-owned ID, planKind="user", preserves financial data, current schemaVersion', () => {
      const sourcePlan = createDefaultPlan();
      sourcePlan.id = 'exported-sample-id';
      sourcePlan.planKind = 'sample';
      sourcePlan.name = 'Exported Retirement Scenario';
      sourcePlan.primaryPerson.currentAge = 54;
      sourcePlan.accounts = [
        {
          id: 'acc-1',
          name: 'Roth IRA',
          owner: 'primary',
          type: 'post-tax',
          balance: 850000,
          annualContribution: 7000,
        },
      ];
      sourcePlan.incomeStreams = [
        {
          id: 'inc-1',
          name: 'Pension',
          owner: 'primary',
          type: 'pension',
          amount: 45000,
          startAge: 65,
          endAge: 95,
          growthRatePct: 2.5,
          taxability: 'fully_taxable',
        },
      ];

      const sourceJson = JSON.stringify(sourcePlan);
      const sourceClone = structuredClone(sourcePlan);

      const store = usePlanStore.getState();
      const success = store.importPlan(sourceJson);

      expect(success).toBe(true);
      const imported = usePlanStore.getState().activePlan;
      expect(imported).not.toBeNull();
      expect(imported!.id).toMatch(/^plan-imported-/);
      expect(imported!.id).not.toBe('exported-sample-id');
      expect(imported!.planKind).toBe('user');
      expect(imported!.schemaVersion).toBe(CURRENT_PLAN_SCHEMA_VERSION);
      expect(imported!.primaryPerson.currentAge).toBe(54);
      expect(imported!.accounts[0].balance).toBe(850000);
      expect(imported!.incomeStreams![0].amount).toBe(45000);

      // Verify original source object was not mutated
      expect(sourcePlan).toEqual(sourceClone);
    });

    it('Invalid or future-version imports fail safely without corrupting store or mutating source', () => {
      const futurePlan = {
        ...createDefaultPlan(),
        schemaVersion: CURRENT_PLAN_SCHEMA_VERSION + 1,
        id: 'future-version-import',
      };
      const sourceJson = JSON.stringify(futurePlan);
      const clone = structuredClone(futurePlan);

      const store = usePlanStore.getState();
      const initialActiveId = store.activePlanId;

      const success = store.importPlan(sourceJson);
      expect(success).toBe(false);
      expect(usePlanStore.getState().activePlanId).toBe(initialActiveId);
      expect(futurePlan).toEqual(clone);
    });
  });

  // ==========================================
  // ISSUE 4: Non-destructive recovery and quarantine
  // ==========================================
  describe('Issue 4: Unrecoverable data safety and quarantine', () => {
    it('4.1 Mixed storage (1 valid + 1 bad): valid plan loads, raw storage quarantined in backup', () => {
      const validPlan = {
        ...createDefaultPlan(),
        id: 'valid-user-1',
        name: 'Valid Plan',
      };
      const badPlan = {
        id: 'bad-plan-1',
        primaryPerson: 'corrupted-non-object',
      };

      const raw = JSON.stringify([validPlan, badPlan]);
      localStorage.setItem('retirement_planner_plans_v1', raw);

      const loaded = getAllPlans();
      expect(loaded.length).toBe(1);
      expect(loaded[0].id).toBe('valid-user-1');

      // Check quarantine backup
      let foundBackup = false;
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith('retirement_planner_migration_backup_')) {
          foundBackup = true;
          const val = JSON.parse(localStorage.getItem(key)!);
          expect(val.rawPayload).toBe(raw);
          expect(val.reason).toContain('Migration failed');
        }
      }
      expect(foundBackup).toBe(true);
    });

    it('4.2 All-invalid storage: returns default in-memory without overwriting raw storage', () => {
      const badPlan1 = { id: 'bad-1', primaryPerson: 'invalid' };
      const badPlan2 = { id: 'bad-2', accounts: 'invalid' };

      const raw = JSON.stringify([badPlan1, badPlan2]);
      localStorage.setItem('retirement_planner_plans_v1', raw);

      const loaded = getAllPlans();
      expect(loaded.length).toBe(1); // In-memory fallback
      expect(localStorage.getItem('retirement_planner_plans_v1')).toBe(raw); // Storage untouched!
    });

    it('4.3 Corrupted JSON string: quarantined safely without throwing', () => {
      const badJson = '{"id": "test", badJsonSyntax...';
      localStorage.setItem('retirement_planner_plans_v1', badJson);

      const loaded = getAllPlans();
      expect(loaded.length).toBe(1);
      expect(localStorage.getItem('retirement_planner_plans_v1')).toBe(badJson);

      // Verify backup key created
      let backupFound = false;
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith('retirement_planner_migration_backup_')) {
          backupFound = true;
          const val = JSON.parse(localStorage.getItem(key)!);
          expect(val.rawPayload).toBe(badJson);
        }
      }
      expect(backupFound).toBe(true);
    });

    it('4.4 Repeated calls to getAllPlans() do not create duplicate backups', () => {
      const badJson = '{"corrupted": true, ...';
      localStorage.setItem('retirement_planner_plans_v1', badJson);

      getAllPlans();
      getAllPlans();
      getAllPlans();

      let backupCount = 0;
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith('retirement_planner_migration_backup_')) {
          backupCount++;
        }
      }
      expect(backupCount).toBe(1);
    });

    it('4.5 Clean migration with valid plans persists updated storage normally', () => {
      const cleanPlan = createDefaultPlan();
      cleanPlan.id = 'clean-plan-1';
      cleanPlan.schemaVersion = 1 as unknown as number; // old version

      localStorage.setItem('retirement_planner_plans_v1', JSON.stringify([cleanPlan]));

      const loaded = getAllPlans();
      expect(loaded.length).toBe(1);
      expect(loaded[0].schemaVersion).toBe(CURRENT_PLAN_SCHEMA_VERSION);

      // Verify backup key was NOT created for clean migration
      let backupCount = 0;
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith('retirement_planner_migration_backup_')) {
          backupCount++;
        }
      }
      expect(backupCount).toBe(0);
    });
  });

  // ==========================================
  // ISSUE 5: Populate missing assumptions and presets
  // ==========================================
  describe('Issue 5: Assumptions and allocation presets merge rules', () => {
    it('5.1 Missing assumptions property entirely -> populated with defaults', () => {
      const raw = createDefaultPlan() as Record<string, unknown>;
      delete raw.assumptions;

      const migrated = migratePlan(raw);
      expect(Array.isArray(migrated.assumptions)).toBe(true);
      expect(migrated.assumptions!.length).toBeGreaterThan(0);
      expect(migrated.assumptions![0].id).toBeDefined();
    });

    it('5.2 Missing allocationPresets property entirely -> populated with defaults', () => {
      const raw = createDefaultPlan() as Record<string, unknown>;
      delete raw.allocationPresets;

      const migrated = migratePlan(raw);
      expect(Array.isArray(migrated.allocationPresets)).toBe(true);
      expect(migrated.allocationPresets!.length).toBeGreaterThan(0);
      expect(migrated.allocationPresets![0].id).toBeDefined();
    });

    it('5.3 User-overridden assumptions are preserved while missing defaults are added', () => {
      const raw = createDefaultPlan() as Record<string, unknown>;
      const userAssumption = {
        id: 'tax_federal_brackets_2026',
        category: 'Tax',
        parameterName: 'Federal Brackets',
        currentValue: 'User Overridden Value',
        sourceName: 'User Custom',
        sourceUrl: '',
        lastUpdated: '2026-01-01',
      };
      raw.assumptions = [userAssumption];

      const migrated = migratePlan(raw);
      const fedBracket = migrated.assumptions?.find(a => a.id === 'tax_federal_brackets_2026');
      expect(fedBracket?.currentValue).toBe('User Overridden Value');
      expect(migrated.assumptions!.length).toBeGreaterThan(1); // Other default assumptions populated!
    });

    it('5.4 User-overridden allocation presets are preserved while missing defaults are added', () => {
      const raw = createDefaultPlan() as Record<string, unknown>;
      const userPreset = {
        id: 'preset-aggressive',
        name: 'User Aggressive Custom',
        equityPctLabel: '95% Equity',
        description: 'Custom user aggressive preset',
        usEquityPct: 65,
        intlEquityPct: 30,
        goldPct: 0,
        bondsPct: 5,
        cashPct: 0,
      };
      raw.allocationPresets = [userPreset];

      const migrated = migratePlan(raw);
      const agg = migrated.allocationPresets?.find(p => p.id === 'preset-aggressive');
      expect(agg?.name).toBe('User Aggressive Custom');
      expect(agg?.usEquityPct).toBe(65);
      expect(migrated.allocationPresets!.length).toBeGreaterThan(1);
    });

    it('5.5 Malformed non-array assumptions or presets handle gracefully', () => {
      const raw = createDefaultPlan() as Record<string, unknown>;
      raw.assumptions = 'invalid string' as unknown;
      raw.allocationPresets = { invalid: 'object' } as unknown;

      const migrated = migratePlan(raw);
      expect(Array.isArray(migrated.assumptions)).toBe(true);
      expect(Array.isArray(migrated.allocationPresets)).toBe(true);
      expect(migrated.assumptions!.length).toBeGreaterThan(0);
      expect(migrated.allocationPresets!.length).toBeGreaterThan(0);
    });
  });

  // ==========================================
  // Zod and Idempotency Tests
  // ==========================================
  describe('Schema & Idempotency', () => {
    it('Migrating an already-current plan is idempotent', () => {
      const currentPlan = createDefaultPlan();
      currentPlan.schemaVersion = CURRENT_PLAN_SCHEMA_VERSION;
      currentPlan.primaryPerson.currentAge = 58;

      const migratedOnce = migratePlan(currentPlan);
      const migratedTwice = migratePlan(migratedOnce);

      expect(migratedOnce).toEqual(migratedTwice);
      expect(migratedTwice.schemaVersion).toBe(CURRENT_PLAN_SCHEMA_VERSION);
      expect(migratedTwice.primaryPerson.currentAge).toBe(58);
    });

    it('Migration followed by Zod/schema validation succeeds', () => {
      const rawUnversioned = createDefaultPlan() as Record<string, unknown>;
      delete rawUnversioned.schemaVersion;

      const migrated = migratePlan(rawUnversioned);
      const zodParse = PlanSchema.safeParse(migrated);

      expect(zodParse.success).toBe(true);
    });
  });
});

