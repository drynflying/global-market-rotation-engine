import { PlanSchema, CURRENT_PLAN_SCHEMA_VERSION } from '../schemas/planSchema';
import { Plan } from '../types';
import { DEFAULT_PLAN } from '../constants/defaultPlan';

export class UnsupportedPlanVersionError extends Error {
  readonly version: number;
  readonly currentSupportedVersion: number;

  constructor(version: number, currentSupportedVersion: number) {
    super(`Plan schema version ${version} is newer than current supported version ${currentSupportedVersion}.`);
    this.name = 'UnsupportedPlanVersionError';
    this.version = version;
    this.currentSupportedVersion = currentSupportedVersion;
  }
}

/**
 * Explicit migration pipeline for Plan objects.
 * Converts legacy raw plans (version 1 or unversioned) to the current schema version
 * while preserving all user-entered data.
 */
export function migratePlan(rawInput: unknown): Plan {
  if (typeof rawInput !== 'object' || rawInput === null || Array.isArray(rawInput)) {
    throw new Error('Invalid plan data: input must be a non-null object');
  }

  // Deep copy to prevent mutating the caller's reference
  const raw = structuredClone(rawInput) as Record<string, unknown>;

  // Detect initial schema version:
  // - completely missing (undefined / null) is treated as legacy version 1
  // - positive integer is accepted normally
  // - integer > CURRENT_PLAN_SCHEMA_VERSION throws UnsupportedPlanVersionError
  // - fractional, zero, negative, NaN, or non-integer numeric versions throw an Error (rejected safely)
  const rawVersion = raw.schemaVersion;
  let detectedVersion = 1;

  if (rawVersion !== undefined && rawVersion !== null) {
    if (
      typeof rawVersion !== 'number' ||
      !Number.isFinite(rawVersion) ||
      !Number.isInteger(rawVersion) ||
      rawVersion <= 0
    ) {
      throw new Error(`Invalid schema version: ${rawVersion}. Schema version must be a positive integer.`);
    }
    detectedVersion = rawVersion;
  }

  // Reject future schema versions immediately without mutating or downgrading
  if (detectedVersion > CURRENT_PLAN_SCHEMA_VERSION) {
    throw new UnsupportedPlanVersionError(detectedVersion, CURRENT_PLAN_SCHEMA_VERSION);
  }

  let currentObj = raw;
  let currentVer = detectedVersion;

  // Sequential migration pipeline
  if (currentVer === 1) {
    currentObj = migrateV1ToV2(currentObj);
    currentVer = 2;
  }

  // Normalize plan fields (schemaVersion, planKind, assumptions, allocationPresets)
  currentObj = normalizePlanFields(currentObj);

  // Validate resulting object against Zod schema
  const parseResult = PlanSchema.safeParse(currentObj);
  if (!parseResult.success) {
    throw new Error(`Plan validation failed after migration: ${parseResult.error.message}`);
  }

  return parseResult.data as Plan;
}

/**
 * Migration Version 1 -> Version 2:
 * - Sets `schemaVersion = 2`
 * - Determines `planKind` ('user' by default for legacy user scenarios)
 * - Safely populates any missing system assumptions or allocation presets without overwriting user values
 * - Preserves ALL user data (ages, balances, accounts, income streams, spending assumptions, etc.)
 */
export function migrateV1ToV2(raw: Record<string, unknown>): Record<string, unknown> {
  return normalizePlanFields({ ...raw, schemaVersion: 2 });
}

/**
 * Normalizes plan fields to conform to current schema expectations:
 * - Sets schemaVersion = CURRENT_PLAN_SCHEMA_VERSION
 * - Defaults planKind = 'user' if not specified
 * - Safely merges default assumptions and allocation presets without overwriting user overrides
 */

export function normalizePlanFields(raw: Record<string, unknown>): Record<string, unknown> {
  const updated: Record<string, unknown> = { ...raw };

  updated.schemaVersion = CURRENT_PLAN_SCHEMA_VERSION;

  // Set planKind if not present (default to 'user' for legacy persisted plans to preserve user edits)
  if (!updated.planKind) {
    updated.planKind = 'user';
  }

  // Populate assumptions if missing or incomplete while preserving user overrides
  const existingAssumptions = Array.isArray(updated.assumptions)
    ? (updated.assumptions as Array<Record<string, unknown>>)
    : [];

  const defaultAssumptions = DEFAULT_PLAN.assumptions || [];
  const assumptionsMap = new Map<string, Record<string, unknown>>();

  defaultAssumptions.forEach(item => {
    assumptionsMap.set(item.id, structuredClone(item) as unknown as Record<string, unknown>);
  });

  existingAssumptions.forEach(item => {
    if (item && typeof item === 'object' && typeof item.id === 'string') {
      assumptionsMap.set(item.id, item);
    }
  });

  updated.assumptions = Array.from(assumptionsMap.values());

  // Populate allocation presets if missing or incomplete while preserving user overrides
  const existingPresets = Array.isArray(updated.allocationPresets)
    ? (updated.allocationPresets as Array<Record<string, unknown>>)
    : [];

  const defaultPresets = DEFAULT_PLAN.allocationPresets || [];
  const presetsMap = new Map<string, Record<string, unknown>>();

  defaultPresets.forEach(item => {
    presetsMap.set(item.id, structuredClone(item) as unknown as Record<string, unknown>);
  });

  existingPresets.forEach(item => {
    if (item && typeof item === 'object' && typeof item.id === 'string') {
      presetsMap.set(item.id, item);
    }
  });

  updated.allocationPresets = Array.from(presetsMap.values());

  return updated;
}

