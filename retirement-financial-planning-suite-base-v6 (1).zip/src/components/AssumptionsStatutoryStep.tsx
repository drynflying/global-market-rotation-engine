import React, { useState } from 'react';
import { NumericInput } from './NumericInput';
import { AcaAssumptionsSection } from './AcaAssumptionsSection';
import { 
  Plan, 
  PlanAssumptionResource, 
  MacroeconomicAssumptions, 
  CapitalMarketAssumptions,
  AssetAllocationTarget,
  StatutoryParameters 
} from '../types';
import { DEFAULT_PLAN, createDefaultPlan } from '../constants/defaultPlan';
import { UpdateOptions } from '../store/usePlanStore';
import { ASSUMPTION_BINDINGS } from '../domain/assumptions/assumptionBindings';
import { 
  TAX_BASE_YEAR, 
  BRACKET_CEILINGS_2026, 
  LTCG_CEILINGS_2026, 
  NIIT_RATE, 
  NIIT_THRESHOLD,
  STANDARD_DEDUCTION_2026,
  ADDL_STD_DEDUCTION_65
} from '../domain/tax/taxConstants';
import { BASE_CONTRIBUTION_LIMITS, IRMAA_REGISTRY } from '../domain/registry/statutoryRegistry';
import { 
  Sliders, 
  TrendingUp, 
  ShieldCheck, 
  ExternalLink, 
  RefreshCw, 
  Plus, 
  Trash2, 
  Edit3, 
  AlertTriangle, 
  Info, 
  BookOpen,
  Scale,
  Search,
  Filter,
  PieChart,
  BarChart3,
  RotateCcw,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  ChevronsDown,
  ChevronsUp,
  X
} from 'lucide-react';

interface AssumptionsStatutoryStepProps {
  plan: Plan;
  onUpdatePlan: (updatedPlan: Plan, options?: UpdateOptions) => void;
  onGoToValidations?: () => void;
}

export const AssumptionsStatutoryStep: React.FC<AssumptionsStatutoryStepProps> = ({
  plan,
  onUpdatePlan,
  onGoToValidations,
}) => {
  // Expand / collapse state for all sections on single page
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    cma: true,
    presets: true,
    macro: true,
    statutory: true,
    sources: true,
  });

  const [showSsInfoModal, setShowSsInfoModal] = useState(false);

  const toggleSection = (sectionKey: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [sectionKey]: !prev[sectionKey]
    }));
  };

  const expandAll = () => {
    setExpandedSections({
      cma: true,
      presets: true,
      macro: true,
      statutory: true,
      sources: true,
    });
  };

  const collapseAll = () => {
    setExpandedSections({
      cma: false,
      presets: false,
      macro: false,
      statutory: false,
      sources: false,
    });
  };

  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');

  // Editing or adding source modal state
  const [editingSource, setEditingSource] = useState<PlanAssumptionResource | null>(null);
  const [isNewSource, setIsNewSource] = useState(false);

  // Fallback defaults if missing
  const macro: MacroeconomicAssumptions = plan.macroAssumptions || {
    generalInflation: 2.00,
    inflationVolatility: 1.90,
    medicalInflation: 5.00,
    medicalInflationFadeHorizonYears: 15,
    nationalWageGrowth: 3.00,
    piaBendPointIndexingMethod: 'wageGrowthIndex',
    educationInflation: 4.00,
    realEstateAppreciation: 3.00,
    cashYield: 3.20,
    preRetirementEquityReturn: 7.50,
    postRetirementEquityReturn: 6.00,
    bondYield: 4.25,
  };

  const cma: CapitalMarketAssumptions = plan.cmaAssumptions || {
    usLargeEquity: { arithmeticReturn: 7.1112, volatility: 16.80, volatilityDrag: -1.4112, derivedGeometric: 5.70 },
    intlEquity: { arithmeticReturn: 8.9405, volatility: 19.70, volatilityDrag: -1.9405, derivedGeometric: 7.00 },
    gold: { arithmeticReturn: 6.5000, volatility: 15.50, volatilityDrag: -1.2013, derivedGeometric: 5.30 },
    intermediateBonds: { arithmeticReturn: 4.9048, volatility: 6.40, volatilityDrag: -0.2048, derivedGeometric: 4.70 },
    cashEquivalents: { arithmeticReturn: 3.2113, volatility: 1.50, volatilityDrag: -0.0113, derivedGeometric: 3.20 },
    equityBondCorrelation: 0.10,
    inflationBondCorrelation: -0.20,
    annualPortfolioFeeDrag: 0.10,
    equityDividendYield: 1.50,
  };

  const defaultPresets = DEFAULT_PLAN.allocationPresets || [];
  const storedPresets = plan.allocationPresets || [];
  const presetsMap = new Map<string, AssetAllocationTarget>();
  defaultPresets.forEach(dp => presetsMap.set(dp.id, dp));
  storedPresets.forEach(sp => presetsMap.set(sp.id, sp));
  const presets = Array.from(presetsMap.values());

  const stat: StatutoryParameters = plan.statutoryParams || {
    standardDeductionJoint: 32200,
    standardDeductionSingle: 16100,
    deferralLimit401k: 24500,
    catchUpLimit401k: 8000,
    iraLimit: 7500,
    iraCatchUpLimit: 1100,
    hsaFamilyLimit: 8750,
    hsaSingleLimit: 4400,
    hsaCatchUpLimit: 1000,
    rmdStartAge: 73,
    fullRetirementAge: 67,
    ssColaRate: 2.50,
  };

  const rawPlanAssumptions = plan.assumptions || [];
  const defaultAssumptions = DEFAULT_PLAN.assumptions || [];

  const defaultAssumptionsMap = new Map<string, PlanAssumptionResource>();
  defaultAssumptions.forEach(item => {
    defaultAssumptionsMap.set(item.id, item);
  });

  const assumptionsMap = new Map<string, PlanAssumptionResource>();
  defaultAssumptions.forEach(item => {
    assumptionsMap.set(item.id, {
      ...item,
      defaultValue: item.defaultValue || item.currentValue,
      isManualOverride: false,
      sourceType: 'Industry',
    });
  });
  rawPlanAssumptions.forEach(item => {
    const defItem = defaultAssumptionsMap.get(item.id);
    const defVal = item.defaultValue || defItem?.currentValue || item.currentValue;
    const isOverride = item.isManualOverride !== undefined 
      ? item.isManualOverride 
      : (item.currentValue !== defVal);

    // If the item has a default assumption definition, prefer the fresh defItem sourceUrl
    // unless the user manually edited the sourceUrl to a custom string
    const updatedSourceUrl = defItem?.sourceUrl || item.sourceUrl || '';

    assumptionsMap.set(item.id, {
      ...item,
      sourceUrl: updatedSourceUrl,
      defaultValue: defVal,
      isManualOverride: isOverride,
      sourceType: isOverride ? 'Manual' : 'Industry',
    });
  });

  const assumptionsList: PlanAssumptionResource[] = Array.from(assumptionsMap.values());

  // Helper function to extract and sync assumption changes to statutoryParams/macroAssumptions
  const syncAssumptionItemToPlan = (
    currentPlan: Plan,
    updatedAssumptions: PlanAssumptionResource[]
  ): Plan => {
    const newMacro = { ...(currentPlan.macroAssumptions || macro) };
    const newStat = { ...(currentPlan.statutoryParams || stat) };

    updatedAssumptions.forEach(item => {
      const binding = ASSUMPTION_BINDINGS.find(b => b.id === item.id);
      if (binding) {
        const val = binding.parse(item.currentValue);
        if (val !== null && !isNaN(val)) {
          if (binding.target === 'macro') {
            (newMacro as unknown as Record<string, number>)[binding.field] = val;
          } else if (binding.target === 'statutory') {
            (newStat as unknown as Record<string, number>)[binding.field] = val;
          }
        }
      }
    });

    return {
      ...currentPlan,
      macroAssumptions: newMacro,
      statutoryParams: newStat,
      assumptions: updatedAssumptions,
    };
  };

  // Sync Macro inputs -> Assumptions Table
  const updateMacro = (field: keyof MacroeconomicAssumptions, val: any) => {
    const updatedMacro = { ...macro, [field]: val };
    const updatedAssumptions = assumptionsList.map(item => {
      const binding = ASSUMPTION_BINDINGS.find(
        b => b.id === item.id && b.target === 'macro' && b.field === field,
      );
      if (!binding) return item;
      const newStr = binding.format(parseFloat(String(val)));
      const defVal = item.defaultValue || newStr;
      return {
        ...item,
        currentValue: newStr,
        isManualOverride: newStr !== defVal,
        sourceType: (newStr !== defVal ? 'Manual' : 'Industry') as any,
      };
    });

    onUpdatePlan({
      ...plan,
      macroAssumptions: updatedMacro,
      assumptions: updatedAssumptions,
    });
  };

  const updateCMAAssetClass = (
    assetKey: 'usLargeEquity' | 'intlEquity' | 'gold' | 'intermediateBonds' | 'cashEquivalents',
    field: 'arithmeticReturn' | 'volatility',
    val: number
  ) => {
    const currentAsset = cma[assetKey] || { arithmeticReturn: 6.50, volatility: 15.50, volatilityDrag: -1.20, derivedGeometric: 5.30 };
    const newArithmetic = field === 'arithmeticReturn' ? val : currentAsset.arithmeticReturn;
    const newVol = field === 'volatility' ? val : currentAsset.volatility;
    const drag = -Math.pow(newVol, 2) / 200; // -(vol^2)/2 in %
    const geom = newArithmetic + drag;

    onUpdatePlan({
      ...plan,
      cmaAssumptions: {
        ...cma,
        [assetKey]: {
          arithmeticReturn: newArithmetic,
          volatility: newVol,
          volatilityDrag: parseFloat(drag.toFixed(4)),
          derivedGeometric: parseFloat(geom.toFixed(2)),
        },
      },
    });
  };

  const updateCMADrag = (field: 'equityBondCorrelation' | 'inflationBondCorrelation' | 'annualPortfolioFeeDrag' | 'equityDividendYield', val: number) => {
    onUpdatePlan({
      ...plan,
      cmaAssumptions: {
        ...cma,
        [field]: val,
      },
    });
  };

  const updatePresetAllocation = (id: string, field: 'usEquityPct' | 'intlEquityPct' | 'goldPct' | 'bondsPct' | 'cashPct', val: number) => {
    const updatedPresets = presets.map((p) => {
      if (p.id === id) {
        const updated = { ...p, [field]: val };
        const totalEquity = updated.usEquityPct + updated.intlEquityPct;
        const goldVal = updated.goldPct || 0;
        updated.equityPctLabel = goldVal > 0 ? `${totalEquity}% Equity / ${goldVal}% Gold` : `${totalEquity}% Equity`;
        return updated;
      }
      return p;
    });
    onUpdatePlan({ ...plan, allocationPresets: updatedPresets });
  };

  // Sync Statutory inputs -> Assumptions Table
  const updateStatutory = (field: keyof StatutoryParameters, val: number) => {
    const updatedStat = { ...stat, [field]: val };
    const updatedAssumptions = assumptionsList.map(item => {
      if ((field === 'deferralLimit401k' || field === 'catchUpLimit401k' || field === 'iraLimit' || field === 'iraCatchUpLimit') && item.id === 'asm-401k-limit') {
        const cur401k = field === 'deferralLimit401k' ? val : (stat.deferralLimit401k || BASE_CONTRIBUTION_LIMITS.deferralLimit401k);
        const curCatch401k = field === 'catchUpLimit401k' ? val : (stat.catchUpLimit401k || BASE_CONTRIBUTION_LIMITS.catchUpLimit401k);
        const curIra = field === 'iraLimit' ? val : (stat.iraLimit || BASE_CONTRIBUTION_LIMITS.iraLimit);
        const curCatchIra = field === 'iraCatchUpLimit' ? val : (stat.iraCatchUpLimit || BASE_CONTRIBUTION_LIMITS.iraCatchUpLimit);
        const newStr = `401(k) Deferral: ${cur401k.toLocaleString()} + ${curCatch401k.toLocaleString()} Catch-up; IRA: ${curIra.toLocaleString()} + ${curCatchIra.toLocaleString()} Catch-up`;
        const defVal = item.defaultValue || `401(k) Deferral: ${BASE_CONTRIBUTION_LIMITS.deferralLimit401k.toLocaleString()} + ${BASE_CONTRIBUTION_LIMITS.catchUpLimit401k.toLocaleString()} Catch-up; IRA: ${BASE_CONTRIBUTION_LIMITS.iraLimit.toLocaleString()} + ${BASE_CONTRIBUTION_LIMITS.iraCatchUpLimit.toLocaleString()} Catch-up`;
        return {
          ...item,
          currentValue: newStr,
          isManualOverride: newStr !== defVal,
          sourceType: (newStr !== defVal ? 'Manual' : 'Industry') as any,
        };
      }
      if ((field === 'standardDeductionJoint' || field === 'standardDeductionSingle') && item.id === 'asm-tax-brackets') {
        const curJoint = field === 'standardDeductionJoint' ? val : (stat.standardDeductionJoint || 32200);
        const curSingle = field === 'standardDeductionSingle' ? val : (stat.standardDeductionSingle || 16100);
        const newStr = `${curJoint.toLocaleString()} Joint (MFJ) / ${curSingle.toLocaleString()} Single`;
        const defVal = item.defaultValue || '$32,200 Joint (MFJ) / $16,100 Single';
        return {
          ...item,
          currentValue: newStr,
          isManualOverride: newStr !== defVal,
          sourceType: (newStr !== defVal ? 'Manual' : 'Industry') as any,
        };
      }
      if ((field === 'hsaFamilyLimit' || field === 'hsaSingleLimit') && item.id === 'asm-hsa-limits') {
        const curFam = field === 'hsaFamilyLimit' ? val : (stat.hsaFamilyLimit || BASE_CONTRIBUTION_LIMITS.hsaFamilyLimit);
        const curSing = field === 'hsaSingleLimit' ? val : (stat.hsaSingleLimit || BASE_CONTRIBUTION_LIMITS.hsaSingleLimit);
        const newStr = `HSA Family: ${curFam.toLocaleString()}; HSA Single: ${curSing.toLocaleString()}; Catch-up (55+): $1,000`;
        const defVal = item.defaultValue || `HSA Family: ${BASE_CONTRIBUTION_LIMITS.hsaFamilyLimit.toLocaleString()}; HSA Single: ${BASE_CONTRIBUTION_LIMITS.hsaSingleLimit.toLocaleString()}; Catch-up (55+): $1,000`;
        return {
          ...item,
          currentValue: newStr,
          isManualOverride: newStr !== defVal,
          sourceType: (newStr !== defVal ? 'Manual' : 'Industry') as any,
        };
      }
      if (field === 'fullRetirementAge' && item.id === 'asm-ss-formula-fra') {
        const newStr = `FRA: Age ${val}; Bend Points: $1,174 (90%), $7,078 (32%)`;
        const defVal = item.defaultValue || 'FRA: Age 67; Bend Points: $1,174 (90%), $7,078 (32%)';
        return {
          ...item,
          currentValue: newStr,
          isManualOverride: newStr !== defVal,
          sourceType: (newStr !== defVal ? 'Manual' : 'Industry') as any,
        };
      }
      if (field === 'rmdStartAge' && item.id === 'asm-medicare-irmaa-rmd') {
        const thresholdStr = `$${IRMAA_REGISTRY.thresholds.joint[0].toLocaleString()} MAGI`;
        const newStr = `RMD Age ${val}; Joint IRMAA Tier 1 Threshold: ${thresholdStr}`;
        const defVal = item.defaultValue || `RMD Age 75; Joint IRMAA Tier 1 Threshold: ${thresholdStr}`;
        return {
          ...item,
          currentValue: newStr,
          isManualOverride: newStr !== defVal,
          sourceType: (newStr !== defVal ? 'Manual' : 'Industry') as any,
        };
      }
      return item;
    });

    onUpdatePlan({
      ...plan,
      statutoryParams: updatedStat,
      assumptions: updatedAssumptions,
    });
  };

  // Add/Edit Source
  const handleSaveSource = (source: PlanAssumptionResource) => {
    let updatedList: PlanAssumptionResource[];
    const defItem = defaultAssumptionsMap.get(source.id);
    const defVal = source.defaultValue || defItem?.currentValue || source.currentValue;
    const isOverride = source.currentValue !== defVal;

    const sourceToSave: PlanAssumptionResource = {
      ...source,
      defaultValue: defVal,
      isManualOverride: isOverride,
      sourceType: isOverride ? 'Manual' : 'Industry',
      lastUpdated: new Date().toISOString().split('T')[0],
    };

    if (isNewSource) {
      updatedList = [sourceToSave, ...assumptionsList];
    } else {
      updatedList = assumptionsList.map(s => s.id === source.id ? sourceToSave : s);
    }

    const syncedPlan = syncAssumptionItemToPlan(plan, updatedList);
    onUpdatePlan(syncedPlan);
    setEditingSource(null);
  };

  const handleResetSourceToDefault = (id: string) => {
    const updatedList = assumptionsList.map(item => {
      if (item.id === id) {
        const defItem = defaultAssumptionsMap.get(id);
        const defVal = item.defaultValue || defItem?.currentValue || item.currentValue;
        return {
          ...item,
          currentValue: defVal,
          isManualOverride: false,
          sourceType: 'Industry' as const,
          lastUpdated: new Date().toISOString().split('T')[0],
        };
      }
      return item;
    });

    const syncedPlan = syncAssumptionItemToPlan(plan, updatedList);
    onUpdatePlan(syncedPlan);
  };

  const handleResetAllToDefaults = () => {
    const defaultAssumptions = DEFAULT_PLAN.assumptions || [];
    const resetList = defaultAssumptions.map(item => ({
      ...item,
      defaultValue: item.currentValue,
      isManualOverride: false,
      sourceType: 'Industry' as const,
    }));

    const syncedPlan = syncAssumptionItemToPlan(
      {
        ...plan,
        statutoryParams: createDefaultPlan().statutoryParams!,
        macroAssumptions: createDefaultPlan().macroAssumptions!,
      },
      resetList
    );
    onUpdatePlan(syncedPlan, { label: 'reset all assumptions to defaults' });
  };

  const handleDeleteSource = (id: string) => {
    const updatedList = assumptionsList.filter(s => s.id !== id);
    onUpdatePlan({
      ...plan,
      assumptions: updatedList,
    });
  };

  const handleApplyRefreshedValue = (id: string) => {
    const updatedList = assumptionsList.map(item => {
      if (item.id === id && item.refreshedValue) {
        const defItem = defaultAssumptionsMap.get(id);
        const defVal = item.defaultValue || defItem?.currentValue || item.currentValue;
        const isOverride = item.refreshedValue !== defVal;
        return {
          ...item,
          currentValue: item.refreshedValue,
          isManualOverride: isOverride,
          sourceType: isOverride ? ('Manual' as const) : ('Industry' as const),
          lastUpdated: new Date().toISOString().split('T')[0],
        };
      }
      return item;
    });

    const syncedPlan = syncAssumptionItemToPlan(plan, updatedList);
    onUpdatePlan(syncedPlan);
  };

  // --- Section 1: Capital Market Assumptions Helpers ---
  const isCMAAssetModified = (assetKey: 'usLargeEquity' | 'intlEquity' | 'gold' | 'intermediateBonds' | 'cashEquivalents') => {
    const cur = cma[assetKey];
    const def = DEFAULT_PLAN.cmaAssumptions?.[assetKey];
    if (!cur || !def) return false;
    return Math.abs(cur.arithmeticReturn - def.arithmeticReturn) > 0.0001 ||
           Math.abs(cur.volatility - def.volatility) > 0.0001;
  };

  const resetCMAAsset = (assetKey: 'usLargeEquity' | 'intlEquity' | 'gold' | 'intermediateBonds' | 'cashEquivalents') => {
    const def = DEFAULT_PLAN.cmaAssumptions?.[assetKey];
    if (!def) return;
    onUpdatePlan(
      {
        ...plan,
        cmaAssumptions: {
          ...cma,
          [assetKey]: { ...def },
        },
      },
      { label: `reset ${assetKey} assumptions` }
    );
  };

  const isCMADragModified = (field: 'equityBondCorrelation' | 'inflationBondCorrelation' | 'annualPortfolioFeeDrag' | 'equityDividendYield') => {
    const cur = cma[field];
    const def = DEFAULT_PLAN.cmaAssumptions?.[field];
    return cur !== def;
  };

  const resetCMADrag = (field: 'equityBondCorrelation' | 'inflationBondCorrelation' | 'annualPortfolioFeeDrag' | 'equityDividendYield') => {
    const def = DEFAULT_PLAN.cmaAssumptions?.[field];
    if (def !== undefined) {
      updateCMADrag(field, def);
    }
  };

  const resetAllCMA = () => {
    onUpdatePlan(
      { ...plan, cmaAssumptions: createDefaultPlan().cmaAssumptions! },
      { label: 'reset all capital market assumptions' }
    );
    // Add comment: Single write, so this is already ONE undo entry rather than one per asset class.
  };

  // --- Section 2: Asset Allocation Presets Helpers ---
  const isPresetModified = (presetId: string) => {
    const curPreset = presets.find(p => p.id === presetId);
    const defPreset = DEFAULT_PLAN.allocationPresets?.find(p => p.id === presetId);
    if (!curPreset || !defPreset) return false;
    return curPreset.usEquityPct !== defPreset.usEquityPct ||
           curPreset.intlEquityPct !== defPreset.intlEquityPct ||
           (curPreset.goldPct || 0) !== (defPreset.goldPct || 0) ||
           curPreset.bondsPct !== defPreset.bondsPct ||
           curPreset.cashPct !== defPreset.cashPct;
  };

  const resetSinglePreset = (presetId: string) => {
    const defPreset = DEFAULT_PLAN.allocationPresets?.find(p => p.id === presetId);
    if (!defPreset) return;
    const updatedPresets = presets.map(p => p.id === presetId ? { ...defPreset } : p);
    onUpdatePlan({ ...plan, allocationPresets: updatedPresets });
  };

  // --- Section 3: Macroeconomic Parameters Helpers ---
  const isMacroFieldModified = (field: keyof MacroeconomicAssumptions) => {
    const cur = macro[field];
    const def = DEFAULT_PLAN.macroAssumptions?.[field];
    return cur !== def;
  };

  const resetMacroField = (field: keyof MacroeconomicAssumptions) => {
    const def = DEFAULT_PLAN.macroAssumptions?.[field];
    if (def !== undefined) {
      updateMacro(field, def);
    }
  };

  // --- Section 4: Statutory Parameters Helpers ---
  const isStatutoryFieldModified = (field: keyof StatutoryParameters) => {
    const cur = stat[field];
    const def = DEFAULT_PLAN.statutoryParams?.[field];
    return cur !== def;
  };

  const resetStatutoryField = (field: keyof StatutoryParameters) => {
    const def = DEFAULT_PLAN.statutoryParams?.[field];
    if (def !== undefined) {
      updateStatutory(field, def);
    }
  };

  // Filter sources
  const categories = ['All', ...Array.from(new Set(assumptionsList.map(s => s.category)))];
  const filteredSources = assumptionsList.filter(s => {
    const matchesCat = categoryFilter === 'All' || s.category === categoryFilter;
    const matchesSearch = s.parameterName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          s.sourceName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          s.notes?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-6">
      
      {/* Top Banner & Control Actions */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-3">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-100">
              Step 2 Engine
            </span>
            <h2 className="text-lg font-bold text-slate-900">
              Assumptions & Statutory Parameters
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Institutional Capital Market Assumptions (CMAs), Volatility Drag Derivations, Asset Allocation Presets, and IRS Statutory Rules.
          </p>
        </div>

        {/* Separate Row for Expand All & Collapse All Buttons */}
        <div className="flex items-center space-x-2 pt-3 border-t border-slate-100 flex-wrap gap-y-2">
          <button
            onClick={expandAll}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium transition-colors whitespace-nowrap"
            title="Expand all sections on page"
          >
            <ChevronsDown className="w-3.5 h-3.5" />
            <span>Expand All</span>
          </button>

          <button
            onClick={collapseAll}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium transition-colors whitespace-nowrap"
            title="Collapse all sections on page"
          >
            <ChevronsUp className="w-3.5 h-3.5" />
            <span>Collapse All</span>
          </button>

          {onGoToValidations && (
            <button
              onClick={onGoToValidations}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 rounded-lg text-xs font-medium transition-colors whitespace-nowrap"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Audit Validation Rules</span>
            </button>
          )}
        </div>
      </div>

      {/* SECTION 1: CAPITAL MARKET ASSUMPTIONS & VOLATILITY DRAG */}
      <div id="section-cma" className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden transition-all">
        <button
          onClick={() => toggleSection('cma')}
          className="w-full flex items-center justify-between p-4 bg-slate-50/80 hover:bg-slate-100/80 transition-colors border-b border-slate-200 text-left cursor-pointer"
        >
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-100 text-blue-700 rounded-lg">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold text-slate-900">1. Capital Market Assumptions & Volatility Drag</h3>
                <span className="text-[10px] font-semibold bg-amber-100 text-amber-900 px-2 py-0.5 rounded-full">
                  5 Asset Classes
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Arithmetic returns, annual volatility ($\sigma$), derived geometric mean ($-\sigma^2/2$), and cross-asset correlations.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 text-slate-500 text-xs font-semibold">
            <span>{expandedSections.cma ? 'Hide Section' : 'Expand Section'}</span>
            {expandedSections.cma ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </div>
        </button>

        {expandedSections.cma && (
          <div className="p-5 space-y-6">
            
            {/* Header Banner Explanation */}
            <div className="bg-blue-50/70 border border-blue-200/80 rounded-xl p-4 text-xs text-blue-950 space-y-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center space-x-2 font-bold text-blue-900">
                  <Info className="w-4 h-4 text-blue-600" />
                  <span>Return Conventions & Volatility Drag Derivation</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded text-[11px] font-semibold">
                    Mathematically Rigorous Framework
                  </span>
                  <button
                    onClick={resetAllCMA}
                    className="flex items-center space-x-1 px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 rounded text-xs font-semibold border border-slate-300 transition-colors"
                    title="Reset all Capital Market Assumptions to industry defaults"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                    <span>Reset CMA Defaults</span>
                  </button>
                </div>
              </div>
              <p className="leading-relaxed text-slate-700">
                Deterministic projections use the derived <strong>Geometric Mean</strong> (approx. <code className="bg-blue-100 px-1 py-0.5 rounded text-blue-900 font-mono">arithmetic − variance/2</code>). Monte Carlo simulations draw from the <strong>Arithmetic Mean</strong> with annual volatility. Returns are applied per asset class without uncalibrated blending.
              </p>
            </div>

            {/* 5 Asset Class Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3 text-xs">
              
              {/* US Large Equity */}
              <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-xs space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <div className="flex items-center space-x-1.5">
                    <span className="font-bold text-slate-900">US Large Equity</span>
                    {isCMAAssetModified('usLargeEquity') ? (
                      <span className="inline-flex items-center space-x-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                        <Sliders className="w-2.5 h-2.5 text-amber-600" />
                        <span>Manual</span>
                      </span>
                    ) : (
                      <span className="text-[10px] font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">Equities</span>
                    )}
                  </div>
                  {isCMAAssetModified('usLargeEquity') && (
                    <button
                      onClick={() => resetCMAAsset('usLargeEquity')}
                      className="p-1 text-amber-700 hover:text-amber-900 hover:bg-amber-100/60 rounded transition-colors flex items-center space-x-0.5 text-[10px] font-semibold"
                      title="Reset US Large Equity to industry defaults"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Reset</span>
                    </button>
                  )}
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Arithmetic Return:</span>
                    <div className="flex items-center space-x-1">
                      <input
                        type="number"
                        step="0.01"
                        value={cma.usLargeEquity.arithmeticReturn}
                        onChange={(e) => updateCMAAssetClass('usLargeEquity', 'arithmeticReturn', parseFloat(e.target.value) || 0)}
                        className="w-16 px-1.5 py-0.5 bg-slate-50 border border-slate-300 rounded text-right font-bold text-slate-900"
                      />
                      <span className="text-slate-500 font-medium">%</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Annual Volatility ($\sigma$):</span>
                    <div className="flex items-center space-x-1">
                      <input
                        type="number"
                        step="0.1"
                        value={cma.usLargeEquity.volatility}
                        onChange={(e) => updateCMAAssetClass('usLargeEquity', 'volatility', parseFloat(e.target.value) || 0)}
                        className="w-16 px-1.5 py-0.5 bg-slate-50 border border-slate-300 rounded text-right font-bold text-slate-900"
                      />
                      <span className="text-slate-500 font-medium">%</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-amber-700 bg-amber-50/60 p-1.5 rounded">
                    <span>Volatility Drag ($-\sigma^2/2$):</span>
                    <span className="font-bold">{cma.usLargeEquity.volatilityDrag.toFixed(2)}%</span>
                  </div>

                  <div className="flex items-center justify-between border-t border-slate-200 pt-2 font-bold text-blue-700">
                    <span>Derived Geometric:</span>
                    <span className="text-sm">{cma.usLargeEquity.derivedGeometric.toFixed(2)}%</span>
                  </div>
                </div>
              </div>

              {/* International Equity */}
              <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-xs space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <div className="flex items-center space-x-1.5">
                    <span className="font-bold text-slate-900">International Equity</span>
                    {isCMAAssetModified('intlEquity') ? (
                      <span className="inline-flex items-center space-x-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                        <Sliders className="w-2.5 h-2.5 text-amber-600" />
                        <span>Manual</span>
                      </span>
                    ) : (
                      <span className="text-[11px] font-semibold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">Intl Equity</span>
                    )}
                  </div>
                  {isCMAAssetModified('intlEquity') && (
                    <button
                      onClick={() => resetCMAAsset('intlEquity')}
                      className="p-1 text-amber-700 hover:text-amber-900 hover:bg-amber-100/60 rounded transition-colors flex items-center space-x-0.5 text-[10px] font-semibold"
                      title="Reset International Equity to industry defaults"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Reset</span>
                    </button>
                  )}
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Arithmetic Return:</span>
                    <div className="flex items-center space-x-1">
                      <input
                        type="number"
                        step="0.01"
                        value={cma.intlEquity.arithmeticReturn}
                        onChange={(e) => updateCMAAssetClass('intlEquity', 'arithmeticReturn', parseFloat(e.target.value) || 0)}
                        className="w-16 px-1.5 py-0.5 bg-slate-50 border border-slate-300 rounded text-right font-bold text-slate-900"
                      />
                      <span className="text-slate-500 font-medium">%</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Annual Volatility ($\sigma$):</span>
                    <div className="flex items-center space-x-1">
                      <input
                        type="number"
                        step="0.1"
                        value={cma.intlEquity.volatility}
                        onChange={(e) => updateCMAAssetClass('intlEquity', 'volatility', parseFloat(e.target.value) || 0)}
                        className="w-16 px-1.5 py-0.5 bg-slate-50 border border-slate-300 rounded text-right font-bold text-slate-900"
                      />
                      <span className="text-slate-500 font-medium">%</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-amber-700 bg-amber-50/60 p-1.5 rounded">
                    <span>Volatility Drag ($-\sigma^2/2$):</span>
                    <span className="font-bold">{cma.intlEquity.volatilityDrag.toFixed(2)}%</span>
                  </div>

                  <div className="flex items-center justify-between border-t border-slate-200 pt-2 font-bold text-indigo-700">
                    <span>Derived Geometric:</span>
                    <span className="text-sm">{cma.intlEquity.derivedGeometric.toFixed(2)}%</span>
                  </div>
                </div>
              </div>

              {/* Gold ETF / Commodity */}
              <div className="bg-amber-50/40 border border-amber-200/90 rounded-xl p-3 shadow-xs space-y-3">
                <div className="flex items-center justify-between border-b border-amber-200/60 pb-2">
                  <div className="flex items-center space-x-1.5">
                    <span className="font-bold text-slate-900">Gold ETF</span>
                    {isCMAAssetModified('gold') ? (
                      <span className="inline-flex items-center space-x-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                        <Sliders className="w-2.5 h-2.5 text-amber-700" />
                        <span>Manual</span>
                      </span>
                    ) : (
                      <span className="text-[11px] font-semibold text-amber-800 bg-amber-100 px-2 py-0.5 rounded border border-amber-200">Gold / Commodity</span>
                    )}
                  </div>
                  {isCMAAssetModified('gold') && (
                    <button
                      onClick={() => resetCMAAsset('gold')}
                      className="p-1 text-amber-800 hover:text-amber-950 hover:bg-amber-200/60 rounded transition-colors flex items-center space-x-0.5 text-[10px] font-semibold"
                      title="Reset Gold to World Gold Council / J.P. Morgan LTCMA defaults"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Reset</span>
                    </button>
                  )}
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Arithmetic Return:</span>
                    <div className="flex items-center space-x-1">
                      <input
                        type="number"
                        step="0.01"
                        value={cma.gold ? cma.gold.arithmeticReturn : 6.50}
                        onChange={(e) => updateCMAAssetClass('gold', 'arithmeticReturn', parseFloat(e.target.value) || 0)}
                        className="w-16 px-1.5 py-0.5 bg-white border border-amber-300 rounded text-right font-bold text-slate-900"
                      />
                      <span className="text-slate-500 font-medium">%</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Annual Volatility ($\sigma$):</span>
                    <div className="flex items-center space-x-1">
                      <input
                        type="number"
                        step="0.1"
                        value={cma.gold ? cma.gold.volatility : 15.50}
                        onChange={(e) => updateCMAAssetClass('gold', 'volatility', parseFloat(e.target.value) || 0)}
                        className="w-16 px-1.5 py-0.5 bg-white border border-amber-300 rounded text-right font-bold text-slate-900"
                      />
                      <span className="text-slate-500 font-medium">%</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-amber-800 bg-amber-100/70 p-1.5 rounded">
                    <span>Volatility Drag ($-\sigma^2/2$):</span>
                    <span className="font-bold">{(cma.gold ? cma.gold.volatilityDrag : -1.20).toFixed(2)}%</span>
                  </div>

                  <div className="flex items-center justify-between border-t border-amber-200 pt-2 font-bold text-amber-900">
                    <span>Derived Geometric:</span>
                    <span className="text-sm">{(cma.gold ? cma.gold.derivedGeometric : 5.30).toFixed(2)}%</span>
                  </div>
                </div>
              </div>

              {/* Intermediate Bonds */}
              <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <div className="flex items-center space-x-1.5">
                    <span className="font-bold text-slate-900">Intermediate Bonds</span>
                    {isCMAAssetModified('intermediateBonds') ? (
                      <span className="inline-flex items-center space-x-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                        <Sliders className="w-2.5 h-2.5 text-amber-600" />
                        <span>Manual</span>
                      </span>
                    ) : (
                      <span className="text-[11px] font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">Fixed Income</span>
                    )}
                  </div>
                  {isCMAAssetModified('intermediateBonds') && (
                    <button
                      onClick={() => resetCMAAsset('intermediateBonds')}
                      className="p-1 text-amber-700 hover:text-amber-900 hover:bg-amber-100/60 rounded transition-colors flex items-center space-x-0.5 text-[10px] font-semibold"
                      title="Reset Intermediate Bonds to industry defaults"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Reset</span>
                    </button>
                  )}
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Arithmetic Return:</span>
                    <div className="flex items-center space-x-1">
                      <input
                        type="number"
                        step="0.01"
                        value={cma.intermediateBonds.arithmeticReturn}
                        onChange={(e) => updateCMAAssetClass('intermediateBonds', 'arithmeticReturn', parseFloat(e.target.value) || 0)}
                        className="w-16 px-1.5 py-0.5 bg-slate-50 border border-slate-300 rounded text-right font-bold text-slate-900"
                      />
                      <span className="text-slate-500 font-medium">%</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Annual Volatility ($\sigma$):</span>
                    <div className="flex items-center space-x-1">
                      <input
                        type="number"
                        step="0.1"
                        value={cma.intermediateBonds.volatility}
                        onChange={(e) => updateCMAAssetClass('intermediateBonds', 'volatility', parseFloat(e.target.value) || 0)}
                        className="w-16 px-1.5 py-0.5 bg-slate-50 border border-slate-300 rounded text-right font-bold text-slate-900"
                      />
                      <span className="text-slate-500 font-medium">%</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-amber-700 bg-amber-50/60 p-1.5 rounded">
                    <span>Volatility Drag ($-\sigma^2/2$):</span>
                    <span className="font-bold">{cma.intermediateBonds.volatilityDrag.toFixed(2)}%</span>
                  </div>

                  <div className="flex items-center justify-between border-t border-slate-200 pt-2 font-bold text-emerald-700">
                    <span>Derived Geometric:</span>
                    <span className="text-sm">{cma.intermediateBonds.derivedGeometric.toFixed(2)}%</span>
                  </div>
                </div>
              </div>

              {/* Cash Equivalents */}
              <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <div className="flex items-center space-x-1.5">
                    <span className="font-bold text-slate-900">Cash Equivalents</span>
                    {isCMAAssetModified('cashEquivalents') ? (
                      <span className="inline-flex items-center space-x-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                        <Sliders className="w-2.5 h-2.5 text-amber-600" />
                        <span>Manual</span>
                      </span>
                    ) : (
                      <span className="text-[11px] font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded">Cash</span>
                    )}
                  </div>
                  {isCMAAssetModified('cashEquivalents') && (
                    <button
                      onClick={() => resetCMAAsset('cashEquivalents')}
                      className="p-1 text-amber-700 hover:text-amber-900 hover:bg-amber-100/60 rounded transition-colors flex items-center space-x-0.5 text-[10px] font-semibold"
                      title="Reset Cash Equivalents to industry defaults"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Reset</span>
                    </button>
                  )}
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Arithmetic Return:</span>
                    <div className="flex items-center space-x-1">
                      <input
                        type="number"
                        step="0.01"
                        value={cma.cashEquivalents.arithmeticReturn}
                        onChange={(e) => updateCMAAssetClass('cashEquivalents', 'arithmeticReturn', parseFloat(e.target.value) || 0)}
                        className="w-16 px-1.5 py-0.5 bg-slate-50 border border-slate-300 rounded text-right font-bold text-slate-900"
                      />
                      <span className="text-slate-500 font-medium">%</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Annual Volatility ($\sigma$):</span>
                    <div className="flex items-center space-x-1">
                      <input
                        type="number"
                        step="0.1"
                        value={cma.cashEquivalents.volatility}
                        onChange={(e) => updateCMAAssetClass('cashEquivalents', 'volatility', parseFloat(e.target.value) || 0)}
                        className="w-16 px-1.5 py-0.5 bg-slate-50 border border-slate-300 rounded text-right font-bold text-slate-900"
                      />
                      <span className="text-slate-500 font-medium">%</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-amber-700 bg-amber-50/60 p-1.5 rounded">
                    <span>Volatility Drag ($-\sigma^2/2$):</span>
                    <span className="font-bold">{cma.cashEquivalents.volatilityDrag.toFixed(2)}%</span>
                  </div>

                  <div className="flex items-center justify-between border-t border-slate-200 pt-2 font-bold text-slate-800">
                    <span>Derived Geometric:</span>
                    <span className="text-sm">{cma.cashEquivalents.derivedGeometric.toFixed(2)}%</span>
                  </div>
                </div>
              </div>

            </div>

            {/* Correlations & Fee Drag Section */}
            <div className="bg-slate-50/50 rounded-xl border border-slate-200 p-4 space-y-4 text-xs">
              <h4 className="font-bold text-slate-900 border-b border-slate-200/80 pb-2">
                Cross-Asset Correlations & Friction Drag Factors
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                
                <div className="p-3 bg-white border border-slate-200 rounded-lg space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="font-semibold text-slate-800 block">Equity-to-Bond Correlation</label>
                    {isCMADragModified('equityBondCorrelation') ? (
                      <div className="flex items-center space-x-1">
                        <span className="px-1.5 py-0.5 bg-amber-50 text-amber-800 border border-amber-200 rounded text-[10px] font-bold">Manual</span>
                        <button
                          onClick={() => resetCMADrag('equityBondCorrelation')}
                          className="p-1 text-amber-700 hover:text-amber-900 rounded"
                          title="Reset to default (0.10)"
                        >
                          <RotateCcw className="w-3 h-3" />
                        </button>
                      </div>
                    ) : (
                      <span className="px-1.5 py-0.5 bg-blue-50 text-blue-700 rounded text-[10px] font-semibold">Default</span>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="number"
                      step="0.05"
                      min="-1.0"
                      max="1.0"
                      value={cma.equityBondCorrelation}
                      onChange={(e) => updateCMADrag('equityBondCorrelation', parseFloat(e.target.value) || 0)}
                      className="w-full px-2 py-1 bg-slate-50 border border-slate-300 rounded font-mono font-bold text-slate-900"
                    />
                  </div>
                  <span className="text-[11px] text-slate-500 block">Morningstar 2024 Diversification Report</span>
                </div>

                <div className="p-3 bg-white border border-slate-200 rounded-lg space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="font-semibold text-slate-800 block">Inflation-to-Bond Correlation</label>
                    {isCMADragModified('inflationBondCorrelation') ? (
                      <div className="flex items-center space-x-1">
                        <span className="px-1.5 py-0.5 bg-amber-50 text-amber-800 border border-amber-200 rounded text-[10px] font-bold">Manual</span>
                        <button
                          onClick={() => resetCMADrag('inflationBondCorrelation')}
                          className="p-1 text-amber-700 hover:text-amber-900 rounded"
                          title="Reset to default (-0.20)"
                        >
                          <RotateCcw className="w-3 h-3" />
                        </button>
                      </div>
                    ) : (
                      <span className="px-1.5 py-0.5 bg-blue-50 text-blue-700 rounded text-[10px] font-semibold">Default</span>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="number"
                      step="0.05"
                      min="-1.0"
                      max="1.0"
                      value={cma.inflationBondCorrelation}
                      onChange={(e) => updateCMADrag('inflationBondCorrelation', parseFloat(e.target.value) || 0)}
                      className="w-full px-2 py-1 bg-slate-50 border border-slate-300 rounded font-mono font-bold text-slate-900"
                    />
                  </div>
                  <span className="text-[11px] text-slate-500 block">NBER Working Paper cross-asset analysis</span>
                </div>

                <div className="p-3 bg-white border border-slate-200 rounded-lg space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="font-semibold text-slate-800 block">Annual Portfolio Expense Drag</label>
                    {isCMADragModified('annualPortfolioFeeDrag') ? (
                      <div className="flex items-center space-x-1">
                        <span className="px-1.5 py-0.5 bg-amber-50 text-amber-800 border border-amber-200 rounded text-[10px] font-bold">Manual</span>
                        <button
                          onClick={() => resetCMADrag('annualPortfolioFeeDrag')}
                          className="p-1 text-amber-700 hover:text-amber-900 rounded"
                          title="Reset to default (0.10%)"
                        >
                          <RotateCcw className="w-3 h-3" />
                        </button>
                      </div>
                    ) : (
                      <span className="px-1.5 py-0.5 bg-blue-50 text-blue-700 rounded text-[10px] font-semibold">Default</span>
                    )}
                  </div>
                  <div className="flex items-center space-x-1">
                    <input
                      type="number"
                      step="0.01"
                      value={cma.annualPortfolioFeeDrag}
                      onChange={(e) => updateCMADrag('annualPortfolioFeeDrag', parseFloat(e.target.value) || 0)}
                      className="w-full px-2 py-1 bg-slate-50 border border-slate-300 rounded font-bold text-slate-900"
                    />
                    <span className="font-bold text-slate-600">%</span>
                  </div>
                  <span className="text-[11px] text-slate-500 block">10 bps index fund expense ratio benchmark</span>
                </div>

                <div className="p-3 bg-white border border-slate-200 rounded-lg space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="font-semibold text-slate-800 block">Equity Dividend Yield Drag</label>
                    {isCMADragModified('equityDividendYield') ? (
                      <div className="flex items-center space-x-1">
                        <span className="px-1.5 py-0.5 bg-amber-50 text-amber-800 border border-amber-200 rounded text-[10px] font-bold">Manual</span>
                        <button
                          onClick={() => resetCMADrag('equityDividendYield')}
                          className="p-1 text-amber-700 hover:text-amber-900 rounded"
                          title="Reset to default (1.50%)"
                        >
                          <RotateCcw className="w-3 h-3" />
                        </button>
                      </div>
                    ) : (
                      <span className="px-1.5 py-0.5 bg-blue-50 text-blue-700 rounded text-[10px] font-semibold">Default</span>
                    )}
                  </div>
                  <div className="flex items-center space-x-1">
                    <input
                      type="number"
                      step="0.05"
                      value={cma.equityDividendYield}
                      onChange={(e) => updateCMADrag('equityDividendYield', parseFloat(e.target.value) || 0)}
                      className="w-full px-2 py-1 bg-slate-50 border border-slate-300 rounded font-bold text-slate-900"
                    />
                    <span className="font-bold text-slate-600">%</span>
                  </div>
                  <span className="text-[11px] text-slate-500 block">S&P 500 / MSCI ACWI taxable dividend drag</span>
                </div>

              </div>
            </div>

          </div>
        )}
      </div>

      {/* SECTION 2: ASSET ALLOCATION PRESETS */}
      <div id="section-presets" className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden transition-all">
        <button
          onClick={() => toggleSection('presets')}
          className="w-full flex items-center justify-between p-4 bg-slate-50/80 hover:bg-slate-100/80 transition-colors border-b border-slate-200 text-left cursor-pointer"
        >
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-indigo-100 text-indigo-700 rounded-lg">
              <PieChart className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold text-slate-900">2. Structured Portfolio Asset Allocation Target Presets</h3>
                <span className="text-[10px] font-semibold bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded-full">
                  {presets.length} Target Portfolios
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Structured target weights (US Equity, International Equity, Gold ETF, Intermediate Bonds, Cash) applied across accounts.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 text-slate-500 text-xs font-semibold">
            <span>{expandedSections.presets ? 'Hide Section' : 'Expand Section'}</span>
            {expandedSections.presets ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </div>
        </button>

        {expandedSections.presets && (
          <div className="p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <p className="text-xs text-slate-600">
                Adjust individual allocation target percentages below. Total sum per portfolio preset should equal 100%.
              </p>

              <button
                onClick={() => {
                  onUpdatePlan({
                    ...plan,
                    allocationPresets: DEFAULT_PLAN.allocationPresets,
                  });
                }}
                className="flex items-center space-x-1 px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium transition-colors shrink-0"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Presets</span>
              </button>
            </div>

            <div className="space-y-4">
              {presets.map((preset) => {
                const total = preset.usEquityPct + preset.intlEquityPct + (preset.goldPct || 0) + preset.bondsPct + preset.cashPct;
                const isValidTotal = total === 100;
                const modified = isPresetModified(preset.id);

                return (
                  <div key={preset.id} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 text-xs">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200/80 pb-2">
                      <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                        <span className="font-bold text-slate-900 text-sm">{preset.name}</span>
                        <span className="px-2 py-0.5 rounded font-bold text-[11px] bg-blue-100 text-blue-800">
                          {preset.equityPctLabel}
                        </span>
                        {modified ? (
                          <span className="px-2 py-0.5 rounded font-bold text-[10px] bg-amber-50 text-amber-800 border border-amber-200 flex items-center space-x-1">
                            <Sliders className="w-2.5 h-2.5 text-amber-600" />
                            <span>Manual Override</span>
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded font-bold text-[10px] bg-blue-50 text-blue-700 border border-blue-200 flex items-center space-x-1">
                            <ShieldCheck className="w-2.5 h-2.5 text-blue-600" />
                            <span>Industry Default</span>
                          </span>
                        )}
                      </div>

                      <div className="flex items-center space-x-2 flex-wrap gap-1">
                        <div className="flex items-center space-x-1.5 font-mono text-[11px] text-slate-600 flex-wrap">
                          <span>{preset.usEquityPct}% US</span>
                          <span>/</span>
                          <span>{preset.intlEquityPct}% Intl</span>
                          <span>/</span>
                          <span className="text-amber-800 font-bold">{preset.goldPct || 0}% Gold</span>
                          <span>/</span>
                          <span>{preset.bondsPct}% Bonds</span>
                          <span>/</span>
                          <span>{preset.cashPct}% Cash</span>
                          <span>—</span>
                          <span className={`font-bold px-2 py-0.5 rounded ${isValidTotal ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>
                            {total}% {isValidTotal ? 'Valid' : 'Invalid Sum'}
                          </span>
                        </div>

                        {modified && (
                          <button
                            onClick={() => resetSinglePreset(preset.id)}
                            className="flex items-center space-x-1 px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded text-xs font-semibold transition-colors ml-1"
                            title="Reset this allocation preset to industry default target weights"
                          >
                            <RotateCcw className="w-3 h-3 text-amber-700" />
                            <span>Reset Preset</span>
                          </button>
                        )}
                      </div>
                    </div>

                    <p className="text-slate-600 leading-relaxed text-[11px]">
                      {preset.description}
                    </p>

                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-1">
                      <div>
                        <label className="text-slate-700 font-semibold block mb-1">US Equity (%)</label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={preset.usEquityPct}
                          onChange={(e) => updatePresetAllocation(preset.id, 'usEquityPct', parseInt(e.target.value) || 0)}
                          className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded font-bold text-slate-900"
                        />
                      </div>

                      <div>
                        <label className="text-slate-700 font-semibold block mb-1">Intl Equity (%)</label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={preset.intlEquityPct}
                          onChange={(e) => updatePresetAllocation(preset.id, 'intlEquityPct', parseInt(e.target.value) || 0)}
                          className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded font-bold text-slate-900"
                        />
                      </div>

                      <div>
                        <label className="text-amber-900 font-semibold block mb-1">Gold ETF (%)</label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={preset.goldPct || 0}
                          onChange={(e) => updatePresetAllocation(preset.id, 'goldPct', parseInt(e.target.value) || 0)}
                          className="w-full px-2.5 py-1.5 bg-amber-50/60 border border-amber-300 rounded font-bold text-slate-900"
                        />
                      </div>

                      <div>
                        <label className="text-slate-700 font-semibold block mb-1">Bonds (%)</label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={preset.bondsPct}
                          onChange={(e) => updatePresetAllocation(preset.id, 'bondsPct', parseInt(e.target.value) || 0)}
                          className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded font-bold text-slate-900"
                        />
                      </div>

                      <div>
                        <label className="text-slate-700 font-semibold block mb-1">Cash (%)</label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={preset.cashPct}
                          onChange={(e) => updatePresetAllocation(preset.id, 'cashPct', parseInt(e.target.value) || 0)}
                          className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded font-bold text-slate-900"
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* SECTION 3: MACROECONOMIC PARAMETERS */}
      <div id="section-macro" className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden transition-all">
        <button
          onClick={() => toggleSection('macro')}
          className="w-full flex items-center justify-between p-4 bg-slate-50/80 hover:bg-slate-100/80 transition-colors border-b border-slate-200 text-left cursor-pointer"
        >
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-emerald-100 text-emerald-700 rounded-lg">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold text-slate-900">3. Macroeconomic Parameters & Wage Growth Dynamics</h3>
                <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                  5 Core Variables
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Inflation expectations, healthcare cost trend fade horizon, national average wage growth, and PIA bend point indexing.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 text-slate-500 text-xs font-semibold">
            <span>{expandedSections.macro ? 'Hide Section' : 'Expand Section'}</span>
            {expandedSections.macro ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </div>
        </button>

        {expandedSections.macro && (
          <div className="p-5 space-y-4 text-xs">
            
            {/* General Inflation Rate */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                  <span className="font-bold text-slate-900 text-sm">General Inflation Rate</span>
                  <code className="text-[11px] bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded">generalInflation</code>
                  {isMacroFieldModified('generalInflation') ? (
                    <span className="bg-amber-50 text-amber-800 border border-amber-200 font-bold px-2 py-0.5 rounded text-[10px] flex items-center space-x-1">
                      <Sliders className="w-2.5 h-2.5 text-amber-600" />
                      <span>MANUAL OVERRIDE</span>
                    </span>
                  ) : (
                    <span className="bg-blue-50 text-blue-700 border border-blue-200 font-bold px-2 py-0.5 rounded text-[10px] flex items-center space-x-1">
                      <ShieldCheck className="w-2.5 h-2.5 text-blue-600" />
                      <span>INDUSTRY DEFAULT</span>
                    </span>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  {isMacroFieldModified('generalInflation') && (
                    <button
                      onClick={() => resetMacroField('generalInflation')}
                      className="flex items-center space-x-1 px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded text-xs font-semibold transition-colors"
                      title="Reset general inflation to industry default (2.0%)"
                    >
                      <RotateCcw className="w-3 h-3 text-amber-700" />
                      <span>Reset to 2.0%</span>
                    </button>
                  )}
                  <div className="flex items-center space-x-1">
                    <input
                      type="number"
                      step="0.1"
                      value={macro.generalInflation}
                      onChange={(e) => updateMacro('generalInflation', parseFloat(e.target.value) || 2.0)}
                      className="w-16 px-2 py-1 bg-white border border-slate-300 rounded font-bold text-slate-900 text-right"
                    />
                    <span className="font-bold text-slate-600">%</span>
                  </div>
                </div>
              </div>
              <p className="text-slate-600 leading-relaxed text-[11px]">
                Vanguard Investment Strategy Group, &quot;Vanguard Capital Markets Model forecasts,&quot; published July 2026 30-year expected inflation rate.
              </p>
            </div>

            {/* Healthcare Inflation Rate */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                  <span className="font-bold text-slate-900 text-sm">Healthcare Inflation Rate</span>
                  <code className="text-[11px] bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded">medicalInflation</code>
                  {isMacroFieldModified('medicalInflation') ? (
                    <span className="bg-amber-50 text-amber-800 border border-amber-200 font-bold px-2 py-0.5 rounded text-[10px] flex items-center space-x-1">
                      <Sliders className="w-2.5 h-2.5 text-amber-600" />
                      <span>MANUAL OVERRIDE</span>
                    </span>
                  ) : (
                    <span className="bg-blue-50 text-blue-700 border border-blue-200 font-bold px-2 py-0.5 rounded text-[10px] flex items-center space-x-1">
                      <ShieldCheck className="w-2.5 h-2.5 text-blue-600" />
                      <span>INDUSTRY DEFAULT</span>
                    </span>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  {isMacroFieldModified('medicalInflation') && (
                    <button
                      onClick={() => resetMacroField('medicalInflation')}
                      className="flex items-center space-x-1 px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded text-xs font-semibold transition-colors"
                      title="Reset healthcare inflation to industry default (5.0%)"
                    >
                      <RotateCcw className="w-3 h-3 text-amber-700" />
                      <span>Reset to 5.0%</span>
                    </button>
                  )}
                  <div className="flex items-center space-x-1">
                    <input
                      type="number"
                      step="0.1"
                      value={macro.medicalInflation}
                      onChange={(e) => updateMacro('medicalInflation', parseFloat(e.target.value) || 5.0)}
                      className="w-16 px-2 py-1 bg-white border border-slate-300 rounded font-bold text-slate-900 text-right"
                    />
                    <span className="font-bold text-slate-600">%</span>
                  </div>
                </div>
              </div>
              <p className="text-slate-600 leading-relaxed text-[11px]">
                Centers for Medicare & Medicaid Services (CMS) 2023-2032 National Health Expenditure Projections (historical 5.0% annual medical cost trend).
              </p>
            </div>

            {/* Healthcare Inflation Fade Horizon */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                  <span className="font-bold text-slate-900 text-sm">Healthcare Inflation Fade Horizon</span>
                  <code className="text-[11px] bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded">healthcareInflationFade</code>
                  {isMacroFieldModified('medicalInflationFadeHorizonYears') ? (
                    <span className="bg-amber-50 text-amber-800 border border-amber-200 font-bold px-2 py-0.5 rounded text-[10px] flex items-center space-x-1">
                      <Sliders className="w-2.5 h-2.5 text-amber-600" />
                      <span>MANUAL OVERRIDE</span>
                    </span>
                  ) : (
                    <span className="bg-blue-50 text-blue-700 border border-blue-200 font-bold px-2 py-0.5 rounded text-[10px] flex items-center space-x-1">
                      <ShieldCheck className="w-2.5 h-2.5 text-blue-600" />
                      <span>INDUSTRY DEFAULT</span>
                    </span>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  {isMacroFieldModified('medicalInflationFadeHorizonYears') && (
                    <button
                      onClick={() => resetMacroField('medicalInflationFadeHorizonYears')}
                      className="flex items-center space-x-1 px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded text-xs font-semibold transition-colors"
                      title="Reset fade horizon to industry default (15 yrs)"
                    >
                      <RotateCcw className="w-3 h-3 text-amber-700" />
                      <span>Reset to 15 yrs</span>
                    </button>
                  )}
                  <div className="flex items-center space-x-1">
                    <input
                      type="number"
                      step="1"
                      value={macro.medicalInflationFadeHorizonYears}
                      onChange={(e) => updateMacro('medicalInflationFadeHorizonYears', parseInt(e.target.value) || 15)}
                      className="w-16 px-2 py-1 bg-white border border-slate-300 rounded font-bold text-slate-900 text-right"
                    />
                    <span className="font-bold text-slate-600">yrs</span>
                  </div>
                </div>
              </div>
              <p className="text-slate-600 leading-relaxed text-[11px]">
                Society of Actuaries (SOA) Getzen Model for Long-Run Medical Cost Trends (15-year fade timeline for excess medical inflation to converge to general GDP/CPI growth).
              </p>
            </div>

            {/* National Wage Growth Rate */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                  <span className="font-bold text-slate-900 text-sm">National Wage Growth Rate</span>
                  <code className="text-[11px] bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded">wageGrowth</code>
                  {isMacroFieldModified('nationalWageGrowth') ? (
                    <span className="bg-amber-50 text-amber-800 border border-amber-200 font-bold px-2 py-0.5 rounded text-[10px] flex items-center space-x-1">
                      <Sliders className="w-2.5 h-2.5 text-amber-600" />
                      <span>MANUAL OVERRIDE</span>
                    </span>
                  ) : (
                    <span className="bg-blue-50 text-blue-700 border border-blue-200 font-bold px-2 py-0.5 rounded text-[10px] flex items-center space-x-1">
                      <ShieldCheck className="w-2.5 h-2.5 text-blue-600" />
                      <span>INDUSTRY DEFAULT</span>
                    </span>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  {isMacroFieldModified('nationalWageGrowth') && (
                    <button
                      onClick={() => resetMacroField('nationalWageGrowth')}
                      className="flex items-center space-x-1 px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded text-xs font-semibold transition-colors"
                      title="Reset wage growth to industry default (3.0%)"
                    >
                      <RotateCcw className="w-3 h-3 text-amber-700" />
                      <span>Reset to 3.0%</span>
                    </button>
                  )}
                  <div className="flex items-center space-x-1">
                    <input
                      type="number"
                      step="0.1"
                      value={macro.nationalWageGrowth}
                      onChange={(e) => updateMacro('nationalWageGrowth', parseFloat(e.target.value) || 3.0)}
                      className="w-16 px-2 py-1 bg-white border border-slate-300 rounded font-bold text-slate-900 text-right"
                    />
                    <span className="font-bold text-slate-600">%</span>
                  </div>
                </div>
              </div>
              <p className="text-slate-600 leading-relaxed text-[11px]">
                Social Security Administration 2024 OASDI Trustees Report intermediate assumption for National Average Wage Index (NAWI) nominal annual growth.
              </p>
            </div>

            {/* Projected PIA Bend Point Indexing Method */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                  <span className="font-bold text-slate-900 text-sm">Projected PIA Bend Point Indexing Method</span>
                  <code className="text-[11px] bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded">projectedBendPointMethod</code>
                  {isMacroFieldModified('piaBendPointIndexingMethod') ? (
                    <span className="bg-amber-50 text-amber-800 border border-amber-200 font-bold px-2 py-0.5 rounded text-[10px] flex items-center space-x-1">
                      <Sliders className="w-2.5 h-2.5 text-amber-600" />
                      <span>MANUAL OVERRIDE</span>
                    </span>
                  ) : (
                    <span className="bg-blue-50 text-blue-700 border border-blue-200 font-bold px-2 py-0.5 rounded text-[10px] flex items-center space-x-1">
                      <ShieldCheck className="w-2.5 h-2.5 text-blue-600" />
                      <span>INDUSTRY DEFAULT</span>
                    </span>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  {isMacroFieldModified('piaBendPointIndexingMethod') && (
                    <button
                      onClick={() => resetMacroField('piaBendPointIndexingMethod')}
                      className="flex items-center space-x-1 px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded text-xs font-semibold transition-colors"
                      title="Reset indexing method to industry default (wageGrowthIndex)"
                    >
                      <RotateCcw className="w-3 h-3 text-amber-700" />
                      <span>Reset</span>
                    </button>
                  )}
                  <select
                    value={macro.piaBendPointIndexingMethod}
                    onChange={(e) => updateMacro('piaBendPointIndexingMethod', e.target.value)}
                    className="px-2.5 py-1 bg-white border border-slate-300 rounded font-bold text-slate-900"
                  >
                    <option value="wageGrowthIndex">wageGrowthIndex</option>
                    <option value="cpiIndex">cpiIndex</option>
                    <option value="constant">constant</option>
                  </select>
                </div>
              </div>
              <p className="text-slate-600 leading-relaxed text-[11px]">
                For workers attaining age 62 in future years, eligibility-year Primary Insurance Amount (PIA) bend points are projected from published statutory bend points growing at national average wage growth rate.
              </p>
            </div>

          </div>
        )}
      </div>

      {/* SECTION 4: STATUTORY & TAX RULES */}
      <div id="section-statutory" className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden transition-all">
        <button
          onClick={() => toggleSection('statutory')}
          className="w-full flex items-center justify-between p-4 bg-slate-50/80 hover:bg-slate-100/80 transition-colors border-b border-slate-200 text-left cursor-pointer"
        >
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-amber-100 text-amber-700 rounded-lg">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold text-slate-900">4. Statutory Frameworks & IRS Limits</h3>
                <span className="text-[10px] font-semibold bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full">
                  Tax Year 2026 Statutory Rules
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Standard deductions, 401(k) / 403(b) elective limits, IRA contribution limits, HSA limits, and SECURE Act RMD ages.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 text-slate-500 text-xs font-semibold">
            <span>{expandedSections.statutory ? 'Hide Section' : 'Expand Section'}</span>
            {expandedSections.statutory ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </div>
        </button>

        {expandedSections.statutory && (
          <div className="p-5 text-xs">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              
              {/* Standard Deductions */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <h4 className="font-bold text-slate-900 border-b border-slate-200 pb-2 flex justify-between items-center">
                  <span>Standard Deductions</span>
                  <span className="text-blue-600 font-semibold">IRS 2026</span>
                </h4>
                <div className="space-y-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-slate-600 block">Married Filing Jointly (MFJ)</label>
                      {isStatutoryFieldModified('standardDeductionJoint') ? (
                        <div className="flex items-center space-x-1">
                          <span className="text-[10px] font-bold text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">Manual</span>
                          <button
                            onClick={() => resetStatutoryField('standardDeductionJoint')}
                            className="p-1 text-amber-700 hover:text-amber-900 hover:bg-amber-100/60 rounded transition-colors"
                            title="Reset to 2026 statutory default ($32,200)"
                          >
                            <RotateCcw className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">Default ($32.2k)</span>
                      )}
                    </div>
                    <div className="flex items-center">
                      <span className="px-2.5 py-1.5 bg-slate-200 text-slate-600 rounded-l border border-r-0 border-slate-300">$</span>
                      <input
                        type="number"
                        value={stat.standardDeductionJoint}
                        onChange={(e) => updateStatutory('standardDeductionJoint', parseInt(e.target.value) || 32200)}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-r font-medium text-slate-900"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-slate-600 block">Single / Separate</label>
                      {isStatutoryFieldModified('standardDeductionSingle') ? (
                        <div className="flex items-center space-x-1">
                          <span className="text-[10px] font-bold text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">Manual</span>
                          <button
                            onClick={() => resetStatutoryField('standardDeductionSingle')}
                            className="p-1 text-amber-700 hover:text-amber-900 hover:bg-amber-100/60 rounded transition-colors"
                            title="Reset to 2026 statutory default ($16,100)"
                          >
                            <RotateCcw className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">Default ($16.1k)</span>
                      )}
                    </div>
                    <div className="flex items-center">
                      <span className="px-2.5 py-1.5 bg-slate-200 text-slate-600 rounded-l border border-r-0 border-slate-300">$</span>
                      <input
                        type="number"
                        value={stat.standardDeductionSingle}
                        onChange={(e) => updateStatutory('standardDeductionSingle', parseInt(e.target.value) || 16100)}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-r font-medium text-slate-900"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* 401(k) / 403(b) Statutory Deferral */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <h4 className="font-bold text-slate-900 border-b border-slate-200 pb-2 flex justify-between items-center">
                  <span>401(k) / 403(b) Elective Limits</span>
                  <span className="text-blue-600 font-semibold">Sec. 402(g)</span>
                </h4>
                <div className="space-y-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-slate-600 block">Base Elective Deferral Limit</label>
                      {isStatutoryFieldModified('deferralLimit401k') ? (
                        <div className="flex items-center space-x-1">
                          <span className="text-[10px] font-bold text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">Manual</span>
                          <button
                            onClick={() => resetStatutoryField('deferralLimit401k')}
                            className="p-1 text-amber-700 hover:text-amber-900 hover:bg-amber-100/60 rounded transition-colors"
                            title={`Reset to statutory default (${BASE_CONTRIBUTION_LIMITS.deferralLimit401k.toLocaleString()})`}
                          >
                            <RotateCcw className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">Default (${(BASE_CONTRIBUTION_LIMITS.deferralLimit401k / 1000).toFixed(1)}k)</span>
                      )}
                    </div>
                    <div className="flex items-center">
                      <span className="px-2.5 py-1.5 bg-slate-200 text-slate-600 rounded-l border border-r-0 border-slate-300">$</span>
                      <input
                        type="number"
                        value={stat.deferralLimit401k}
                        onChange={(e) => updateStatutory('deferralLimit401k', parseInt(e.target.value) || BASE_CONTRIBUTION_LIMITS.deferralLimit401k)}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-r font-medium text-slate-900"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-slate-600 block">Age 50+ Catch-up Limit</label>
                      {isStatutoryFieldModified('catchUpLimit401k') ? (
                        <div className="flex items-center space-x-1">
                          <span className="text-[10px] font-bold text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">Manual</span>
                          <button
                            onClick={() => resetStatutoryField('catchUpLimit401k')}
                            className="p-1 text-amber-700 hover:text-amber-900 hover:bg-amber-100/60 rounded transition-colors"
                            title={`Reset to statutory default (${BASE_CONTRIBUTION_LIMITS.catchUpLimit401k.toLocaleString()})`}
                          >
                            <RotateCcw className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">Default (${(BASE_CONTRIBUTION_LIMITS.catchUpLimit401k / 1000).toFixed(1)}k)</span>
                      )}
                    </div>
                    <div className="flex items-center">
                      <span className="px-2.5 py-1.5 bg-slate-200 text-slate-600 rounded-l border border-r-0 border-slate-300">$</span>
                      <input
                        type="number"
                        value={stat.catchUpLimit401k}
                        onChange={(e) => updateStatutory('catchUpLimit401k', parseInt(e.target.value) || BASE_CONTRIBUTION_LIMITS.catchUpLimit401k)}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-r font-medium text-slate-900"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* IRA Contribution Limits */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <h4 className="font-bold text-slate-900 border-b border-slate-200 pb-2 flex justify-between items-center">
                  <span>Traditional & Roth IRA Limits</span>
                  <span className="text-blue-600 font-semibold">Sec. 219</span>
                </h4>
                <div className="space-y-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-slate-600 block">Base IRA Contribution Limit</label>
                      {isStatutoryFieldModified('iraLimit') ? (
                        <div className="flex items-center space-x-1">
                          <span className="text-[10px] font-bold text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">Manual</span>
                          <button
                            onClick={() => resetStatutoryField('iraLimit')}
                            className="p-1 text-amber-700 hover:text-amber-900 hover:bg-amber-100/60 rounded transition-colors"
                            title={`Reset to statutory default (${BASE_CONTRIBUTION_LIMITS.iraLimit.toLocaleString()})`}
                          >
                            <RotateCcw className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">Default (${(BASE_CONTRIBUTION_LIMITS.iraLimit / 1000).toFixed(1)}k)</span>
                      )}
                    </div>
                    <div className="flex items-center">
                      <span className="px-2.5 py-1.5 bg-slate-200 text-slate-600 rounded-l border border-r-0 border-slate-300">$</span>
                      <input
                        type="number"
                        value={stat.iraLimit}
                        onChange={(e) => updateStatutory('iraLimit', parseInt(e.target.value) || BASE_CONTRIBUTION_LIMITS.iraLimit)}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-r font-medium text-slate-900"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-slate-600 block">Age 50+ Catch-up Limit</label>
                      {isStatutoryFieldModified('iraCatchUpLimit') ? (
                        <div className="flex items-center space-x-1">
                          <span className="text-[10px] font-bold text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">Manual</span>
                          <button
                            onClick={() => resetStatutoryField('iraCatchUpLimit')}
                            className="p-1 text-amber-700 hover:text-amber-900 hover:bg-amber-100/60 rounded transition-colors"
                            title={`Reset to statutory default (${BASE_CONTRIBUTION_LIMITS.iraCatchUpLimit.toLocaleString()})`}
                          >
                            <RotateCcw className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">Default (${(BASE_CONTRIBUTION_LIMITS.iraCatchUpLimit / 1000).toFixed(1)}k)</span>
                      )}
                    </div>
                    <div className="flex items-center">
                      <span className="px-2.5 py-1.5 bg-slate-200 text-slate-600 rounded-l border border-r-0 border-slate-300">$</span>
                      <input
                        type="number"
                        value={stat.iraCatchUpLimit}
                        onChange={(e) => updateStatutory('iraCatchUpLimit', parseInt(e.target.value) || BASE_CONTRIBUTION_LIMITS.iraCatchUpLimit)}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-r font-medium text-slate-900"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Health Savings Account (HSA) Limits */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <h4 className="font-bold text-slate-900 border-b border-slate-200 pb-2 flex justify-between items-center">
                  <span>Health Savings Account (HSA)</span>
                  <span className="text-blue-600 font-semibold">Sec. 223</span>
                </h4>
                <div className="space-y-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-slate-600 block">Family Coverage Limit</label>
                      {isStatutoryFieldModified('hsaFamilyLimit') ? (
                        <div className="flex items-center space-x-1">
                          <span className="text-[10px] font-bold text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">Manual</span>
                          <button
                            onClick={() => resetStatutoryField('hsaFamilyLimit')}
                            className="p-1 text-amber-700 hover:text-amber-900 hover:bg-amber-100/60 rounded transition-colors"
                            title={`Reset to statutory default (${BASE_CONTRIBUTION_LIMITS.hsaFamilyLimit.toLocaleString()})`}
                          >
                            <RotateCcw className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">Default (${(BASE_CONTRIBUTION_LIMITS.hsaFamilyLimit / 1000).toFixed(2)}k)</span>
                      )}
                    </div>
                    <div className="flex items-center">
                      <span className="px-2.5 py-1.5 bg-slate-200 text-slate-600 rounded-l border border-r-0 border-slate-300">$</span>
                      <input
                        type="number"
                        value={stat.hsaFamilyLimit}
                        onChange={(e) => updateStatutory('hsaFamilyLimit', parseInt(e.target.value) || BASE_CONTRIBUTION_LIMITS.hsaFamilyLimit)}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-r font-medium text-slate-900"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-slate-600 block">Self-Only Coverage Limit</label>
                      {isStatutoryFieldModified('hsaSingleLimit') ? (
                        <div className="flex items-center space-x-1">
                          <span className="text-[10px] font-bold text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">Manual</span>
                          <button
                            onClick={() => resetStatutoryField('hsaSingleLimit')}
                            className="p-1 text-amber-700 hover:text-amber-900 hover:bg-amber-100/60 rounded transition-colors"
                            title={`Reset to statutory default (${BASE_CONTRIBUTION_LIMITS.hsaSingleLimit.toLocaleString()})`}
                          >
                            <RotateCcw className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">Default (${(BASE_CONTRIBUTION_LIMITS.hsaSingleLimit / 1000).toFixed(1)}k)</span>
                      )}
                    </div>
                    <div className="flex items-center">
                      <span className="px-2.5 py-1.5 bg-slate-200 text-slate-600 rounded-l border border-r-0 border-slate-300">$</span>
                      <input
                        type="number"
                        value={stat.hsaSingleLimit}
                        onChange={(e) => updateStatutory('hsaSingleLimit', parseInt(e.target.value) || BASE_CONTRIBUTION_LIMITS.hsaSingleLimit)}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-r font-medium text-slate-900"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* RMD & Retirement Statutory Ages */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <h4 className="font-bold text-slate-900 border-b border-slate-200 pb-2 flex justify-between items-center">
                  <span>Retirement Statutory Ages</span>
                  <span className="text-blue-600 font-semibold">SECURE 2.0</span>
                </h4>
                <div className="space-y-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-slate-600 block">RMD Starting Age (Sec. 401(a)(9))</label>
                      {isStatutoryFieldModified('rmdStartAge') ? (
                        <div className="flex items-center space-x-1">
                          <span className="text-[10px] font-bold text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">Manual</span>
                          <button
                            onClick={() => resetStatutoryField('rmdStartAge')}
                            className="p-1 text-amber-700 hover:text-amber-900 hover:bg-amber-100/60 rounded transition-colors"
                            title="Reset to statutory default (Age 73)"
                          >
                            <RotateCcw className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">Default (Age 73)</span>
                      )}
                    </div>
                    <div className="flex items-center">
                      <input
                        type="number"
                        value={stat.rmdStartAge}
                        onChange={(e) => updateStatutory('rmdStartAge', parseInt(e.target.value) || 73)}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-l font-medium text-slate-900"
                      />
                      <span className="px-2.5 py-1.5 bg-slate-200 text-slate-600 rounded-r border border-l-0 border-slate-300 font-medium">yrs</span>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-slate-600 block">SS Full Retirement Age (FRA)</label>
                      {isStatutoryFieldModified('fullRetirementAge') ? (
                        <div className="flex items-center space-x-1">
                          <span className="text-[10px] font-bold text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">Manual</span>
                          <button
                            onClick={() => resetStatutoryField('fullRetirementAge')}
                            className="p-1 text-amber-700 hover:text-amber-900 hover:bg-amber-100/60 rounded transition-colors"
                            title="Reset to statutory default (Age 67)"
                          >
                            <RotateCcw className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">Default (Age 67)</span>
                      )}
                    </div>
                    <div className="flex items-center">
                      <input
                        type="number"
                        value={stat.fullRetirementAge}
                        onChange={(e) => updateStatutory('fullRetirementAge', parseInt(e.target.value) || 67)}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-l font-medium text-slate-900"
                      />
                      <span className="px-2.5 py-1.5 bg-slate-200 text-slate-600 rounded-r border border-l-0 border-slate-300 font-medium">yrs</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Social Security COLA Assumption */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <h4 className="font-bold text-slate-900 border-b border-slate-200 pb-2 flex justify-between items-center">
                  <span>Social Security COLA</span>
                  <span className="text-blue-600 font-semibold">SSA Annual</span>
                </h4>
                <div className="space-y-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-slate-600 block">Base Annual COLA Rate</label>
                      {isStatutoryFieldModified('ssColaRate') ? (
                        <div className="flex items-center space-x-1">
                          <span className="text-[10px] font-bold text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">Manual</span>
                          <button
                            onClick={() => resetStatutoryField('ssColaRate')}
                            className="p-1 text-amber-700 hover:text-amber-900 hover:bg-amber-100/60 rounded transition-colors"
                            title="Reset to statutory default (2.5%)"
                          >
                            <RotateCcw className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">Default (2.5%)</span>
                      )}
                    </div>
                    <div className="flex items-center">
                      <input
                        type="number"
                        step="0.1"
                        value={stat.ssColaRate}
                        onChange={(e) => updateStatutory('ssColaRate', parseFloat(e.target.value) || 2.5)}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-l font-medium text-slate-900"
                      />
                      <span className="px-2.5 py-1.5 bg-slate-200 text-slate-600 rounded-r border border-l-0 border-slate-300 font-medium">%</span>
                    </div>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    Annual cost-of-living adjustment applied to Social Security Primary Insurance Amount (PIA) in post-benefit years.
                  </p>
                </div>
              </div>

              {/* Social Security Trust Fund Solvency Level Lever */}
              <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl space-y-3 col-span-1 md:col-span-2">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-amber-200/80 pb-2">
                  <div className="flex items-center space-x-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    <h4 className="font-bold text-amber-950 text-xs uppercase tracking-wider">
                      Social Security Trust Fund Solvency Lever
                    </h4>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowSsInfoModal(true)}
                    className="inline-flex items-center space-x-1 text-[11px] font-bold text-amber-800 hover:text-amber-950 underline"
                  >
                    <Info className="w-3.5 h-3.5" />
                    <span>SSA Trustees Report & Depletion Info</span>
                  </button>
                </div>

                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-1">
                  <div className="space-y-1 max-w-xl">
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={plan.primaryPerson.includeSsProjectedReduction || false}
                        onChange={(e) => {
                          const val = e.target.checked;
                          onUpdatePlan({
                            ...plan,
                            primaryPerson: { ...plan.primaryPerson, includeSsProjectedReduction: val },
                            spousePerson: { ...plan.spousePerson, includeSsProjectedReduction: val },
                          });
                        }}
                        className="w-4 h-4 text-amber-600 rounded border-amber-300 focus:ring-amber-500 cursor-pointer"
                      />
                      <span className="font-bold text-slate-900 text-xs">
                        Model Projected ~21% Statutory SSA Trust Fund Reduction (~2033 OASI Depletion)
                      </span>
                    </label>
                    <p className="text-[11px] text-slate-600 leading-snug pl-6">
                      If OASI reserves deplete around 2033 without congressional reform, tax collections will cover ~79% of scheduled benefits. Checking this reduces all modeled Social Security benefits by 21%.
                    </p>
                  </div>

                  <div className="shrink-0 bg-white p-3 rounded-lg border border-amber-200 text-right space-y-0.5">
                    <span className="text-[10px] uppercase tracking-wider font-bold text-slate-500 block">Solvency Modeled</span>
                    {plan.primaryPerson.includeSsProjectedReduction ? (
                      <span className="text-xs font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded border border-amber-300 inline-block">
                        21% Reduction Modeled
                      </span>
                    ) : (
                      <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded border border-emerald-300 inline-block">
                        100% Scheduled Benefits
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Statutory IRS Tax Brackets, Capital Gains & Standard Deductions Tables */}
              <div className="col-span-1 md:col-span-2 lg:col-span-3 pt-5 border-t border-slate-200/80 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm flex items-center space-x-2">
                      <Scale className="w-4 h-4 text-amber-600" />
                      <span>Federal Standard Deductions & Tax Bracket Ceilings ({TAX_BASE_YEAR} Statutory Base Year)</span>
                    </h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Statutory standard deductions, tax bracket ceilings, and long-term capital gains thresholds used by the engine before annual CPI indexation.
                    </p>
                  </div>
                  <span className="text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200 px-2.5 py-1 rounded-full shrink-0 self-start sm:self-auto">
                    Rev. Proc. {TAX_BASE_YEAR} Statutory Schedules
                  </span>
                </div>

                {/* Standard Deductions Summary Table */}
                <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
                  <div className="bg-slate-100/80 px-4 py-2.5 border-b border-slate-200 flex items-center justify-between">
                    <span className="font-bold text-slate-800 text-xs flex items-center space-x-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                      <span>Federal Standard Deductions ({TAX_BASE_YEAR} Base Year)</span>
                    </span>
                    <span className="text-[10px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">IRC §63 Baseline</span>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                        <tr>
                          <th className="py-2 px-3">Deduction Tier / Category</th>
                          <th className="py-2 px-3">Single Filing Status</th>
                          <th className="py-2 px-3">Married Filing Jointly (MFJ)</th>
                          <th className="py-2 px-3">Notes & Rules</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-slate-800 font-mono text-[11px]">
                        <tr className="hover:bg-slate-50/80">
                          <td className="py-2 px-3 font-bold text-slate-900 font-sans">Basic Standard Deduction</td>
                          <td className="py-2 px-3 font-bold text-blue-700">${STANDARD_DEDUCTION_2026.single.toLocaleString()}</td>
                          <td className="py-2 px-3 font-bold text-blue-700">${STANDARD_DEDUCTION_2026.joint.toLocaleString()}</td>
                          <td className="py-2 px-3 text-[10px] text-slate-500 font-sans font-normal">Base statutory deduction per return</td>
                        </tr>
                        <tr className="hover:bg-slate-50/80">
                          <td className="py-2 px-3 font-medium text-slate-800 font-sans">Additional Deduction (Age 65+ / Blind)</td>
                          <td className="py-2 px-3 text-indigo-700">+${ADDL_STD_DEDUCTION_65.single.toLocaleString()}</td>
                          <td className="py-2 px-3 text-indigo-700">+${ADDL_STD_DEDUCTION_65.joint.toLocaleString()} <span className="text-[10px] text-slate-500 font-sans font-normal">(per spouse)</span></td>
                          <td className="py-2 px-3 text-[10px] text-slate-500 font-sans font-normal">Applied automatically when taxpayer reaches age 65</td>
                        </tr>
                        <tr className="hover:bg-slate-50/80 bg-indigo-50/30">
                          <td className="py-2 px-3 font-bold text-indigo-950 font-sans">Total Senior Deduction (Both Age 65+)</td>
                          <td className="py-2 px-3 font-bold text-indigo-900">${(STANDARD_DEDUCTION_2026.single + ADDL_STD_DEDUCTION_65.single).toLocaleString()}</td>
                          <td className="py-2 px-3 font-bold text-indigo-900">${(STANDARD_DEDUCTION_2026.joint + ADDL_STD_DEDUCTION_65.joint * 2).toLocaleString()}</td>
                          <td className="py-2 px-3 text-[10px] text-indigo-800 font-sans font-normal">Fully modeled in cash flow engine when both age ≥ 65</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                  {/* Ordinary Income Tax Brackets Table */}
                  <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
                    <div className="bg-slate-100/80 px-4 py-2.5 border-b border-slate-200 flex items-center justify-between">
                      <span className="font-bold text-slate-800 text-xs">Federal Ordinary Income Tax Brackets</span>
                      <span className="text-[10px] font-semibold text-slate-500">{TAX_BASE_YEAR} Base Year</span>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                          <tr>
                            <th className="py-2 px-3">Tax Rate</th>
                            <th className="py-2 px-3">Single Filing Status</th>
                            <th className="py-2 px-3">Married Filing Jointly (MFJ)</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-slate-800 font-mono text-[11px]">
                          <tr className="hover:bg-slate-50/80">
                            <td className="py-2 px-3 font-bold text-emerald-700 bg-emerald-50/40">10%</td>
                            <td className="py-2 px-3">$0 – ${BRACKET_CEILINGS_2026.single.b10.toLocaleString()}</td>
                            <td className="py-2 px-3">$0 – ${BRACKET_CEILINGS_2026.joint.b10.toLocaleString()}</td>
                          </tr>
                          <tr className="hover:bg-slate-50/80">
                            <td className="py-2 px-3 font-bold text-blue-700 bg-blue-50/40">12%</td>
                            <td className="py-2 px-3">${(BRACKET_CEILINGS_2026.single.b10 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.single.b12.toLocaleString()}</td>
                            <td className="py-2 px-3">${(BRACKET_CEILINGS_2026.joint.b10 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.joint.b12.toLocaleString()}</td>
                          </tr>
                          <tr className="hover:bg-slate-50/80">
                            <td className="py-2 px-3 font-bold text-indigo-700 bg-indigo-50/40">22%</td>
                            <td className="py-2 px-3">${(BRACKET_CEILINGS_2026.single.b12 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.single.b22.toLocaleString()}</td>
                            <td className="py-2 px-3">${(BRACKET_CEILINGS_2026.joint.b12 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.joint.b22.toLocaleString()}</td>
                          </tr>
                          <tr className="hover:bg-slate-50/80">
                            <td className="py-2 px-3 font-bold text-purple-700 bg-purple-50/40">24%</td>
                            <td className="py-2 px-3">${(BRACKET_CEILINGS_2026.single.b22 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.single.b24.toLocaleString()}</td>
                            <td className="py-2 px-3">${(BRACKET_CEILINGS_2026.joint.b22 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.joint.b24.toLocaleString()}</td>
                          </tr>
                          <tr className="hover:bg-slate-50/80">
                            <td className="py-2 px-3 font-bold text-amber-700 bg-amber-50/40">32%</td>
                            <td className="py-2 px-3">${(BRACKET_CEILINGS_2026.single.b24 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.single.b32.toLocaleString()}</td>
                            <td className="py-2 px-3">${(BRACKET_CEILINGS_2026.joint.b24 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.joint.b32.toLocaleString()}</td>
                          </tr>
                          <tr className="hover:bg-slate-50/80">
                            <td className="py-2 px-3 font-bold text-orange-700 bg-orange-50/40">35%</td>
                            <td className="py-2 px-3">${(BRACKET_CEILINGS_2026.single.b32 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.single.b35.toLocaleString()}</td>
                            <td className="py-2 px-3">${(BRACKET_CEILINGS_2026.joint.b32 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.joint.b35.toLocaleString()}</td>
                          </tr>
                          <tr className="hover:bg-slate-50/80">
                            <td className="py-2 px-3 font-bold text-rose-700 bg-rose-50/40">37%</td>
                            <td className="py-2 px-3">Over ${BRACKET_CEILINGS_2026.single.b35.toLocaleString()}</td>
                            <td className="py-2 px-3">Over ${BRACKET_CEILINGS_2026.joint.b35.toLocaleString()}</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Long-Term Capital Gains & NIIT Table */}
                  <div className="space-y-3">
                    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
                      <div className="bg-slate-100/80 px-4 py-2.5 border-b border-slate-200 flex items-center justify-between">
                        <span className="font-bold text-slate-800 text-xs">Long-Term Capital Gains (LTCG) Brackets</span>
                        <span className="text-[10px] font-semibold text-slate-500">{TAX_BASE_YEAR} Base Year</span>
                      </div>
                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-xs">
                          <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                            <tr>
                              <th className="py-2 px-3">LTCG Rate</th>
                              <th className="py-2 px-3">Single Taxable Income</th>
                              <th className="py-2 px-3">Married Filing Jointly (MFJ)</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 text-slate-800 font-mono text-[11px]">
                            <tr className="hover:bg-slate-50/80">
                              <td className="py-2 px-3 font-bold text-emerald-700 bg-emerald-50/40">0%</td>
                              <td className="py-2 px-3">$0 – ${LTCG_CEILINGS_2026.single.zero.toLocaleString()}</td>
                              <td className="py-2 px-3">$0 – ${LTCG_CEILINGS_2026.joint.zero.toLocaleString()}</td>
                            </tr>
                            <tr className="hover:bg-slate-50/80">
                              <td className="py-2 px-3 font-bold text-blue-700 bg-blue-50/40">15%</td>
                              <td className="py-2 px-3">${(LTCG_CEILINGS_2026.single.zero + 1).toLocaleString()} – ${LTCG_CEILINGS_2026.single.fifteen.toLocaleString()}</td>
                              <td className="py-2 px-3">${(LTCG_CEILINGS_2026.joint.zero + 1).toLocaleString()} – ${LTCG_CEILINGS_2026.joint.fifteen.toLocaleString()}</td>
                            </tr>
                            <tr className="hover:bg-slate-50/80">
                              <td className="py-2 px-3 font-bold text-purple-700 bg-purple-50/40">20%</td>
                              <td className="py-2 px-3">Over ${LTCG_CEILINGS_2026.single.fifteen.toLocaleString()}</td>
                              <td className="py-2 px-3">Over ${LTCG_CEILINGS_2026.joint.fifteen.toLocaleString()}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>

                    {/* NIIT Card */}
                    <div className="p-3 bg-indigo-50/60 border border-indigo-200 rounded-xl space-y-1 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-indigo-950">Net Investment Income Tax (NIIT - IRC §1411)</span>
                        <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 rounded font-bold text-[10px]">{(NIIT_RATE * 100).toFixed(1)}% Surtax</span>
                      </div>
                      <p className="text-[11px] text-indigo-900 leading-snug">
                        Applies an additional {(NIIT_RATE * 100).toFixed(1)}% tax on net investment income when MAGI exceeds <span className="font-mono font-bold">${NIIT_THRESHOLD.single.toLocaleString()}</span> (Single) or <span className="font-mono font-bold">${NIIT_THRESHOLD.joint.toLocaleString()}</span> (MFJ). Note: Thresholds are statutory and not indexed for inflation.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        )}
      </div>

      {/* SECTION 5: VERIFIABLE DATA SOURCE CITATIONS & AUDIT TABLE */}
      <div id="section-sources" className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden transition-all">
        <button
          onClick={() => toggleSection('sources')}
          className="w-full flex items-center justify-between p-4 bg-slate-50/80 hover:bg-slate-100/80 transition-colors border-b border-slate-200 text-left cursor-pointer"
        >
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-purple-100 text-purple-700 rounded-lg">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold text-slate-900">5. Verifiable Data Source Citations & Benchmark Audit Table</h3>
                <span className="text-[10px] font-semibold bg-purple-100 text-purple-800 px-2 py-0.5 rounded-full">
                  {assumptionsList.length} Citation Records
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Official source citations, direct links, statutory parameters, and refreshed benchmark comparisons.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 text-slate-500 text-xs font-semibold">
            <span>{expandedSections.sources ? 'Hide Section' : 'Expand Section'}</span>
            {expandedSections.sources ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </div>
        </button>

        {expandedSections.sources && (
          <div className="p-5 space-y-4">
            
            {/* Filter & Add Controls */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs">
              <div className="flex items-center space-x-2 flex-1 flex-wrap gap-y-2">
                <div className="relative flex-1 min-w-[180px] max-w-xs">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search parameters or citations..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400"
                  />
                </div>

                <div className="flex items-center space-x-1 shrink-0">
                  <Filter className="w-3.5 h-3.5 text-slate-400" />
                  <select
                    value={categoryFilter}
                    onChange={(e) => setCategoryFilter(e.target.value)}
                    className="px-2 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-700 font-medium"
                  >
                    {categories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex items-center space-x-2 shrink-0">
                <button
                  onClick={handleResetAllToDefaults}
                  className="flex items-center space-x-1.5 px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 rounded-lg font-semibold border border-slate-300 transition-colors"
                  title="Reset all plan assumptions to original Industry Defaults"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                  <span>Reset All to Defaults</span>
                </button>

                <button
                  onClick={() => {
                    setIsNewSource(true);
                    setEditingSource({
                      id: `assumption-${Date.now()}`,
                      parameterName: '',
                      category: 'Macroeconomic',
                      currentValue: '',
                      defaultValue: '',
                      isManualOverride: true,
                      sourceType: 'Manual',
                      sourceName: '',
                      sourceUrl: '',
                      lastUpdated: new Date().toISOString().split('T')[0],
                      notes: '',
                    });
                  }}
                  className="flex items-center space-x-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Source Citation</span>
                </button>
              </div>
            </div>

            {/* Citations Table */}
            <div className="border border-slate-200 rounded-xl overflow-x-auto bg-white">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="p-3">Parameter & Category</th>
                    <th className="p-3">Model Value</th>
                    <th className="p-3">Refreshed Benchmark</th>
                    <th className="p-3">Source & Citation</th>
                    <th className="p-3">Last Verified</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-800">
                  {filteredSources.map((item) => {
                    const isManual = item.isManualOverride || (Boolean(item.defaultValue) && item.currentValue !== item.defaultValue);

                    return (
                      <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="p-3 font-medium">
                          <div className="font-bold text-slate-900">{item.parameterName}</div>
                          <span className="text-[10px] text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded font-mono">
                            {item.category}
                          </span>
                        </td>

                        <td className="p-3 font-mono font-semibold text-blue-700 max-w-xs">
                          <div>{item.currentValue}</div>
                        </td>

                        <td className="p-3">
                          {item.refreshedValue ? (
                            <div className="flex items-center space-x-1.5">
                              <span className="font-mono text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                                {item.refreshedValue}
                              </span>
                              <button
                                onClick={() => handleApplyRefreshedValue(item.id)}
                                className="text-[10px] bg-blue-50 text-blue-700 hover:bg-blue-100 px-1.5 py-0.5 rounded font-medium border border-blue-200 transition-colors"
                                title="Apply refreshed value to model"
                              >
                                Apply
                              </button>
                            </div>
                          ) : (
                            <span className="text-slate-400 font-mono text-[11px]">—</span>
                          )}
                        </td>

                        <td className="p-3 max-w-xs">
                          <a
                            href={item.sourceUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="font-medium text-blue-600 hover:underline flex items-center space-x-1 truncate"
                          >
                            <span className="truncate">{item.sourceName}</span>
                            <ExternalLink className="w-3 h-3 shrink-0 ml-0.5" />
                          </a>
                          {item.notes && (
                            <p className="text-[11px] text-slate-500 truncate mt-0.5">{item.notes}</p>
                          )}
                        </td>

                        <td className="p-3 text-slate-500 font-mono text-[11px]">
                          {item.lastUpdated}
                        </td>

                        <td className="p-3 text-right">
                          <div className="flex items-center justify-end space-x-1">
                            {isManual && (
                              <button
                                onClick={() => handleResetSourceToDefault(item.id)}
                                className="p-1 text-amber-700 hover:text-amber-900 hover:bg-amber-50 rounded transition-colors"
                                title="Reset to Industry Default for this plan"
                              >
                                <RotateCcw className="w-3.5 h-3.5" />
                              </button>
                            )}
                            <button
                              onClick={() => {
                                setIsNewSource(false);
                                setEditingSource({ ...item });
                              }}
                              className="p-1 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded transition-colors"
                              title="Edit Value or Source Citation"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteSource(item.id)}
                              className="p-1 text-slate-500 hover:text-rose-600 hover:bg-slate-100 rounded transition-colors"
                              title="Delete Citation"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}

                  {filteredSources.length === 0 && (
                    <tr>
                      <td colSpan={7} className="p-6 text-center text-slate-500">
                        No citations found matching search or category filters.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

          </div>
        )}

        <AcaAssumptionsSection plan={plan} onUpdatePlan={onUpdatePlan} />
      </div>

      {/* EDIT / ADD CITATION MODAL */}
      {editingSource && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 text-xs">
          <div className="bg-white rounded-xl border border-slate-200 shadow-xl max-w-md w-full p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-bold text-slate-900 text-sm">
                  {isNewSource ? 'Add New Data Source Citation' : 'Edit Parameter & Citation'}
                </h3>
                <p className="text-[11px] text-slate-500">
                  {editingSource.isManualOverride ? 'Manual Override Active' : 'Standard Industry Default'}
                </p>
              </div>
              <button
                onClick={() => setEditingSource(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Parameter Name</label>
                <input
                  type="text"
                  placeholder="e.g. 30-Yr General Inflation"
                  value={editingSource.parameterName}
                  onChange={(e) => setEditingSource({ ...editingSource, parameterName: e.target.value })}
                  className="w-full px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Category</label>
                <select
                  value={editingSource.category}
                  onChange={(e) => setEditingSource({ ...editingSource, category: e.target.value as any })}
                  className="w-full px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
                >
                  <option value="Macroeconomic">Macroeconomic</option>
                  <option value="Asset Return">Asset Return</option>
                  <option value="Statutory Limit">Statutory Limit</option>
                  <option value="Tax Rate">Tax Rate</option>
                  <option value="Demographic">Demographic</option>
                </select>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block font-semibold text-slate-700">Model Value (Plan Override)</label>
                  {editingSource.defaultValue && (
                    <span className="text-[10px] text-slate-500 font-mono">
                      Default: {editingSource.defaultValue}
                    </span>
                  )}
                </div>
                <input
                  type="text"
                  placeholder="e.g. 2.00%"
                  value={editingSource.currentValue}
                  onChange={(e) => setEditingSource({ ...editingSource, currentValue: e.target.value })}
                  className="w-full px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono font-medium"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Refreshed Benchmark</label>
                <input
                  type="text"
                  placeholder="e.g. 2.10% (BLS release)"
                  value={editingSource.refreshedValue || ''}
                  onChange={(e) => setEditingSource({ ...editingSource, refreshedValue: e.target.value })}
                  className="w-full px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Source Name</label>
                <input
                  type="text"
                  placeholder="e.g. Bureau of Labor Statistics CPI-U Report"
                  value={editingSource.sourceName}
                  onChange={(e) => setEditingSource({ ...editingSource, sourceName: e.target.value })}
                  className="w-full px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Source URL</label>
                <input
                  type="url"
                  placeholder="https://www.bls.gov/cpi/"
                  value={editingSource.sourceUrl}
                  onChange={(e) => setEditingSource({ ...editingSource, sourceUrl: e.target.value })}
                  className="w-full px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Notes / Description</label>
                <textarea
                  rows={2}
                  placeholder="Additional context or notes..."
                  value={editingSource.notes || ''}
                  onChange={(e) => setEditingSource({ ...editingSource, notes: e.target.value })}
                  className="w-full px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-100">
              {editingSource.defaultValue && editingSource.currentValue !== editingSource.defaultValue ? (
                <button
                  onClick={() => {
                    if (editingSource.defaultValue) {
                      setEditingSource({
                        ...editingSource,
                        currentValue: editingSource.defaultValue,
                        isManualOverride: false,
                        sourceType: 'Industry',
                      });
                    }
                  }}
                  className="flex items-center space-x-1 text-amber-700 hover:text-amber-900 text-xs font-semibold"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset to Industry Default</span>
                </button>
              ) : <div />}

              <div className="flex space-x-2">
                <button
                  onClick={() => setEditingSource(null)}
                  className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors font-medium"
                >
                  Cancel
                </button>
                <button
                  onClick={() => handleSaveSource(editingSource)}
                  className="px-4 py-1.5 bg-blue-600 text-white hover:bg-blue-700 rounded-lg transition-colors font-semibold"
                >
                  Save Citation
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Social Security Trust Fund Info Modal */}
      {showSsInfoModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6 border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2 text-amber-700">
                <Info className="w-5 h-5 text-amber-600" />
                <h3 className="text-base font-bold text-slate-900">Social Security Trust Fund Reduction</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowSsInfoModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-600 leading-relaxed">
              <p>
                According to the <strong>2024 Social Security Board of Trustees Annual Report</strong>, the Old-Age and Survivors Insurance (OASI) Trust Fund reserve is projected to become depleted in approximately <strong>2033 to 2035</strong>.
              </p>
              <p>
                Upon depletion, ongoing payroll tax revenues will still cover approximately <strong>79% of scheduled benefits</strong> (a projected 21% benefit reduction) unless Congress passes legislative reforms.
              </p>

              <div className="bg-amber-50 p-3 rounded-xl border border-amber-200 text-amber-900 space-y-1">
                <div className="font-bold flex items-center space-x-1 text-amber-950">
                  <span>Official Reference Source:</span>
                </div>
                <div className="text-[11px] font-medium text-amber-800">
                  SSA Board of Trustees OASDI Annual Report (2024)
                </div>
                <a
                  href="https://www.ssa.gov/oact/TR/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center space-x-1 text-blue-700 hover:text-blue-900 font-bold underline text-[11px] pt-1"
                >
                  <span>https://www.ssa.gov/oact/TR/</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              <p className="text-slate-500 italic">
                Checking this toggle adjusts your modeled Social Security monthly income downward by 21% across future cash flow projections.
              </p>
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowSsInfoModal(false)}
                className="px-4 py-2 bg-slate-900 text-white font-semibold rounded-xl text-xs hover:bg-slate-800 transition-colors"
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
