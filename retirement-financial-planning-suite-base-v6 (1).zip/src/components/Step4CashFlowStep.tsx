import React, { useState, useMemo } from 'react';
import { Plan, SpendingAssumptions } from '../types';
import { UpdateOptions } from '../store/usePlanStore';
import { DEFAULT_PLAN } from '../constants/defaultPlan';
import { runStep4Validations } from '../domain/validation/validations';
import { IRMAA_REGISTRY } from '../domain/registry/statutoryRegistry';
import { getSsAnnualBenefit } from '../domain/simulation/simulationEngine';
import { getSimulation } from '../domain/simulation/simulationCache';
import { resolveRetirementStrategy } from '../domain/strategy';
import { RothConversionImpactAnalysis } from './cashflow/RothConversionImpactAnalysis';
import { bracketCeilingsFor, BRACKET_CEILINGS_2026, STANDARD_DEDUCTION_2026 } from '../domain/tax/taxConstants';
import { IRMAA_THRESHOLDS } from '../domain/tax/headroom';
import { 
  ArrowRight, 
  ShieldAlert, 
  Layers, 
  Receipt, 
  BarChart3, 
  Sparkles, 
  Percent, 
  ShieldCheck
} from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine
} from 'recharts';

interface Step4CashFlowStepProps {
  plan: Plan;
  onUpdatePlan: (updatedPlan: Plan, options?: UpdateOptions) => void;
  onGoToValidations: () => void;
  onGoToStrategy?: () => void;
  onGoToNextStep?: () => void;
}

export const Step4CashFlowStep: React.FC<Step4CashFlowStepProps> = ({
  plan,
  onUpdatePlan,
  onGoToValidations,
  onGoToStrategy,
  onGoToNextStep,
}) => {
  const spending: SpendingAssumptions = {
    ...DEFAULT_PLAN.spendingAssumptions!,
    ...(plan.spendingAssumptions || {}),
  };

  const primary = plan.primaryPerson;
  const spouse = plan.spousePerson;
  const macro = plan.macroAssumptions || DEFAULT_PLAN.macroAssumptions!;
  const statutory = plan.statutoryParams || DEFAULT_PLAN.statutoryParams!;
  const cma = plan.cmaAssumptions || DEFAULT_PLAN.cmaAssumptions!;
  const feeDrag = cma.annualPortfolioFeeDrag ?? 0.10;

  // Chart Overlay Toggles
  const [showTaxBrackets, setShowTaxBrackets] = useState(true);
  const [showIrmaaTiers, setShowIrmaaTiers] = useState(true);
  const [showEssentialVsDisc, setShowEssentialVsDisc] = useState(false);

  // Table filter state
  const [activeDecade, setActiveDecade] = useState<'all' | 'gap' | 'rmd'>('all');

  // Federal Filing Status parameters
  const isJoint = plan.filingStatus === 'joint';
  const stdDeduction = isJoint ? statutory.standardDeductionJoint : statutory.standardDeductionSingle;

  // Sourced from the same table the simulation engine uses. These were previously
  // hardcoded 2024 figures, so the chart's bracket lines could disagree with the tax
  // actually computed in the table below them.
  const bracketCeilings = bracketCeilingsFor(isJoint, 1.0);

  const formatBracketLabel = (rate: string, ceiling: number) =>
    `${rate} Bracket ($${(ceiling / 1000).toFixed(1)}k)`;

  // IRMAA MAGI Tier Thresholds
  const irmaaTier1 = isJoint ? IRMAA_REGISTRY.thresholds.joint[0] : IRMAA_REGISTRY.thresholds.single[0];
  const irmaaTier2 = isJoint ? IRMAA_REGISTRY.thresholds.joint[1] : IRMAA_REGISTRY.thresholds.single[1];

  // Frame display selection: 'real' (Today's 2026 Dollars) vs 'nominal' (Future Nominal Dollars)
  const [displayFrame, setDisplayFrame] = useState<'real' | 'nominal'>('real');

  // Dependencies reduced to `plan` alone: the other entries were all sub-objects OF
  // plan, so they could never change without plan changing. getSimulation memoizes on
  // plan identity, so this useMemo is now a formality rather than the real cache.
  const activeStrategy = useMemo(() => resolveRetirementStrategy(plan), [plan]);
  const currentSim = useMemo(() => getSimulation(plan), [plan]);
  const baselineSim = useMemo(
    () => getSimulation(plan, { strategyOverride: { rothConversion: { type: 'none' } } }),
    [plan]
  );

  // Deflated Real (2026 Dollars) or Future Nominal Projection Dataset
  const projection = useMemo(() => {
    if (displayFrame === 'nominal') {
      return currentSim.rows;
    }
    return currentSim.rows.map(r => {
      const yearsFromStart = r.age - primary.currentAge;
      const deflator = Math.pow(1 + (macro.generalInflation || 2.0) / 100, yearsFromStart);
      return {
        ...r,
        baseLiving: r.baseLiving / deflator,
        essentialExpense: r.essentialExpense / deflator,
        discretionaryExpense: r.discretionaryExpense / deflator,
        healthExpense: r.healthExpense / deflator,
        debtService: r.debtService / deflator,
        totalExpenseNeed: r.totalExpenseNeed / deflator,
        guaranteedIncome: r.guaranteedIncome / deflator,
        primarySs: r.primarySs / deflator,
        spouseSs: r.spouseSs / deflator,
        pensionIncome: r.pensionIncome / deflator,
        rmdAmount: r.rmdAmount / deflator,
        rothConversion: r.rothConversion / deflator,
        taxableWd: r.taxableWd / deflator,
        preTaxWd: r.preTaxWd / deflator,
        postTaxWd: r.postTaxWd / deflator,
        preTaxBal: r.preTaxBal / deflator,
        postTaxBal: r.postTaxBal / deflator,
        taxableBal: r.taxableBal / deflator,
        totalPortfolio: r.totalPortfolio / deflator,
        taxableMagi: r.taxableMagi / deflator,
        conversionTaxPaid: r.conversionTaxPaid / deflator,
        rmdTaxPaid: r.rmdTaxPaid / deflator,
        fedTaxPaid: r.fedTaxPaid / deflator,
        stateTaxPaid: r.stateTaxPaid / deflator,
        ficaTaxPaid: r.ficaTaxPaid / deflator,
        preTaxContrib: r.preTaxContrib / deflator,
        postTaxContrib: r.postTaxContrib / deflator,
        taxableContrib: r.taxableContrib / deflator,
      };
    });
  }, [currentSim.rows, displayFrame, primary.currentAge, macro.generalInflation]);

  // Context-aware Lifetime Tax Totals
  const baselineLifetimeTotalTax = displayFrame === 'real' ? baselineSim.lifetimeTotalTaxReal : baselineSim.lifetimeTotalTaxNominal;
  const strategyLifetimeTotalTax = displayFrame === 'real' ? currentSim.lifetimeTotalTaxReal : currentSim.lifetimeTotalTaxNominal;
  const lifetimeTaxSavings = baselineLifetimeTotalTax - strategyLifetimeTotalTax;

  const retirementRow = projection.find(r => r.age === primary.retirementAge) || projection[0];

  const step4Validations = runStep4Validations(plan);

  const filteredRows = useMemo(() => {
    if (activeDecade === 'gap') {
      return projection.filter(r => r.age >= primary.retirementAge && r.age < statutory.rmdStartAge);
    }
    if (activeDecade === 'rmd') {
      return projection.filter(r => r.age >= statutory.rmdStartAge);
    }
    return projection;
  }, [projection, activeDecade, primary.retirementAge, statutory.rmdStartAge]);

  // Relevance flags for chart series to omit zero/irrelevant assets from the legend
  const retiredRows = useMemo(() => projection.filter(r => r.isRetired), [projection]);
  const hasPrimarySs = useMemo(() => retiredRows.some(r => r.primarySs > 0), [retiredRows]);
  const hasSpouseSs = useMemo(() => retiredRows.some(r => r.spouseSs > 0), [retiredRows]);
  const hasPension = useMemo(() => retiredRows.some(r => r.pensionIncome > 0), [retiredRows]);
  const hasTaxableWd = useMemo(() => retiredRows.some(r => r.taxableWd > 0), [retiredRows]);
  const hasPreTaxWd = useMemo(() => retiredRows.some(r => r.preTaxWd > 0), [retiredRows]);
  const hasPostTaxWd = useMemo(() => retiredRows.some(r => r.postTaxWd > 0), [retiredRows]);
  const hasRothConv = useMemo(() => retiredRows.some(r => r.rothConversion > 0), [retiredRows]);

  return (
    <div className="space-y-8 w-full pb-12">
      
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
              Step 4
            </span>
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">
              Cash Flow & Tax-Efficient Spending Engine
            </span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 mt-1">
            Multi-Year Cash Flow, Social Security & Roth Tax Strategy
          </h1>
          <p className="text-sm text-slate-600 mt-1 max-w-3xl">
            Simulate retirement spending profiles, Social Security claiming strategy, Roth conversion tax bracket filling, and Medicare IRMAA surcharge boundaries.
          </p>
        </div>

        <div className="flex items-center space-x-3 shrink-0">
          <button
            onClick={onGoToValidations}
            className="flex items-center space-x-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-sm font-semibold rounded-lg transition-colors border border-slate-200"
          >
            <span>Validations</span>
            <span className="ml-1 px-1.5 py-0.5 text-xs bg-slate-200 rounded-full font-bold">
              {step4Validations.length}
            </span>
          </button>

          {onGoToNextStep && (
            <button
              onClick={onGoToNextStep}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors"
            >
              <span>Step 5: Stress Test</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Frame Context & View Options Toolbar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
        <div className="flex items-center space-x-2 text-xs font-medium text-slate-700">
          <Sparkles className={`w-4 h-4 ${displayFrame === 'real' ? 'text-emerald-600' : 'text-amber-600'}`} />
          <span>
            {displayFrame === 'real' ? (
              <>
                <strong>Real (Today's Dollars) View Active:</strong> All figures deflated to constant 2026 purchasing power using <strong>{macro.generalInflation}%</strong> CPI inflation.
              </>
            ) : (
              <>
                <strong>Nominal (Future Dollars) View Active:</strong> All figures compounded at <strong>{macro.generalInflation}%</strong> annual inflation.
              </>
            )}
          </span>
        </div>

        {/* Real vs Nominal Frame Toggle Control */}
        <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 shrink-0">
          <button
            type="button"
            onClick={() => setDisplayFrame('real')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1.5 ${
              displayFrame === 'real'
                ? 'bg-white text-blue-900 shadow-xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
            title="Express all future income, spending, and portfolio balances in constant 2026 purchasing power"
          >
            <span>Today's Dollars (Real 2026)</span>
            <span className="text-[9px] bg-emerald-100 text-emerald-800 font-extrabold px-1.5 py-0.5 rounded">REAL</span>
          </button>

          <button
            type="button"
            onClick={() => setDisplayFrame('nominal')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1.5 ${
              displayFrame === 'nominal'
                ? 'bg-white text-indigo-900 shadow-xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
            title="Express all future figures in raw future inflated dollars"
          >
            <span>Future Dollars (Nominal)</span>
            <span className="text-[9px] bg-amber-100 text-amber-800 font-extrabold px-1.5 py-0.5 rounded">NOMINAL</span>
          </button>
        </div>
      </div>

      {/* Quick KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Retirement Spending Need</span>
          <div className="mt-2 text-2xl font-bold text-slate-900">
            ${Math.round(retirementRow.totalExpenseNeed).toLocaleString()}
            <span className="text-xs font-normal text-slate-500">/yr</span>
          </div>
          <p className="mt-1 text-xs text-slate-500">Model: <strong className="text-slate-800 capitalize">{(spending.spendingModel || 'blanchett_smile').replace('_', ' ')}</strong></p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Guaranteed Annual Income</span>
          <div className="mt-2 text-2xl font-bold text-emerald-700">
            ${Math.round(retirementRow.guaranteedIncome).toLocaleString()}
            <span className="text-xs font-normal text-slate-500">/yr</span>
          </div>
          <p className="mt-1 text-xs text-slate-500">Social Security & Pensions</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Roth Conversion Strategy</span>
          <div className="mt-2 text-2xl font-bold text-amber-600">
            {activeStrategy.rothConversion.type === 'none' ? (
              <span>None</span>
            ) : activeStrategy.rothConversion.type === 'fill_bracket' ? (
              <span>Fill {activeStrategy.rothConversion.bracket * 100}%</span>
            ) : (
              <span>
                ${activeStrategy.rothConversion.annualTarget.toLocaleString()}
                <span className="text-xs font-normal text-slate-500">/yr</span>
              </span>
            )}
          </div>
          <p className="mt-1 text-xs text-slate-500">
            {activeStrategy.rothConversion.type === 'none'
              ? 'Zero conversions planned'
              : `Ages ${activeStrategy.rothConversion.startAge} to ${activeStrategy.rothConversion.endAge}`}
          </p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Net Lifetime Tax Savings</span>
          <div className={`mt-2 text-2xl font-bold ${lifetimeTaxSavings >= 0 ? 'text-indigo-700' : 'text-rose-700'}`}>
            {lifetimeTaxSavings >= 0
              ? `$${Math.round(lifetimeTaxSavings).toLocaleString()}`
              : `-$${Math.round(Math.abs(lifetimeTaxSavings)).toLocaleString()}`}
          </div>
          <p className="mt-1 text-xs text-slate-500">
            Total tax change vs baseline ({displayFrame === 'real' ? "Today's $" : 'Future $'})
          </p>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SECTION 1: SOCIAL SECURITY CLAIMING STRATEGY                             */}
      {/* ========================================================================= */}
      <section className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-200 pb-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
              <ShieldCheck className="w-5 h-5 text-blue-600" />
              <span>1. Social Security Claiming Strategy</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Adjust claim ages between 62 (Early) and 70 (Delayed Retirement Credits). Delaying claims opens low-income gap years for tax-free Roth conversions.
            </p>
          </div>
          <span className="text-xs font-bold text-blue-800 bg-blue-50 px-3 py-1 rounded-lg border border-blue-200 shrink-0">
            Social Security Strategy Levers
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Primary Person SS Claim Control */}
          <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <div>
                <span className="font-bold text-slate-900 text-sm">{primary.name} ({primary.currentAge} yrs)</span>
                <span className="block text-[11px] text-slate-500">FRA: Age {statutory.fullRetirementAge} | Benefit at FRA: ${primary.ssMonthlyBenefit.toLocaleString()}/mo</span>
              </div>
              <span className="text-sm font-extrabold text-blue-900 bg-blue-100 px-3 py-1 rounded-lg border border-blue-200">
                Age {primary.ssClaimAge}
              </span>
            </div>

            <div className="space-y-2 pt-1">
              <div className="flex justify-between text-[11px] font-bold text-slate-500">
                <span>Age 62 (Early: -30%)</span>
                <span>FRA 67 (100%)</span>
                <span>Age 70 (+24% Delayed)</span>
              </div>
              <input
                type="range"
                min="62"
                max="70"
                step="1"
                value={primary.ssClaimAge}
                onChange={(e) => {
                  const val = parseInt(e.target.value) || 67;
                  onUpdatePlan({
                    ...plan,
                    primaryPerson: { ...plan.primaryPerson, ssClaimAge: val },
                  });
                }}
                className="w-full accent-blue-600 h-2.5 bg-slate-200 rounded-lg cursor-pointer"
              />
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs pt-1">
              <div className="bg-white p-3 rounded-lg border border-slate-200">
                <span className="text-slate-500 block text-[11px]">Monthly Payable</span>
                <span className="font-bold text-slate-900 text-sm">
                  ${Math.round(getSsAnnualBenefit(primary, primary.ssClaimAge, statutory) / 12).toLocaleString()} / mo
                </span>
              </div>
              <div className="bg-white p-3 rounded-lg border border-slate-200">
                <span className="text-slate-500 block text-[11px]">Low-Income Gap Window</span>
                <span className="font-bold text-amber-800 text-sm">
                  {Math.max(0, primary.ssClaimAge - primary.retirementAge)} Gap Years
                </span>
              </div>
            </div>
          </div>

          {/* Spouse Person SS Claim Control */}
          {plan.hasSpouse ? (
            <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                <div>
                  <span className="font-bold text-slate-900 text-sm">{spouse.name} ({spouse.currentAge} yrs)</span>
                  <span className="block text-[11px] text-slate-500">FRA: Age {statutory.fullRetirementAge} | Benefit at FRA: ${spouse.ssMonthlyBenefit.toLocaleString()}/mo</span>
                </div>
                <span className="text-sm font-extrabold text-indigo-900 bg-indigo-100 px-3 py-1 rounded-lg border border-indigo-200">
                  Age {spouse.ssClaimAge}
                </span>
              </div>

              <div className="space-y-2 pt-1">
                <div className="flex justify-between text-[11px] font-bold text-slate-500">
                  <span>Age 62 (Early: -30%)</span>
                  <span>FRA 67 (100%)</span>
                  <span>Age 70 (+24% Delayed)</span>
                </div>
                <input
                  type="range"
                  min="62"
                  max="70"
                  step="1"
                  value={spouse.ssClaimAge}
                  onChange={(e) => {
                    const val = parseInt(e.target.value) || 67;
                    onUpdatePlan({
                      ...plan,
                      spousePerson: { ...plan.spousePerson, ssClaimAge: val },
                    });
                  }}
                  className="w-full accent-indigo-600 h-2.5 bg-slate-200 rounded-lg cursor-pointer"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs pt-1">
                <div className="bg-white p-3 rounded-lg border border-slate-200">
                  <span className="text-slate-500 block text-[11px]">Monthly Payable</span>
                  <span className="font-bold text-slate-900 text-sm">
                    ${Math.round(getSsAnnualBenefit(spouse, spouse.ssClaimAge, statutory) / 12).toLocaleString()} / mo
                  </span>
                </div>
                <div className="bg-white p-3 rounded-lg border border-slate-200">
                  <span className="text-slate-500 block text-[11px]">Low-Income Gap Window</span>
                  <span className="font-bold text-amber-800 text-sm">
                    {Math.max(0, spouse.ssClaimAge - spouse.retirementAge)} Gap Years
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-slate-50 p-5 rounded-xl border border-dashed border-slate-200 flex flex-col items-center justify-center text-center space-y-1">
              <span className="font-bold text-slate-700 text-xs">Single Household Plan</span>
              <p className="text-[11px] text-slate-500">No spousal Social Security claiming strategy active.</p>
            </div>
          )}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 2: MULTI-YEAR CASH FLOW CHART & ANALYSIS                          */}
      {/* ========================================================================= */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-4">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 border-b border-slate-200 pb-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
              <BarChart3 className="w-5 h-5 text-blue-600" />
              <span>2. Multi-Year Income, Withdrawal & MAGI Tax Overlay Chart</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Visual breakdown of cash flow sources against federal tax bracket ceilings and Medicare IRMAA thresholds
            </p>
          </div>

          {/* Overlay Toggle Buttons */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <button
              onClick={() => setShowTaxBrackets(!showTaxBrackets)}
              className={`px-3 py-1.5 rounded-lg border font-semibold flex items-center space-x-1.5 transition-colors ${
                showTaxBrackets ? 'bg-amber-100 border-amber-300 text-amber-900' : 'bg-slate-50 border-slate-200 text-slate-600'
              }`}
            >
              <Percent className="w-3.5 h-3.5 text-amber-600" />
              <span>Tax Bracket Overlays</span>
            </button>

            <button
              onClick={() => setShowIrmaaTiers(!showIrmaaTiers)}
              className={`px-3 py-1.5 rounded-lg border font-semibold flex items-center space-x-1.5 transition-colors ${
                showIrmaaTiers ? 'bg-indigo-100 border-indigo-300 text-indigo-900' : 'bg-slate-50 border-slate-200 text-slate-600'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5 text-indigo-600" />
              <span>IRMAA Threshold Lines</span>
            </button>

            <button
              onClick={() => setShowEssentialVsDisc(!showEssentialVsDisc)}
              className={`px-3 py-1.5 rounded-lg border font-semibold flex items-center space-x-1.5 transition-colors ${
                showEssentialVsDisc ? 'bg-emerald-100 border-emerald-300 text-emerald-900' : 'bg-slate-50 border-slate-200 text-slate-600'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-emerald-600" />
              <span>Essential / Discretionary</span>
            </button>
          </div>
        </div>

        <div className="h-96 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={projection.filter(r => r.isRetired)} margin={{ top: 15, right: 25, left: 15, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="age" tick={{ fontSize: 11, fill: '#64748b' }} />
              <YAxis tickFormatter={(val) => `$${Math.round(val / 1000)}k`} tick={{ fontSize: 11, fill: '#64748b' }} />
              <Tooltip 
                content={({ active, payload, label }) => {
                  if (!active || !payload || !payload.length) return null;
                  const rowData = payload[0]?.payload;
                  const isRetireAge = label === primary.retirementAge;
                  const isRmdAge = label === statutory.rmdStartAge;

                  return (
                    <div className="bg-white/95 backdrop-blur-xs p-3.5 rounded-xl shadow-xl text-xs space-y-2.5 border border-slate-200 min-w-[250px] z-50">
                      <div className="font-bold border-b border-slate-200 pb-2 flex items-center justify-between gap-2">
                        <div className="flex items-center space-x-1.5">
                          <span className="text-slate-900 font-extrabold text-sm">Age {label}</span>
                          {isRetireAge && (
                            <span className="px-1.5 py-0.5 text-[10px] bg-blue-100 text-blue-800 font-bold rounded">
                              Retire
                            </span>
                          )}
                          {isRmdAge && (
                            <span className="px-1.5 py-0.5 text-[10px] bg-amber-100 text-amber-800 font-bold rounded">
                              RMD Start
                            </span>
                          )}
                        </div>
                        {rowData?.totalPortfolio !== undefined && (
                          <span className="text-[11px] font-mono text-slate-500 font-medium">
                            Portfolio: ${Math.round(rowData.totalPortfolio).toLocaleString()}
                          </span>
                        )}
                      </div>

                      <div className="space-y-1.5">
                        {payload.map((entry: any, idx: number) => {
                          const val = Number(entry.value || 0);
                          if (val === 0 && entry.dataKey !== 'totalExpenseNeed' && entry.dataKey !== 'taxableMagi') {
                            return null;
                          }
                          return (
                            <div key={`tooltip-item-${idx}`} className="flex items-center justify-between gap-3">
                              <div className="flex items-center space-x-2 min-w-0">
                                <span
                                  className="w-2.5 h-2.5 rounded-full shrink-0"
                                  style={{ backgroundColor: entry.fill || entry.stroke || entry.color }}
                                />
                                <span className="text-slate-700 font-medium truncate">
                                  {entry.name}
                                </span>
                              </div>
                              <span className="font-mono font-bold text-slate-900 shrink-0">
                                ${Math.round(val).toLocaleString()}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                }}
              />
              <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />

              {/* Vertical Milestone Lines */}
              <ReferenceLine x={primary.retirementAge} stroke="#3b82f6" strokeDasharray="3 3" label={{ value: 'Retire', fill: '#1d4ed8', fontSize: 11 }} />
              <ReferenceLine x={statutory.rmdStartAge} stroke="#f59e0b" strokeDasharray="3 3" label={{ value: `RMD Age ${statutory.rmdStartAge}`, fill: '#b45309', fontSize: 11 }} />

              {/* Horizontal Tax Bracket Overlay Lines */}
              {showTaxBrackets && (
                <>
                  <ReferenceLine y={bracketCeilings.b12} stroke="#f59e0b" strokeDasharray="4 4" label={{ value: formatBracketLabel('12%', bracketCeilings.b12), fill: '#d97706', fontSize: 10, position: 'right' }} />
                  <ReferenceLine y={bracketCeilings.b22} stroke="#d97706" strokeDasharray="4 4" label={{ value: formatBracketLabel('22%', bracketCeilings.b22), fill: '#b45309', fontSize: 10, position: 'right' }} />
                </>
              )}

              {/* Horizontal IRMAA Threshold Lines */}
              {showIrmaaTiers && (
                <>
                  <ReferenceLine y={irmaaTier1} stroke="#6366f1" strokeWidth={2} label={{ value: `IRMAA Tier 1 ($${Math.round(irmaaTier1/1000)}k)`, fill: '#4338ca', fontSize: 10, position: 'left' }} />
                  <ReferenceLine y={irmaaTier2} stroke="#818cf8" strokeDasharray="3 3" label={{ value: `IRMAA Tier 2 ($${Math.round(irmaaTier2/1000)}k)`, fill: '#4f46e5', fontSize: 10, position: 'left' }} />
                </>
              )}

              {/* Stacked Bar Cash Flow Components */}
              {hasPrimarySs && <Bar dataKey="primarySs" name="Primary Social Security" stackId="a" fill="#10b981" />}
              {hasSpouseSs && <Bar dataKey="spouseSs" name="Spouse Social Security" stackId="a" fill="#34d399" />}
              {hasPension && <Bar dataKey="pensionIncome" name="Pension Income" stackId="a" fill="#059669" />}
              {hasTaxableWd && <Bar dataKey="taxableWd" name="Taxable Brokerage W/D" stackId="a" fill="#3b82f6" />}
              {hasPreTaxWd && <Bar dataKey="preTaxWd" name="Pre-Tax IRA/401k W/D" stackId="a" fill="#f59e0b" />}
              {hasPostTaxWd && <Bar dataKey="postTaxWd" name="Post-Tax Roth W/D" stackId="a" fill="#8b5cf6" />}
              {hasRothConv && <Bar dataKey="rothConversion" name="Actual Roth Conversion" stackId="a" fill="#a855f7" opacity={0.6} />}

              {/* Spending Need Lines */}
              <Line type="monotone" dataKey="totalExpenseNeed" name="Total Expense Need" stroke="#ef4444" strokeWidth={2.5} dot={false} />
              
              {showEssentialVsDisc && (
                <>
                  <Line type="monotone" dataKey="essentialExpense" name="Essential Living Floor" stroke="#059669" strokeWidth={1.5} strokeDasharray="2 2" dot={false} />
                  <Line type="monotone" dataKey="discretionaryExpense" name="Discretionary Ceiling" stroke="#3b82f6" strokeWidth={1.5} strokeDasharray="2 2" dot={false} />
                </>
              )}

              <Line type="monotone" dataKey="taxableMagi" name="Estimated MAGI" stroke="#6366f1" strokeWidth={1.8} dot={false} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 3: ROTH CONVERSION IMPACT ANALYSIS                                */}
      {/* ========================================================================= */}
      <RothConversionImpactAnalysis
        plan={plan}
        currentSim={currentSim}
        baselineSim={baselineSim}
        displayFrame={displayFrame}
        statutoryRmdAge={statutory.rmdStartAge}
        onGoToStrategy={onGoToStrategy}
      />

      {/* ========================================================================= */}
      {/* SECTION 4: TAX & IRMAA SURCHARGE REFERENCE TABLES                         */}
      {/* ========================================================================= */}
      <section className="space-y-6">
        {/* IRMAA Surcharge Reference Card */}
        {showIrmaaTiers && (
          <div className="bg-indigo-50/60 rounded-xl border border-indigo-200 p-5 space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-indigo-200 pb-3">
              <div className="flex items-center space-x-2">
                <ShieldAlert className="w-5 h-5 text-indigo-700" />
                <h3 className="text-sm font-bold text-indigo-950">
                  Official CMS Medicare Part B & Part D IRMAA Surcharge Brackets
                </h3>
              </div>
              <span className="text-xs font-semibold px-2.5 py-1 bg-indigo-100 text-indigo-800 rounded-full">
                Filing Status: <strong className="uppercase">{plan.filingStatus}</strong>
              </span>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Medicare Income-Related Monthly Adjustment Amounts (IRMAA) are cliff-based premium surcharges based on your Modified Adjusted Gross Income (MAGI) from <strong>2 years prior</strong>. Crossing a threshold by even $1 triggers the full monthly surcharge for the entire calendar year.
            </p>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs bg-white rounded-lg border border-indigo-200 overflow-hidden">
                <thead className="bg-indigo-100/70 text-indigo-950 font-semibold border-b border-indigo-200">
                  <tr>
                    <th className="py-2 px-3">IRMAA Tier</th>
                    <th className="py-2 px-3">Single / Individual MAGI</th>
                    <th className="py-2 px-3">Joint / Couple MAGI</th>
                    <th className="py-2 px-3 text-right">Part B Surcharge / mo</th>
                    <th className="py-2 px-3 text-right">Part D Surcharge / mo</th>
                    <th className="py-2 px-3 text-right font-bold">Total Annual Surcharge (Per Person)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-indigo-100 font-mono text-[11px]">
                  {[
                    {
                      tier: 'Tier 0 (Base)',
                      single: `≤ ${IRMAA_THRESHOLDS.single[0].toLocaleString()}`,
                      joint: `≤ ${IRMAA_THRESHOLDS.joint[0].toLocaleString()}`,
                      partB: '$0.00',
                      partD: '$0.00',
                      annual: '$0 / yr',
                    },
                    {
                      tier: 'Tier 1',
                      single: `${(IRMAA_THRESHOLDS.single[0] + 1).toLocaleString()} – ${IRMAA_THRESHOLDS.single[1].toLocaleString()}`,
                      joint: `${(IRMAA_THRESHOLDS.joint[0] + 1).toLocaleString()} – ${IRMAA_THRESHOLDS.joint[1].toLocaleString()}`,
                      partB: '+$74.20',
                      partD: '+$21.50',
                      annual: `${IRMAA_REGISTRY.surchargesPerPerson2026.tier1.toLocaleString()} / yr`,
                    },
                    {
                      tier: 'Tier 2',
                      single: `${(IRMAA_THRESHOLDS.single[1] + 1).toLocaleString()} – ${IRMAA_THRESHOLDS.single[2].toLocaleString()}`,
                      joint: `${(IRMAA_THRESHOLDS.joint[1] + 1).toLocaleString()} – ${IRMAA_THRESHOLDS.joint[2].toLocaleString()}`,
                      partB: '+$185.60',
                      partD: '+$54.80',
                      annual: `${IRMAA_REGISTRY.surchargesPerPerson2026.tier2.toLocaleString()} / yr`,
                    },
                    {
                      tier: 'Tier 3',
                      single: `${(IRMAA_THRESHOLDS.single[2] + 1).toLocaleString()} – ${IRMAA_THRESHOLDS.single[3].toLocaleString()}`,
                      joint: `${(IRMAA_THRESHOLDS.joint[2] + 1).toLocaleString()} – ${IRMAA_THRESHOLDS.joint[3].toLocaleString()}`,
                      partB: '+$296.90',
                      partD: '+$88.10',
                      annual: `${IRMAA_REGISTRY.surchargesPerPerson2026.tier3.toLocaleString()} / yr`,
                    },
                    {
                      tier: 'Tier 4',
                      single: `${(IRMAA_THRESHOLDS.single[3] + 1).toLocaleString()} – ${IRMAA_THRESHOLDS.single[4].toLocaleString()}`,
                      joint: `${(IRMAA_THRESHOLDS.joint[3] + 1).toLocaleString()} – ${IRMAA_THRESHOLDS.joint[4].toLocaleString()}`,
                      partB: '+$408.20',
                      partD: '+$121.40',
                      annual: `${IRMAA_REGISTRY.surchargesPerPerson2026.tier4.toLocaleString()} / yr`,
                    },
                    {
                      tier: 'Tier 5 (Max)',
                      single: `≥ ${IRMAA_THRESHOLDS.single[4].toLocaleString()}`,
                      joint: `≥ ${IRMAA_THRESHOLDS.joint[4].toLocaleString()}`,
                      partB: '+$445.30',
                      partD: '+$132.70',
                      annual: `${IRMAA_REGISTRY.surchargesPerPerson2026.tier5.toLocaleString()} / yr`,
                    },
                  ].map((row, idx) => (
                    <tr key={idx} className="hover:bg-indigo-50/50">
                      <td className="py-2 px-3 font-bold font-sans text-indigo-900">{row.tier}</td>
                      <td className="py-2 px-3">{row.single}</td>
                      <td className="py-2 px-3">{row.joint}</td>
                      <td className="py-2 px-3 text-right text-indigo-900 font-semibold">{row.partB}</td>
                      <td className="py-2 px-3 text-right text-indigo-900 font-semibold">{row.partD}</td>
                      <td className="py-2 px-3 text-right font-bold text-indigo-950">{row.annual}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Federal Income Tax Brackets Reference Card */}
        {showTaxBrackets && (
          <div className="bg-amber-50/60 rounded-xl border border-amber-200 p-5 space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-amber-200 pb-3">
              <div className="flex items-center space-x-2">
                <Percent className="w-5 h-5 text-amber-700" />
                <h3 className="text-sm font-bold text-amber-950">
                  Official Federal Ordinary Income Tax Brackets & Standard Deduction
                </h3>
              </div>
              <span className="text-xs font-semibold px-2.5 py-1 bg-amber-100 text-amber-900 rounded-full">
                Standard Deduction: <strong className="font-bold">${stdDeduction.toLocaleString()}</strong> ({plan.filingStatus})
              </span>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Federal marginal tax rates apply to taxable income <em>after</em> subtracting the standard deduction (${stdDeduction.toLocaleString()}). Use low-income gap years to fill the 10%, 12%, and 22% brackets with Roth conversions prior to Social Security and mandatory RMDs.
            </p>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs bg-white rounded-lg border border-amber-200 overflow-hidden">
                <thead className="bg-amber-100/70 text-amber-950 font-semibold border-b border-amber-200">
                  <tr>
                    <th className="py-2 px-3">Tax Rate</th>
                    <th className="py-2 px-3">Single / Individual Taxable Income</th>
                    <th className="py-2 px-3">Joint / Couple Taxable Income</th>
                    <th className="py-2 px-3 text-right">Gross Income Top Limit (Single)</th>
                    <th className="py-2 px-3 text-right">Gross Income Top Limit (Joint)</th>
                    <th className="py-2 px-3 text-right font-bold">Roth Bracket Fill Strategy</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-amber-100 font-mono text-[11px]">
                  {[
                    {
                      rate: '10%',
                      singleRange: `$0 – ${BRACKET_CEILINGS_2026.single.b10.toLocaleString()}`,
                      jointRange: `$0 – ${BRACKET_CEILINGS_2026.joint.b10.toLocaleString()}`,
                      singleGross: `${(BRACKET_CEILINGS_2026.single.b10 + STANDARD_DEDUCTION_2026.single).toLocaleString()}`,
                      jointGross: `${(BRACKET_CEILINGS_2026.joint.b10 + STANDARD_DEDUCTION_2026.joint).toLocaleString()}`,
                      strategy: 'Lowest Rate / Must Fill',
                      color: 'text-emerald-700 font-bold',
                    },
                    {
                      rate: '12%',
                      singleRange: `${(BRACKET_CEILINGS_2026.single.b10 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.single.b12.toLocaleString()}`,
                      jointRange: `${(BRACKET_CEILINGS_2026.joint.b10 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.joint.b12.toLocaleString()}`,
                      singleGross: `${(BRACKET_CEILINGS_2026.single.b12 + STANDARD_DEDUCTION_2026.single).toLocaleString()}`,
                      jointGross: `${(BRACKET_CEILINGS_2026.joint.b12 + STANDARD_DEDUCTION_2026.joint).toLocaleString()}`,
                      strategy: 'Sweet Spot Conversion Target',
                      color: 'text-emerald-700 font-bold',
                    },
                    {
                      rate: '22%',
                      singleRange: `${(BRACKET_CEILINGS_2026.single.b12 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.single.b22.toLocaleString()}`,
                      jointRange: `${(BRACKET_CEILINGS_2026.joint.b12 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.joint.b22.toLocaleString()}`,
                      singleGross: `${(BRACKET_CEILINGS_2026.single.b22 + STANDARD_DEDUCTION_2026.single).toLocaleString()}`,
                      jointGross: `${(BRACKET_CEILINGS_2026.joint.b22 + STANDARD_DEDUCTION_2026.joint).toLocaleString()}`,
                      strategy: 'Moderate Tax Bracket Fill',
                      color: 'text-amber-800 font-bold',
                    },
                    {
                      rate: '24%',
                      singleRange: `${(BRACKET_CEILINGS_2026.single.b22 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.single.b24.toLocaleString()}`,
                      jointRange: `${(BRACKET_CEILINGS_2026.joint.b22 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.joint.b24.toLocaleString()}`,
                      singleGross: `${(BRACKET_CEILINGS_2026.single.b24 + STANDARD_DEDUCTION_2026.single).toLocaleString()}`,
                      jointGross: `${(BRACKET_CEILINGS_2026.joint.b24 + STANDARD_DEDUCTION_2026.joint).toLocaleString()}`,
                      strategy: 'Upper Middle Tier',
                      color: 'text-slate-700 font-medium',
                    },
                    {
                      rate: '32%',
                      singleRange: `${(BRACKET_CEILINGS_2026.single.b24 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.single.b32.toLocaleString()}`,
                      jointRange: `${(BRACKET_CEILINGS_2026.joint.b24 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.joint.b32.toLocaleString()}`,
                      singleGross: `${(BRACKET_CEILINGS_2026.single.b32 + STANDARD_DEDUCTION_2026.single).toLocaleString()}`,
                      jointGross: `${(BRACKET_CEILINGS_2026.joint.b32 + STANDARD_DEDUCTION_2026.joint).toLocaleString()}`,
                      strategy: 'High Tax Rate',
                      color: 'text-slate-600',
                    },
                    {
                      rate: '35%',
                      singleRange: `${(BRACKET_CEILINGS_2026.single.b32 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.single.b35.toLocaleString()}`,
                      jointRange: `${(BRACKET_CEILINGS_2026.joint.b32 + 1).toLocaleString()} – ${BRACKET_CEILINGS_2026.joint.b35.toLocaleString()}`,
                      singleGross: `${(BRACKET_CEILINGS_2026.single.b35 + STANDARD_DEDUCTION_2026.single).toLocaleString()}`,
                      jointGross: `${(BRACKET_CEILINGS_2026.joint.b35 + STANDARD_DEDUCTION_2026.joint).toLocaleString()}`,
                      strategy: 'High Bracket',
                      color: 'text-rose-800',
                    },
                    {
                      rate: '37%',
                      singleRange: `> ${BRACKET_CEILINGS_2026.single.b35.toLocaleString()}`,
                      jointRange: `> ${BRACKET_CEILINGS_2026.joint.b35.toLocaleString()}`,
                      singleGross: `> ${(BRACKET_CEILINGS_2026.single.b35 + STANDARD_DEDUCTION_2026.single).toLocaleString()}`,
                      jointGross: `> ${(BRACKET_CEILINGS_2026.joint.b35 + STANDARD_DEDUCTION_2026.joint).toLocaleString()}`,
                      strategy: 'Top Bracket',
                      color: 'text-rose-950 font-bold',
                    },
                  ].map((row, idx) => (
                    <tr key={idx} className="hover:bg-amber-50/50">
                      <td className="py-2 px-3 font-bold font-sans text-amber-900">{row.rate}</td>
                      <td className="py-2 px-3">{row.singleRange}</td>
                      <td className="py-2 px-3">{row.jointRange}</td>
                      <td className="py-2 px-3 text-right font-sans text-slate-700">{row.singleGross}</td>
                      <td className="py-2 px-3 text-right font-sans text-slate-700">{row.jointGross}</td>
                      <td className={`py-2 px-3 text-right font-sans ${row.color}`}>{row.strategy}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </section>

      {/* ========================================================================= */}
      {/* SECTION 5: DETAILED YEAR-BY-YEAR CASH FLOW SCHEDULE                       */}
      {/* ========================================================================= */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-50/50">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
              <Receipt className="w-5 h-5 text-blue-600" />
              <span>4. Detailed Multi-Year Cash Flow & RMD Schedule</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Complete accounting of living needs, guaranteed income, bucket draws, conversions, and ending portfolio
            </p>
          </div>

          <div className="flex items-center space-x-1 bg-white p-1 rounded-lg border border-slate-200 shadow-xs shrink-0">
            <button
              onClick={() => setActiveDecade('all')}
              className={`px-3 py-1 rounded-md text-xs font-semibold transition-colors ${
                activeDecade === 'all' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              All Years ({projection.length})
            </button>
            <button
              onClick={() => setActiveDecade('gap')}
              className={`px-3 py-1 rounded-md text-xs font-semibold transition-colors ${
                activeDecade === 'gap' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              Gap Window
            </button>
            <button
              onClick={() => setActiveDecade('rmd')}
              className={`px-3 py-1 rounded-md text-xs font-semibold transition-colors ${
                activeDecade === 'rmd' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              RMD Years ({statutory.rmdStartAge}+)
            </button>
          </div>
        </div>

        <div className="overflow-x-auto max-h-[550px]">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="sticky top-0 bg-slate-100 text-slate-700 font-semibold border-b border-slate-200 shadow-xs z-10">
              <tr>
                <th className="py-2.5 px-3">Age</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Essential Need</th>
                <th className="py-2.5 px-3 text-right">Discretionary</th>
                <th className="py-2.5 px-3 text-right">Total Need</th>
                <th className="py-2.5 px-3 text-right">Guaranteed Inc.</th>
                <th className="py-2.5 px-3 text-right">Taxable Draw</th>
                <th className="py-2.5 px-3 text-right">Pre-Tax Draw</th>
                <th className="py-2.5 px-3 text-right">Roth Conv.</th>
                <th className="py-2.5 px-3 text-right">RMD Amount</th>
                <th className="py-2.5 px-3 text-right font-bold text-slate-900">Total Portfolio</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 font-mono">
              {filteredRows.map((r) => (
                <tr 
                  key={r.age} 
                  className={`hover:bg-slate-50/80 transition-colors ${
                    r.age === primary.retirementAge ? 'bg-blue-50/60 font-medium' :
                    r.age === statutory.rmdStartAge ? 'bg-amber-50/60 font-medium' : ''
                  }`}
                >
                  <td className="py-2.5 px-3 font-bold text-slate-900 font-sans">{r.age}</td>

                  <td className="py-2.5 px-3 font-sans">
                    <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${
                      !r.isRetired ? 'bg-slate-200 text-slate-700' :
                      r.age === primary.retirementAge ? 'bg-blue-600 text-white' :
                      r.age === statutory.rmdStartAge ? 'bg-amber-500 text-white' :
                      'bg-emerald-100 text-emerald-800'
                    }`}>
                      {!r.isRetired ? 'Working' : r.age === primary.retirementAge ? 'Retire' : r.age === statutory.rmdStartAge ? 'RMD' : 'Retired'}
                    </span>
                  </td>

                  <td className="py-2.5 px-3 text-right text-emerald-800">
                    {r.essentialExpense > 0 ? `$${Math.round(r.essentialExpense).toLocaleString()}` : '—'}
                  </td>

                  <td className="py-2.5 px-3 text-right text-blue-700">
                    {r.discretionaryExpense > 0 ? `$${Math.round(r.discretionaryExpense).toLocaleString()}` : '—'}
                  </td>

                  <td className="py-2.5 px-3 text-right font-bold text-slate-900">
                    {r.totalExpenseNeed > 0 ? `$${Math.round(r.totalExpenseNeed).toLocaleString()}` : '—'}
                  </td>

                  <td className="py-2.5 px-3 text-right text-emerald-700">
                    {r.guaranteedIncome > 0 ? `$${Math.round(r.guaranteedIncome).toLocaleString()}` : '—'}
                  </td>

                  <td className="py-2.5 px-3 text-right text-blue-700">
                    {r.taxableWd > 0 ? `$${Math.round(r.taxableWd).toLocaleString()}` : '—'}
                  </td>

                  <td className="py-2.5 px-3 text-right text-amber-700">
                    {r.preTaxWd > 0 ? `$${Math.round(r.preTaxWd).toLocaleString()}` : '—'}
                  </td>

                  <td className="py-2.5 px-3 text-right font-bold text-purple-700">
                    {r.rothConversion > 0 ? `$${Math.round(r.rothConversion).toLocaleString()}` : '—'}
                  </td>

                  <td className="py-2.5 px-3 text-right text-amber-800 font-bold">
                    {r.rmdAmount > 0 ? `$${Math.round(r.rmdAmount).toLocaleString()}` : '—'}
                  </td>

                  <td className="py-2.5 px-3 text-right font-bold font-sans text-slate-900">
                    ${Math.round(r.totalPortfolio).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

    </div>
  );
};
