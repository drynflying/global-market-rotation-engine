import React, { useState, useMemo } from 'react';
import { Plan } from '../types';
import { UpdateOptions } from '../store/usePlanStore';
import { getSimulation } from '../domain/simulation/simulationCache';
import { resolveRetirementStrategy } from '../domain/strategy/strategyResolver';
import { DEFAULT_PLAN } from '../constants/defaultPlan';
import {
  WITHDRAWAL_POLICIES,
  WithdrawalPolicyId,
  ConversionStrategyType,
  ConversionTaxPaymentSource,
} from '../domain/strategy/strategyTypes';
import {
  SlidersHorizontal,
  ShieldAlert,
  FolderKanban,
} from 'lucide-react';

import { StrategySummary } from './strategy/StrategySummary';
import { WithdrawalPolicySection } from './strategy/WithdrawalPolicySection';
import { RothConversionPolicySection } from './strategy/RothConversionPolicySection';
import { ConversionTaxSourceSection } from './strategy/ConversionTaxSourceSection';
import { RothConversionDecisionDetails } from './strategy/RothConversionDecisionDetails';
import { StrategyComparison } from './strategy/StrategyComparison';
import { StrategyTradeoffSummary } from './strategy/StrategyTradeoffSummary';

interface StrategyStepProps {
  plan: Plan;
  plans: Plan[];
  onUpdatePlan: (updatedPlan: Plan, options?: UpdateOptions) => void;
  onDuplicatePlan?: (plan: Plan, newName?: string) => void;
  onGoToValidations?: () => void;
  onGoToScenarios?: () => void;
}

export const StrategyStep: React.FC<StrategyStepProps> = ({
  plan,
  plans,
  onUpdatePlan,
  onGoToValidations,
  onGoToScenarios,
}) => {
  // Display frame for metrics: 'nominal' vs 'real'
  const [displayFrame, setDisplayFrame] = useState<'nominal' | 'real'>('nominal');

  // Selected comparison plan ID for scenario comparison
  const otherPlans = useMemo(() => plans.filter((p) => p.id !== plan.id), [plans, plan.id]);
  const [comparisonPlanId, setComparisonPlanId] = useState<string>(
    otherPlans.length > 0 ? otherPlans[0].id : plan.id
  );

  // Selected year filter for conversion explainability table
  const [explainFilter, setExplainFilter] = useState<'window' | 'all'>('window');

  // Resolve current active strategy
  const activeStrategy = useMemo(() => resolveRetirementStrategy(plan), [plan]);

  // Current plan simulation
  const currentSim = useMemo(() => getSimulation(plan), [plan]);

  const spending = plan.spendingAssumptions ?? DEFAULT_PLAN.spendingAssumptions!;
  const currentWithdrawalPolicy = activeStrategy.withdrawal.policyId;
  const currentConversionType = activeStrategy.rothConversion.type === 'manual'
    ? 'manual'
    : activeStrategy.rothConversion.type === 'none'
    ? 'none'
    : activeStrategy.rothConversion.targetBracketName;
  const currentTaxSource = activeStrategy.taxPayment.conversionTaxSource;

  const startAge = activeStrategy.rothConversion.startAge;
  const endAge = activeStrategy.rothConversion.endAge;
  const annualTarget = activeStrategy.rothConversion.annualTarget;

  // Handler functions for updating plan spendingAssumptions
  const handleUpdateWithdrawalPolicy = (policyId: WithdrawalPolicyId) => {
    onUpdatePlan(
      {
        ...plan,
        spendingAssumptions: {
          ...spending,
          withdrawalPolicy: policyId,
        },
        updatedAt: new Date().toISOString(),
      },
      { label: `Update withdrawal policy to ${WITHDRAWAL_POLICIES[policyId].name}` }
    );
  };

  const handleUpdateConversionStrategy = (strategyType: ConversionStrategyType) => {
    onUpdatePlan(
      {
        ...plan,
        spendingAssumptions: {
          ...spending,
          conversionStrategy: strategyType,
        },
        updatedAt: new Date().toISOString(),
      },
      { label: `Update Roth conversion policy to ${strategyType}` }
    );
  };

  const handleUpdateStartAge = (newStartAge: number) => {
    const validStart = Math.max(50, Math.min(95, newStartAge));
    onUpdatePlan(
      {
        ...plan,
        spendingAssumptions: {
          ...spending,
          rothConversionStartAge: validStart,
        },
        updatedAt: new Date().toISOString(),
      },
      { label: `Update Roth conversion start age to ${validStart}` }
    );
  };

  const handleUpdateEndAge = (newEndAge: number) => {
    const validEnd = Math.max(50, Math.min(95, newEndAge));
    onUpdatePlan(
      {
        ...plan,
        spendingAssumptions: {
          ...spending,
          rothConversionEndAge: validEnd,
        },
        updatedAt: new Date().toISOString(),
      },
      { label: `Update Roth conversion end age to ${validEnd}` }
    );
  };

  const handleUpdateAnnualTarget = (target: number) => {
    const validTarget = Math.max(0, target);
    onUpdatePlan(
      {
        ...plan,
        spendingAssumptions: {
          ...spending,
          annualRothConversionTarget: validTarget,
        },
        updatedAt: new Date().toISOString(),
      },
      { label: `Update annual Roth conversion target to $${validTarget.toLocaleString()}` }
    );
  };

  const handleUpdateTaxSource = (source: ConversionTaxPaymentSource) => {
    onUpdatePlan(
      {
        ...plan,
        spendingAssumptions: {
          ...spending,
          taxPaymentSource: source,
        },
        updatedAt: new Date().toISOString(),
      },
      { label: `Update conversion tax payment source` }
    );
  };

  // Filter simulation rows for explainability table
  const explainabilityRows = useMemo(() => {
    if (!currentSim || !currentSim.rows) return [];
    if (explainFilter === 'window') {
      return currentSim.rows.filter((r) => r.age >= startAge && r.age <= endAge);
    }
    return currentSim.rows;
  }, [currentSim, explainFilter, startAge, endAge]);

  return (
    <div className="space-y-6 pb-12">
      {/* 1. Header Navigation & Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-neutral-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <SlidersHorizontal className="w-5 h-5 text-indigo-600" />
            <h1 className="text-xl font-black text-neutral-900 tracking-tight">Strategy & Levers</h1>
            <span className="text-xs font-bold bg-indigo-50 text-indigo-700 px-2.5 py-0.5 rounded-full border border-indigo-200">
              Active Strategy Engine
            </span>
          </div>
          <p className="text-xs text-neutral-600 max-w-2xl">
            Configure authoritative decision policies for portfolio withdrawal ordering, Roth conversion bracket targets, and tax payment sources.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {onGoToScenarios && (
            <button
              type="button"
              onClick={onGoToScenarios}
              className="px-3 py-1.5 text-xs font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <FolderKanban className="w-3.5 h-3.5" />
              Manage Scenarios
            </button>
          )}
          {onGoToValidations && (
            <button
              type="button"
              onClick={onGoToValidations}
              className="px-3 py-1.5 text-xs font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
              Validations
            </button>
          )}
        </div>
      </div>

      {/* 2. Resolved Strategy Contract Banner */}
      <StrategySummary
        plan={plan}
        activeStrategy={activeStrategy}
        displayFrame={displayFrame}
        onToggleDisplayFrame={setDisplayFrame}
      />

      {/* 3. Withdrawal Sequence Policy Section */}
      <WithdrawalPolicySection
        currentPolicyId={currentWithdrawalPolicy}
        onUpdateWithdrawalPolicy={handleUpdateWithdrawalPolicy}
      />

      {/* 4. Roth Conversion Strategy Section */}
      <RothConversionPolicySection
        currentConversionType={currentConversionType}
        annualTarget={annualTarget}
        startAge={startAge}
        endAge={endAge}
        onUpdateConversionStrategy={handleUpdateConversionStrategy}
        onUpdateAnnualTarget={handleUpdateAnnualTarget}
        onUpdateStartAge={handleUpdateStartAge}
        onUpdateEndAge={handleUpdateEndAge}
      />

      {/* 5. Conversion Tax Liability Payment Source */}
      <ConversionTaxSourceSection
        currentTaxSource={currentTaxSource}
        onUpdateTaxSource={handleUpdateTaxSource}
      />

      {/* 6. Decision Audit & Explainability Table */}
      <RothConversionDecisionDetails
        plan={plan}
        explainabilityRows={explainabilityRows}
        explainFilter={explainFilter}
        onSetExplainFilter={setExplainFilter}
        startAge={startAge}
        endAge={endAge}
      />

      {/* 7. Strategy Comparison & Baseline */}
      <StrategyComparison
        plan={plan}
        currentSim={currentSim}
        otherPlans={otherPlans}
        comparisonPlanId={comparisonPlanId}
        onSelectComparisonPlanId={setComparisonPlanId}
        displayFrame={displayFrame}
      />

      {/* 8. Structural Tradeoff Notes */}
      <StrategyTradeoffSummary
        plan={plan}
      />
    </div>
  );
};
