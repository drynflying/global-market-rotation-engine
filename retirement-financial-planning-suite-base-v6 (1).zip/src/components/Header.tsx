import React from 'react';
import { Plan } from '../types';
import { TabId } from '../constants/tabs';
import { 
  FolderOpen, 
  Trash2, 
  Download, 
  Upload, 
  RotateCcw, 
  User
} from 'lucide-react';
import { SaveIndicator } from './SaveIndicator';
import { UndoButton } from './UndoButton';

interface HeaderProps {
  plans: Plan[];
  activePlan: Plan;
  onSelectPlan: (id: string) => void;
  onCreatePlan?: (name: string) => void;
  onClonePlan?: (plan: Plan) => void;
  onDeletePlan: (id: string) => void;
  onResetSample: () => void;
  onExportPlan: () => void;
  onImportPlan: (jsonStr: string) => void;
  activeTab: TabId;
  setActiveTab: (tab: TabId) => void;
  validationCount: { pass: number; warning: number; fail: number };
}

export const Header: React.FC<HeaderProps> = ({
  plans,
  activePlan,
  onSelectPlan,
  onDeletePlan,
  onResetSample,
  onExportPlan,
  onImportPlan,
}) => {
  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (evt) => {
        const content = evt.target?.result as string;
        if (content) {
          onImportPlan(content);
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <header className="bg-[#f3f3f3] border-b border-neutral-300 sticky top-0 z-30 select-none">
      {/* Top Utility Header */}
      <div className="w-full px-6">
        <div className="flex items-center justify-between h-14">
          
          {/* Brand & Plan Switcher */}
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-3">
              <h1 className="text-xl font-black text-neutral-900 tracking-wider font-sans uppercase">
                MERIDIAN
              </h1>
              {/* Static sync badge replaced by a transient save acknowledgement. */}
              <SaveIndicator />
            </div>

            <div className="h-5 w-px bg-neutral-300" />

            <UndoButton />

            <div className="h-5 w-px bg-neutral-300" />

            {/* Plan Selector Dropdown */}
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono font-semibold uppercase text-neutral-500 hidden sm:inline">Scenario:</span>
              <div className="relative flex items-center bg-white border border-neutral-300 rounded px-2.5 py-1 hover:border-neutral-400 transition-colors">
                <FolderOpen className="w-3.5 h-3.5 text-[#b92d1d] mr-1.5" />
                <select
                  value={activePlan.id}
                  onChange={(e) => onSelectPlan(e.target.value)}
                  className="bg-transparent text-xs font-bold text-neutral-800 focus:outline-none cursor-pointer pr-1"
                >
                  {plans.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Action Tools & User Profile */}
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-1.5 border-r border-neutral-300 pr-3">
              <button
                onClick={onExportPlan}
                title="Download scenario JSON"
                className="p-1 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-200/60 rounded transition-colors"
              >
                <Download className="w-4 h-4" />
              </button>

              <label
                title="Import scenario JSON"
                className="p-1 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-200/60 rounded cursor-pointer transition-colors"
              >
                <Upload className="w-4 h-4" />
                <input type="file" accept=".json" onChange={handleImportFile} className="hidden" />
              </label>

              {plans.length > 1 && (
                <button
                  onClick={() => onDeletePlan(activePlan.id)}
                  title="Delete current scenario"
                  className="p-1 text-red-600 hover:bg-red-100/60 rounded transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}

              <button
                onClick={onResetSample}
                title="Reset to sample data"
                className="p-1 text-neutral-500 hover:text-neutral-800 hover:bg-neutral-200/60 rounded transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>

            {/* User Profile Badge */}
            <div className="flex items-center space-x-2 pl-1" title="User Profile">
              <span className="text-xs font-semibold text-neutral-800 hidden sm:inline">
                Profile
              </span>
              <div className="w-7 h-7 bg-neutral-200 border border-neutral-300 rounded text-neutral-800 text-xs font-bold flex items-center justify-center">
                <User className="w-4 h-4 text-neutral-700" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

