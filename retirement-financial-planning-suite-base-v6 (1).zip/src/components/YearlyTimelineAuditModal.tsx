import React from 'react';
import { SimulationRow } from '../domain/simulation/simulationTypes';
import { ROW_FIELDS, FieldGroup } from '../domain/simulation/rowFields';
import { reconcileRow } from '../domain/simulation/rowReconciliation';
import { X, CheckCircle2, AlertTriangle, ShieldCheck } from 'lucide-react';

interface YearlyTimelineAuditModalProps {
  row: SimulationRow | null;
  onClose: () => void;
  displayMode: 'nominal' | 'real';
  macroInflation: number;
  primaryCurrentAge: number;
}

export const YearlyTimelineAuditModal: React.FC<YearlyTimelineAuditModalProps> = ({
  row,
  onClose,
  displayMode,
  macroInflation,
  primaryCurrentAge,
}) => {
  if (!row) return null;

  const deflator =
    displayMode === 'real'
      ? Math.pow(1 + macroInflation / 100, row.age - primaryCurrentAge)
      : 1;

  const checks = reconcileRow(row);
  const groups: FieldGroup[] = [
    'Identity',
    'Expenses',
    'Income',
    'Withdrawals',
    'Contributions',
    'Balances',
    'Tax',
    'Cash flow',
  ];

  const formatValue = (field: typeof ROW_FIELDS[number], raw: unknown) => {
    if (raw === undefined || raw === null) return '-';
    if (typeof raw === 'boolean') return raw ? 'TRUE' : 'FALSE';
    if (typeof raw === 'number') {
      const val = field.numeric && deflator !== 1 ? raw / deflator : raw;
      if (field.numeric) {
        return `$${Math.round(val).toLocaleString()}`;
      }
      return val.toString();
    }
    return String(raw);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 overflow-y-auto backdrop-blur-xs">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] flex flex-col border border-neutral-300 overflow-hidden">
        {/* Modal Header */}
        <div className="bg-neutral-900 text-white p-4 flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <h3 className="text-base font-bold">
                Year Audit Drill-Down: {row.calendarYear} (Age {row.age})
              </h3>
              {row.isRetired ? (
                <span className="px-2 py-0.5 text-xs font-semibold rounded bg-emerald-800 text-emerald-100">
                  Retired
                </span>
              ) : (
                <span className="px-2 py-0.5 text-xs font-semibold rounded bg-neutral-700 text-neutral-200">
                  Working
                </span>
              )}
            </div>
            <p className="text-xs text-neutral-400 mt-1">
              Detailed single-year audit across all 53 SimulationRow fields with engine accounting identities.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-6 text-xs">
          {/* Section 1: Accounting Identities Reconciliation */}
          <div className="bg-neutral-50 border border-neutral-200 rounded-md p-4">
            <h4 className="font-bold text-neutral-900 text-sm mb-3 flex items-center space-x-1.5">
              <span>Accounting Identities Reconciliation</span>
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {checks.map((chk, idx) => (
                <div
                  key={idx}
                  className={`p-3 rounded border text-xs flex flex-col justify-between ${
                    !chk.applicable
                      ? 'bg-neutral-100/70 border-neutral-200 text-neutral-500'
                      : chk.passed
                      ? 'bg-emerald-50/60 border-emerald-200 text-emerald-900'
                      : 'bg-red-50 border-red-200 text-red-900'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold">{chk.label}</span>
                      {!chk.applicable ? (
                        <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 bg-neutral-200 text-neutral-600 rounded">
                          N/A
                        </span>
                      ) : chk.passed ? (
                        <span className="inline-flex items-center text-[10px] font-bold font-mono px-1.5 py-0.5 bg-emerald-100 text-emerald-800 rounded">
                          <CheckCircle2 className="w-3 h-3 mr-1 text-emerald-600" /> PASS
                        </span>
                      ) : (
                        <span className="inline-flex items-center text-[10px] font-bold font-mono px-1.5 py-0.5 bg-red-100 text-red-800 rounded">
                          <AlertTriangle className="w-3 h-3 mr-1 text-red-600" /> FAIL
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-neutral-600 font-mono mb-2">{chk.formula}</p>
                  </div>
                  {chk.applicable && (
                    <div className="text-[11px] font-mono flex justify-between border-t border-black/10 pt-1.5 mt-1">
                      <span>Expected: ${Math.round(chk.expected).toLocaleString()}</span>
                      <span>Actual: ${Math.round(chk.actual).toLocaleString()}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Section 2: Fields Grouped by Concern */}
          <div className="space-y-4">
            <h4 className="font-bold text-neutral-900 text-sm">
              All SimulationRow Fields Transposed ({ROW_FIELDS.length} Columns)
            </h4>

            {groups.map((grp) => {
              const grpFields = ROW_FIELDS.filter((f) => f.group === grp);
              if (grpFields.length === 0) return null;

              return (
                <div key={grp} className="border border-neutral-200 rounded-md overflow-hidden bg-white">
                  <div className="bg-neutral-100 px-3 py-1.5 font-bold text-neutral-800 border-b border-neutral-200 uppercase text-[10px] font-mono tracking-wider flex items-center justify-between">
                    <span>{grp}</span>
                    <span className="text-[10px] text-neutral-500 font-normal">
                      {grpFields.length} fields
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-x-4 gap-y-2 p-3">
                    {grpFields.map((field) => {
                      const rawVal = row[field.key];
                      const formatted = formatValue(field, rawVal);

                      return (
                        <div key={field.key} className="flex flex-col justify-between p-2 rounded bg-neutral-50/50 hover:bg-neutral-100/50 border border-neutral-100 transition-colors">
                          <div className="flex items-center justify-between text-[11px] text-neutral-500">
                            <span className="font-medium text-neutral-700">{field.label}</span>
                            {field.summary && (
                              <span className="text-[9px] px-1 bg-amber-100 text-amber-800 rounded font-mono">Summary</span>
                            )}
                          </div>
                          <div className="text-xs font-mono font-bold text-neutral-900 mt-1">
                            {formatted}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-neutral-50 border-t border-neutral-200 p-3 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-neutral-800 hover:bg-neutral-900 text-white font-bold rounded text-xs transition-colors cursor-pointer"
          >
            Close Audit
          </button>
        </div>
      </div>
    </div>
  );
};
