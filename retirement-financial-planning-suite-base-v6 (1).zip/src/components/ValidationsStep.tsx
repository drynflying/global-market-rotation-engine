import React, { useState } from 'react';
import { Plan, ValidationResult } from '../types';
import { TabId } from '../constants/tabs';
import { 
  ShieldCheck, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Filter, 
  ArrowRight,
  Info
} from 'lucide-react';

interface ValidationsStepProps {
  plan: Plan;
  validations: ValidationResult[];
  onNavigateTab: (tabId: TabId) => void;
}

export const ValidationsStep: React.FC<ValidationsStepProps> = ({
  plan,
  validations,
  onNavigateTab,
}) => {
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const passes = validations.filter(v => v.status === 'pass');
  const warnings = validations.filter(v => v.status === 'warning');
  const fails = validations.filter(v => v.status === 'fail');

  const hasFails = fails.length > 0;
  const hasWarnings = warnings.length > 0;

  let headerBg = 'bg-emerald-50/80 border-emerald-200';
  let badgeBg = 'bg-emerald-600';
  let titleColor = 'text-emerald-950';
  let textColor = 'text-emerald-800';
  let pillStyle = 'bg-white border-emerald-200 text-emerald-900';
  let HeaderIcon = CheckCircle2;
  let headerTitle = 'All Validations Passed';
  let summaryLabel = 'All Tests Passed:';
  let summaryText = 'No validation errors or warnings detected across plan rules.';

  if (hasFails) {
    headerBg = 'bg-rose-50/90 border-rose-200';
    badgeBg = 'bg-rose-600';
    titleColor = 'text-rose-950';
    textColor = 'text-rose-800';
    pillStyle = 'bg-white border-rose-200 text-rose-900';
    HeaderIcon = XCircle;
    headerTitle = 'Validation Failure Detected';
    summaryLabel = 'Failing Tests:';
    summaryText = fails.map(f => f.title).join(', ');
  } else if (hasWarnings) {
    headerBg = 'bg-amber-50/90 border-amber-200';
    badgeBg = 'bg-amber-500';
    titleColor = 'text-amber-950';
    textColor = 'text-amber-800';
    pillStyle = 'bg-white border-amber-200 text-amber-900';
    HeaderIcon = AlertTriangle;
    headerTitle = 'Validation Warnings Detected';
    summaryLabel = 'Warning Tests:';
    summaryText = warnings.map(w => w.title).join(', ');
  }

  const filteredValidations = validations.filter(v => {
    if (filterCategory !== 'all' && v.category !== filterCategory) return false;
    if (filterStatus !== 'all' && v.status !== filterStatus) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Redesigned Header Banner */}
      <div className={`p-4 rounded-2xl border ${headerBg} shadow-2xs flex items-center space-x-3.5`}>
        <div className={`w-10 h-10 ${badgeBg} rounded-xl flex items-center justify-center shrink-0 shadow-xs`}>
          <HeaderIcon className="w-6 h-6 text-white" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center space-x-2.5">
            <h2 className={`text-base font-bold ${titleColor} tracking-tight leading-none`}>
              {headerTitle}
            </h2>
            <span className={`px-2.5 py-0.5 border rounded-md text-xs font-bold shadow-2xs ${pillStyle}`}>
              {passes.length} / {validations.length} Passed
            </span>
          </div>

          <p className={`text-xs ${textColor} font-medium mt-1 truncate`}>
            <span className="font-bold">{summaryLabel} </span>
            <span>{summaryText}</span>
          </p>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="font-semibold text-slate-700">Filter Audits:</span>
          
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:outline-none"
          >
            <option value="all">All Statuses ({validations.length})</option>
            <option value="pass">Passed Only ({passes.length})</option>
            <option value="warning">Warnings Only ({warnings.length})</option>
            <option value="fail">Errors Only ({fails.length})</option>
          </select>

          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:outline-none"
          >
            <option value="all">All Categories</option>
            <option value="Profile">Profile & Timeline</option>
            <option value="Accounts">Accounts & Assets</option>
            <option value="Contributions">Contributions & IRS Limits</option>
          </select>
        </div>

        <div className="text-slate-500 text-xs">
          Showing <span className="font-bold text-slate-900">{filteredValidations.length}</span> rule check(s)
        </div>
      </div>

      {/* Validations List */}
      <div className="space-y-3">
        {filteredValidations.length === 0 ? (
          <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center text-slate-400 text-xs">
            No rule checks match the selected filters.
          </div>
        ) : (
          filteredValidations.map((val) => {
            const isPass = val.status === 'pass';
            const isWarn = val.status === 'warning';
            const isFail = val.status === 'fail';

            const cardBorder = isPass 
              ? 'border-emerald-200 bg-emerald-50/20' 
              : isWarn 
              ? 'border-amber-200 bg-amber-50/20' 
              : 'border-rose-200 bg-rose-50/20';

            const badgeBg = isPass 
              ? 'bg-emerald-100 text-emerald-800 border-emerald-200' 
              : isWarn 
              ? 'bg-amber-100 text-amber-800 border-amber-200' 
              : 'bg-rose-100 text-rose-800 border-rose-200';

            return (
              <div
                key={val.id}
                className={`bg-white p-4 rounded-xl border ${cardBorder} shadow-2xs transition-all space-y-2`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center space-x-2.5">
                    {isPass && <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />}
                    {isWarn && <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />}
                    {isFail && <XCircle className="w-5 h-5 text-rose-600 shrink-0" />}

                    <div>
                      <h4 className="text-sm font-bold text-slate-900 leading-tight">
                        {val.title}
                      </h4>
                      <div className="flex items-center space-x-2 mt-0.5 text-[11px] text-slate-500">
                        <span>Step {val.step}: {val.stepName}</span>
                        <span>•</span>
                        <span className="font-semibold text-slate-700">{val.category}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 self-start sm:self-center">
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border ${badgeBg}`}>
                      {val.status}
                    </span>

                    {val.targetTab && (
                      <button
                        onClick={() => onNavigateTab(val.targetTab!)}
                        className="inline-flex items-center space-x-1 px-2.5 py-1 text-xs font-semibold text-blue-700 hover:bg-blue-50 border border-blue-200 rounded-lg transition-colors"
                      >
                        <span>Fix in Step 1</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>

                <p className="text-xs text-slate-700 pl-7">{val.description}</p>

                {val.recommendation && (
                  <div className="ml-7 p-2.5 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-600 flex items-start space-x-2">
                    <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-slate-800">Recommendation: </span>
                      {val.recommendation}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
