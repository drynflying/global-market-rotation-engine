import React, { useState, useMemo } from 'react';
import { Plan } from '../types';
import { SimulationRow } from '../domain/simulation/simulationTypes';
import { getSimulation } from '../domain/simulation/simulationCache';
import { calculateAccountTotals } from '../domain/accounts/accountCapabilities';
import { buildCsv, csvFilename, downloadCsv } from '../domain/simulation/rowExport';
import { ROW_FIELDS, SUMMARY_FIELDS, ExportScope } from '../domain/simulation/rowFields';
import { YearlyTimelineAuditModal } from './YearlyTimelineAuditModal';
import { 
  Table, 
  Copy, 
  Check, 
  FileSpreadsheet, 
  Search, 
  Info, 
  SlidersHorizontal,
  AlertTriangle
} from 'lucide-react';

interface YearlyTimelineStepProps {
  plan: Plan;
  onGoToValidations?: () => void;
}

export const YearlyTimelineStep: React.FC<YearlyTimelineStepProps> = ({ plan }) => {
  const [displayMode, setDisplayMode] = useState<'nominal' | 'real'>('nominal');
  const [filterPhase, setFilterPhase] = useState<'all' | 'working' | 'retired'>('all');
  const [searchAge, setSearchAge] = useState('');
  const [copiedStatus, setCopiedStatus] = useState<'none' | 'csv' | 'tsv'>('none');
  const [exportedScope, setExportedScope] = useState<ExportScope | null>(null);
  const [auditRow, setAuditRow] = useState<SimulationRow | null>(null);
  const [selectedColumns, setSelectedColumns] = useState<{ [key: string]: boolean }>({
    expenses: true,
    guaranteedIncome: true,
    rmdAndConversions: true,
    withdrawals: true,
    balances: true,
    reconciliation: true,
    magiAndTax: true,
    annotations: true,
  });

  const simulation = useMemo(() => {
    return getSimulation(plan);
  }, [plan]);

  const primaryAge = plan.primaryPerson.currentAge;
  const macroInflation = plan.macroAssumptions?.generalInflation ?? 2.5;

  // Transform rows based on Real vs Nominal display
  const displayRows = useMemo(() => {
    return simulation.rows.map((row) => {
      const yearsFromStart = row.age - primaryAge;
      const deflator = Math.pow(1 + macroInflation / 100, yearsFromStart);

      if (displayMode === 'real' && deflator > 0) {
        return {
          ...row,
          calendarYear: row.calendarYear,
          baseLiving: Math.round(row.baseLiving / deflator),
          essentialExpense: Math.round(row.essentialExpense / deflator),
          discretionaryExpense: Math.round(row.discretionaryExpense / deflator),
          healthExpense: Math.round(row.healthExpense / deflator),
          specialExpense: Math.round((row.specialExpense || 0) / deflator),
          totalExpenseNeed: Math.round(row.totalExpenseNeed / deflator),
          w2Income: Math.round(row.w2Income / deflator),
          guaranteedIncome: Math.round(row.guaranteedIncome / deflator),
          primarySs: Math.round(row.primarySs / deflator),
          spouseSs: Math.round(row.spouseSs / deflator),
          pensionIncome: Math.round(row.pensionIncome / deflator),
          rmdAmount: Math.round(row.rmdAmount / deflator),
          rothConversion: Math.round(row.rothConversion / deflator),
          taxableWd: Math.round(row.taxableWd / deflator),
          preTaxWd: Math.round(row.preTaxWd / deflator),
          postTaxWd: Math.round(row.postTaxWd / deflator),
          totalWithdrawals: Math.round(row.totalWithdrawals / deflator),
          beginningPortfolio: Math.round(row.beginningPortfolio / deflator),
          portfolioGrowth: Math.round(row.portfolioGrowth / deflator),
          preTaxBal: Math.round(row.preTaxBal / deflator),
          postTaxBal: Math.round(row.postTaxBal / deflator),
          taxableBal: Math.round(row.taxableBal / deflator),
          totalPortfolio: Math.round(row.totalPortfolio / deflator),
          provisionalIncome: Math.round(row.provisionalIncome / deflator),
          taxableSs: Math.round(row.taxableSs / deflator),
          taxableMagi: Math.round(row.taxableMagi / deflator),
          conversionTaxPaid: Math.round(row.conversionTaxPaid / deflator),
          rmdTaxPaid: Math.round(row.rmdTaxPaid / deflator),
          fedTaxPaid: Math.round(row.fedTaxPaid / deflator),
          stateTaxPaid: Math.round(row.stateTaxPaid / deflator),
          ficaTaxPaid: Math.round(row.ficaTaxPaid / deflator),
          preTaxContrib: Math.round(row.preTaxContrib / deflator),
          postTaxContrib: Math.round(row.postTaxContrib / deflator),
          taxableContrib: Math.round(row.taxableContrib / deflator),
          irmaaSurcharge: Math.round(row.irmaaSurcharge / deflator),
          realizedCapGains: Math.round(row.realizedCapGains / deflator),
          taxableCostBasis: Math.round(row.taxableCostBasis / deflator),
          totalEstimatedTax: Math.round(row.totalEstimatedTax / deflator),
          totalCashInflow: Math.round(row.totalCashInflow / deflator),
          totalCashOutflow: Math.round(row.totalCashOutflow / deflator),
          netCashFlow: Math.round(row.netCashFlow / deflator),
          unfundedShortfall: Math.round(row.unfundedShortfall / deflator),
          surplusReinvested: Math.round(row.surplusReinvested / deflator),
        };
      }
      return row;
    });
  }, [simulation.rows, displayMode, primaryAge, macroInflation]);

  // Filtered rows
  const filteredRows = useMemo(() => {
    return displayRows.filter(row => {
      if (filterPhase === 'working' && row.isRetired) return false;
      if (filterPhase === 'retired' && !row.isRetired) return false;
      if (searchAge.trim()) {
        const query = searchAge.trim();
        const matchesAge = row.age.toString().includes(query);
        const matchesYear = row.calendarYear.toString().includes(query);
        if (!matchesAge && !matchesYear) return false;
      }
      return true;
    });
  }, [displayRows, filterPhase, searchAge]);

  // Totals calculations
  const totals = useMemo(() => {
    return filteredRows.reduce((acc, r) => ({
      totalExpenseNeed: acc.totalExpenseNeed + r.totalExpenseNeed,
      healthExpense: acc.healthExpense + r.healthExpense,
      specialExpense: (acc.specialExpense || 0) + (r.specialExpense || 0),
      w2Income: acc.w2Income + r.w2Income,
      guaranteedIncome: acc.guaranteedIncome + r.guaranteedIncome,
      primarySs: acc.primarySs + r.primarySs,
      spouseSs: acc.spouseSs + r.spouseSs,
      pensionIncome: acc.pensionIncome + r.pensionIncome,
      rmdAmount: acc.rmdAmount + r.rmdAmount,
      rothConversion: acc.rothConversion + r.rothConversion,
      taxableWd: acc.taxableWd + r.taxableWd,
      preTaxWd: acc.preTaxWd + r.preTaxWd,
      postTaxWd: acc.postTaxWd + r.postTaxWd,
      totalWithdrawals: acc.totalWithdrawals + r.totalWithdrawals,
      portfolioGrowth: acc.portfolioGrowth + r.portfolioGrowth,
      conversionTaxPaid: acc.conversionTaxPaid + r.conversionTaxPaid,
      rmdTaxPaid: acc.rmdTaxPaid + r.rmdTaxPaid,
      totalEstimatedTax: acc.totalEstimatedTax + r.totalEstimatedTax,
      totalCashInflow: acc.totalCashInflow + r.totalCashInflow,
      totalCashOutflow: acc.totalCashOutflow + r.totalCashOutflow,
      unfundedShortfall: acc.unfundedShortfall + r.unfundedShortfall,
    }), {
      totalExpenseNeed: 0,
      healthExpense: 0,
      specialExpense: 0,
      w2Income: 0,
      guaranteedIncome: 0,
      primarySs: 0,
      spouseSs: 0,
      pensionIncome: 0,
      rmdAmount: 0,
      rothConversion: 0,
      taxableWd: 0,
      preTaxWd: 0,
      postTaxWd: 0,
      totalWithdrawals: 0,
      portfolioGrowth: 0,
      conversionTaxPaid: 0,
      rmdTaxPaid: 0,
      totalEstimatedTax: 0,
      totalCashInflow: 0,
      totalCashOutflow: 0,
      unfundedShortfall: 0,
    });
  }, [filteredRows]);

  // Total Lifetime Shortfall across plan
  const totalLifetimeShortfall = useMemo(() => {
    return simulation.rows.reduce((sum, r) => sum + r.unfundedShortfall, 0);
  }, [simulation.rows]);

  // Helper currency formatter
  const fmt = (val: number) => {
    if (val === 0) return '-';
    return '$' + Math.round(val).toLocaleString();
  };

  // Handle Export to CSV File (Excel compatibility)
  //
  // Two scopes: 'summary' mirrors the on-screen columns, 'all' emits every field on
  // SimulationRow for auditing a year in a spreadsheet. Columns come from the ROW_FIELDS
  // registry rather than a hand-maintained list.
  const handleExport = (scope: ExportScope) => {
    const deflatorFor =
      displayMode === 'real'
        ? (row: { age: number }) =>
            Math.pow(
              1 + (plan.macroAssumptions?.generalInflation ?? 2.5) / 100,
              row.age - plan.primaryPerson.currentAge,
            )
        : undefined;

    const content = buildCsv(simulation.rows, { scope, deflatorFor });
    downloadCsv(content, csvFilename(plan.name, scope, displayMode));
    setExportedScope(scope);
    setTimeout(() => setExportedScope(null), 2000);
  };

  // Copy Tab-Separated Data for Google Sheets / Excel direct paste
  const handleCopyForSheets = () => {
    const headers = [
      'Year',
      'Age',
      'Phase',
      'Expense Need',
      'Guaranteed Income',
      'Primary SS',
      'Spouse SS',
      'Pension',
      'RMD Amount',
      'Roth Conversion',
      'Taxable W/D',
      'Pre-Tax W/D',
      'Roth W/D',
      'Total W/D',
      'End Portfolio',
      'Cash Inflow',
      'Cash Outflow',
      'Shortfall',
      'MAGI',
      'Tax Owed',
      'Solvency',
      'Milestone'
    ];

    const lines = displayRows.map(r => [
      r.calendarYear,
      r.age,
      r.isRetired ? 'Retired' : 'Working',
      r.totalExpenseNeed,
      r.guaranteedIncome,
      r.primarySs,
      r.spouseSs,
      r.pensionIncome,
      r.rmdAmount,
      r.rothConversion,
      r.taxableWd,
      r.preTaxWd,
      r.postTaxWd,
      r.totalWithdrawals,
      r.totalPortfolio,
      r.totalCashInflow,
      r.totalCashOutflow,
      r.unfundedShortfall,
      r.taxableMagi,
      r.totalEstimatedTax,
      r.solvencyStatus,
      r.annotation || ''
    ].join('\t'));

    const tsvData = [headers.join('\t'), ...lines].join('\n');
    navigator.clipboard.writeText(tsvData);
    setCopiedStatus('tsv');
    setTimeout(() => setCopiedStatus('none'), 3000);
  };

  const toggleColumn = (colKey: string) => {
    setSelectedColumns(prev => ({ ...prev, [colKey]: !prev[colKey] }));
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Depletion & Solvency Alert Banner */}
      {simulation.depletionAge && (
        <div className="bg-amber-50 border-l-4 border-amber-600 p-4 rounded-r shadow-2xs">
          <div className="flex items-start space-x-3">
            <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <h3 className="text-sm font-bold text-amber-900">
                Plan Depletion Warning: Portfolio Depleted at Age {simulation.depletionAge}
              </h3>
              <p className="text-xs text-amber-800 mt-1">
                Based on current inflation, living expense needs, and tax gross-up withdrawals, the portfolio reaches $0 at age {simulation.depletionAge}. Total cumulative unfunded shortfall across the plan horizon is <span className="font-bold text-amber-950">${Math.round(totalLifetimeShortfall).toLocaleString()}</span> nominal.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-white border border-neutral-300 rounded-md p-6 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono font-bold text-[#b92d1d] uppercase tracking-wider mb-1">
              <Table className="w-4 h-4" />
              <span>Audit & Validation Table</span>
            </div>
            <h2 className="text-xl font-black text-neutral-900 tracking-tight">
              Year-by-Year Financial Validation Timeline
            </h2>
            <p className="text-xs text-neutral-600 mt-1 max-w-3xl">
              Complete deterministic trajectory mapping cash flows, tax gross-up withdrawals, Social Security provisional income taxation, RMD obligations, and full cash flow reconciliation from age {primaryAge} through horizon.
            </p>
          </div>

          {/* Quick Export Actions */}
          <div className="flex items-center space-x-2 flex-wrap gap-y-2">
            <button
              onClick={() => handleExport('summary')}
              title={`Export the ${SUMMARY_FIELDS.length} columns shown in this table`}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 text-xs font-bold text-white bg-[#b92d1d] hover:bg-[#9e2a1b] rounded shadow-2xs transition-colors cursor-pointer"
            >
              {exportedScope === 'summary' ? (
                <>
                  <Check className="w-4 h-4 text-emerald-200" />
                  <span>Downloaded</span>
                </>
              ) : (
                <>
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>Export as shown ({SUMMARY_FIELDS.length} cols)</span>
                </>
              )}
            </button>

            <button
              onClick={() => handleExport('all')}
              title={`Export all ${ROW_FIELDS.length} engine fields for full year-by-year audit`}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 text-xs font-bold text-neutral-800 bg-white hover:bg-neutral-100 border border-neutral-300 rounded shadow-2xs transition-colors cursor-pointer"
            >
              {exportedScope === 'all' ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>Downloaded</span>
                </>
              ) : (
                <>
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>Export all fields ({ROW_FIELDS.length} cols)</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleCopyForSheets}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 text-xs font-bold text-neutral-800 bg-white hover:bg-neutral-100 border border-neutral-300 rounded shadow-2xs transition-colors cursor-pointer"
            >
              {copiedStatus === 'tsv' ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>Copied for Sheets!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-neutral-600" />
                  <span>Copy for Excel / Sheets</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Milestone Summary Metrics Cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-6 pt-6 border-t border-neutral-200 text-xs">
          <div className="bg-[#fcfcfc] p-3 rounded border border-neutral-200">
            <span className="text-[11px] text-neutral-500 font-mono block mb-1 uppercase">Timeline Horizon</span>
            <span className="text-sm font-bold text-neutral-900">
              {displayRows.length} Years <span className="text-[10px] text-neutral-500 font-normal">(Age {primaryAge}–{displayRows[displayRows.length - 1]?.age})</span>
            </span>
          </div>

          <div className="bg-[#fcfcfc] p-3 rounded border border-neutral-200">
            <span className="text-[11px] text-neutral-500 font-mono block mb-1 uppercase">Peak Portfolio</span>
            <span className="text-sm font-bold text-emerald-700">
              ${Math.round(Math.max(...displayRows.map(r => r.totalPortfolio))).toLocaleString()}
            </span>
          </div>

          <div className="bg-[#fcfcfc] p-3 rounded border border-neutral-200">
            <span className="text-[11px] text-neutral-500 font-mono block mb-1 uppercase">Solvency Horizon</span>
            <span className={`text-sm font-bold ${simulation.depletionAge ? 'text-amber-800' : 'text-emerald-700'}`}>
              {simulation.depletionAge ? `Depleted Age ${simulation.depletionAge}` : `Fully Solvent to ${displayRows[displayRows.length - 1]?.age}`}
            </span>
          </div>

          <div className="bg-[#fcfcfc] p-3 rounded border border-neutral-200">
            <span className="text-[11px] text-neutral-500 font-mono block mb-1 uppercase">Lifetime Total Tax Liability</span>
            <span className="text-sm font-bold text-[#b92d1d]">
              ${Math.round(displayRows.reduce((s, r) => s + r.totalEstimatedTax, 0)).toLocaleString()}
            </span>
          </div>

          <div className="bg-[#fcfcfc] p-3 rounded border border-neutral-200">
            <span className="text-[11px] text-neutral-500 font-mono block mb-1 uppercase">Lifetime Shortfall ($)</span>
            <span className={`text-sm font-bold ${totalLifetimeShortfall > 0 ? 'text-red-700' : 'text-emerald-700'}`}>
              ${Math.round(totalLifetimeShortfall).toLocaleString()}
            </span>
          </div>
        </div>

        {calculateAccountTotals(plan.accounts, plan).hasUnmodeledAssets && (
          <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-md text-xs text-amber-900 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Info className="w-4 h-4 text-amber-700 shrink-0" />
              <span>
                <strong>Recorded Non-Modeled Assets:</strong> Your plan includes ${Math.round(calculateAccountTotals(plan.accounts, plan).recordedNotModeledBalance).toLocaleString()} in HSA / Real Estate accounts marked as <em>'Recorded — not currently included in retirement projection'</em>.
              </span>
            </div>
            <span className="text-[11px] font-semibold text-amber-800 shrink-0 ml-3">
              Modeled Capital: ${Math.round(calculateAccountTotals(plan.accounts, plan).modeledPortfolioBalance).toLocaleString()}
            </span>
          </div>
        )}
      </div>

      {/* Controls & Filter Toolbar */}
      <div className="bg-white border border-neutral-300 rounded-md p-4 shadow-2xs space-y-3">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Phase Filter Tabs & Search */}
          <div className="flex items-center space-x-3 flex-wrap gap-y-2">
            <div className="inline-flex bg-neutral-100 p-1 rounded border border-neutral-200 text-xs font-semibold">
              <button
                onClick={() => setFilterPhase('all')}
                className={`px-3 py-1 rounded transition-colors ${filterPhase === 'all' ? 'bg-white text-neutral-900 shadow-2xs font-bold' : 'text-neutral-600 hover:text-neutral-900'}`}
              >
                All Years ({displayRows.length})
              </button>
              <button
                onClick={() => setFilterPhase('working')}
                className={`px-3 py-1 rounded transition-colors ${filterPhase === 'working' ? 'bg-white text-neutral-900 shadow-2xs font-bold' : 'text-neutral-600 hover:text-neutral-900'}`}
              >
                Working Phase
              </button>
              <button
                onClick={() => setFilterPhase('retired')}
                className={`px-3 py-1 rounded transition-colors ${filterPhase === 'retired' ? 'bg-white text-neutral-900 shadow-2xs font-bold' : 'text-neutral-600 hover:text-neutral-900'}`}
              >
                Retirement Phase
              </button>
            </div>

            {/* Nominal vs Real Toggle */}
            <div className="inline-flex bg-neutral-100 p-1 rounded border border-neutral-200 text-xs font-semibold">
              <button
                onClick={() => setDisplayMode('nominal')}
                className={`px-3 py-1 rounded transition-colors ${displayMode === 'nominal' ? 'bg-[#b92d1d] text-white font-bold' : 'text-neutral-600 hover:text-neutral-900'}`}
              >
                Nominal $
              </button>
              <button
                onClick={() => setDisplayMode('real')}
                className={`px-3 py-1 rounded transition-colors ${displayMode === 'real' ? 'bg-[#b92d1d] text-white font-bold' : 'text-neutral-600 hover:text-neutral-900'}`}
              >
                Real Today's $ ({macroInflation}% Inf)
              </button>
            </div>

            {/* Quick Search */}
            <div className="relative flex items-center">
              <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-2.5 pointer-events-none" />
              <input
                type="text"
                placeholder="Search age or year..."
                value={searchAge}
                onChange={(e) => setSearchAge(e.target.value)}
                className="pl-8 pr-3 py-1 text-xs border border-neutral-300 rounded bg-white focus:outline-none focus:ring-1 focus:ring-[#b92d1d] w-40"
              />
            </div>
          </div>

          {/* Column Toggle Checklist & Quick Presets */}
          <div className="flex items-center space-x-2 text-xs font-mono text-neutral-600 flex-wrap gap-y-1.5">
            <SlidersHorizontal className="w-3.5 h-3.5 text-neutral-500" />
            <span className="font-bold uppercase text-[10px]">Columns:</span>

            {/* Quick Presets */}
            <div className="inline-flex bg-neutral-100 p-0.5 rounded border border-neutral-200 text-[11px] mr-1">
              <button
                type="button"
                onClick={() => setSelectedColumns({
                  expenses: true,
                  guaranteedIncome: false,
                  rmdAndConversions: false,
                  withdrawals: true,
                  balances: true,
                  reconciliation: true,
                  magiAndTax: false,
                  annotations: true,
                })}
                className="px-2 py-0.5 rounded hover:bg-white text-neutral-700 font-semibold"
                title="Compact view optimized for smaller screens"
              >
                Compact
              </button>
              <button
                type="button"
                onClick={() => setSelectedColumns({
                  expenses: true,
                  guaranteedIncome: true,
                  rmdAndConversions: true,
                  withdrawals: true,
                  balances: true,
                  reconciliation: true,
                  magiAndTax: true,
                  annotations: true,
                })}
                className="px-2 py-0.5 rounded hover:bg-white text-neutral-700 font-semibold"
                title="Show all detailed tax and income columns"
              >
                All
              </button>
            </div>

            <label className="inline-flex items-center space-x-1 cursor-pointer">
              <input type="checkbox" checked={selectedColumns.expenses} onChange={() => toggleColumn('expenses')} className="rounded text-[#b92d1d]" />
              <span>Needs</span>
            </label>

            <label className="inline-flex items-center space-x-1 cursor-pointer">
              <input type="checkbox" checked={selectedColumns.guaranteedIncome} onChange={() => toggleColumn('guaranteedIncome')} className="rounded text-[#b92d1d]" />
              <span>Income</span>
            </label>

            <label className="inline-flex items-center space-x-1 cursor-pointer">
              <input type="checkbox" checked={selectedColumns.rmdAndConversions} onChange={() => toggleColumn('rmdAndConversions')} className="rounded text-[#b92d1d]" />
              <span>RMD/Roth</span>
            </label>

            <label className="inline-flex items-center space-x-1 cursor-pointer">
              <input type="checkbox" checked={selectedColumns.withdrawals} onChange={() => toggleColumn('withdrawals')} className="rounded text-[#b92d1d]" />
              <span>Withdrawals</span>
            </label>

            <label className="inline-flex items-center space-x-1 cursor-pointer">
              <input type="checkbox" checked={selectedColumns.reconciliation} onChange={() => toggleColumn('reconciliation')} className="rounded text-[#b92d1d]" />
              <span>Reconciliation</span>
            </label>

            <label className="inline-flex items-center space-x-1 cursor-pointer">
              <input type="checkbox" checked={selectedColumns.balances} onChange={() => toggleColumn('balances')} className="rounded text-[#b92d1d]" />
              <span>Balances</span>
            </label>

            <label className="inline-flex items-center space-x-1 cursor-pointer">
              <input type="checkbox" checked={selectedColumns.magiAndTax} onChange={() => toggleColumn('magiAndTax')} className="rounded text-[#b92d1d]" />
              <span>Taxes</span>
            </label>

            <label className="inline-flex items-center space-x-1 cursor-pointer">
              <input type="checkbox" checked={selectedColumns.annotations} onChange={() => toggleColumn('annotations')} className="rounded text-[#b92d1d]" />
              <span>Milestones</span>
            </label>
          </div>
        </div>
      </div>

      {/* Main Interactive Validation Table */}
      <div className="bg-white border border-neutral-300 rounded-md shadow-2xs overflow-hidden">
        <div className="overflow-x-auto max-h-[650px] overflow-y-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="bg-[#ececec] text-neutral-700 font-mono uppercase text-[10px] tracking-wider sticky top-0 z-20 border-b border-neutral-300">
              <tr>
                <th className="py-2.5 px-3 font-bold border-r border-neutral-300 bg-[#ececec] sticky left-0 z-30">Year</th>
                <th className="py-2.5 px-2 font-bold border-r border-neutral-300 text-center">Age</th>
                {plan.hasSpouse && (
                  <th className="py-2.5 px-2 font-bold border-r border-neutral-300 text-center">Spouse Age</th>
                )}
                <th className="py-2.5 px-2 font-bold border-r border-neutral-300 text-center">Phase</th>

                {selectedColumns.expenses && (
                  <>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-amber-50/50">Expense Need</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-amber-50/50">Healthcare</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-amber-50/50">Special Expense</th>
                  </>
                )}

                {selectedColumns.guaranteedIncome && (
                  <>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-emerald-50/50">Salary Income</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-emerald-50/50">Guaranteed Inc</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-emerald-50/50">Primary SS</th>
                    {plan.hasSpouse && (
                      <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-emerald-50/50">Spouse SS</th>
                    )}
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-emerald-50/50">Pension</th>
                  </>
                )}

                {selectedColumns.rmdAndConversions && (
                  <>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-indigo-50/50">RMD Amount</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-indigo-50/50">Roth Conv</th>
                  </>
                )}

                {selectedColumns.withdrawals && (
                  <>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right">Taxable W/D</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right">Pre-Tax W/D</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right">Roth W/D</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right font-black text-neutral-900">Total W/D</th>
                  </>
                )}

                {selectedColumns.reconciliation && (
                  <>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-purple-50/50">Cash Inflow</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-purple-50/50">Cash Outflow</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-purple-50/50">Net Cash Flow</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-red-100/70 text-red-900">Shortfall ($)</th>
                  </>
                )}

                {selectedColumns.balances && (
                  <>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-blue-50/50">Growth ($)</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-blue-50/50">Pre-Tax Bal</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-blue-50/50">Roth Bal</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-blue-50/50">Taxable Bal</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-blue-100/60 font-black text-neutral-900">Total Portfolio</th>
                  </>
                )}

                {selectedColumns.magiAndTax && (
                  <>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-rose-50/50">Prov Income</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-rose-50/50">Taxable SS</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-rose-50/50">EST MAGI</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-rose-50/50">Tax Bracket</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-rose-50/50">IRMAA</th>
                    <th className="py-2.5 px-3 font-bold border-r border-neutral-300 text-right bg-rose-50/50">Total Tax</th>
                  </>
                )}

                {selectedColumns.annotations && (
                  <th className="py-2.5 px-3 font-bold text-left bg-neutral-100">Milestone Event</th>
                )}
              </tr>
            </thead>

            <tbody className="divide-y divide-neutral-200 font-mono">
              {filteredRows.map((row) => {
                const isRetirementMilestone = row.age === plan.primaryPerson.retirementAge;
                const isDepleted = row.solvencyStatus !== 'Solvent';

                let rowBg = 'hover:bg-neutral-50/80';
                if (isDepleted) rowBg = 'bg-red-50/60 hover:bg-red-100/70 border-l-4 border-red-600';
                else if (isRetirementMilestone) rowBg = 'bg-emerald-50/70 hover:bg-emerald-100/70 border-l-4 border-emerald-600';
                else if (!row.isRetired) rowBg = 'bg-slate-50/30 hover:bg-slate-100/50';

                return (
                  <tr
                    key={row.age}
                    onClick={() => setAuditRow(row)}
                    title="Click to drill down into single-year accounting audit"
                    className={`transition-colors cursor-pointer ${rowBg}`}
                  >
                    {/* Year */}
                    <td className="py-2 px-3 font-bold text-neutral-900 border-r border-neutral-200 sticky left-0 z-10 bg-inherit">
                      {row.calendarYear}
                    </td>

                    {/* Age */}
                    <td className="py-2 px-2 text-center text-neutral-800 font-bold border-r border-neutral-200">
                      {row.age}
                    </td>
                    {plan.hasSpouse && (
                      <td className="py-2 px-2 text-center text-neutral-600 border-r border-neutral-200">
                        {row.spouseAge ?? '-'}
                      </td>
                    )}

                    {/* Phase Badge */}
                    <td className="py-2 px-2 text-center border-r border-neutral-200">
                      {row.isRetired ? (
                        <span className="inline-block px-1.5 py-0.5 text-[9px] font-bold rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
                          Retired
                        </span>
                      ) : (
                        <span className="inline-block px-1.5 py-0.5 text-[9px] font-bold rounded bg-slate-200 text-slate-700">
                          Working
                        </span>
                      )}
                    </td>

                    {/* Expenses */}
                    {selectedColumns.expenses && (
                      <>
                        <td className="py-2 px-3 text-right font-medium text-neutral-800 border-r border-neutral-200">
                          {fmt(row.totalExpenseNeed)}
                        </td>
                        <td className="py-2 px-3 text-right text-neutral-600 border-r border-neutral-200">
                          {fmt(row.healthExpense)}
                        </td>
                        <td className="py-2 px-3 text-right text-neutral-600 border-r border-neutral-200">
                          {row.specialExpense ? fmt(row.specialExpense) : '-'}
                        </td>
                      </>
                    )}

                    {/* Guaranteed Income */}
                    {selectedColumns.guaranteedIncome && (
                      <>
                        <td className="py-2 px-3 text-right font-semibold text-emerald-800 border-r border-neutral-200">
                          {fmt(row.w2Income)}
                        </td>
                        <td className="py-2 px-3 text-right font-semibold text-emerald-800 border-r border-neutral-200">
                          {fmt(row.guaranteedIncome)}
                        </td>
                        <td className="py-2 px-3 text-right text-emerald-700 border-r border-neutral-200">
                          {fmt(row.primarySs)}
                        </td>
                        {plan.hasSpouse && (
                          <td className="py-2 px-3 text-right text-emerald-700 border-r border-neutral-200">
                            {fmt(row.spouseSs)}
                          </td>
                        )}
                        <td className="py-2 px-3 text-right text-neutral-600 border-r border-neutral-200">
                          {fmt(row.pensionIncome)}
                        </td>
                      </>
                    )}

                    {/* RMD & Roth Conversions */}
                    {selectedColumns.rmdAndConversions && (
                      <>
                        <td className="py-2 px-3 text-right font-semibold text-indigo-900 border-r border-neutral-200">
                          {fmt(row.rmdAmount)}
                        </td>
                        <td className="py-2 px-3 text-right text-indigo-700 border-r border-neutral-200">
                          {fmt(row.rothConversion)}
                        </td>
                      </>
                    )}

                    {/* Withdrawals */}
                    {selectedColumns.withdrawals && (
                      <>
                        <td className="py-2 px-3 text-right text-neutral-700 border-r border-neutral-200">
                          {fmt(row.taxableWd)}
                        </td>
                        <td className="py-2 px-3 text-right text-neutral-700 border-r border-neutral-200">
                          {fmt(row.preTaxWd)}
                        </td>
                        <td className="py-2 px-3 text-right text-neutral-700 border-r border-neutral-200">
                          {fmt(row.postTaxWd)}
                        </td>
                        <td className="py-2 px-3 text-right font-black text-neutral-900 border-r border-neutral-200 bg-neutral-100/50">
                          {fmt(row.totalWithdrawals)}
                        </td>
                      </>
                    )}

                    {/* Reconciliation */}
                    {selectedColumns.reconciliation && (
                      <>
                        <td className="py-2 px-3 text-right text-emerald-800 font-semibold border-r border-neutral-200">
                          {fmt(row.totalCashInflow)}
                        </td>
                        <td className="py-2 px-3 text-right text-neutral-800 font-semibold border-r border-neutral-200">
                          {fmt(row.totalCashOutflow)}
                        </td>
                        <td className={`py-2 px-3 text-right font-bold border-r border-neutral-200 ${row.netCashFlow < 0 ? 'text-amber-800' : 'text-emerald-800'}`}>
                          {fmt(row.netCashFlow)}
                        </td>
                        <td className={`py-2 px-3 text-right font-black border-r border-neutral-200 ${row.unfundedShortfall > 0 ? 'bg-red-100 text-red-900 font-black' : 'text-neutral-400'}`}>
                          {row.unfundedShortfall > 0 ? `$${Math.round(row.unfundedShortfall).toLocaleString()}` : '-'}
                        </td>
                      </>
                    )}

                    {/* Balances */}
                    {selectedColumns.balances && (
                      <>
                        <td className="py-2 px-3 text-right text-blue-800 font-medium border-r border-neutral-200">
                          {fmt(row.portfolioGrowth)}
                        </td>
                        <td className="py-2 px-3 text-right text-neutral-700 border-r border-neutral-200">
                          {fmt(row.preTaxBal)}
                        </td>
                        <td className="py-2 px-3 text-right text-neutral-700 border-r border-neutral-200">
                          {fmt(row.postTaxBal)}
                        </td>
                        <td className="py-2 px-3 text-right text-neutral-700 border-r border-neutral-200">
                          {fmt(row.taxableBal)}
                        </td>
                        <td className={`py-2 px-3 text-right font-black border-r border-neutral-200 bg-blue-50/30 ${row.totalPortfolio === 0 ? 'text-red-700 font-black' : 'text-neutral-900'}`}>
                          {fmt(row.totalPortfolio)}
                        </td>
                      </>
                    )}

                    {/* MAGI & Taxes */}
                    {selectedColumns.magiAndTax && (
                      <>
                        <td className="py-2 px-3 text-right text-neutral-700 border-r border-neutral-200">
                          {fmt(row.provisionalIncome)}
                        </td>
                        <td className="py-2 px-3 text-right text-neutral-700 border-r border-neutral-200">
                          {fmt(row.taxableSs)}
                        </td>
                        <td className="py-2 px-3 text-right text-neutral-800 border-r border-neutral-200 font-medium">
                          {fmt(row.taxableMagi)}
                        </td>
                        <td className="py-2 px-3 text-right font-semibold text-amber-900 border-r border-neutral-200">
                          {row.taxBracket}
                        </td>
                        <td className="py-2 px-3 text-right font-semibold text-indigo-900 border-r border-neutral-200">
                          {row.irmaaBracket}
                        </td>
                        <td className="py-2 px-3 text-right text-rose-900 font-bold border-r border-neutral-200">
                          {fmt(row.totalEstimatedTax)}
                        </td>
                      </>
                    )}

                    {/* Milestone Annotations */}
                    {selectedColumns.annotations && (
                      <td className="py-2 px-3 text-left font-sans text-[11px]">
                        {row.annotation ? (
                          <span className={`inline-block px-2 py-0.5 rounded font-bold ${
                            row.solvencyStatus !== 'Solvent' 
                              ? 'bg-red-100 text-red-800 border border-red-300' 
                              : row.age === plan.primaryPerson.retirementAge 
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                              : 'bg-neutral-100 text-neutral-800 border border-neutral-300'
                          }`}>
                            {row.annotation}
                          </span>
                        ) : (
                          <span className="text-neutral-300">-</span>
                        )}
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>

            {/* Table Footer / Summary Row */}
            <tfoot className="bg-[#ececec] text-neutral-900 font-mono text-xs border-t-2 border-neutral-400 font-bold sticky bottom-0 z-20">
              <tr>
                <td className="py-3 px-3 border-r border-neutral-300 bg-[#ececec] sticky left-0 z-30">
                  TOTAL
                </td>
                <td className="py-3 px-2 text-center border-r border-neutral-300">
                  {filteredRows.length} Yrs
                </td>
                <td className="py-3 px-2 text-center border-r border-neutral-300">-</td>

                {selectedColumns.expenses && (
                  <>
                    <td className="py-3 px-3 text-right border-r border-neutral-300">{fmt(totals.totalExpenseNeed)}</td>
                    <td className="py-3 px-3 text-right border-r border-neutral-300">{fmt(totals.healthExpense)}</td>
                    <td className="py-3 px-3 text-right border-r border-neutral-300">{fmt(totals.specialExpense)}</td>
                  </>
                )}

                {selectedColumns.guaranteedIncome && (
                  <>
                    <td className="py-3 px-3 text-right text-emerald-800 border-r border-neutral-300">{fmt(totals.w2Income)}</td>
                    <td className="py-3 px-3 text-right text-emerald-800 border-r border-neutral-300">{fmt(totals.guaranteedIncome)}</td>
                    <td className="py-3 px-3 text-right text-emerald-800 border-r border-neutral-300">{fmt(totals.primarySs)}</td>
                    {plan.hasSpouse && (
                      <td className="py-3 px-3 text-right text-emerald-800 border-r border-neutral-300">{fmt(totals.spouseSs)}</td>
                    )}
                    <td className="py-3 px-3 text-right border-r border-neutral-300">{fmt(totals.pensionIncome)}</td>
                  </>
                )}

                {selectedColumns.rmdAndConversions && (
                  <>
                    <td className="py-3 px-3 text-right text-indigo-900 border-r border-neutral-300">{fmt(totals.rmdAmount)}</td>
                    <td className="py-3 px-3 text-right text-indigo-900 border-r border-neutral-300">{fmt(totals.rothConversion)}</td>
                  </>
                )}

                {selectedColumns.withdrawals && (
                  <>
                    <td className="py-3 px-3 text-right border-r border-neutral-300">{fmt(totals.taxableWd)}</td>
                    <td className="py-3 px-3 text-right border-r border-neutral-300">{fmt(totals.preTaxWd)}</td>
                    <td className="py-3 px-3 text-right border-r border-neutral-300">{fmt(totals.postTaxWd)}</td>
                    <td className="py-3 px-3 text-right border-r border-neutral-300 font-black">{fmt(totals.totalWithdrawals)}</td>
                  </>
                )}

                {selectedColumns.reconciliation && (
                  <>
                    <td className="py-3 px-3 text-right border-r border-neutral-300 text-emerald-800">{fmt(totals.totalCashInflow)}</td>
                    <td className="py-3 px-3 text-right border-r border-neutral-300">{fmt(totals.totalCashOutflow)}</td>
                    <td className="py-3 px-3 text-right border-r border-neutral-300">-</td>
                    <td className={`py-3 px-3 text-right border-r border-neutral-300 font-black ${totals.unfundedShortfall > 0 ? 'bg-red-200 text-red-950 font-black' : ''}`}>
                      {totals.unfundedShortfall > 0 ? `$${Math.round(totals.unfundedShortfall).toLocaleString()}` : '-'}
                    </td>
                  </>
                )}

                {selectedColumns.balances && (
                  <>
                    <td className="py-3 px-3 text-right border-r border-neutral-300 text-blue-900">{fmt(totals.portfolioGrowth)}</td>
                    <td className="py-3 px-3 text-right border-r border-neutral-300">-</td>
                    <td className="py-3 px-3 text-right border-r border-neutral-300">-</td>
                    <td className="py-3 px-3 text-right border-r border-neutral-300">-</td>
                    <td className="py-3 px-3 text-right border-r border-neutral-300 bg-blue-100 font-black">
                      {fmt(filteredRows[filteredRows.length - 1]?.totalPortfolio || 0)}
                    </td>
                  </>
                )}

                {selectedColumns.magiAndTax && (
                  <>
                    <td className="py-3 px-3 text-right border-r border-neutral-300">-</td>
                    <td className="py-3 px-3 text-right border-r border-neutral-300">-</td>
                    <td className="py-3 px-3 text-right border-r border-neutral-300">-</td>
                    <td className="py-3 px-3 text-right border-r border-neutral-300">-</td>
                    <td className="py-3 px-3 text-right border-r border-neutral-300">-</td>
                    <td className="py-3 px-3 text-right text-rose-900 font-bold border-r border-neutral-300">{fmt(totals.totalEstimatedTax)}</td>
                  </>
                )}

                {selectedColumns.annotations && (
                  <td className="py-3 px-3 border-r border-neutral-300">-</td>
                )}
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Explanatory Notes & Documentation */}
      <div className="bg-white border border-neutral-300 rounded-md p-4 shadow-2xs text-xs text-neutral-600 space-y-2 font-sans">
        <div className="flex items-center space-x-2 text-neutral-900 font-bold">
          <Info className="w-4 h-4 text-[#b92d1d]" />
          <span>Timeline Validation Engine Mechanics</span>
        </div>
        <ul className="list-disc list-inside space-y-1 text-neutral-600 pl-1">
          <li><strong>Single-Year Drill-Down Audit:</strong> Click any row in the timeline table to open a detailed single-year audit modal displaying all 53 fields grouped by concern with accounting identities verification.</li>
          <li><strong>Tax Gross-up Mechanics:</strong> Withdrawals in retirement are grossed up to cover both living expense needs and income taxes owed, preventing hidden tax funding gaps.</li>
          <li><strong>IRS Provisional Income SS Test:</strong> Social Security taxability is determined using exact IRS provisional income rules (Provisional Income = Other MAGI + 0.5 × Gross SS) with 50% and 85% progressive taxation brackets.</li>
          <li><strong>SECURE 2.0 RMD Rules:</strong> Mandatory distributions begin at age 75 for taxpayers born in 1960 or later, and age 73 for earlier cohorts.</li>
          <li><strong>Excel & Google Sheets Validation Export:</strong> Use "Export as shown" ({SUMMARY_FIELDS.length} columns) or "Export all fields" ({ROW_FIELDS.length} columns) to download audit spreadsheets including beginning/ending balances, growth, inflows, outflows, tax calculations, and shortfall metrics.</li>
        </ul>
      </div>

      <YearlyTimelineAuditModal
        row={auditRow}
        onClose={() => setAuditRow(null)}
        displayMode={displayMode}
        macroInflation={macroInflation}
        primaryCurrentAge={primaryAge}
      />
    </div>
  );
};
