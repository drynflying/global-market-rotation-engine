import React, { useState, useEffect } from 'react';

interface NumericInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'value' | 'onChange' | 'min' | 'max'> {
  value: number | undefined | null;
  onChange: (val: number) => void;
  min?: number | string;
  max?: number | string;
  fallbackOnBlur?: number;
  isFloat?: boolean;
}

export const NumericInput: React.FC<NumericInputProps> = ({
  value,
  onChange,
  min,
  max,
  fallbackOnBlur,
  isFloat = false,
  className = '',
  onFocus,
  onBlur,
  ...props
}) => {
  const [localStr, setLocalStr] = useState<string>(
    value !== undefined && value !== null && !isNaN(value) ? String(value) : ''
  );
  const [isFocused, setIsFocused] = useState(false);

  // Keep local string in sync with external numeric value when not focused
  useEffect(() => {
    if (!isFocused) {
      setLocalStr(
        value !== undefined && value !== null && !isNaN(value) ? String(value) : ''
      );
    }
  }, [value, isFocused]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    setLocalStr(raw);

    if (raw === '' || raw === '-') {
      return;
    }

    const parsed = isFloat ? parseFloat(raw) : parseInt(raw, 10);
    if (!isNaN(parsed)) {
      onChange(parsed);
    }
  };

  const handleFocus = (e: React.FocusEvent<HTMLInputElement>) => {
    setIsFocused(true);
    if (onFocus) onFocus(e);
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    setIsFocused(false);

    let parsed = isFloat ? parseFloat(localStr) : parseInt(localStr, 10);

    if (isNaN(parsed)) {
      if (fallbackOnBlur !== undefined) {
        parsed = fallbackOnBlur;
      } else if (value !== undefined && value !== null && !isNaN(value)) {
        parsed = value;
      } else {
        parsed = 0;
      }
    }

    const minNum = min !== undefined ? Number(min) : undefined;
    const maxNum = max !== undefined ? Number(max) : undefined;

    if (minNum !== undefined && !isNaN(minNum) && parsed < minNum) parsed = minNum;
    if (maxNum !== undefined && !isNaN(maxNum) && parsed > maxNum) parsed = maxNum;

    onChange(parsed);
    setLocalStr(String(parsed));

    if (onBlur) onBlur(e);
  };

  return (
    <input
      type="number"
      min={min}
      max={max}
      {...props}
      value={localStr}
      onChange={handleChange}
      onFocus={handleFocus}
      onBlur={handleBlur}
      className={className}
    />
  );
};
