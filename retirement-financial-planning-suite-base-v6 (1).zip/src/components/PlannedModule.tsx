import React from 'react';
import { Sparkles, CheckCircle2, LucideIcon } from 'lucide-react';

/**
 * Placeholder for a module that is planned but not yet built.
 *
 * Replaces StepPlaceholder, which rendered a "Step N" badge and a "Proceed to Step N"
 * action — wizard-era numbering that no longer matches anything. The app has not been a
 * linear sequence of steps for some time; the positional tab ids were retired for the
 * same reason.
 */
interface PlannedModuleProps {
  title: string;
  subtitle: string;
  features: string[];
  icon?: LucideIcon;
  /** Shown when the module's shape is still an open question. */
  note?: string;
}

export const PlannedModule: React.FC<PlannedModuleProps> = ({
  title,
  subtitle,
  features,
  icon: Icon = Sparkles,
  note,
}) => (
  <div className="space-y-6 max-w-5xl mx-auto">
    <div className="bg-white border border-slate-200/90 rounded-2xl p-6 sm:p-8 shadow-sm">
      <div className="flex items-center space-x-2 mb-3">
        <span className="inline-flex items-center gap-1 text-xs font-semibold text-slate-500 uppercase tracking-wider">
          <Icon className="w-3.5 h-3.5 text-blue-500" /> Planned Module
        </span>
      </div>

      <h2 className="text-2xl font-bold text-slate-900 tracking-tight">{title}</h2>
      <p className="mt-2 text-sm text-slate-600">{subtitle}</p>

      <ul className="mt-6 space-y-2.5">
        {features.map((f) => (
          <li key={f} className="flex items-start gap-2 text-sm text-slate-700">
            <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0 text-slate-300" />
            <span>{f}</span>
          </li>
        ))}
      </ul>

      {note && (
        <p className="mt-6 px-3 py-2 rounded-lg bg-slate-50 border border-slate-200 text-[12px] text-slate-600">
          {note}
        </p>
      )}
    </div>
  </div>
);
