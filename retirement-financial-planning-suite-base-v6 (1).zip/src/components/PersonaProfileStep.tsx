import React, { useState } from 'react';
import { Plan, UserProfile, IncomeStream, IncomeType, OwnerType } from '../types';
import { DEFAULT_PLAN } from '../constants/defaultPlan';
import { UpdateOptions } from '../store/usePlanStore';
import { getSsAnnualBenefit } from '../domain/simulation/simulationEngine';
import { syncSocialSecurityStreams } from '../domain/income/ssStreamSync';
import { NumericInput } from './NumericInput';
import { 
  User, 
  Users, 
  Info, 
  ExternalLink, 
  X,
  ShieldAlert,
  AlertTriangle,
  DollarSign,
  Plus,
  Trash2,
  Edit2,
  Briefcase,
  Building,
  Gift,
  TrendingUp,
  Wallet,
  Calendar,
  Layers,
  MapPin
} from 'lucide-react';
import { STATE_TAX_RULES, findStateRule } from '../domain/tax/stateTaxConstants';

interface PersonaProfileStepProps {
  plan: Plan;
  onUpdatePlan: (updated: Plan, options?: UpdateOptions) => void;
  onGoToValidations?: () => void;
  onGoToScenarios?: () => void;
}

export const calculateAgeFromBirthdate = (birthDateStr?: string): number => {
  if (!birthDateStr) return 52;
  let birthDate: Date | null = null;
  
  if (birthDateStr.includes('/')) {
    const parts = birthDateStr.split('/');
    if (parts.length === 3) {
      const month = parseInt(parts[0], 10) - 1;
      const day = parseInt(parts[1], 10);
      const year = parseInt(parts[2], 10);
      if (!isNaN(month) && !isNaN(day) && !isNaN(year) && year > 1900 && year < 2100) {
        birthDate = new Date(year, month, day);
      }
    }
  } else if (birthDateStr.includes('-')) {
    const parts = birthDateStr.split('-');
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      if (!isNaN(month) && !isNaN(day) && !isNaN(year) && year > 1900 && year < 2100) {
        birthDate = new Date(year, month, day);
      }
    }
  }

  if (!birthDate || isNaN(birthDate.getTime())) return 52;

  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age >= 0 ? age : 0;
};

export const PersonaProfileStep: React.FC<PersonaProfileStepProps> = ({
  plan,
  onUpdatePlan,
  onGoToValidations,
  onGoToScenarios,
}) => {
  const p = plan.primaryPerson;
  const s = plan.spousePerson;
  const stateRule = findStateRule(plan.stateOfResidence);

  // Modal for Income Amount guidance
  const [showIncomeGuidanceModal, setShowIncomeGuidanceModal] = useState(false);
  const [openWarningStreamId, setOpenWarningStreamId] = useState<string | null>(null);  // Helper updates for primary & spouse profiles
  const updatePrimary = (field: keyof UserProfile, val: any) => {
    const updatedPrimary = { ...plan.primaryPerson, [field]: val };
    if (field === 'birthDate') {
      updatedPrimary.currentAge = calculateAgeFromBirthdate(val);
    }

    const updatedStreams = syncSocialSecurityStreams(
      (plan.incomeStreams ?? []).map(s => {
        if (s.owner === 'primary' && s.type === 'salary' && field === 'retirementAge') {
          return { ...s, endAge: val };
        }
        return s;
      }),
      updatedPrimary,
      plan.spousePerson
    );

    onUpdatePlan({
      ...plan,
      primaryPerson: updatedPrimary,
      incomeStreams: updatedStreams,
    });
  };

  const updateSpouse = (field: keyof UserProfile, val: any) => {
    const updatedSpouse = { ...plan.spousePerson, [field]: val };
    if (field === 'birthDate') {
      updatedSpouse.currentAge = calculateAgeFromBirthdate(val);
    }

    const updatedStreams = syncSocialSecurityStreams(
      (plan.incomeStreams ?? []).map(s => {
        if (s.owner === 'spouse' && s.type === 'salary' && field === 'retirementAge') {
          return { ...s, endAge: val };
        }
        return s;
      }),
      plan.primaryPerson,
      updatedSpouse
    );

    onUpdatePlan({
      ...plan,
      spousePerson: updatedSpouse,
      incomeStreams: updatedStreams,
    });
  };

  // Switch Filing Structure (Married Joint vs Single)
  const toggleFilingStructure = (hasSpouse: boolean) => {
    onUpdatePlan({
      ...plan,
      hasSpouse,
      filingStatus: hasSpouse ? 'joint' : 'single',
    });
  };

  // Income Streams State & Handlers
  const incomeStreams: IncomeStream[] = plan.incomeStreams !== undefined
    ? plan.incomeStreams
    : (DEFAULT_PLAN.incomeStreams || []);

  const [showIncomeModal, setShowIncomeModal] = useState(false);
  const [editingStreamId, setEditingStreamId] = useState<string | null>(null);
  const [incomeForm, setIncomeForm] = useState<{
    name: string;
    owner: OwnerType;
    type: IncomeType;
    amount: number;
    startAge: number;
    endAge: number;
    growthRatePct: number;
    taxability: 'fully_taxable' | 'partially_taxable' | 'tax_exempt';
    notes?: string;
  }>({
    name: '',
    owner: 'primary',
    type: 'salary',
    amount: 60000,
    startAge: p.currentAge,
    endAge: p.retirementAge,
    growthRatePct: 2.5,
    taxability: 'fully_taxable',
    notes: '',
  });

  const updateIncomeStreams = (updatedStreams: IncomeStream[]) => {
    onUpdatePlan({
      ...plan,
      incomeStreams: updatedStreams,
    });
  };

  const openNewIncomeModal = () => {
    setEditingStreamId(null);
    setIncomeForm({
      name: '',
      owner: 'primary',
      type: 'salary',
      amount: 60000,
      startAge: p.currentAge,
      endAge: p.retirementAge,
      growthRatePct: 2.5,
      taxability: 'fully_taxable',
      notes: '',
    });
    setShowIncomeModal(true);
  };

  const openEditIncomeModal = (stream: IncomeStream) => {
    setEditingStreamId(stream.id);
    setIncomeForm({
      name: stream.name,
      owner: stream.owner,
      type: stream.type,
      amount: stream.amount,
      startAge: stream.startAge,
      endAge: stream.endAge,
      growthRatePct: stream.growthRatePct ?? 2.5,
      taxability: stream.taxability || 'fully_taxable',
      notes: stream.notes || '',
    });
    setShowIncomeModal(true);
  };

  const handleSaveIncomeModal = (e: React.FormEvent) => {
    e.preventDefault();
    const title = incomeForm.name.trim() || 'Income Stream';
    
    if (editingStreamId) {
      const updated = incomeStreams.map(s => 
        s.id === editingStreamId 
          ? { ...incomeForm, name: title, id: editingStreamId } 
          : s
      );
      updateIncomeStreams(updated);
    } else {
      const newStream: IncomeStream = {
        ...incomeForm,
        name: title,
        id: `inc-${Date.now()}`,
      };
      updateIncomeStreams([newStream, ...incomeStreams]);
    }
    setShowIncomeModal(false);
  };

  const deleteIncomeStream = (id: string) => {
    updateIncomeStreams(incomeStreams.filter(s => s.id !== id));
  };

  // Income summary calculations
  const totalPreRetirementIncome = incomeStreams
    .filter(s => s.type === 'salary' || (s.startAge <= p.currentAge && s.endAge <= p.retirementAge))
    .reduce((acc, s) => acc + s.amount, 0);

  const totalPostRetirementIncome = incomeStreams
    .filter(s => s.type !== 'salary' && s.startAge >= p.retirementAge)
    .reduce((acc, s) => acc + s.amount, 0);

  const getTypeIcon = (type: IncomeType) => {
    switch (type) {
      case 'salary': return <Briefcase className="w-4 h-4 text-blue-600" />;
      case 'pension': return <Building className="w-4 h-4 text-emerald-600" />;
      case 'social_security': return <Wallet className="w-4 h-4 text-indigo-600" />;
      case 'rental': return <Building className="w-4 h-4 text-amber-600" />;
      case 'business': return <TrendingUp className="w-4 h-4 text-cyan-600" />;
      case 'inheritance': return <Gift className="w-4 h-4 text-purple-600" />;
      case 'annuity': return <DollarSign className="w-4 h-4 text-teal-600" />;
      default: return <DollarSign className="w-4 h-4 text-slate-600" />;
    }
  };

  // Helper to compute SS annual benefit based on strategy levers
  const calculateSsAnnualStreamBenefit = (streamOwner: OwnerType) => {
    const person = streamOwner === 'spouse' ? s : p;
    const statutory = plan.statutoryParams || DEFAULT_PLAN.statutoryParams!;
    return Math.round(getSsAnnualBenefit(person, person.ssClaimAge, statutory));
  };

  return (
    <div className="space-y-6">
      
      {/* Persona Profiles Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Primary Profile Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 min-h-[44px]">
            <div className="flex items-center space-x-2">
              <User className="w-4 h-4 text-blue-600" />
              <h3 className="text-sm font-bold text-slate-900">Primary</h3>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="col-span-2">
              <div className="flex items-center justify-between mb-1 min-h-[22px]">
                <label className="block text-slate-600 font-medium">Full Name</label>
              </div>
              <input
                type="text"
                value={p.name}
                autoComplete="off"
                data-lpignore="true"
                data-1p-ignore="true"
                data-bwignore="true"
                onChange={(e) => updatePrimary('name', e.target.value)}
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>

            <div className="col-span-2 sm:col-span-1">
              <div className="flex items-center justify-between mb-1 min-h-[22px]">
                <label className="block text-slate-600 font-medium">Birthdate</label>
                <span className="text-[11px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-100">
                  Age: {calculateAgeFromBirthdate(p.birthDate)} yrs
                </span>
              </div>
              <input
                type="text"
                placeholder="01/01/1974"
                value={p.birthDate ?? '01/01/1974'}
                autoComplete="off"
                data-lpignore="true"
                data-1p-ignore="true"
                data-bwignore="true"
                onChange={(e) => {
                  const val = e.target.value;
                  const newAge = calculateAgeFromBirthdate(val);
                  onUpdatePlan({
                    ...plan,
                    primaryPerson: {
                      ...plan.primaryPerson,
                      birthDate: val,
                      currentAge: newAge,
                    },
                  });
                }}
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
              <span className="text-[10px] text-slate-400 mt-0.5 block">Format: MM/DD/YYYY</span>
            </div>

            <div className="col-span-2 sm:col-span-1">
              <div className="flex items-center justify-between mb-1 min-h-[22px]">
                <label className="block text-slate-600 font-medium">Target Retirement Age</label>
              </div>
              <NumericInput
                value={p.retirementAge}
                autoComplete="off"
                onChange={(val) => updatePrimary('retirementAge', val)}
                fallbackOnBlur={p.currentAge}
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-bold text-blue-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
              <span className="text-[10px] text-transparent mt-0.5 block select-none" aria-hidden="true">&nbsp;</span>
            </div>

            <div className="col-span-2 sm:col-span-1">
              <div className="flex items-center justify-between mb-1 min-h-[22px]">
                <label className="block text-slate-600 font-medium">Life Expectancy</label>
              </div>
              <NumericInput
                value={p.lifeExpectancy}
                autoComplete="off"
                onChange={(val) => updatePrimary('lifeExpectancy', val)}
                fallbackOnBlur={90}
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>

            <div className="col-span-2 sm:col-span-1">
              <div className="flex items-center justify-between mb-1 min-h-[22px]">
                <label className="block text-slate-600 font-medium">SS Benefit at FRA ($/mo)</label>
              </div>
              <NumericInput
                value={p.ssMonthlyBenefit}
                isFloat
                autoComplete="off"
                onChange={(val) => updatePrimary('ssMonthlyBenefit', val)}
                placeholder="Benefit at FRA (67)"
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-bold focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>
        </div>

        {/* Spouse Profile Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 min-h-[44px]">
            <div className="flex items-center space-x-2">
              <Users className="w-4 h-4 text-indigo-600" />
              <h3 className="text-sm font-bold text-slate-900">Spouse</h3>
            </div>

            {/* Married Joint vs Single Filing Structure Toggle */}
            <div className="bg-slate-100 p-0.5 rounded-xl border border-slate-200 flex items-center space-x-1">
              <button
                type="button"
                onClick={() => toggleFilingStructure(true)}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-all flex items-center space-x-1 ${
                  plan.hasSpouse
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span>Married Joint</span>
              </button>

              <button
                type="button"
                onClick={() => toggleFilingStructure(false)}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-all flex items-center space-x-1 ${
                  !plan.hasSpouse
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <User className="w-3.5 h-3.5" />
                <span>Single</span>
              </button>
            </div>
          </div>

          {plan.hasSpouse ? (
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="col-span-2">
                <div className="flex items-center justify-between mb-1 min-h-[22px]">
                  <label className="block text-slate-600 font-medium">Full Name</label>
                </div>
                <input
                  type="text"
                  value={s.name}
                  autoComplete="off"
                  data-lpignore="true"
                  data-1p-ignore="true"
                  data-bwignore="true"
                  onChange={(e) => updateSpouse('name', e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div className="col-span-2 sm:col-span-1">
                <div className="flex items-center justify-between mb-1 min-h-[22px]">
                  <label className="block text-slate-600 font-medium">Birthdate</label>
                  <span className="text-[11px] font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
                    Age: {calculateAgeFromBirthdate(s.birthDate)} yrs
                  </span>
                </div>
                <input
                  type="text"
                  placeholder="01/01/1974"
                  value={s.birthDate ?? '01/01/1974'}
                  autoComplete="off"
                  data-lpignore="true"
                  data-1p-ignore="true"
                  data-bwignore="true"
                  onChange={(e) => {
                    const val = e.target.value;
                    const newAge = calculateAgeFromBirthdate(val);
                    onUpdatePlan({
                      ...plan,
                      spousePerson: {
                        ...plan.spousePerson,
                        birthDate: val,
                        currentAge: newAge,
                      },
                    });
                  }}
                  className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
                <span className="text-[10px] text-slate-400 mt-0.5 block">Format: MM/DD/YYYY</span>
              </div>

              <div className="col-span-2 sm:col-span-1">
                <div className="flex items-center justify-between mb-1 min-h-[22px]">
                  <label className="block text-slate-600 font-medium">Target Retirement Age</label>
                </div>
                <NumericInput
                  value={s.retirementAge}
                  autoComplete="off"
                  onChange={(val) => updateSpouse('retirementAge', val)}
                  fallbackOnBlur={s.currentAge}
                  className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-bold text-indigo-700 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
                <span className="text-[10px] text-transparent mt-0.5 block select-none" aria-hidden="true">&nbsp;</span>
              </div>

              <div className="col-span-2 sm:col-span-1">
                <div className="flex items-center justify-between mb-1 min-h-[22px]">
                  <label className="block text-slate-600 font-medium">Life Expectancy</label>
                </div>
                <NumericInput
                  value={s.lifeExpectancy}
                  autoComplete="off"
                  onChange={(val) => updateSpouse('lifeExpectancy', val)}
                  fallbackOnBlur={95}
                  className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div className="col-span-2 sm:col-span-1">
                <div className="flex items-center justify-between mb-1 min-h-[22px]">
                  <label className="block text-slate-600 font-medium">SS Benefit at FRA ($/mo)</label>
                </div>
                <NumericInput
                  value={s.ssMonthlyBenefit}
                  isFloat
                  autoComplete="off"
                  onChange={(val) => updateSpouse('ssMonthlyBenefit', val)}
                  placeholder="Benefit at FRA (67)"
                  className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-bold focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
            </div>
          ) : (
            <div className="py-5 px-4 border border-dashed border-slate-200 rounded-xl flex flex-col items-center justify-center text-center space-y-2 bg-slate-50/50">
              <p className="text-xs font-semibold text-slate-700">
                Single filing structure selected.
              </p>
              <p className="text-xs text-slate-500 max-w-md leading-relaxed">
                If you are married and filing separately, each spouse should maintain a separate financial plan. You can create or manage additional plans in{' '}
                <button
                  type="button"
                  onClick={onGoToScenarios}
                  className="inline-flex items-center font-semibold text-blue-600 hover:text-blue-800 underline underline-offset-2 cursor-pointer transition-colors"
                >
                  Scenario Planning
                </button>
                .
              </p>
            </div>
          )}

        </div>

        {/* Tax Residence Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 min-h-[44px]">
            <div className="flex items-center space-x-2">
              <MapPin className="w-4 h-4 text-emerald-600" />
              <h3 className="text-sm font-bold text-slate-900">Tax Residence</h3>
            </div>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-600 font-medium mb-1">State of Residence</label>
              <select
                value={plan.stateOfResidence || 'CO'}
                onChange={(e) => onUpdatePlan({ ...plan, stateOfResidence: e.target.value })}
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
              >
                {STATE_TAX_RULES.map((r) => (
                  <option key={r.code} value={r.code}>
                    {r.name}
                  </option>
                ))}
              </select>
              <span className="text-[11px] text-slate-500 mt-1 block">
                {stateRule.kind === 'none'
                  ? 'No state income tax is applied.'
                  : stateRule.kind === 'unsupported'
                  ? 'State income tax is not modeled for this state ($0 modeled).'
                  : stateRule.kind === 'custom'
                  ? 'Enter your own effective state rate.'
                  : `Flat ${stateRule.ratePct}% on state-taxable income.`}
              </span>
            </div>

            {stateRule.kind === 'unsupported' && (
              <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg flex items-start space-x-2 text-amber-900">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <p className="text-[11px] leading-relaxed">
                  State income tax for {plan.stateOfResidence} is not currently modeled in the tax engine ($0 applied). Use &quot;Custom Rate&quot; to specify your estimated effective state tax rate.
                </p>
              </div>
            )}

            {stateRule.kind === 'custom' && (
              <div>
                <label className="block text-slate-600 font-medium mb-1">Effective State Rate (%)</label>
                <input
                  type="number"
                  step="0.01"
                  placeholder="e.g. 5.0"
                  value={plan.customStateRatePct ?? ''}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    onUpdatePlan({
                      ...plan,
                      customStateRatePct: isNaN(val) ? undefined : val,
                    });
                  }}
                  className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-bold focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>
            )}

            {stateRule.progressiveNotModelled && (
              <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg flex items-start space-x-2 text-amber-900">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <p className="text-[11px] leading-relaxed">
                  This state uses progressive tax brackets. It is approximated in the projection with a single estimated effective rate.
                </p>
              </div>
            )}

            {stateRule.notes && (
              <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg flex items-start space-x-2 text-slate-700">
                <Info className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                <p className="text-[11px] leading-relaxed">{stateRule.notes}</p>
              </div>
            )}
          </div>
        </div>

      </div>

      {/* SECTION 2: Income Streams */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-3 border-b border-slate-100 gap-3">
          <div className="flex items-center space-x-2">
            <DollarSign className="w-5 h-5 text-emerald-600" />
            <h3 className="text-base font-bold text-slate-900 tracking-tight">
              Income Streams
            </h3>
          </div>

          <div className="flex items-center space-x-2 shrink-0">
            <button
              type="button"
              onClick={openNewIncomeModal}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-2xs flex items-center space-x-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Income Stream</span>
            </button>
          </div>
        </div>

        {/* Income Stream Summary Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-center space-x-3">
            <div className="p-2 bg-blue-100 text-blue-700 rounded-lg">
              <Briefcase className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">Pre-Retirement Earned</span>
              <span className="text-sm font-extrabold text-slate-900">${totalPreRetirementIncome.toLocaleString()}/yr</span>
            </div>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-center space-x-3">
            <div className="p-2 bg-emerald-100 text-emerald-700 rounded-lg">
              <Wallet className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">Post-Retirement Guaranteed</span>
              <span className="text-sm font-extrabold text-slate-900">${totalPostRetirementIncome.toLocaleString()}/yr</span>
            </div>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-center space-x-3">
            <div className="p-2 bg-purple-100 text-purple-700 rounded-lg">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">Total Active Streams</span>
              <span className="text-sm font-extrabold text-slate-900">{incomeStreams.length} Sources</span>
            </div>
          </div>
        </div>

        {/* Income Streams Register Table */}
        <div className="border border-slate-200 rounded-xl bg-white shadow-2xs overflow-hidden">
          <table className="w-full text-left text-xs table-fixed">
            <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-2.5 px-3 w-[28%]">Income Source & Type</th>
                <th className="py-2.5 px-2 w-[16%]">Owner</th>
                <th className="py-2.5 px-2 w-[16%]">
                  <div className="flex items-center space-x-1">
                    <span>Amount ($/yr)</span>
                    <button
                      type="button"
                      onClick={() => setShowIncomeGuidanceModal(true)}
                      className="p-0.5 text-slate-400 hover:text-blue-600 rounded hover:bg-slate-200 transition-colors cursor-pointer"
                      title="View Income Guidance (Pre-Tax Gross vs Net)"
                    >
                      <Info className="w-3.5 h-3.5 text-blue-600" />
                    </button>
                  </div>
                </th>
                <th className="py-2.5 px-2 w-[16%]">Timeline (Age)</th>
                <th className="py-2.5 px-2 w-[9%]">COLA %</th>
                <th className="py-2.5 px-2 w-[11%]">Tax Status</th>
                <th className="py-2.5 px-1 text-center w-[6%]">Act</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
              {incomeStreams.map((stream) => {
                const isSs = stream.type === 'social_security';
                const ssPerson = stream.owner === 'spouse' ? s : p;
                const ssAmount = isSs ? calculateSsAnnualStreamBenefit(stream.owner) : stream.amount;
                const ssStartAge = isSs ? ssPerson.ssClaimAge : stream.startAge;
                const ssEndAge = isSs ? ssPerson.lifeExpectancy : stream.endAge;

                const streamOwnerPerson = stream.owner === 'spouse' && plan.hasSpouse && s ? s : p;
                const expectedRetirementAge = streamOwnerPerson.retirementAge;
                const showSalaryEndAgeWarning = stream.type === 'salary' && stream.endAge !== expectedRetirementAge;
                const ownerFirstName = streamOwnerPerson.name ? streamOwnerPerson.name.split(' ')[0] : (stream.owner === 'spouse' ? 'Spouse' : 'Primary');

                const typeLabelMap: Record<IncomeType, string> = {
                  salary: 'W-2 Salary',
                  pension: 'Pension Annuity',
                  social_security: 'Social Security',
                  rental: 'Rental Income',
                  business: 'Business / Self-Employed',
                  inheritance: 'Inheritance / Lump Sum',
                  annuity: 'Fixed Annuity',
                  other: 'Other Inflow'
                };

                const taxLabelMap: Record<string, string> = {
                  fully_taxable: 'Fully Taxable',
                  partially_taxable: 'Partially Taxable',
                  tax_exempt: 'Tax Exempt'
                };

                return (
                  <tr key={stream.id} className={`hover:bg-slate-50/80 transition-colors ${isSs ? 'bg-blue-50/30' : ''}`}>
                    <td className="py-2.5 px-3">
                      <div className="flex items-center space-x-2">
                        <div className="p-1.5 bg-slate-100 rounded-lg text-slate-600 shrink-0">
                          {getTypeIcon(stream.type)}
                        </div>
                        <div className="min-w-0">
                          <div className="font-bold text-slate-900 text-xs truncate">{stream.name}</div>
                          <span className={`inline-block text-[10px] font-semibold px-1.5 py-0.2 rounded ${
                            isSs ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-700'
                          }`}>
                            {typeLabelMap[stream.type] || stream.type}
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="py-2.5 px-2 text-slate-700 font-semibold text-xs">
                      {stream.owner === 'spouse' ? `Spouse (${s.name ? s.name.split(' ')[0] : 'Spouse'})` : (stream.owner === 'joint' ? 'Joint' : `Primary (${p.name ? p.name.split(' ')[0] : 'Primary'})`)}
                    </td>

                    <td className="py-2.5 px-2 font-extrabold text-slate-900 text-xs">
                      ${ssAmount.toLocaleString()}<span className="text-[10px] text-slate-500 font-normal">/yr</span>
                    </td>

                    <td className="py-2.5 px-2">
                      <div className="flex items-center space-x-1.5">
                        <span className="font-bold text-slate-800 text-xs">Age {ssStartAge} → {ssEndAge}</span>
                        {showSalaryEndAgeWarning && (
                          <div className="relative inline-flex items-center shrink-0">
                            <button
                              type="button"
                              onClick={() => setOpenWarningStreamId(openWarningStreamId === stream.id ? null : stream.id)}
                              className="inline-flex items-center text-amber-500 hover:text-amber-600 transition-colors cursor-pointer p-0.5 rounded"
                              title="Retirement Age Mismatch Warning"
                            >
                              <AlertTriangle className="w-3.5 h-3.5" />
                            </button>
                            {openWarningStreamId === stream.id && (
                              <div className="absolute right-0 top-full mt-1.5 w-60 p-2.5 bg-amber-50 border border-amber-200 rounded-lg shadow-lg z-30 text-left text-xs text-amber-950">
                                <div className="flex items-start justify-between gap-1 mb-1">
                                  <span className="font-semibold text-amber-900 flex items-center gap-1.5 text-[11px]">
                                    <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                                    Retirement Age Mismatch
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => setOpenWarningStreamId(null)}
                                    className="text-amber-700 hover:text-amber-950 p-0.5 rounded hover:bg-amber-100 transition-colors cursor-pointer"
                                  >
                                    <X className="w-3 h-3" />
                                  </button>
                                </div>
                                <p className="text-[11px] text-amber-800 leading-relaxed">
                                  W-2 Salary end age (<strong>{stream.endAge}</strong>) differs from {ownerFirstName}&apos;s target retirement age (<strong>{expectedRetirementAge}</strong>).
                                </p>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </td>

                    <td className="py-2.5 px-2 font-semibold text-slate-700 text-xs">
                      {stream.growthRatePct ?? 2.5}%
                    </td>

                    <td className="py-2.5 px-2">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200">
                        {taxLabelMap[stream.taxability || 'fully_taxable'] || 'Fully Taxable'}
                      </span>
                    </td>

                    <td className="py-2.5 px-1 text-center">
                      {isSs ? (
                        <span className="text-[9px] text-blue-700 font-bold italic bg-blue-50 px-1.5 py-0.5 rounded border border-blue-100 inline-block">
                          Auto
                        </span>
                      ) : (
                        <div className="flex items-center justify-center space-x-1">
                          <button
                            type="button"
                            onClick={() => openEditIncomeModal(stream)}
                            className="p-1 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors cursor-pointer"
                            title="Edit income stream"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => deleteIncomeStream(stream.id)}
                            className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                            title="Delete income stream"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Add / Edit Income Stream */}
      {showIncomeModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 border border-slate-200 relative space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  {editingStreamId ? 'Edit Income Stream' : 'Add New Income Stream'}
                </h3>
                <p className="text-xs text-slate-500">
                  Configure income owner, stream type, gross annual amount, growth rate, and active timeline.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowIncomeModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveIncomeModal} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Income Source Title</label>
                <input
                  type="text"
                  required
                  value={incomeForm.name}
                  onChange={(e) => setIncomeForm({ ...incomeForm, name: e.target.value })}
                  placeholder="e.g., Primary W-2 Salary, Consulting Income, or Pension"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Income Owner</label>
                  <select
                    value={incomeForm.owner}
                    onChange={(e) => setIncomeForm({ ...incomeForm, owner: e.target.value as OwnerType })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
                  >
                    <option value="primary">Primary ({p.name ? p.name.split(' ')[0] : 'Primary'})</option>
                    {plan.hasSpouse && <option value="spouse">Spouse ({s.name ? s.name.split(' ')[0] : 'Spouse'})</option>}
                    <option value="joint">Joint Household</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Income Type / Category</label>
                  <select
                    value={incomeForm.type}
                    onChange={(e) => setIncomeForm({ ...incomeForm, type: e.target.value as IncomeType })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
                  >
                    <option value="salary">W-2 Salary</option>
                    <option value="pension">Pension Annuity</option>
                    <option value="rental">Rental Income</option>
                    <option value="business">Business / Self-Employed</option>
                    <option value="inheritance">One-Time / Inheritance</option>
                    <option value="annuity">Fixed Annuity</option>
                    <option value="other">Other Inflow</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Gross Annual Amount ($/yr)</label>
                  <NumericInput
                    value={incomeForm.amount}
                    isFloat
                    min="0"
                    onChange={(val) => setIncomeForm({ ...incomeForm, amount: val })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-bold focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Annual COLA / Growth (%)</label>
                  <NumericInput
                    value={incomeForm.growthRatePct}
                    isFloat
                    step="0.1"
                    onChange={(val) => setIncomeForm({ ...incomeForm, growthRatePct: val })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-bold focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Start Age (Yr)</label>
                  <NumericInput
                    value={incomeForm.startAge}
                    onChange={(val) => setIncomeForm({ ...incomeForm, startAge: val })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-bold focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">End Age (Yr)</label>
                  <NumericInput
                    value={incomeForm.endAge}
                    onChange={(val) => setIncomeForm({ ...incomeForm, endAge: val })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-bold focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Tax Treatment Status</label>
                <select
                  value={incomeForm.taxability}
                  onChange={(e) => setIncomeForm({ ...incomeForm, taxability: e.target.value as any })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
                >
                  <option value="fully_taxable">Fully Taxable (Earned Income, Pension, Traditional)</option>
                  <option value="partially_taxable">Partially Taxable (Social Security, Partial Return of Capital)</option>
                  <option value="tax_exempt">Tax Exempt (Roth Distribution, Tax-Exempt Muni Interest)</option>
                </select>
              </div>

              <div className="flex justify-end space-x-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowIncomeModal(false)}
                  className="px-4 py-2 font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs transition-colors cursor-pointer"
                >
                  Save Income Stream
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Income Guidance Info Modal */}
      {showIncomeGuidanceModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6 border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2 text-blue-700">
                <Info className="w-5 h-5 text-blue-600" />
                <h3 className="text-base font-bold text-slate-900">Income Amount Guidance</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowIncomeGuidanceModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-600 leading-relaxed">
              <div className="p-3 bg-blue-50/80 rounded-xl border border-blue-200 space-y-1 text-blue-950">
                <span className="font-bold block text-xs">Enter Gross Pre-Tax Annual Income</span>
                <p className="text-[11px] text-blue-900">
                  For earned income, salary, pension, or annuity streams, enter the total annual gross (pre-tax) figure before federal/state withholdings, payroll taxes, or 401(k) deductions.
                </p>
              </div>

              <div className="space-y-2 pt-1">
                <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wide">Why Pre-Tax (Gross) Income?</h4>
                <ul className="list-disc pl-4 space-y-1 text-[11px] text-slate-600">
                  <li>
                    <strong>Comprehensive Tax Engine:</strong> The retirement model calculates income taxes (Federal Brackets, Standard Deductions, State Tax, FICA, and IRMAA surcharges) on top of gross income.
                  </li>
                  <li>
                    <strong>Pre-Tax Retirement Contributions:</strong> 401(k) / 403(b) elective deferrals are modeled as tax-deductible pre-tax savings taken out of your gross earned income.
                  </li>
                  <li>
                    <strong>Do NOT enter Net / Take-Home Pay or AGI:</strong> Entering net pay would cause income taxes to be double-counted in cash flow projections.
                  </li>
                </ul>
              </div>

              <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 text-[11px] text-slate-500">
                <strong>Tax Treatment Column:</strong> You can set individual streams as <em>Fully Taxable</em> (Salary/Pension), <em>Partially Taxable</em> (Social Security), or <em>Tax Exempt</em> (Municipal Bonds/Roth distributions) in the register.
              </div>
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowIncomeGuidanceModal(false)}
                className="px-4 py-2 bg-slate-900 text-white font-semibold rounded-xl text-xs hover:bg-slate-800 transition-colors"
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
