import React from 'react';
import { Plan, AccountItem, AccountAllocation } from '../types';
import { UpdateOptions } from '../store/usePlanStore';
import { DEFAULT_PLAN } from '../constants/defaultPlan';
import { runStep3Validations } from '../domain/validation/validations';
import { calculateAccountTotals, isAccountModeledInProjection } from '../domain/accounts/accountCapabilities';
import { getActiveW2Compensation, resolveAccountContribution } from '../domain/contributions/contributionResolver';
import { 
  TrendingUp, 
  PieChart, 
  Percent, 
  DollarSign, 
  AlertTriangle, 
  Info, 
  ArrowRight,
  Calculator
} from 'lucide-react';

interface Step3InvestmentsStepProps {
  plan: Plan;
  onUpdatePlan: (updatedPlan: Plan, options?: UpdateOptions) => void;
  onGoToValidations: () => void;
  onGoToNextStep?: () => void;
  hideHeader?: boolean;
}

export const Step3InvestmentsStep: React.FC<Step3InvestmentsStepProps> = ({
  plan,
  onUpdatePlan,
  onGoToValidations,
  onGoToNextStep,
  hideHeader = false,
}) => {
  const accounts = plan.accounts || [];
  const cma = plan.cmaAssumptions || DEFAULT_PLAN.cmaAssumptions!;
  const macro = plan.macroAssumptions || DEFAULT_PLAN.macroAssumptions!;
  const accountTotals = calculateAccountTotals(accounts, plan);

  // Helper to ensure an account has an allocation object
  const getAccountAlloc = (acc: AccountItem): AccountAllocation => {
    if (acc.allocation) return acc.allocation;
    if (acc.type === 'cash') {
      return { usEquityPct: 0, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 100 };
    }
    return { usEquityPct: 35, intlEquityPct: 20, goldPct: 10, bondsPct: 25, cashPct: 10 };
  };

  const getAccountFlow = (acc: AccountItem): number => {
    const ownerComp = getActiveW2Compensation(
      plan,
      acc.owner,
      plan.primaryPerson.currentAge,
      plan.hasSpouse ? plan.spousePerson.currentAge : undefined,
      0
    );
    const breakdown = resolveAccountContribution(acc, {
      ownerW2Compensation: ownerComp,
      contributionScale: 1.0,
    });
    return breakdown.totalAccountContribution;
  };

  // --- Portfolio Totals Calculation ---
  // Modeled accounts drive the expected geometric return for projections
  const allocAccounts = accounts.filter(a => isAccountModeledInProjection(a.type));

  const totalBalance = allocAccounts.reduce((sum, acc) => sum + (acc.balance || 0), 0);

  const totalUsEquityDollars = allocAccounts.reduce((sum, acc) => {
    const alloc = getAccountAlloc(acc);
    return sum + (acc.balance * (alloc.usEquityPct || 0) / 100);
  }, 0);

  const totalIntlEquityDollars = allocAccounts.reduce((sum, acc) => {
    const alloc = getAccountAlloc(acc);
    return sum + (acc.balance * (alloc.intlEquityPct || 0) / 100);
  }, 0);

  const totalGoldDollars = allocAccounts.reduce((sum, acc) => {
    const alloc = getAccountAlloc(acc);
    return sum + (acc.balance * (alloc.goldPct || 0) / 100);
  }, 0);

  const totalBondsDollars = allocAccounts.reduce((sum, acc) => {
    const alloc = getAccountAlloc(acc);
    return sum + (acc.balance * (alloc.bondsPct || 0) / 100);
  }, 0);

  const totalCashDollars = allocAccounts.reduce((sum, acc) => {
    const alloc = getAccountAlloc(acc);
    return sum + (acc.balance * (alloc.cashPct || 0) / 100);
  }, 0);

  // Portfolio overall percentages
  const usEquityPct = totalBalance > 0 ? (totalUsEquityDollars / totalBalance) * 100 : 0;
  const intlEquityPct = totalBalance > 0 ? (totalIntlEquityDollars / totalBalance) * 100 : 0;
  const goldPct = totalBalance > 0 ? (totalGoldDollars / totalBalance) * 100 : 0;
  const bondsPct = totalBalance > 0 ? (totalBondsDollars / totalBalance) * 100 : 0;
  const cashPct = totalBalance > 0 ? (totalCashDollars / totalBalance) * 100 : 0;

  // Annual Contributions by Asset Class
  const annualUsEquity = allocAccounts.reduce((sum, acc) => {
    const alloc = getAccountAlloc(acc);
    const flow = getAccountFlow(acc);
    return sum + (flow * (alloc.usEquityPct || 0) / 100);
  }, 0);

  const annualIntlEquity = allocAccounts.reduce((sum, acc) => {
    const alloc = getAccountAlloc(acc);
    const flow = getAccountFlow(acc);
    return sum + (flow * (alloc.intlEquityPct || 0) / 100);
  }, 0);

  const annualGold = allocAccounts.reduce((sum, acc) => {
    const alloc = getAccountAlloc(acc);
    const flow = getAccountFlow(acc);
    return sum + (flow * (alloc.goldPct || 0) / 100);
  }, 0);

  const annualBonds = allocAccounts.reduce((sum, acc) => {
    const alloc = getAccountAlloc(acc);
    const flow = getAccountFlow(acc);
    return sum + (flow * (alloc.bondsPct || 0) / 100);
  }, 0);

  const annualCash = allocAccounts.reduce((sum, acc) => {
    const alloc = getAccountAlloc(acc);
    const flow = getAccountFlow(acc);
    return sum + (flow * (alloc.cashPct || 0) / 100);
  }, 0);

  // --- Calculated Portfolio Weighted Return ---
  const weightedUsReturn = (usEquityPct / 100) * cma.usLargeEquity.derivedGeometric;
  const weightedIntlReturn = (intlEquityPct / 100) * cma.intlEquity.derivedGeometric;
  const weightedGoldReturn = (goldPct / 100) * cma.gold.derivedGeometric;
  const weightedBondReturn = (bondsPct / 100) * cma.intermediateBonds.derivedGeometric;
  const weightedCashReturn = (cashPct / 100) * cma.cashEquivalents.derivedGeometric;

  const grossNominalGeometricReturn = weightedUsReturn + weightedIntlReturn + weightedGoldReturn + weightedBondReturn + weightedCashReturn;
  const feeDrag = cma.annualPortfolioFeeDrag || 0.10;
  const netNominalGeometricReturn = Math.max(0, grossNominalGeometricReturn - feeDrag);
  const realGeometricReturn = (((1 + netNominalGeometricReturn / 100) / (1 + macro.generalInflation / 100)) - 1) * 100;

  // Step 3 Validation Checks
  const step3Validations = runStep3Validations(plan);
  const failCount = step3Validations.filter(v => v.status === 'fail').length;
  const warnCount = step3Validations.filter(v => v.status === 'warning').length;
  const passCount = step3Validations.filter(v => v.status === 'pass').length;

  return (
    <div className="space-y-6 w-full pb-12">
      
      {/* Step Header */}
      {!hideHeader && (
        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                Step 3
              </span>
              <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">
                Investments & Asset Class Allocations
              </span>
            </div>
            <h1 className="text-2xl font-bold text-slate-900 mt-1">
              Portfolio Asset Allocation & Expected Returns
            </h1>
            <p className="text-sm text-slate-600 mt-1 max-w-3xl">
              Configure line-item asset class targets per account (US & International Equities, Gold Commodity, Bonds, and Cash), review portfolio-wide weighted geometric returns, and test target model allocations.
            </p>
          </div>

          {onGoToNextStep && (
            <div className="flex items-center space-x-3 shrink-0">
              <button
                onClick={onGoToNextStep}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors"
              >
                <span>Step 4: Cash Flow</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* Top Portfolio Highlights KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Modeled Retirement Capital */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Modeled Retirement Capital</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 text-2xl font-bold text-slate-900">
            ${Math.round(accountTotals.modeledPortfolioBalance).toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-slate-500 flex flex-col gap-0.5">
            <div className="flex items-center justify-between">
              <span>{accountTotals.modeledCount} modeled accounts</span>
              <span className="text-emerald-600 font-medium">+${Math.round(accountTotals.modeledAnnualContributions).toLocaleString()}/yr flow</span>
            </div>
            {accountTotals.hasUnmodeledAssets && (
              <span className="text-[10px] text-amber-700 font-medium pt-0.5 border-t border-slate-100">
                +${Math.round(accountTotals.recordedNotModeledBalance).toLocaleString()} recorded assets (HSA / Real Estate)
              </span>
            )}
          </div>
        </div>

        {/* Card 2: Weighted Nominal Geometric Return */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Net Nominal Return</span>
            <TrendingUp className="w-4 h-4 text-blue-600" />
          </div>
          <div className="mt-2 text-2xl font-bold text-blue-900">
            {netNominalGeometricReturn.toFixed(2)}%
          </div>
          <div className="mt-1 text-xs text-slate-500 flex items-center justify-between">
            <span>Gross: {grossNominalGeometricReturn.toFixed(2)}%</span>
            <span className="text-slate-600 font-medium">-{(feeDrag * 100).toFixed(0)} bps fees</span>
          </div>
        </div>

        {/* Card 3: Real Expected Return (After Inflation) */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Real Expected Return</span>
            <Percent className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 text-2xl font-bold text-emerald-700">
            {realGeometricReturn.toFixed(2)}%
          </div>
          <div className="mt-1 text-xs text-slate-500 flex items-center justify-between">
            <span>CPI Inflation: {macro.generalInflation.toFixed(2)}%</span>
            <span className="text-emerald-600 font-medium">Net Real Purchasing Growth</span>
          </div>
        </div>

        {/* Card 4: Total Equity Risk Exposure */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Equity Exposure</span>
            <PieChart className="w-4 h-4 text-purple-600" />
          </div>
          <div className="mt-2 text-2xl font-bold text-purple-900">
            {(usEquityPct + intlEquityPct).toFixed(1)}%
          </div>
          <div className="mt-1 text-xs text-slate-500 flex items-center justify-between">
            <span>US: {usEquityPct.toFixed(1)}%</span>
            <span>Intl: {intlEquityPct.toFixed(1)}%</span>
          </div>
        </div>

      </div>

      {/* Validation Banner Summary */}
      {(failCount > 0 || warnCount > 0) && (
        <div className={`p-4 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
          failCount > 0 ? 'bg-amber-50 border-amber-200 text-amber-900' : 'bg-blue-50 border-blue-200 text-blue-900'
        }`}>
          <div className="flex items-center space-x-3">
            {failCount > 0 ? (
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
            ) : (
              <Info className="w-5 h-5 text-blue-600 shrink-0" />
            )}
            <div>
              <p className="text-sm font-semibold">
                Step 3 Allocation Diagnostics: {failCount} Error{failCount !== 1 ? 's' : ''}, {warnCount} Warning{warnCount !== 1 ? 's' : ''} detected
              </p>
              <p className="text-xs text-slate-600 mt-0.5">
                {failCount > 0 
                  ? 'One or more accounts have allocation totals that deviate from 100%.' 
                  : 'Review cash drag, international equity diversification, and sequence-of-returns risk warnings.'}
              </p>
            </div>
          </div>
          <button
            onClick={onGoToValidations}
            className="px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 text-slate-800 text-xs font-semibold rounded-lg shrink-0 shadow-sm"
          >
            Review Validations ({step3Validations.length})
          </button>
        </div>
      )}

      {/* Consolidated Portfolio Asset Class Distribution Bar & Breakdown */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
                <PieChart className="w-5 h-5 text-blue-600" />
                <span>Consolidated Portfolio Asset Allocation</span>
              </h2>
              <span className="inline-flex items-center space-x-1 text-[10px] font-semibold text-slate-600 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded-md">
                <Calculator className="w-3 h-3 text-slate-500" />
                <span>Calculated Output</span>
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Weighted breakdown across all {allocAccounts.length} modeled asset accounts
            </p>
          </div>
          <div className="text-right">
            <span className="text-xs font-medium text-slate-500">Asset Class Sum</span>
            <p className="text-sm font-bold text-emerald-600">
              {allocAccounts.length > 0 ? '100.0% Validated' : 'No Modeled Capital'}
            </p>
          </div>
        </div>

        {/* Stacked Percentage Bar */}
        <div className="space-y-1.5">
          <div className="h-6 w-full bg-slate-100 rounded-lg overflow-hidden flex shadow-inner">
            <div 
              style={{ width: `${usEquityPct}%` }} 
              className="bg-blue-600 h-full flex items-center justify-center text-[10px] font-bold text-white transition-all duration-300 relative group"
              title={`US Large Equity: ${usEquityPct.toFixed(1)}% ($${Math.round(totalUsEquityDollars).toLocaleString()})`}
            >
              {usEquityPct >= 6 && `${usEquityPct.toFixed(0)}%`}
            </div>
            <div 
              style={{ width: `${intlEquityPct}%` }} 
              className="bg-indigo-500 h-full flex items-center justify-center text-[10px] font-bold text-white transition-all duration-300 relative group"
              title={`Intl Equity: ${intlEquityPct.toFixed(1)}% ($${Math.round(totalIntlEquityDollars).toLocaleString()})`}
            >
              {intlEquityPct >= 6 && `${intlEquityPct.toFixed(0)}%`}
            </div>
            <div 
              style={{ width: `${goldPct}%` }} 
              className="bg-amber-500 h-full flex items-center justify-center text-[10px] font-bold text-white transition-all duration-300 relative group"
              title={`Gold Commodity: ${goldPct.toFixed(1)}% ($${Math.round(totalGoldDollars).toLocaleString()})`}
            >
              {goldPct >= 6 && `${goldPct.toFixed(0)}%`}
            </div>
            <div 
              style={{ width: `${bondsPct}%` }} 
              className="bg-emerald-600 h-full flex items-center justify-center text-[10px] font-bold text-white transition-all duration-300 relative group"
              title={`Intermediate Bonds: ${bondsPct.toFixed(1)}% ($${Math.round(totalBondsDollars).toLocaleString()})`}
            >
              {bondsPct >= 6 && `${bondsPct.toFixed(0)}%`}
            </div>
            <div 
              style={{ width: `${cashPct}%` }} 
              className="bg-slate-400 h-full flex items-center justify-center text-[10px] font-bold text-white transition-all duration-300 relative group"
              title={`Cash & Equivalents: ${cashPct.toFixed(1)}% ($${Math.round(totalCashDollars).toLocaleString()})`}
            >
              {cashPct >= 6 && `${cashPct.toFixed(0)}%`}
            </div>
          </div>
        </div>

        {/* 5 Asset Class Cards Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 pt-2">
          
          {/* Asset Class 1: US Equity */}
          <div className="p-3 rounded-lg border border-blue-100 bg-blue-50/50 space-y-1">
            <div className="flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-600 shrink-0"></span>
              <span className="text-xs font-semibold text-slate-800 truncate">US Equity</span>
            </div>
            <div className="text-lg font-bold text-slate-900">
              {usEquityPct.toFixed(1)}%
            </div>
            <div className="text-xs text-slate-600 font-medium">
              ${Math.round(totalUsEquityDollars).toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-500 border-t border-blue-100/80 pt-1 mt-1">
              +${Math.round(annualUsEquity).toLocaleString()}/yr flow
            </div>
          </div>

          {/* Asset Class 2: Intl Equity */}
          <div className="p-3 rounded-lg border border-indigo-100 bg-indigo-50/50 space-y-1">
            <div className="flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 shrink-0"></span>
              <span className="text-xs font-semibold text-slate-800 truncate">Intl Equity</span>
            </div>
            <div className="text-lg font-bold text-slate-900">
              {intlEquityPct.toFixed(1)}%
            </div>
            <div className="text-xs text-slate-600 font-medium">
              ${Math.round(totalIntlEquityDollars).toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-500 border-t border-indigo-100/80 pt-1 mt-1">
              +${Math.round(annualIntlEquity).toLocaleString()}/yr flow
            </div>
          </div>

          {/* Asset Class 3: Gold Commodity */}
          <div className="p-3 rounded-lg border border-amber-100 bg-amber-50/50 space-y-1">
            <div className="flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shrink-0"></span>
              <span className="text-xs font-semibold text-slate-800 truncate">Gold / Commodity</span>
            </div>
            <div className="text-lg font-bold text-slate-900">
              {goldPct.toFixed(1)}%
            </div>
            <div className="text-xs text-slate-600 font-medium">
              ${Math.round(totalGoldDollars).toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-500 border-t border-amber-100/80 pt-1 mt-1">
              +${Math.round(annualGold).toLocaleString()}/yr flow
            </div>
          </div>

          {/* Asset Class 4: Bonds */}
          <div className="p-3 rounded-lg border border-emerald-100 bg-emerald-50/50 space-y-1">
            <div className="flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 shrink-0"></span>
              <span className="text-xs font-semibold text-slate-800 truncate">Bonds</span>
            </div>
            <div className="text-lg font-bold text-slate-900">
              {bondsPct.toFixed(1)}%
            </div>
            <div className="text-xs text-slate-600 font-medium">
              ${Math.round(totalBondsDollars).toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-500 border-t border-emerald-100/80 pt-1 mt-1">
              +${Math.round(annualBonds).toLocaleString()}/yr flow
            </div>
          </div>

          {/* Asset Class 5: Cash */}
          <div className="p-3 rounded-lg border border-slate-200 bg-slate-50 space-y-1">
            <div className="flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-400 shrink-0"></span>
              <span className="text-xs font-semibold text-slate-800 truncate">Cash / ST Yield</span>
            </div>
            <div className="text-lg font-bold text-slate-900">
              {cashPct.toFixed(1)}%
            </div>
            <div className="text-xs text-slate-600 font-medium">
              ${Math.round(totalCashDollars).toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-500 border-t border-slate-200 pt-1 mt-1">
              +${Math.round(annualCash).toLocaleString()}/yr flow
            </div>
          </div>

        </div>
      </div>

    </div>
  );
};
