import React, { useState, useMemo } from 'react';
import { Plan, SpendingAssumptions, SpecialExpense } from '../types';
import { DEFAULT_PLAN } from '../constants/defaultPlan';
import { UpdateOptions } from '../store/usePlanStore';
import { NumericInput } from './NumericInput';
import { 
  DollarSign, 
  HeartPulse, 
  Smile, 
  Check, 
  Plus, 
  Trash2, 
  Sparkles, 
  ArrowRight,
  TrendingDown,
  Calendar,
  Layers,
  Info,
  Shield,
  ShieldAlert,
  PieChart,
  Edit3,
  Calculator,
  Sliders,
  Home,
  Utensils,
  Car,
  Activity,
  Compass,
  Briefcase,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  ShieldCheck,
  Zap,
  X
} from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
  ReferenceArea
} from 'recharts';
import { computeEssentialFloorPct } from '../domain/spending/essentialFloor';
import { getSimulation } from '../domain/simulation/simulationCache';

const RefArea = ReferenceArea as any;

interface SpendingStepProps {
  plan: Plan;
  onUpdatePlan: (updatedPlan: Plan, options?: UpdateOptions) => void;
  onGoToValidations?: () => void;
  onGoToNextStep?: () => void;
}

export interface BLSCategory {
  id: string;
  name: string;
  blsSharePct: number;
  defaultEssentialPct: number;
  group: 'Housing & Utilities' | 'Food & Dining' | 'Transportation' | 'Healthcare' | 'Discretionary & Leisure' | 'Other';
  description: string;
}

export const BLS_CATEGORIES: BLSCategory[] = [
  {
    id: 'housing',
    name: 'Housing (Mortgage/Rent, Tax, Ins, HOA)',
    blsSharePct: 28,
    defaultEssentialPct: 100,
    group: 'Housing & Utilities',
    description: 'Shelter, property taxes, home & umbrella liability insurance & HOA dues',
  },
  {
    id: 'utilities',
    name: 'Utilities (Power, Gas, Water, Internet)',
    blsSharePct: 7,
    defaultEssentialPct: 100,
    group: 'Housing & Utilities',
    description: 'Essential utility bills & home communications',
  },
  {
    id: 'home_maint',
    name: 'Home Maintenance & Improvements',
    blsSharePct: 3,
    defaultEssentialPct: 40,
    group: 'Housing & Utilities',
    description: 'Critical home repairs (40%) vs non-essential upgrades (60%)',
  },
  {
    id: 'groceries',
    name: 'Groceries & Food at Home',
    blsSharePct: 9,
    defaultEssentialPct: 100,
    group: 'Food & Dining',
    description: 'Essential supermarket groceries & household food staples',
  },
  {
    id: 'dining',
    name: 'Dining Out & Restaurants',
    blsSharePct: 4,
    defaultEssentialPct: 0,
    group: 'Food & Dining',
    description: 'Restaurants, takeout, cafes & social drinks',
  },
  {
    id: 'transportation',
    name: 'Transportation (Fuel, Ins, Upkeep)',
    blsSharePct: 10,
    defaultEssentialPct: 80,
    group: 'Transportation',
    description: 'Essential driving & upkeep (80%) vs secondary vehicle perks (20%)',
  },
  {
    id: 'vehicle_replace',
    name: 'Vehicle Replacement Reserve',
    blsSharePct: 5,
    defaultEssentialPct: 30,
    group: 'Transportation',
    description: 'Basic vehicle replacement fund (30%) vs upgraded luxury cars (70%)',
  },
  {
    id: 'pre65_bridge',
    name: 'Pre-65 ACA Health Insurance Bridge',
    blsSharePct: 0,
    defaultEssentialPct: 100,
    group: 'Healthcare',
    description: 'ACA Marketplace bridge premiums from retirement until Medicare starts at age 65',
  },
  {
    id: 'health_premiums',
    name: 'Health Insurance Premiums (Medicare)',
    blsSharePct: 8,
    defaultEssentialPct: 100,
    group: 'Healthcare',
    description: 'Medicare Part B/D/G supplemental premiums (Starts at Medicare age 65)',
  },
  {
    id: 'health_oop',
    name: 'Out-of-Pocket Medical & Rx (Medicare)',
    blsSharePct: 5,
    defaultEssentialPct: 100,
    group: 'Healthcare',
    description: 'Deductibles, copays, prescription drugs, dental & vision (Starts at Medicare age 65)',
  },
  {
    id: 'travel',
    name: 'Travel, Vacations & Expeditions',
    blsSharePct: 6,
    defaultEssentialPct: 0,
    group: 'Discretionary & Leisure',
    description: 'Flights, hotels, ocean cruises & extended trips',
  },
  {
    id: 'entertainment',
    name: 'Entertainment, Hobbies & Recreation',
    blsSharePct: 5,
    defaultEssentialPct: 0,
    group: 'Discretionary & Leisure',
    description: 'Golf, hobbies, theater, sports & streaming subscriptions',
  },
  {
    id: 'gifts_charity',
    name: 'Gifts & Charitable Giving',
    blsSharePct: 5,
    defaultEssentialPct: 0,
    group: 'Discretionary & Leisure',
    description: 'Family gifts, holiday presents & non-profit donations',
  },
  {
    id: 'clothing',
    name: 'Clothing & Personal Care',
    blsSharePct: 3,
    defaultEssentialPct: 50,
    group: 'Other',
    description: 'Essential apparel & grooming (50%) vs discretionary luxury fashion (50%)',
  },
  {
    id: 'everything_else',
    name: 'Everything Else & Sundry',
    blsSharePct: 2,
    defaultEssentialPct: 50,
    group: 'Other',
    description: 'Miscellaneous household supplies, legal/tax prep & admin',
  },
];

interface CategoryEssentialSliderProps {
  value: number;
  onChange: (val: number) => void;
  isDraggingRef: React.MutableRefObject<boolean>;
}

const CategoryEssentialSlider: React.FC<CategoryEssentialSliderProps> = ({ value, onChange, isDraggingRef }) => {
  const discretionaryPct = 100 - value;

  return (
    <div className="space-y-1 select-none">
      <input
        type="range"
        min="0"
        max="100"
        step="5"
        value={value}
        onPointerDown={() => {
          isDraggingRef.current = true;
        }}
        onPointerUp={() => {
          isDraggingRef.current = false;
        }}
        onMouseDown={() => {
          isDraggingRef.current = true;
        }}
        onMouseUp={() => {
          isDraggingRef.current = false;
        }}
        onTouchStart={() => {
          isDraggingRef.current = true;
        }}
        onTouchEnd={() => {
          isDraggingRef.current = false;
        }}
        onInput={(e) => {
          const val = parseInt((e.target as HTMLInputElement).value, 10);
          if (!isNaN(val)) {
            onChange(val);
          }
        }}
        onChange={(e) => {
          const val = parseInt(e.target.value, 10);
          if (!isNaN(val)) {
            onChange(val);
          }
        }}
        className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600 touch-none select-none active:cursor-grabbing"
      />
      <div className="flex items-center justify-between text-[9px] font-bold select-none tabular-nums">
        <span className="text-emerald-700">{value}% Ess</span>
        <span className="text-indigo-700">{discretionaryPct}% Disc</span>
      </div>
    </div>
  );
};

interface AnnualBudgetInputProps {
  value: number;
  onChange: (val: number) => void;
}

const AnnualBudgetInput: React.FC<AnnualBudgetInputProps> = ({ value, onChange }) => {
  const monthlyVal = Math.round((value || 0) / 12);

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="text-xs font-extrabold text-blue-950 uppercase tracking-wider block">
          Total Annual Household Budget
        </label>
        <span className="text-[9px] font-black text-blue-700 bg-blue-100 px-2 py-0.5 rounded-full uppercase tracking-wider">
          Primary Input
        </span>
      </div>

      <div className="relative">
        <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-black text-blue-600 text-xl">$</span>
        <NumericInput
          value={value}
          isFloat
          step="1000"
          min="0"
          onChange={onChange}
          className="w-full pl-9 pr-3 py-2.5 bg-blue-50/40 border-2 border-blue-400 rounded-lg font-black text-blue-950 text-xl focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white shadow-inner transition-all tabular-nums"
        />
      </div>

      <div className="flex items-center justify-between bg-blue-100/70 border border-blue-200 px-3 py-1.5 rounded-lg text-xs font-bold text-blue-950 tabular-nums">
        <span className="text-[10px] text-blue-800 font-extrabold uppercase tracking-wider">Monthly Equivalent:</span>
        <span className="text-sm font-black text-blue-900">
          ${monthlyVal.toLocaleString()} <span className="text-[10px] font-semibold text-blue-700">/ mo</span>
        </span>
      </div>

      <span className="text-[10px] text-slate-500 font-medium block">
        Baseline living expense in today's purchasing power
      </span>
    </div>
  );
};

interface CategoryTableRowProps {
  cat: any;
  primary: any;
  onUpdateEssentialPct: (catId: string, pct: number) => void;
  onUpdatePre65Surcharge?: (val: number) => void;
}

const CategoryTableRow: React.FC<CategoryTableRowProps> = ({ cat, primary, onUpdateEssentialPct, onUpdatePre65Surcharge }) => {
  const [localPct, setLocalPct] = useState(cat.essentialPct);
  const [showAcaInfoModal, setShowAcaInfoModal] = useState(false);
  const isDraggingRef = React.useRef(false);

  React.useEffect(() => {
    if (!isDraggingRef.current) {
      setLocalPct(cat.essentialPct);
    }
  }, [cat.essentialPct]);

  const discretionaryPct = 100 - localPct;
  const essentialDollar = Math.round(cat.annualDollar * (localPct / 100));
  const essentialMonthly = Math.round(essentialDollar / 12);
  const discretionaryDollar = cat.annualDollar - essentialDollar;
  const discretionaryMonthly = cat.monthlyDollar - essentialMonthly;

  const handleSliderChange = (newVal: number) => {
    setLocalPct(newVal);
    onUpdateEssentialPct(cat.id, newVal);
  };

  return (
    <>
      <tr 
        className={`hover:bg-slate-50/80 transition-colors ${
          cat.id === 'pre65_bridge'
            ? 'bg-amber-50/40'
            : cat.group === 'Healthcare' 
            ? 'bg-rose-50/30' 
            : cat.group === 'Housing & Utilities'
            ? 'bg-blue-50/20'
            : ''
        }`}
      >
        {/* Category Name & Description */}
        <td className="py-2.5 px-3">
          <div className="flex items-center space-x-1.5 flex-wrap gap-y-1">
            <span className="font-bold text-slate-900">{cat.name}</span>
            <span className={`text-[9px] font-extrabold px-1.5 py-0.2 rounded ${
              cat.id === 'pre65_bridge' ? 'bg-amber-100 text-amber-900 border border-amber-300' :
              cat.group === 'Healthcare' ? 'bg-rose-100 text-rose-800' :
              cat.group === 'Housing & Utilities' ? 'bg-blue-100 text-blue-800' :
              cat.group === 'Food & Dining' ? 'bg-amber-100 text-amber-800' :
              cat.group === 'Transportation' ? 'bg-emerald-100 text-emerald-800' :
              cat.group === 'Discretionary & Leisure' ? 'bg-indigo-100 text-indigo-800' :
              'bg-slate-100 text-slate-700'
            }`}>
              {cat.group}
            </span>
            {cat.id === 'pre65_bridge' && (
              <button
                type="button"
                onClick={() => setShowAcaInfoModal(true)}
                className="inline-flex items-center space-x-1 px-1.5 py-0.5 text-amber-900 hover:text-amber-950 bg-amber-200/80 hover:bg-amber-300/90 border border-amber-300 rounded transition-colors cursor-pointer shadow-2xs"
                title="Click to view details on how Pre-65 ACA health coverage is derived and calculated"
              >
                <Info className="w-3.5 h-3.5 text-amber-800 shrink-0" />
                <span className="text-[10px] font-black uppercase tracking-wide">Info</span>
              </button>
            )}
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5 leading-tight">{cat.description}</p>
        </td>

      {/* BLS Share */}
      <td className="py-2.5 px-2 text-center whitespace-nowrap">
        {cat.id === 'pre65_bridge' ? (
          <span className="font-extrabold text-amber-900 bg-amber-100 border border-amber-300 px-1.5 py-0.5 rounded text-[10px]">
            Bridge
          </span>
        ) : (
          <span className="font-bold text-slate-700 bg-slate-100 border border-slate-200 px-1.5 py-0.5 rounded text-[10px] tabular-nums">
            {cat.blsSharePct}%
          </span>
        )}
      </td>

      {/* Total Budget Annual & Monthly */}
      <td className="py-2.5 px-3 text-right whitespace-nowrap tabular-nums">
        {cat.id === 'pre65_bridge' && onUpdatePre65Surcharge ? (
          <div className="flex flex-col items-end">
            <div className="flex items-center space-x-1">
              <span className="text-xs font-bold text-slate-400">$</span>
              <input
                type="number"
                step="500"
                value={cat.annualDollar}
                onChange={(e) => onUpdatePre65Surcharge(parseFloat(e.target.value) || 0)}
                className="w-20 px-1.5 py-0.5 text-right font-extrabold text-xs text-amber-900 bg-white border border-amber-300 rounded focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
              <span className="text-[10px] font-normal text-slate-500">/yr</span>
            </div>
            <div className="text-[10px] text-slate-500 font-semibold">${cat.monthlyDollar.toLocaleString()} <span className="text-[9px] font-normal text-slate-400">/mo</span></div>
          </div>
        ) : (
          <>
            <div className="font-extrabold text-slate-900">${cat.annualDollar.toLocaleString()} <span className="text-[10px] font-normal text-slate-500">/yr</span></div>
            <div className="text-[10px] text-slate-500 font-semibold">${cat.monthlyDollar.toLocaleString()} <span className="text-[9px] font-normal text-slate-400">/mo</span></div>
          </>
        )}
      </td>

      {/* Essential Column (Amount & % Badge) */}
      <td className="py-2.5 px-3 text-right whitespace-nowrap bg-emerald-50/20 border-l border-emerald-100/50 min-w-[150px] tabular-nums">
        <div className="flex items-center justify-end space-x-1.5">
          <span className="text-[10px] font-extrabold text-emerald-800 bg-emerald-100 px-1.5 py-0.2 rounded border border-emerald-200">
            {localPct}%
          </span>
          <span className="text-xs font-bold text-emerald-950">
            ${essentialDollar.toLocaleString()} <span className="text-[10px] font-normal text-emerald-700">/yr</span>
          </span>
        </div>
        <div className="text-[10px] text-emerald-700 font-semibold">
          ${essentialMonthly.toLocaleString()} <span className="text-[9px] font-normal text-emerald-600">/mo</span>
        </div>
      </td>

      {/* Essential Split Slider Column (In Between) */}
      <td className="py-2.5 px-3 text-center w-40 min-w-[140px]">
        <CategoryEssentialSlider
          value={localPct}
          onChange={handleSliderChange}
          isDraggingRef={isDraggingRef}
        />
      </td>

      {/* Discretionary Column (Amount & % Badge) */}
      <td className="py-2.5 px-3 text-right whitespace-nowrap bg-indigo-50/20 border-r border-indigo-100/50 min-w-[150px] tabular-nums">
        {discretionaryDollar > 0 ? (
          <>
            <div className="flex items-center justify-end space-x-1.5">
              <span className="text-[10px] font-extrabold text-indigo-800 bg-indigo-100 px-1.5 py-0.2 rounded border border-indigo-200">
                {discretionaryPct}%
              </span>
              <span className="text-xs font-bold text-indigo-950">
                ${discretionaryDollar.toLocaleString()} <span className="text-[10px] font-normal text-indigo-700">/yr</span>
              </span>
            </div>
            <div className="text-[10px] text-indigo-700 font-semibold">
              ${discretionaryMonthly.toLocaleString()} <span className="text-[9px] font-normal text-indigo-600">/mo</span>
            </div>
          </>
        ) : (
          <div className="text-[10px] text-slate-400 italic">0% Discretionary</div>
        )}
      </td>

      {/* Active Ages */}
      <td className="py-2.5 px-3 text-center whitespace-nowrap">
        {cat.id === 'pre65_bridge' ? (
          cat.isEarlyRetirement ? (
            <span className="inline-flex items-center text-xs font-bold px-2 py-1 rounded-lg border bg-amber-100 text-amber-900 border-amber-300">
              Age {cat.startAge} – {cat.endAge} (Pre-65 Gap)
            </span>
          ) : (
            <span className="inline-flex items-center text-xs font-bold px-2 py-1 rounded-lg border bg-slate-100 text-slate-500 border-slate-200">
              N/A (Medicare Active)
            </span>
          )
        ) : (cat.id === 'health_premiums' || cat.id === 'health_oop') ? (
          <span className="inline-flex items-center text-xs font-bold px-2 py-1 rounded-lg border bg-rose-50 text-rose-800 border-rose-200">
            Age {cat.startAge} – {cat.endAge} (Medicare)
          </span>
        ) : (
          <span className="inline-flex items-center text-xs font-bold px-2 py-1 rounded-lg border bg-slate-100 text-slate-700 border-slate-200">
            Age {cat.startAge} – {cat.endAge}
          </span>
        )}
      </td>
    </tr>

    {showAcaInfoModal && (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs text-left font-sans">
        <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full max-h-[90vh] flex flex-col border border-slate-200 overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-amber-600 via-amber-700 to-amber-800 text-white p-4 flex items-center justify-between shadow-xs">
            <div className="flex items-center space-x-2">
              <HeartPulse className="w-5 h-5 text-amber-200 shrink-0" />
              <div>
                <h3 className="text-sm font-black tracking-tight">Pre-65 ACA Health Insurance Bridge</h3>
                <p className="text-[10px] text-amber-100 font-medium">Healthcare sourcing &amp; spending assumptions before Medicare</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setShowAcaInfoModal(false)}
              className="text-amber-100 hover:text-white hover:bg-amber-800/60 p-1.5 rounded-lg transition-colors cursor-pointer"
              title="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body Content */}
          <div className="p-5 overflow-y-auto space-y-4 text-xs text-slate-700 leading-relaxed">
            {/* Section 1 */}
            <div className="space-y-1.5 bg-amber-50/80 p-3.5 rounded-xl border border-amber-200/80">
              <h4 className="font-extrabold text-amber-950 flex items-center space-x-1.5 text-xs">
                <Calculator className="w-4 h-4 text-amber-700 shrink-0" />
                <span>1. How Pre-65 Healthcare Need is Derived</span>
              </h4>
              <p className="text-slate-700">
                In retirement prior to age 65 (when Medicare starts), health insurance is purchased through the ACA Marketplace. Premium costs are derived from:
              </p>
              <ul className="list-disc list-inside space-y-1 pl-1 text-slate-600">
                <li>
                  <strong>Statutory Age Rating:</strong> Standard 3:1 age-rating curves (45 CFR §147.102) scale base monthly premiums based on household member ages.
                </li>
                <li>
                  <strong>Dynamic Subsidy Calculation:</strong> The engine calculates your Premium Tax Credit by comparing annual Modified Adjusted Gross Income (MAGI) against Federal Poverty Level (FPL) thresholds.
                </li>
                <li>
                  <strong>400% FPL Subsidy Cliff:</strong> Under standard law, crossing 400% FPL ($84,600 for a couple) eliminates subsidies, increasing out-of-pocket health costs.
                </li>
              </ul>
            </div>

            {/* Section 2 */}
            <div className="space-y-1.5 bg-blue-50/80 p-3.5 rounded-xl border border-blue-200/80">
              <h4 className="font-extrabold text-blue-950 flex items-center space-x-1.5 text-xs">
                <ShieldAlert className="w-4 h-4 text-blue-700 shrink-0" />
                <span>2. Role of the $14,000 / yr Spending Table Line Item</span>
              </h4>
              <p className="text-slate-700">
                This line item ($14,000/yr default) plays two specific roles in your financial plan:
              </p>
              <ul className="list-disc list-inside space-y-1 pl-1 text-slate-600">
                <li>
                  <strong>Baseline Budget Estimate:</strong> It serves as an initial placeholder budget for unsubsidized or partially subsidized coverage for an early-retiring couple.
                </li>
                <li>
                  <strong>Fallback Cost Bridge:</strong> If dynamic subsidy modeling is disabled, the simulation uses this exact input directly as the fixed annual pre-65 health cost.
                </li>
              </ul>
            </div>

            {/* Section 3 */}
            <div className="space-y-1.5 bg-emerald-50/80 p-3.5 rounded-xl border border-emerald-200/80">
              <h4 className="font-extrabold text-emerald-950 flex items-center space-x-1.5 text-xs">
                <Check className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>3. Is it Still Needed &amp; How Should You Adjust It?</span>
              </h4>
              <p className="text-slate-700">
                <strong>Yes, it remains necessary</strong> whenever retiring before age 65. Guidance on adjusting it:
              </p>
              <ul className="list-disc list-inside space-y-1 pl-1 text-slate-600">
                <li>
                  <strong>Marketplace Coverage:</strong> Keep near default or calibrate base premiums in the ACA Assumptions tab.
                </li>
                <li>
                  <strong>COBRA / Employer Retiree Plan:</strong> Enter your actual annual premium cost directly in the input box.
                </li>
                <li>
                  <strong>Retiring at 65+:</strong> This line item automatically deactivates (shows $0 / N/A) as Medicare coverage takes effect.
                </li>
              </ul>
            </div>
          </div>

          {/* Footer */}
          <div className="bg-slate-50 px-4 py-3 border-t border-slate-200 flex justify-end">
            <button
              type="button"
              onClick={() => setShowAcaInfoModal(false)}
              className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs shadow-xs transition-colors cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    )}
    </>
  );
};

export const SpendingStep: React.FC<SpendingStepProps> = ({
  plan,
  onUpdatePlan,
  onGoToNextStep,
}) => {
  const spending: SpendingAssumptions = {
    ...DEFAULT_PLAN.spendingAssumptions!,
    ...(plan.spendingAssumptions || {}),
  };

  const primary = plan.primaryPerson;
  const macro = plan.macroAssumptions || DEFAULT_PLAN.macroAssumptions!;
  const inflationRate = (macro.generalInflation || 2.0) / 100;
  const medicalInflationRate = (macro.medicalInflation || 5.0) / 100;

  const [showCategoryDetail, setShowCategoryDetail] = useState(true);

  // Category essential percentage overrides from state (stored in spending.categoryOverrides)
  const categoryOverrides: Record<string, number> = spending.categoryOverrides || {};

  // Category age range overrides from state (stored in spending.categoryAges)
  const categoryAges: Record<string, { startAge?: number; endAge?: number }> = spending.categoryAges || {};

  // No literal fallbacks. The schema supplies defaults on parse, so whatever is on the
  // plan is what the engine sees. A component-local default silently disagrees with the
  // engine — this one said 96000 while DEFAULT_PLAN said 80000.
  const totalAnnualBudget = spending.desiredAnnualLivingExpenses;

  // Pre-65 ACA Bridge Surcharge setting (Default: $14,000/yr for unsubsidized couple if retiring pre-65)
  const pre65BridgeSurcharge = spending.pre65AcaBridgeSurcharge;

  // Single-source simulation engine projection results
  const simulation = useMemo(() => {
    return getSimulation(plan);
  }, [plan]);

  const specialExpenses: SpecialExpense[] = spending.specialExpenses;

  // Handler for updating spending parameters
  const handleUpdateSpending = (updates: Partial<SpendingAssumptions>, options?: UpdateOptions) => {
    React.startTransition(() => {
      onUpdatePlan(
        {
          ...plan,
          spendingAssumptions: {
            ...spending,
            ...updates,
          },
        },
        options
      );
    });
  };

  // The rolled-up floor is written to essentialLivingPct in the SAME update. That field
  // is the only thing the simulation engine consumes from this table; without the write
  // the engine silently keeps using its stored default and the charts disagree with
  // what this tab displays.
  // Handler for updating individual category essential %
  const handleUpdateCategoryEssentialPct = (catId: string, pct: number) => {
    if (typeof pct !== 'number' || isNaN(pct)) return;
    const clamped = Math.min(100, Math.max(0, Math.round(pct)));
    if (categoryOverrides[catId] === clamped) return;
    const updatedOverrides = {
      ...categoryOverrides,
      [catId]: clamped,
    };
    handleUpdateSpending({
      categoryOverrides: updatedOverrides,
      essentialLivingPct: computeEssentialFloorPct(BLS_CATEGORIES, updatedOverrides),
    });
  };

  // Handler for updating category active age timeframe (startAge and endAge)
  const handleUpdateCategoryAges = (catId: string, field: 'startAge' | 'endAge', value: number) => {
    const currentOverride = categoryAges[catId] || {};
    const updatedAges = {
      ...categoryAges,
      [catId]: {
        ...currentOverride,
        [field]: value,
      },
    };
    handleUpdateSpending({ categoryAges: updatedAges });
  };

  // Reset all category essential overrides & age timeframes to BLS defaults
  const handleResetCategoryDefaults = () => {
    // One write clearing overrides, ages and the rolled-up floor together, so undo
    // reverts the whole reset rather than needing one press per category.
    handleUpdateSpending(
      { categoryOverrides: {}, categoryAges: {}, essentialLivingPct: computeEssentialFloorPct(BLS_CATEGORIES, {}) },
      { label: 'reset spending categories to defaults' },
    );
  };

  const defaultStart = primary.retirementAge || 62;
  const defaultEnd = primary.lifeExpectancy || 92;

  // Calculate detailed category breakdown based on current budget & overrides
  const categoryBreakdown = useMemo(() => {
    return BLS_CATEGORIES.map(cat => {
      const essentialPct = categoryOverrides[cat.id] ?? cat.defaultEssentialPct;
      const ageOverride = categoryAges[cat.id] || {};

      if (cat.id === 'pre65_bridge') {
        const isEarlyRetirement = defaultStart < 65;
        const startAge = defaultStart;
        const endAge = 64;
        const annualDollar = isEarlyRetirement ? pre65BridgeSurcharge : 0;
        const monthlyDollar = Math.round(annualDollar / 12);

        const essentialDollar = Math.round(annualDollar * (essentialPct / 100));
        const essentialMonthly = Math.round(essentialDollar / 12);

        const discretionaryDollar = annualDollar - essentialDollar;
        const discretionaryMonthly = monthlyDollar - essentialMonthly;

        return {
          ...cat,
          essentialPct,
          annualDollar,
          monthlyDollar,
          essentialDollar,
          essentialMonthly,
          discretionaryDollar,
          discretionaryMonthly,
          startAge,
          endAge,
          isEarlyRetirement,
        };
      }

      const catDefaultStart = (cat.id === 'health_premiums' || cat.id === 'health_oop')
        ? Math.max(65, defaultStart)
        : defaultStart;

      const startAge = ageOverride.startAge ?? catDefaultStart;
      const endAge = ageOverride.endAge ?? defaultEnd;

      const annualDollar = Math.round(totalAnnualBudget * (cat.blsSharePct / 100));
      const monthlyDollar = Math.round(annualDollar / 12);

      const essentialDollar = Math.round(annualDollar * (essentialPct / 100));
      const essentialMonthly = Math.round(essentialDollar / 12);

      const discretionaryDollar = annualDollar - essentialDollar;
      const discretionaryMonthly = monthlyDollar - essentialMonthly;

      return {
        ...cat,
        essentialPct,
        annualDollar,
        monthlyDollar,
        essentialDollar,
        essentialMonthly,
        discretionaryDollar,
        discretionaryMonthly,
        startAge,
        endAge,
      };
    });
  }, [totalAnnualBudget, categoryOverrides, categoryAges, defaultStart, defaultEnd, pre65BridgeSurcharge]);

  // Aggregate Category Metrics
  const summaryMetrics = useMemo(() => {
    let totalEssential = 0;
    let totalEssentialMonthly = 0;
    let totalDiscretionary = 0;
    let totalDiscretionaryMonthly = 0;
    let totalHealthcare = 0;
    let totalHealthcareMonthly = 0;
    let totalHealthcareEssential = 0;
    let totalHealthcareEssentialMonthly = 0;

    categoryBreakdown.forEach(cat => {
      if (cat.id !== 'pre65_bridge') {
        totalEssential += cat.essentialDollar;
        totalEssentialMonthly += cat.essentialMonthly;
        totalDiscretionary += cat.discretionaryDollar;
        totalDiscretionaryMonthly += cat.discretionaryMonthly;
      }
      if (cat.group === 'Healthcare') {
        totalHealthcare += cat.annualDollar;
        totalHealthcareMonthly += cat.monthlyDollar;
        totalHealthcareEssential += cat.essentialDollar;
        totalHealthcareEssentialMonthly += cat.essentialMonthly;
      }
    });

    const nonHealthcareEssential = totalEssential - totalHealthcareEssential;
    const nonHealthcareEssentialMonthly = totalEssentialMonthly - totalHealthcareEssentialMonthly;

    const essentialFloorPct = totalAnnualBudget > 0 ? (totalEssential / totalAnnualBudget) * 100 : 0;
    const discretionaryCushionPct = totalAnnualBudget > 0 ? (totalDiscretionary / totalAnnualBudget) * 100 : 0;

    return {
      totalEssential,
      totalEssentialMonthly,
      totalDiscretionary,
      totalDiscretionaryMonthly,
      totalHealthcare,
      totalHealthcareMonthly,
      totalHealthcareEssential,
      totalHealthcareEssentialMonthly,
      nonHealthcareEssential,
      nonHealthcareEssentialMonthly,
      essentialFloorPct,
      discretionaryCushionPct,
    };
  }, [categoryBreakdown, totalAnnualBudget]);

  // Handlers for Special Expenses (Adding PREPENDS to top of list)
  const handleAddSpecialExpense = () => {
    const newExpense: SpecialExpense = {
      id: `sp-${Date.now()}`,
      name: 'New Special Expense',
      amount: 10000,
      startAge: primary.retirementAge + 2,
      endAge: primary.retirementAge + 2,
      category: 'travel',
      isEssential: false,
      notes: '',
    };
    const updated = [newExpense, ...specialExpenses];
    handleUpdateSpending({ specialExpenses: updated });
  };

  const handleUpdateSpecialExpense = (id: string, field: keyof SpecialExpense, value: any) => {
    const updated = specialExpenses.map(item => {
      if (item.id === id) {
        return { ...item, [field]: value };
      }
      return item;
    });
    handleUpdateSpending({ specialExpenses: updated });
  };

  const handleDeleteSpecialExpense = (id: string) => {
    const updated = specialExpenses.filter(item => item.id !== id);
    handleUpdateSpending({ specialExpenses: updated });
  };

  // Multi-Year Bottom-Up Spending Trajectory Calculation
  const timelineData = useMemo(() => {
    const currentAge = primary.currentAge || 52;
    const endAge = primary.lifeExpectancy || 92;
    const retAge = primary.retirementAge || 62;
    const model = spending.spendingModel || 'blanchett_smile';

    const rows = [];
    for (let age = currentAge; age <= endAge; age++) {
      const yearIndex = age - currentAge;
      const isRetired = age >= retAge;
      const yearsInRetirement = Math.max(0, age - retAge);
      const isPre65Retired = isRetired && age < 65;

      // Filter categories active for this specific age based on startAge and endAge
      const activeCats = categoryBreakdown.filter(c => age >= c.startAge && age <= c.endAge);

      const baseNonHealthEssentialReal = activeCats
        .filter(c => c.group !== 'Healthcare')
        .reduce((sum, c) => sum + c.essentialDollar, 0);

      const baseNonHealthDiscretionaryReal = activeCats
        .filter(c => c.group !== 'Healthcare')
        .reduce((sum, c) => sum + c.discretionaryDollar, 0);

      const baseHealthcareReal = activeCats
        .filter(c => c.group === 'Healthcare')
        .reduce((sum, c) => sum + c.annualDollar, 0);

      // Essential Non-Health Living (100% floor, grows with CPI inflation)
      const essentialReal = baseNonHealthEssentialReal;

      // Discretionary Non-Health Living (Tapers bottom-up based on retirement phase)
      let discretionaryReal = baseNonHealthDiscretionaryReal;
      let modelDiscretionaryMultiplier = 1.0;

      if (isRetired) {
        if (model === 'blanchett_smile') {
          // Bottom-up Blanchett Smile: Discretionary decays over Go-Go (105%), Slow-Go (75%), No-Go (50%)
          if (yearsInRetirement <= 10) {
            modelDiscretionaryMultiplier = 1.05;
          } else if (yearsInRetirement <= 20) {
            modelDiscretionaryMultiplier = 0.75;
          } else {
            modelDiscretionaryMultiplier = 0.50;
          }
        } else if (model === 'declining_real') {
          // Declining Real: -1.2%/yr taper on discretionary
          modelDiscretionaryMultiplier = Math.pow(1 - 0.012, yearsInRetirement);
        } else {
          // Constant Real
          modelDiscretionaryMultiplier = 1.0;
        }
      }

      discretionaryReal = baseNonHealthDiscretionaryReal * modelDiscretionaryMultiplier;

      // Calculate Nominal Values using General CPI
      const essentialNominal = essentialReal * Math.pow(1 + inflationRate, yearIndex);
      const discretionaryNominal = discretionaryReal * Math.pow(1 + inflationRate, yearIndex);
      const baseLivingNominal = essentialNominal + discretionaryNominal;

      // Healthcare calculation: source directly from simulation engine (single source of truth)
      const simRow = simulation.rows.find(r => r.age === age);
      const acaBridgeAmount = isPre65Retired ? pre65BridgeSurcharge : 0;
      const healthRealFallback = baseHealthcareReal + acaBridgeAmount;
      const baseHealthNominal = simRow 
        ? simRow.healthExpense 
        : Math.round(healthRealFallback * Math.pow(1 + medicalInflationRate, yearIndex));

      // Special Expenses active for this age (categorized by Essential vs Discretionary)
      let specialEssentialNominal = 0;
      let specialDiscretionaryNominal = 0;
      specialExpenses.forEach(sp => {
        if (age >= sp.startAge && age <= sp.endAge) {
          const amountNominal = sp.amount * Math.pow(1 + inflationRate, yearIndex);
          if (sp.isEssential) {
            specialEssentialNominal += amountNominal;
          } else {
            specialDiscretionaryNominal += amountNominal;
          }
        }
      });

      const specialNominal = specialEssentialNominal + specialDiscretionaryNominal;
      const totalNominal = baseLivingNominal + baseHealthNominal + specialNominal;
      const totalReal = totalNominal / Math.pow(1 + inflationRate, yearIndex);

      const essentialRealVal = Math.round(essentialReal);
      const discretionaryRealVal = Math.round(discretionaryReal);
      const healthRealVal = Math.round(baseHealthNominal / Math.pow(1 + inflationRate, yearIndex));
      const specialRealVal = Math.round(specialNominal / Math.pow(1 + inflationRate, yearIndex));

      rows.push({
        age,
        year: simRow?.calendarYear ?? ((simulation.rows[0]?.calendarYear ?? new Date().getFullYear()) + yearIndex),
        isRetired,
        isPre65Retired,
        essentialNominal: Math.round(essentialNominal),
        discretionaryNominal: Math.round(discretionaryNominal),
        baseLivingNominal: Math.round(baseLivingNominal),
        baseHealthNominal: Math.round(baseHealthNominal),
        specialNominal: Math.round(specialNominal),
        specialEssentialNominal: Math.round(specialEssentialNominal),
        specialDiscretionaryNominal: Math.round(specialDiscretionaryNominal),
        essentialReal: essentialRealVal,
        discretionaryReal: discretionaryRealVal,
        healthReal: healthRealVal,
        specialReal: specialRealVal,
        totalNominal: Math.round(totalNominal),
        totalReal: Math.round(totalReal),
        phase: !isRetired ? 'Pre-Retirement' : (yearsInRetirement <= 10 ? 'Go-Go' : yearsInRetirement <= 20 ? 'Slow-Go' : 'No-Go'),
      });
    }

    const firstRetiredRow = rows.find(r => r.isRetired);
    const baseRealVal = firstRetiredRow 
      ? (firstRetiredRow.essentialReal + firstRetiredRow.discretionaryReal + firstRetiredRow.healthReal) 
      : 1;

    return rows.map(r => {
      if (!r.isRetired || baseRealVal === 0) {
        return { ...r, spendingAdjustmentPct: 0 };
      }
      const currentReal = r.essentialReal + r.discretionaryReal + r.healthReal;
      const pct = ((currentReal - baseRealVal) / baseRealVal) * 100;
      return {
        ...r,
        spendingAdjustmentPct: Number(pct.toFixed(1))
      };
    });
  }, [primary, spending, inflationRate, medicalInflationRate, specialExpenses, summaryMetrics, categoryBreakdown, pre65BridgeSurcharge, simulation]);

  const retirementRow = timelineData.find(r => r.age === primary.retirementAge) || timelineData[0];
  const isEarlyRetirement = (primary.retirementAge || 62) < 65;

  return (
    <div className="space-y-6">
      
      {/* Title & Navigation Action */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <PieChart className="w-5 h-5 text-blue-600" />
            <span>Retirement Household Budget & Spending Engine</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            BLS 65+ benchmark allocation, essential spending floor & bottom-up dynamic curve modeling
          </p>
        </div>

        {onGoToNextStep && (
          <button
            type="button"
            onClick={onGoToNextStep}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-xs flex items-center space-x-2 transition-colors cursor-pointer"
          >
            <span>Proceed to Income & Tax Strategy</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Card 1: Total Annual Budget */}
        <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-4 rounded-2xl border border-blue-700 shadow-md text-white space-y-1.5 ring-2 ring-blue-400/30">
          <span className="text-[11px] font-bold text-blue-100 uppercase tracking-wider flex items-center justify-between">
            <span>Target Household Spending</span>
            <span className="text-[9px] bg-white/20 px-1.5 py-0.2 rounded font-extrabold text-white">PRIMARY</span>
          </span>
          <div className="text-2xl font-black text-white tabular-nums">
            ${totalAnnualBudget.toLocaleString()} <span className="text-xs font-normal text-blue-200">/ yr</span>
          </div>
          <div className="text-xs font-bold text-blue-100 bg-white/15 px-2 py-0.5 rounded inline-block tabular-nums border border-white/20">
            ≈ ${Math.round(totalAnnualBudget / 12).toLocaleString()} / month
          </div>
          <span className="text-[10px] text-blue-100/90 block font-medium">Baseline living budget in today's dollars</span>
        </div>

        {/* Card 2: Essential Spending Floor (with Healthcare & Non-Healthcare Breakdown) */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center space-x-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Essential Spending Floor</span>
            </span>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200/60 tabular-nums">
              {summaryMetrics.essentialFloorPct.toFixed(1)}% of budget
            </span>
          </div>

          <div className="text-2xl font-black text-emerald-900 tabular-nums">
            ${summaryMetrics.totalEssential.toLocaleString()} <span className="text-xs font-normal text-slate-500">/ yr</span>
          </div>

          {/* Sub-breakdown for Healthcare and Non-Healthcare */}
          <div className="pt-2 border-t border-slate-100 space-y-1 text-xs">
            <div className="flex items-center justify-between text-slate-600 font-medium">
              <span className="flex items-center space-x-1.5">
                <HeartPulse className="w-3.5 h-3.5 text-rose-500" />
                <span>Healthcare Essential:</span>
              </span>
              <span className="font-extrabold text-slate-800 tabular-nums">
                ${summaryMetrics.totalHealthcareEssential.toLocaleString()} <span className="text-[10px] font-semibold text-slate-400">/yr</span>
              </span>
            </div>
            <div className="flex items-center justify-between text-slate-600 font-medium">
              <span>Non-Healthcare Essential:</span>
              <span className="font-extrabold text-slate-800 tabular-nums">
                ${summaryMetrics.nonHealthcareEssential.toLocaleString()} <span className="text-[10px] font-semibold text-slate-400">/yr</span>
              </span>
            </div>
          </div>

          <span className="text-[10px] text-emerald-700 block font-medium pt-0.5">
            Non-negotiable survival floor
            {isEarlyRetirement && <span className="text-rose-600 font-bold"> • Includes Pre-65 ACA Bridge</span>}
          </span>
        </div>

        {/* Card 3: Discretionary Cushion */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center space-x-1">
              <Zap className="w-3.5 h-3.5 text-indigo-600" />
              <span>Discretionary Cushion</span>
            </span>
            <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-200/60 tabular-nums">
              {summaryMetrics.discretionaryCushionPct.toFixed(1)}% of budget
            </span>
          </div>

          <div className="text-2xl font-black text-indigo-950 tabular-nums">
            ${summaryMetrics.totalDiscretionary.toLocaleString()} <span className="text-xs font-normal text-slate-500">/ yr</span>
          </div>

          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600 font-medium">
            <span>Monthly Cushion:</span>
            <span className="font-extrabold text-indigo-900 tabular-nums">
              ≈ ${Math.round(summaryMetrics.totalDiscretionary / 12).toLocaleString()} <span className="text-[10px] font-semibold text-slate-400">/mo</span>
            </span>
          </div>

          <span className="text-[10px] text-indigo-700 block font-medium pt-0.5">
            Flexible budget in sequence downturns
          </span>
        </div>

      </div>

      {/* SECTION 1: Single Top-Level Target Input & BLS Share Allocator */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-3 border-b border-slate-100 gap-3">
          <div className="flex items-center space-x-2">
            <DollarSign className="w-5 h-5 text-blue-600" />
            <div>
              <h3 className="text-base font-bold text-slate-900">1. Household Spending</h3>
              <p className="text-xs text-slate-500">
                Single input auto-allocates into 15 BLS categories. Split within categories into essential vs discretionary.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={handleResetCategoryDefaults}
              className="px-2.5 py-1 text-xs text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center space-x-1 font-medium cursor-pointer"
              title="Reset category essential splits to BLS standard benchmarks"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Reset Defaults</span>
            </button>
            <button
              type="button"
              onClick={() => setShowCategoryDetail(!showCategoryDetail)}
              className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center space-x-1 transition-colors cursor-pointer"
            >
              <span>{showCategoryDetail ? 'Collapse Detail' : 'Expand 15 Categories'}</span>
              {showCategoryDetail ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Primary Single Input: Desired Annual Household Budget */}
        <div className="bg-gradient-to-r from-blue-50/90 via-indigo-50/50 to-slate-50 p-5 rounded-2xl border-2 border-blue-200 shadow-xs grid grid-cols-1 lg:grid-cols-3 gap-6 items-center">
          <div className="lg:col-span-1 bg-white p-4 rounded-xl border-2 border-blue-500 shadow-sm ring-4 ring-blue-500/10">
            <AnnualBudgetInput
              value={spending.desiredAnnualLivingExpenses}
              onChange={(val) => handleUpdateSpending({ desiredAnnualLivingExpenses: val, preRetirementAnnualSpending: val })}
            />
          </div>

          <div className="lg:col-span-2 bg-white p-4 rounded-xl border border-slate-200/80 space-y-3">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
              <div className="flex items-center space-x-2">
                <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block"></span>
                <span>Essential Spending Floor: <strong>${summaryMetrics.totalEssential.toLocaleString()} / yr</strong> ({summaryMetrics.essentialFloorPct.toFixed(1)}%)</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="w-3 h-3 rounded-full bg-indigo-500 inline-block"></span>
                <span>Discretionary Cushion: <strong>${summaryMetrics.totalDiscretionary.toLocaleString()} / yr</strong> ({summaryMetrics.discretionaryCushionPct.toFixed(1)}%)</span>
              </div>
            </div>

            {/* Visual Split Stack Bar */}
            <div className="w-full h-3.5 bg-slate-100 rounded-full overflow-hidden flex shadow-inner">
              <div 
                className="bg-emerald-500 h-full transition-all duration-300" 
                style={{ width: `${summaryMetrics.essentialFloorPct}%` }}
                title={`Essential Floor: ${summaryMetrics.essentialFloorPct.toFixed(1)}%`}
              />
              <div 
                className="bg-indigo-500 h-full transition-all duration-300" 
                style={{ width: `${summaryMetrics.discretionaryCushionPct}%` }}
                title={`Discretionary Cushion: ${summaryMetrics.discretionaryCushionPct.toFixed(1)}%`}
              />
            </div>

            <p className="text-[11px] text-slate-500">
              <strong>Why this matters:</strong> Split within categories ensures your discretionary budget can flex downward during bad market sequences without touching non-negotiable housing, healthcare, or groceries.
            </p>
          </div>
        </div>

        {/* 15 BLS Category Compact Table with Monthly Conversion & Timeframe Controls */}
        {showCategoryDetail && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Category Breakdown & Essential Split Table (BLS 65+ Benchmark Shares)
              </h4>
              <span className="text-[11px] font-medium text-slate-500">
                Amounts shown in annual ($/yr) and converted monthly ($/mo). Adjust sliders & active age ranges.
              </span>
            </div>

            <div className="overflow-x-auto border border-slate-200 rounded-xl bg-white shadow-2xs">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                  <tr>
                    <th className="py-2.5 px-3">Category & Description</th>
                    <th className="py-2.5 px-2 text-center w-14">Share</th>
                    <th className="py-2.5 px-3 text-right">Total Budget</th>
                    <th className="py-2.5 px-3 text-right text-emerald-800 bg-emerald-50/50">Essential Floor</th>
                    <th className="py-2.5 px-3 text-center min-w-[140px]">Split Slider</th>
                    <th className="py-2.5 px-3 text-right text-indigo-800 bg-indigo-50/50">Discretionary</th>
                    <th className="py-2.5 px-3 text-center min-w-[130px]">Active Ages</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
                  {categoryBreakdown.map((cat) => (
                    <CategoryTableRow
                      key={cat.id}
                      cat={cat}
                      primary={primary}
                      onUpdateEssentialPct={handleUpdateCategoryEssentialPct}
                      onUpdatePre65Surcharge={(val) => handleUpdateSpending({ pre65AcaBridgeSurcharge: val })}
                    />
                  ))}
                </tbody>
                <tfoot className="bg-slate-100/90 border-t-2 border-slate-300 font-extrabold text-slate-900 text-xs tabular-nums">
                  <tr>
                    <td className="py-3 px-3 uppercase tracking-wider">Total Household Budget</td>
                    <td className="py-3 px-2 text-center">100%</td>
                    <td className="py-3 px-3 text-right">
                      <div>${totalAnnualBudget.toLocaleString()} /yr</div>
                      <div className="text-[10px] font-normal text-slate-600">${Math.round(totalAnnualBudget / 12).toLocaleString()} /mo</div>
                    </td>
                    <td className="py-3 px-3 text-right text-emerald-800 bg-emerald-100/40">
                      <div className="font-black">${summaryMetrics.totalEssential.toLocaleString()} /yr</div>
                      <div className="text-[10px] font-medium text-emerald-700">${summaryMetrics.totalEssentialMonthly.toLocaleString()} /mo</div>
                      <div className="text-[10px] font-bold text-emerald-800">({summaryMetrics.essentialFloorPct.toFixed(1)}% Floor)</div>
                    </td>
                    <td className="py-3 px-3 text-center text-[10px] text-slate-500 font-normal">
                      Interactive Split
                    </td>
                    <td className="py-3 px-3 text-right text-indigo-800 bg-indigo-100/40">
                      <div className="font-black">${summaryMetrics.totalDiscretionary.toLocaleString()} /yr</div>
                      <div className="text-[10px] font-medium text-indigo-700">${summaryMetrics.totalDiscretionaryMonthly.toLocaleString()} /mo</div>
                      <div className="text-[10px] font-bold text-indigo-800">({summaryMetrics.discretionaryCushionPct.toFixed(1)}% Cushion)</div>
                    </td>
                    <td className="py-3 px-3 text-center text-[10px] font-normal text-slate-500">
                      Ages {primary.retirementAge} - {primary.lifeExpectancy}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* SECTION 2: Bottom-Up Blanchett Spending Profile & Dynamic Curve Engine */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs space-y-5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-3 border-b border-slate-100 gap-3">
          <div className="flex items-center space-x-2">
            <Smile className="w-5 h-5 text-emerald-600" />
            <div>
              <h3 className="text-base font-bold text-slate-900">2. Dynamic Spending Curve & Dynamic Model Engine</h3>
              <p className="text-xs text-slate-500">
                Discretionary expenses decay over Go-Go / Slow-Go / No-Go phases while healthcare escalates with medical CPI.
              </p>
            </div>
          </div>

          <span className="inline-flex items-center space-x-1 text-[10px] font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200/80 px-2 py-0.5 rounded-md">
            <Sliders className="w-3 h-3 text-indigo-500" />
            <span>Bottom-Up Derived Smile</span>
          </span>
        </div>

        {/* Dynamic Model Options */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div 
            onClick={() => handleUpdateSpending({ spendingModel: 'blanchett_smile' })}
            className={`p-4 rounded-xl border-2 cursor-pointer transition-all space-y-2 ${
              (spending.spendingModel || 'blanchett_smile') === 'blanchett_smile'
                ? 'border-blue-600 bg-blue-50/40 shadow-xs'
                : 'border-slate-200 hover:border-slate-300 bg-white'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-blue-900 uppercase tracking-wider">Bottom-Up Blanchett Smile</span>
              {(spending.spendingModel || 'blanchett_smile') === 'blanchett_smile' && (
                <Check className="w-4 h-4 text-blue-600" />
              )}
            </div>
            <p className="text-xs text-slate-600 leading-snug">
              Discretionary travel & hobbies decay through Go-Go (105%), Slow-Go (75%), and No-Go (50%) phases, while medical CPI escalates independently.
            </p>
          </div>

          <div 
            onClick={() => handleUpdateSpending({ spendingModel: 'declining_real' })}
            className={`p-4 rounded-xl border-2 cursor-pointer transition-all space-y-2 ${
              spending.spendingModel === 'declining_real'
                ? 'border-blue-600 bg-blue-50/40 shadow-xs'
                : 'border-slate-200 hover:border-slate-300 bg-white'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">Declining Real (-1.2%/yr)</span>
              {spending.spendingModel === 'declining_real' && (
                <Check className="w-4 h-4 text-blue-600" />
              )}
            </div>
            <p className="text-xs text-slate-600 leading-snug">
              Gradual steady decline in discretionary real spending (-1.2%/year) throughout retirement phase.
            </p>
          </div>

          <div 
            onClick={() => handleUpdateSpending({ spendingModel: 'constant' })}
            className={`p-4 rounded-xl border-2 cursor-pointer transition-all space-y-2 ${
              spending.spendingModel === 'constant'
                ? 'border-blue-600 bg-blue-50/40 shadow-xs'
                : 'border-slate-200 hover:border-slate-300 bg-white'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">Constant Inflation-Adjusted</span>
              {spending.spendingModel === 'constant' && (
                <Check className="w-4 h-4 text-blue-600" />
              )}
            </div>
            <p className="text-xs text-slate-600 leading-snug">
              Full purchasing power maintained 100% flat in real terms across all years of retirement.
            </p>
          </div>
        </div>

        {/* Dynamic Model Trajectory Mini Chart */}
        <div className="bg-slate-50 border border-slate-200/90 rounded-xl p-3.5 space-y-2">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs">
            <div className="flex items-center space-x-2">
              <span className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">Spending Model Curve</span>
              <span className="text-[10px] bg-blue-100 text-blue-800 font-bold px-2 py-0.5 rounded-full">
                {spending.spendingModel === 'declining_real' ? 'Declining Real (-1.2%/yr)' : spending.spendingModel === 'constant' ? 'Constant Purchasing Power' : 'Bottom-Up Blanchett Smile'}
              </span>
            </div>
            
            {/* Phase legend indicators */}
            <div className="flex items-center space-x-3 text-[10px] font-bold flex-wrap">
              <span className="flex items-center space-x-1 text-emerald-700">
                <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block"></span>
                <span>GO-GO (Ages {primary.retirementAge || 62}–{(primary.retirementAge || 62) + 10})</span>
              </span>
              <span className="flex items-center space-x-1 text-blue-700">
                <span className="w-2 h-2 rounded-full bg-blue-500 inline-block"></span>
                <span>SLOW-GO (Ages {(primary.retirementAge || 62) + 10}–{(primary.retirementAge || 62) + 20})</span>
              </span>
              <span className="flex items-center space-x-1 text-amber-800">
                <span className="w-2 h-2 rounded-full bg-amber-500 inline-block"></span>
                <span>NO-GO (Ages {(primary.retirementAge || 62) + 20}+)</span>
              </span>
            </div>
          </div>

          <div className="h-44 w-full relative pt-1">
            {/* Y-Axis Label */}
            <div className="absolute left-1 top-0 text-[9px] font-bold text-slate-500 uppercase tracking-wider z-10">
              Spending Adjustment (%)
            </div>

            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart 
                data={timelineData.filter(r => r.isRetired)} 
                margin={{ top: 18, right: 15, left: -10, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={true} stroke="#e2e8f0" />
                <XAxis 
                  dataKey="age" 
                  tickLine={false} 
                  tick={{ fontSize: 10, fill: '#475569', fontWeight: 600 }} 
                  axisLine={{ stroke: '#cbd5e1' }}
                  tickFormatter={(val) => `${val}`}
                />
                <YAxis 
                  domain={[-25, 20]}
                  ticks={[-25, -20, -15, -10, -5, 0, 5, 10, 15, 20]}
                  tickLine={false} 
                  axisLine={{ stroke: '#cbd5e1' }}
                  tick={{ fontSize: 10, fill: '#475569', fontWeight: 600 }} 
                  tickFormatter={(val) => `${val > 0 ? '+' : ''}${val}%`}
                  width={42}
                />
                <Tooltip 
                  formatter={(value: any) => [`${Number(value) > 0 ? '+' : ''}${value}%`, 'Spending Adjustment']}
                  labelFormatter={(label) => {
                    const row = timelineData.find(r => r.age === label);
                    return `Age ${label} (${row?.year || ''}) • ${row?.phase || ''} Phase`;
                  }}
                  contentStyle={{ borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '11px', padding: '6px 10px', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }}
                />

                {/* Shaded Area for No-Go Phase */}
                <RefArea 
                  x1={(primary.retirementAge || 62) + 20} 
                  x2={primary.lifeExpectancy || 92} 
                  y1={-25}
                  y2={20}
                  fill="#fef3c7" 
                  fillOpacity={0.45} 
                  strokeOpacity={0} 
                />

                {/* Horizontal Baseline 0% */}
                <ReferenceLine y={0} stroke="#64748b" strokeDasharray="3 3" strokeWidth={1.5} />

                {/* Single Smooth Model Trajectory Line with nodes */}
                <Line 
                  type="monotone" 
                  dataKey="spendingAdjustmentPct" 
                  name="Spending Adjustment (%)" 
                  stroke="#2563eb" 
                  strokeWidth={2.5} 
                  dot={{ r: 3.5, fill: '#3b82f6', stroke: '#ffffff', strokeWidth: 1.5 }}
                  activeDot={{ r: 6, fill: '#1d4ed8', stroke: '#60a5fa', strokeWidth: 2 }} 
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* SECTION 3: Special Expenses & Expense Shocks Register */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-3 border-b border-slate-100 gap-3">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-5 h-5 text-indigo-600" />
            <h3 className="text-base font-bold text-slate-900">3. Special Expenses & One-Time Shocks</h3>
            <span className="inline-flex items-center space-x-1 text-[10px] font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200/80 px-2 py-0.5 rounded-md">
              <Edit3 className="w-3 h-3 text-indigo-500" />
              <span>Editable Inputs</span>
            </span>
          </div>

          <button
            type="button"
            onClick={handleAddSpecialExpense}
            className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg text-xs font-semibold flex items-center space-x-1 transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Special Expense</span>
          </button>
        </div>

        {specialExpenses.length === 0 ? (
          <div className="p-6 text-center bg-slate-50 border border-dashed border-slate-300 rounded-xl">
            <p className="text-xs text-slate-500">No special lump-sum expenses defined yet.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {specialExpenses.map((expense) => (
              <div key={expense.id} className="p-4 bg-slate-50 border border-slate-200 rounded-xl grid grid-cols-1 lg:grid-cols-12 gap-3 items-center">
                <div className="lg:col-span-3">
                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Expense Name</label>
                  <input
                    type="text"
                    value={expense.name}
                    onChange={(e) => handleUpdateSpecialExpense(expense.id, 'name', e.target.value)}
                    className="w-full px-2.5 py-1 bg-white border border-slate-300 rounded text-xs font-bold text-slate-900 focus:outline-none"
                  />
                </div>

                <div className="lg:col-span-2">
                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Annual Amount ($)</label>
                  <NumericInput
                    value={expense.amount}
                    isFloat
                    step="1000"
                    onChange={(val) => handleUpdateSpecialExpense(expense.id, 'amount', val)}
                    className="w-full px-2.5 py-1 bg-white border border-slate-300 rounded text-xs font-bold text-indigo-700 focus:outline-none"
                  />
                </div>

                <div className="lg:col-span-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Start Age</label>
                  <NumericInput
                    value={expense.startAge}
                    onChange={(val) => handleUpdateSpecialExpense(expense.id, 'startAge', val)}
                    fallbackOnBlur={primary.retirementAge}
                    className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs font-medium text-slate-800 text-center focus:outline-none"
                  />
                </div>

                <div className="lg:col-span-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">End Age</label>
                  <NumericInput
                    value={expense.endAge}
                    onChange={(val) => handleUpdateSpecialExpense(expense.id, 'endAge', val)}
                    fallbackOnBlur={primary.retirementAge}
                    className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs font-medium text-slate-800 text-center focus:outline-none"
                  />
                </div>

                <div className="lg:col-span-4">
                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Expense Type</label>
                  <div className="inline-flex p-0.5 bg-slate-200/90 rounded-lg w-full text-xs font-semibold">
                    <button
                      type="button"
                      onClick={() => handleUpdateSpecialExpense(expense.id, 'isEssential', false)}
                      className={`flex-1 py-1 px-2 rounded-md transition-all flex items-center justify-center space-x-1 cursor-pointer ${
                        !expense.isEssential
                          ? 'bg-white text-indigo-700 shadow-2xs font-bold'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <Sparkles className="w-3 h-3 text-indigo-500" />
                      <span>Discretionary</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleUpdateSpecialExpense(expense.id, 'isEssential', true)}
                      className={`flex-1 py-1 px-2 rounded-md transition-all flex items-center justify-center space-x-1 cursor-pointer ${
                        expense.isEssential
                          ? 'bg-emerald-600 text-white shadow-2xs font-bold'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <Shield className="w-3 h-3 text-white" />
                      <span>Essential Floor</span>
                    </button>
                  </div>
                </div>

                <div className="lg:col-span-1 flex items-center justify-end">
                  <button
                    type="button"
                    onClick={() => handleDeleteSpecialExpense(expense.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                    title="Delete item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* SECTION 4: Multi-Year Projected Spending Chart & Trajectory */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-base font-bold text-slate-900">Multi-Year Projected Spending Timeline</h3>
              <span className="inline-flex items-center space-x-1 text-[10px] font-semibold text-slate-600 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded-md">
                <Calculator className="w-3 h-3 text-slate-500" />
                <span>Calculated Output</span>
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Annual projected outlay broken down by Essential Floor, Discretionary, Healthcare, and Special Shocks.
            </p>
          </div>
        </div>

        {/* Stacked Chart */}
        <div className="h-72 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={timelineData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
              <XAxis dataKey="age" tickLine={false} tick={{ fontSize: 11, fill: '#64748b' }} />
              <YAxis 
                tickLine={false} 
                tick={{ fontSize: 11, fill: '#64748b' }} 
                tickFormatter={(val) => `$${(val / 1000).toFixed(0)}k`}
              />
              <Tooltip 
                formatter={(value: any) => [`$${Number(value).toLocaleString()}`, '']}
                labelFormatter={(label) => `Age ${label}`}
                contentStyle={{ borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '12px' }}
              />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
              <Bar dataKey="essentialNominal" name="Essential Living Floor" stackId="a" fill="#10b981" radius={[0, 0, 0, 0]} />
              <Bar dataKey="discretionaryNominal" name="Discretionary Cushion" stackId="a" fill="#6366f1" radius={[0, 0, 0, 0]} />
              <Bar dataKey="baseHealthNominal" name="Healthcare & Medical CPI" stackId="a" fill="#f43f5e" radius={[0, 0, 0, 0]} />
              <Bar dataKey="specialNominal" name="Special Expenses / Shocks" stackId="a" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
              <Line type="monotone" dataKey="totalNominal" name="Total Nominal Outlay" stroke="#1e293b" strokeWidth={2.5} dot={false} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        {/* Compressed Data Table */}
        <div className="border border-slate-200 rounded-xl overflow-x-auto max-h-56 overflow-y-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 text-[11px] font-bold text-slate-500 uppercase tracking-wider sticky top-0 border-b border-slate-200">
              <tr>
                <th className="px-3 py-2">Age / Year</th>
                <th className="px-3 py-2">Phase</th>
                <th className="px-3 py-2 text-right">Essential Floor</th>
                <th className="px-3 py-2 text-right">Discretionary</th>
                <th className="px-3 py-2 text-right">Healthcare</th>
                <th className="px-3 py-2 text-right">Special Expenses</th>
                <th className="px-3 py-2 text-right font-extrabold text-slate-900">Total Nominal</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {timelineData.map((row) => (
                <tr key={row.age} className={`hover:bg-slate-50/80 ${row.age === primary.retirementAge ? 'bg-blue-50/40 font-bold' : ''}`}>
                  <td className="px-3 py-1.5 whitespace-nowrap">
                    Age {row.age} ({row.year}) {row.age === primary.retirementAge && <span className="text-[10px] bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded font-bold ml-1">Retire</span>}
                  </td>
                  <td className="px-3 py-1.5 whitespace-nowrap">
                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-semibold ${
                      row.phase === 'Go-Go' ? 'bg-emerald-100 text-emerald-800' :
                      row.phase === 'Slow-Go' ? 'bg-amber-100 text-amber-800' :
                      row.phase === 'No-Go' ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {row.phase}
                    </span>
                  </td>
                  <td className="px-3 py-1.5 text-right font-mono text-emerald-700">${row.essentialNominal.toLocaleString()}</td>
                  <td className="px-3 py-1.5 text-right font-mono text-indigo-700">${row.discretionaryNominal.toLocaleString()}</td>
                  <td className="px-3 py-1.5 text-right font-mono text-rose-600">${row.baseHealthNominal.toLocaleString()}</td>
                  <td className="px-3 py-1.5 text-right font-mono text-purple-700">${row.specialNominal.toLocaleString()}</td>
                  <td className="px-3 py-1.5 text-right font-mono font-extrabold text-slate-900">${row.totalNominal.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
