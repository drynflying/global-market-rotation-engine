import React, { useState } from 'react';
import { AlertTriangle, Info, HeartPulse, RotateCcw } from 'lucide-react';
import { Plan, AcaAssumptions } from '../types';
import { UpdateOptions } from '../store/usePlanStore';
import { DEFAULT_PLAN } from '../constants/defaultPlan';
import {
  AGE_RATING_CURVE,
  STANDARD_SUBSIDY_SCHEDULE,
  ENHANCED_SUBSIDY_SCHEDULE,
  FPL_FIRST_PERSON,
  FPL_EACH_ADDITIONAL,
  FPL_BASE_YEAR,
  ACA_BASE_YEAR,
  federalPovertyLevel,
  subsidyCliffIncome,
  calibrateBasePremium,
  SubsidyRegime,
} from '../domain/health/acaConstants';
import { calculateAcaPremium, cliffCost } from '../domain/health/acaSubsidy';

/**
 * ACA marketplace assumptions — a permanent section of the Assumptions tab.
 *
 * These belong here, beside the IRS brackets and state tax rules, for the same reason
 * those do: they are statutory tables published annually by a named federal source that
 * go stale and must be re-verified. The ACA parameters are the MOST volatile of the set
 * — the FPL guidelines update each year, the applicable percentage schedule is reissued
 * by Rev. Proc., and the enhanced-credit restoration bill is live legislation.
 *
 * The base premium is real user data (calibrated from a marketplace quote) and persists
 * on the plan. Phase 2 wires these into the projection.
 */
const money = (n: number) => `$${Math.round(n).toLocaleString()}`;

interface Props {
  plan: Plan;
  onUpdatePlan: (updated: Plan, options?: UpdateOptions) => void;
}

export const AcaAssumptionsSection: React.FC<Props> = ({ plan, onUpdatePlan }) => {
  const aca: AcaAssumptions = plan.acaAssumptions ?? DEFAULT_PLAN.acaAssumptions!;
  const [quote, setQuote] = useState('');
  const [quoteAge, setQuoteAge] = useState(String(plan.primaryPerson.currentAge));
  const [magi, setMagi] = useState(80000);

  const update = (patch: Partial<AcaAssumptions>, label: string) => {
    onUpdatePlan({ ...plan, acaAssumptions: { ...aca, ...patch } }, { label });
  };

  const isModified = (field: keyof AcaAssumptions) =>
    aca[field] !== DEFAULT_PLAN.acaAssumptions![field];

  const resetField = (field: keyof AcaAssumptions) =>
    update({ [field]: DEFAULT_PLAN.acaAssumptions![field] } as Partial<AcaAssumptions>,
           `reset ACA ${field}`);

  const ages = plan.hasSpouse
    ? [plan.primaryPerson.currentAge, plan.spousePerson.currentAge]
    : [plan.primaryPerson.currentAge];

  const cliff = subsidyCliffIncome(aca.householdSize);
  const example = calculateAcaPremium({
    magi,
    coveredAges: ages,
    householdSize: aca.householdSize,
    baseMonthlyPremiumAge21: aca.baseMonthlyPremiumAge21,
    regime: aca.subsidyRegime,
  });
  const impact = cliffCost({
    coveredAges: ages,
    householdSize: aca.householdSize,
    baseMonthlyPremiumAge21: aca.baseMonthlyPremiumAge21,
  });
  const schedule = aca.subsidyRegime === 'enhanced' ? ENHANCED_SUBSIDY_SCHEDULE : STANDARD_SUBSIDY_SCHEDULE;

  const applyCalibration = () => {
    const q = parseFloat(quote);
    const a = parseInt(quoteAge, 10);
    if (!isNaN(q) && !isNaN(a) && q > 0) {
      update({ baseMonthlyPremiumAge21: Math.round(calibrateBasePremium(q, a)) },
             'calibrate ACA base premium');
    }
  };

  return (
    <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-5">
      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
        <div className="flex items-center space-x-2">
          <HeartPulse className="w-4 h-4 text-rose-600" />
          <h3 className="text-sm font-bold text-slate-900">
            ACA Marketplace Premiums &amp; Subsidies ({ACA_BASE_YEAR} plan year)
          </h3>
        </div>
        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-100 text-amber-800 border border-amber-300">
          Not yet in projection
        </span>
      </div>

      <div className="flex items-start gap-2 px-3 py-2 rounded-lg bg-amber-50 border border-amber-200 text-[11px] text-amber-900">
        <AlertTriangle className="w-3.5 h-3.5 mt-px shrink-0" />
        <span>
          The ARPA/IRA enhanced credits expired 31 Dec 2025, so the hard 400% FPL cliff is back for
          {' '}{ACA_BASE_YEAR}. A bill restoring them passed the House in Jan 2026 but is not law.
          These tables reissue annually — re-verify each planning cycle.
        </span>
      </div>

      {/* Household inputs */}
      <div>
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
          Household position
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">
              Base premium, age 21 ($/mo)
              {isModified('baseMonthlyPremiumAge21') && (
                <button onClick={() => resetField('baseMonthlyPremiumAge21')} className="ml-1 text-blue-600" title="Reset">
                  <RotateCcw className="w-3 h-3 inline" />
                </button>
              )}
            </label>
            <input type="number" value={aca.baseMonthlyPremiumAge21}
              onChange={(e) => update({ baseMonthlyPremiumAge21: parseFloat(e.target.value) || 0 }, 'ACA base premium')}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg font-bold" />
          </div>
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Household size (on policy)</label>
            <input type="number" value={aca.householdSize}
              onChange={(e) => update({ householdSize: parseInt(e.target.value, 10) || 1 }, 'ACA household size')}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg font-bold" />
          </div>
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Premium trend (%/yr)</label>
            <input type="number" step="0.1" value={aca.premiumTrendPct}
              onChange={(e) => update({ premiumTrendPct: parseFloat(e.target.value) || 0 }, 'ACA premium trend')}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg font-bold" />
          </div>
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Subsidy regime</label>
            <select value={aca.subsidyRegime}
              onChange={(e) => update({ subsidyRegime: e.target.value as SubsidyRegime }, 'ACA subsidy regime')}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg font-bold">
              <option value="standard">Standard ({ACA_BASE_YEAR} law, cliff)</option>
              <option value="enhanced">Enhanced (if restored)</option>
            </select>
          </div>
        </div>

        <div className="mt-3 flex flex-wrap items-end gap-3 px-3 py-2 rounded-lg bg-slate-50 border border-slate-200">
          <Info className="w-3.5 h-3.5 text-slate-400 mb-2" />
          <span className="text-[11px] text-slate-600 mb-2">
            Calibrate from a real quote — the benchmark premium varies by county, so the shipped
            default is only a placeholder:
          </span>
          <div>
            <label className="block text-[10px] text-slate-500">Quoted $/mo</label>
            <input value={quote} onChange={(e) => setQuote(e.target.value)} placeholder="1000"
              className="w-24 px-2 py-1 border border-slate-300 rounded text-xs font-bold" />
          </div>
          <div>
            <label className="block text-[10px] text-slate-500">At age</label>
            <input value={quoteAge} onChange={(e) => setQuoteAge(e.target.value)}
              className="w-16 px-2 py-1 border border-slate-300 rounded text-xs font-bold" />
          </div>
          <button onClick={applyCalibration}
            className="px-3 py-1 rounded text-xs font-bold text-white bg-blue-600 hover:bg-blue-700">
            Calibrate
          </button>
        </div>
      </div>

      {/* Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
            Age rating curve
          </h4>
          <p className="text-[10px] text-slate-500 mb-2">
            45 CFR 147.102, capped 3:1. <em>interp.</em> rows are approximate.
          </p>
          <div className="max-h-64 overflow-y-auto border border-slate-200 rounded">
            <table className="w-full text-[11px]">
              <thead className="bg-slate-50 sticky top-0 text-[9px] uppercase text-slate-500">
                <tr><th className="text-left py-1 px-2">Age</th><th className="text-right py-1 px-2">Factor</th><th className="text-right py-1 px-2">$/mo</th></tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {AGE_RATING_CURVE.map((r) => (
                  <tr key={r.age} className={ages.includes(r.age) ? 'bg-blue-50 font-bold' : ''}>
                    <td className="py-1 px-2">{r.age}{r.age === 64 ? '+' : ''}</td>
                    <td className="py-1 px-2 text-right font-mono">
                      {r.factor.toFixed(3)}
                      {!r.verified && <span className="ml-1 text-[8px] text-slate-400">interp.</span>}
                    </td>
                    <td className="py-1 px-2 text-right font-mono">{money(aca.baseMonthlyPremiumAge21 * r.factor)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
            Federal poverty level
          </h4>
          <p className="text-[10px] text-slate-500 mb-2">
            {FPL_BASE_YEAR} guidelines govern {ACA_BASE_YEAR}. {money(FPL_FIRST_PERSON)} + {money(FPL_EACH_ADDITIONAL)} each. 48 states.
          </p>
          <table className="w-full text-[11px] border border-slate-200 rounded">
            <thead className="bg-slate-50 text-[9px] uppercase text-slate-500">
              <tr><th className="text-left py-1 px-2">Size</th><th className="text-right py-1 px-2">100%</th><th className="text-right py-1 px-2">400% cliff</th></tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {[1, 2, 3, 4, 5].map((n) => (
                <tr key={n} className={n === aca.householdSize ? 'bg-blue-50 font-bold' : ''}>
                  <td className="py-1 px-2">{n}</td>
                  <td className="py-1 px-2 text-right font-mono">{money(federalPovertyLevel(n))}</td>
                  <td className="py-1 px-2 text-right font-mono">{money(subsidyCliffIncome(n))}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
            Applicable percentage
          </h4>
          <p className="text-[10px] text-slate-500 mb-2">
            {aca.subsidyRegime === 'standard' ? 'Rev. Proc. 2025-25' : 'ARPA / IRA schedule'}
          </p>
          <table className="w-full text-[11px] border border-slate-200 rounded">
            <thead className="bg-slate-50 text-[9px] uppercase text-slate-500">
              <tr><th className="text-left py-1 px-2">% FPL</th><th className="text-right py-1 px-2">Contribution</th></tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {schedule.map((b) => (
                <tr key={b.fplFrom}>
                  <td className="py-1 px-2">{b.fplFrom}%{b.fplTo === Infinity ? '+' : `–${b.fplTo}%`}</td>
                  <td className="py-1 px-2 text-right font-mono">
                    {b.startPct === b.endPct ? `${b.startPct.toFixed(2)}%` : `${b.startPct.toFixed(2)}→${b.endPct.toFixed(2)}%`}
                  </td>
                </tr>
              ))}
              {aca.subsidyRegime === 'standard' && (
                <tr className="bg-red-50">
                  <td className="py-1 px-2 font-bold text-red-800">Over 400%</td>
                  <td className="py-1 px-2 text-right font-bold text-red-800">No credit</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Worked example */}
      <div className="pt-4 border-t border-slate-100">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
          Worked example — ages {ages.join(' and ')}
        </h4>
        <label className="block text-[11px] font-semibold text-slate-600 mb-1">
          Household MAGI: {money(magi)}
        </label>
        <input type="range" min={20000} max={200000} step={500} value={magi}
          onChange={(e) => setMagi(parseInt(e.target.value, 10))} className="w-full mb-3" />

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center">
          {[
            ['% of FPL', `${example.fplPercent.toFixed(0)}%`],
            ['Benchmark', money(example.benchmarkAnnual)],
            ['Tax credit', money(example.premiumTaxCredit)],
            ['Net premium', money(example.netAnnualPremium)],
          ].map(([label, val]) => (
            <div key={label} className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
              <div className="text-[9px] uppercase tracking-wider text-slate-500">{label}</div>
              <div className="text-sm font-black text-slate-900">{val}</div>
            </div>
          ))}
        </div>

        {aca.subsidyRegime === 'standard' && (
          <div className={`mt-3 flex items-start gap-2 px-3 py-2 rounded-lg text-[11px] border ${
            example.overCliff ? 'bg-red-50 border-red-200 text-red-900' : 'bg-emerald-50 border-emerald-200 text-emerald-900'
          }`}>
            {example.overCliff ? <AlertTriangle className="w-3.5 h-3.5 mt-px shrink-0" /> : <Info className="w-3.5 h-3.5 mt-px shrink-0" />}
            <span>
              {example.overCliff
                ? <>Above the {money(cliff)} cliff — no credit. Getting under it is worth about <strong>{money(impact.annualCost)}/yr</strong>.</>
                : <>{money(example.cliffHeadroom)} of MAGI headroom before the {money(cliff)} cliff. Crossing costs about <strong>{money(impact.annualCost)}/yr</strong> — weigh that against the tax saved by any Roth conversion that would push you over.</>}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
