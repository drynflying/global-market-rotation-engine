import React, { useEffect } from 'react';
import { Undo2 } from 'lucide-react';
import { usePlanStore } from '../store/usePlanStore';

/**
 * Undo the last committed plan edit.
 *
 * Granularity comes from NumericInput committing on blur rather than on keystroke, so
 * one press reverts one field edit. Multi-field operations (the Assumptions resets, the
 * Spending category reset) are single writes and therefore single undo entries.
 *
 * Scenario operations — create, duplicate, remove — deliberately do NOT appear here.
 * They change which plans exist rather than the contents of one, and reverting a
 * deletion with the same keystroke that fixes a typo would be surprising.
 *
 * History is per active plan and clears on switch, so this can never revert a change to
 * a plan the user is no longer looking at.
 */
export const UndoButton: React.FC = () => {
  const undo = usePlanStore((s) => s.undo);
  const undoStack = usePlanStore((s) => s.undoStack);
  const enabled = undoStack.length > 0;
  const label = enabled ? undoStack[undoStack.length - 1].label : null;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const meta = e.metaKey || e.ctrlKey;
      if (!meta || e.key.toLowerCase() !== 'z' || e.shiftKey) return;

      // Never steal undo from a field the user is editing — the browser's own text
      // undo is what they mean there.
      const el = document.activeElement;
      const tag = el?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if (el instanceof HTMLElement && el.isContentEditable) return;

      e.preventDefault();
      undo();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [undo]);

  return (
    <button
      type="button"
      onClick={() => undo()}
      disabled={!enabled}
      title={enabled ? `Undo: ${label}` : 'Nothing to undo'}
      className={`inline-flex items-center space-x-1 px-2 py-1 rounded text-xs font-semibold border transition-colors ${
        enabled
          ? 'text-neutral-800 bg-white border-neutral-300 hover:bg-neutral-100'
          : 'text-neutral-400 bg-neutral-50 border-neutral-200 cursor-not-allowed'
      }`}
    >
      <Undo2 className="w-3.5 h-3.5" />
      <span className="hidden lg:inline">Undo</span>
    </button>
  );
};
