import React from 'react';
import { Plan } from '../../types';
import {
  resolveRetirementStrategy,
  getRothConversionPolicyBadge,
  getRothConversionPolicyLabel,
  getTaxPaymentSourceLabel,
} from '../../domain/strategy';
import { SlidersHorizontal, ShieldCheck } from 'lucide-react';

interface ActiveStrategySummaryProps {
  plan: Plan;
  onGoToStrategy?: () => void;
}

export const ActiveStrategySummary: React.FC<ActiveStrategySummaryProps> = ({
  plan,
  onGoToStrategy,
}) => {
  const activeStrategy = resolveRetirementStrategy(plan);
  const conversion = activeStrategy.rothConversion;
  const badge = getRothConversionPolicyBadge(conversion);
  const label = getRothConversionPolicyLabel(conversion);
  const taxSourceLabel = getTaxPaymentSourceLabel(activeStrategy.taxPayment.conversionTaxSource);

  return (
    <div className="bg-amber-50/70 border border-amber-200/90 rounded-xl p-4 space-y-3">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-amber-200/80 pb-2.5">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-amber-950">
            Active Strategy Configuration (Read-Only)
          </h3>
          <span className="px-2 py-0.5 text-[10px] bg-amber-200 text-amber-900 font-extrabold rounded-full">
            {badge}
          </span>
        </div>

        {onGoToStrategy && (
          <button
            type="button"
            onClick={onGoToStrategy}
            className="px-3 py-1 text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white rounded-lg transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer shadow-2xs"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Edit Strategy</span>
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
        <div>
          <span className="text-[10px] font-bold text-amber-800 uppercase block mb-0.5">
            Roth Conversion Policy
          </span>
          <span className="font-bold text-neutral-900">{label}</span>
          <span className="text-[11px] text-neutral-600 block">
            Ages {conversion.startAge}–{conversion.endAge}
          </span>
        </div>

        <div>
          <span className="text-[10px] font-bold text-amber-800 uppercase block mb-0.5">
            Annual Conversion Execution
          </span>
          <span className="font-bold text-amber-950">
            {conversion.type === 'manual'
              ? `$${conversion.annualTarget.toLocaleString()} / year`
              : conversion.type === 'none'
              ? '$0 / year'
              : 'Calculated each year from tax context'}
          </span>
        </div>

        <div>
          <span className="text-[10px] font-bold text-amber-800 uppercase block mb-0.5">
            Conversion Tax Payment Source
          </span>
          <span className="font-bold text-neutral-900">{taxSourceLabel}</span>
        </div>
      </div>
    </div>
  );
};
