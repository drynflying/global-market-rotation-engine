import React from 'react';
import { Plan } from '../../types';
import { SimulationResult } from '../../domain/simulation/simulationTypes';
import { resolveRetirementStrategy, getRothConversionPolicyLabel } from '../../domain/strategy';
import { ActiveStrategySummary } from './ActiveStrategySummary';
import { Zap, Sparkles } from 'lucide-react';

interface RothConversionImpactAnalysisProps {
  plan: Plan;
  currentSim: SimulationResult;
  baselineSim: SimulationResult;
  displayFrame: 'nominal' | 'real';
  statutoryRmdAge: number;
  onGoToStrategy?: () => void;
}

export const RothConversionImpactAnalysis: React.FC<RothConversionImpactAnalysisProps> = ({
  plan,
  currentSim,
  baselineSim,
  displayFrame,
  statutoryRmdAge,
  onGoToStrategy,
}) => {
  const activeStrategy = resolveRetirementStrategy(plan);

  // Baseline metrics
  const baselineRmdTaxes =
    displayFrame === 'real'
      ? baselineSim.lifetimeRmdTaxesReal
      : baselineSim.lifetimeRmdTaxesNominal;
  const baselineTotalTax =
    displayFrame === 'real'
      ? baselineSim.lifetimeTotalTaxReal
      : baselineSim.lifetimeTotalTaxNominal;

  // Active strategy metrics
  const activeConversionTaxPaid =
    displayFrame === 'real'
      ? currentSim.lifetimeConversionTaxPaidReal
      : currentSim.lifetimeConversionTaxPaidNominal;
  const activeRmdTaxes =
    displayFrame === 'real'
      ? currentSim.lifetimeRmdTaxesReal
      : currentSim.lifetimeRmdTaxesNominal;
  const activeTotalTax =
    displayFrame === 'real'
      ? currentSim.lifetimeTotalTaxReal
      : currentSim.lifetimeTotalTaxNominal;

  // Lifetime tax savings
  const lifetimeTaxSavings = baselineTotalTax - activeTotalTax;

  const baselinePreTaxAtRmd =
    baselineSim.rows.find((r) => r.age === statutoryRmdAge)?.preTaxBal || 0;
  const activePreTaxAtRmd =
    currentSim.rows.find((r) => r.age === statutoryRmdAge)?.preTaxBal || 0;

  return (
    <section className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs space-y-5">
      {/* Header */}
      <div className="border-b border-neutral-200 pb-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold text-neutral-900 flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-500" />
            <span>Roth Conversion Impact Analysis</span>
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Evaluate converting pre-tax IRAs to tax-free Roth during low-income gap years before Social Security & RMDs
          </p>
        </div>
      </div>

      {/* Read-Only Active Strategy Summary */}
      <ActiveStrategySummary plan={plan} onGoToStrategy={onGoToStrategy} />

      {/* Side-by-Side Comparison Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Baseline Scenario: No Conversions */}
        <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-200 space-y-3">
          <div className="flex items-center justify-between border-b border-neutral-200 pb-2">
            <span className="font-bold text-neutral-800 text-xs">
              Comparison Baseline: No Roth Conversions
            </span>
            <span className="px-2 py-0.5 text-[10px] bg-neutral-200 text-neutral-700 font-bold rounded-full">
              No Action
            </span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-neutral-600">Roth Conversion Policy:</span>
              <span className="font-bold text-neutral-900">No Conversions</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-neutral-600">Conversion Taxes Paid Now:</span>
              <span className="font-bold text-emerald-700">$0</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-neutral-600">
                Pre-Tax Balance at RMD Age {statutoryRmdAge}:
              </span>
              <span className="font-bold text-rose-700">
                ${Math.round(baselinePreTaxAtRmd).toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between border-t border-neutral-200 pt-2">
              <span className="font-bold text-neutral-900">
                Lifetime Mandatory RMD Tax Drag:
              </span>
              <span className="font-extrabold text-rose-800 text-xs">
                ${Math.round(baselineRmdTaxes).toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Active Strategy Scenario */}
        <div className="bg-amber-50/50 p-4 rounded-xl border border-amber-200 space-y-3">
          <div className="flex items-center justify-between border-b border-amber-200 pb-2">
            <span className="font-bold text-amber-950 text-xs">
              Active Roth Conversion Strategy
            </span>
            <span className="px-2 py-0.5 text-[10px] bg-amber-200 text-amber-900 font-bold rounded-full">
              Active
            </span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-neutral-600">Roth Conversion Policy:</span>
              <span className="font-bold text-amber-950">
                {getRothConversionPolicyLabel(activeStrategy.rothConversion)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-neutral-600">Lifetime Conversion Taxes Paid:</span>
              <span className="font-bold text-amber-900">
                ${Math.round(activeConversionTaxPaid).toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-neutral-600">
                Pre-Tax Balance at RMD Age {statutoryRmdAge}:
              </span>
              <span className="font-bold text-emerald-800">
                ${Math.round(activePreTaxAtRmd).toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between border-t border-amber-200 pt-2">
              <span className="font-bold text-neutral-900">
                Lifetime Mandatory RMD Tax Drag:
              </span>
              <span className="font-extrabold text-emerald-800 text-xs">
                ${Math.round(activeRmdTaxes).toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Net Lifetime Tax Savings Highlight Banner */}
      <div className="p-4 rounded-xl bg-indigo-50 border border-indigo-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-0.5">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-indigo-600" />
            <span className="text-xs font-bold text-indigo-950 uppercase tracking-wider">
              Lifetime Tax Difference vs. No-Conversion Baseline
            </span>
          </div>
          <p className="text-xs text-neutral-600">
            {lifetimeTaxSavings >= 0
              ? `By paying ~$${Math.round(activeConversionTaxPaid).toLocaleString()} in Roth conversion taxes during gap years, total lifetime taxes are reduced by ~$${Math.round(lifetimeTaxSavings).toLocaleString()}.`
              : `By paying ~$${Math.round(activeConversionTaxPaid).toLocaleString()} in Roth conversion taxes, total lifetime taxes are increased by ~$${Math.round(Math.abs(lifetimeTaxSavings)).toLocaleString()}.`}
          </p>
        </div>

        <div className="bg-white px-4 py-2 rounded-xl border border-indigo-200 text-right shrink-0">
          <span className="text-[10px] font-semibold text-neutral-500 uppercase block">
            Net Tax Difference
          </span>
          <span className={`text-lg font-extrabold ${lifetimeTaxSavings >= 0 ? 'text-indigo-900' : 'text-rose-700'}`}>
            {lifetimeTaxSavings >= 0
              ? `+$${Math.round(lifetimeTaxSavings).toLocaleString()}`
              : `-$${Math.round(Math.abs(lifetimeTaxSavings)).toLocaleString()}`}
          </span>
        </div>
      </div>
    </section>
  );
};
