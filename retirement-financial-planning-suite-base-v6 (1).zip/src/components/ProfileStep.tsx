import React, { useState } from 'react';
import { Plan, UserProfile, AccountItem, OwnerType, AccountType, AccountAllocation } from '../types';
import { DEFAULT_PLAN } from '../constants/defaultPlan';
import { UpdateOptions } from '../store/usePlanStore';
import { Step3InvestmentsStep } from './Step3InvestmentsStep';
import { NumericInput } from './NumericInput';
import { calculateAccountTotals, getAccountCapability, ACCOUNT_CAPABILITIES } from '../domain/accounts/accountCapabilities';
import { getActiveW2Compensation, resolveAccountContribution } from '../domain/contributions/contributionResolver';
import { 
  User, 
  Users, 
  Layers,
  Plus, 
  Trash2, 
  Edit2, 
  CheckCircle,
  HelpCircle,
  ArrowUpRight,
  Info,
  ExternalLink,
  X,
  PieChart,
  TrendingUp,
  ArrowRight
} from 'lucide-react';

interface ProfileStepProps {
  plan: Plan;
  onUpdatePlan: (updated: Plan, options?: UpdateOptions) => void;
  onGoToValidations: () => void;
  onGoToNextStep?: () => void;
}

export const ProfileStep: React.FC<ProfileStepProps> = ({ plan, onUpdatePlan, onGoToValidations, onGoToNextStep }) => {
  const p = plan.primaryPerson;
  const s = plan.spousePerson;

  const defaultPresets = DEFAULT_PLAN.allocationPresets || [];
  const storedPresets = plan.allocationPresets || [];
  const presetsMap = new Map<string, any>();
  defaultPresets.forEach(preset => presetsMap.set(preset.id, preset));
  storedPresets.forEach(preset => presetsMap.set(preset.id, preset));
  const availablePresets = Array.from(presetsMap.values());

  const getDefaultAllocation = (presetId: string): AccountAllocation => {
    const preset = availablePresets.find(p => p.id === presetId);
    if (preset) {
      return {
        usEquityPct: preset.usEquityPct,
        intlEquityPct: preset.intlEquityPct,
        goldPct: preset.goldPct || 0,
        bondsPct: preset.bondsPct,
        cashPct: preset.cashPct,
      };
    }
    return { usEquityPct: 30, intlEquityPct: 15, goldPct: 7.5, bondsPct: 40, cashPct: 7.5 };
  };

  // Social Security Info & Source Modal
  const [showSsInfoModal, setShowSsInfoModal] = useState(false);

  // Modal State for adding/editing accounts
  const [showAccountModal, setShowAccountModal] = useState(false);
  const [editingAccountId, setEditingAccountId] = useState<string | null>(null);
  const [accountForm, setAccountForm] = useState<Omit<AccountItem, 'id'>>({
    name: '',
    owner: 'primary',
    type: 'pre-tax',
    balance: 100000,
    annualContribution: 10000,
    allocationPresetId: 'preset-allweather',
    allocation: { usEquityPct: 30, intlEquityPct: 15, goldPct: 7.5, bondsPct: 40, cashPct: 7.5 },
  });

  // Helper updates
  const updatePrimary = (field: keyof UserProfile, val: any) => {
    onUpdatePlan({
      ...plan,
      primaryPerson: { ...plan.primaryPerson, [field]: val },
    });
  };

  const updateSpouse = (field: keyof UserProfile, val: any) => {
    onUpdatePlan({
      ...plan,
      spousePerson: { ...plan.spousePerson, [field]: val },
    });
  };

  const updateSsReductionToggle = (personKey: 'primary' | 'spouse', value: boolean) => {
    const isPrimary = personKey === 'primary';
    const updatedPrimary = isPrimary
      ? { ...plan.primaryPerson, includeSsProjectedReduction: value }
      : plan.primaryPerson;
    const updatedSpouse = !isPrimary
      ? { ...plan.spousePerson, includeSsProjectedReduction: value }
      : plan.spousePerson;

    const anyReduced = (updatedPrimary.includeSsProjectedReduction || false) || (updatedSpouse.includeSsProjectedReduction || false);

    const existingAssumptions = plan.assumptions || [];
    const otherAssumptions = existingAssumptions.filter(a => a.id !== 'asm-ss-trust-fund');

    const ssAssumption = {
      id: 'asm-ss-trust-fund',
      category: 'Social Security',
      parameterName: 'Projected SSA Trust Fund Solvency Reduction',
      currentValue: anyReduced ? '21.0% Benefit Reduction Applied (~79% Payable)' : '100% Scheduled Benefits (Reduction Excluded)',
      refreshedValue: '21.0% Payable Benefit Reduction (~2033-2035 Depletion)',
      sourceName: 'SSA Board of Trustees OASDI Annual Report',
      sourceUrl: 'https://www.ssa.gov/oact/TR/',
      lastUpdated: '2024-05-06',
      notes: anyReduced
        ? 'User enabled 21% benefit reduction modeling based on SSA Trustees projected ~2033-2035 OASDI trust fund depletion.'
        : 'Default modeling assuming 100% full scheduled benefits under future Congressional legislative action.'
    };

    onUpdatePlan({
      ...plan,
      primaryPerson: updatedPrimary,
      spousePerson: updatedSpouse,
      assumptions: [...otherAssumptions, ssAssumption],
    });
  };

  // Account modal handlers
  const openNewAccountModal = () => {
    setEditingAccountId(null);
    const defaultPresetId = 'preset-allweather';
    setAccountForm({
      name: '',
      owner: 'primary',
      type: 'pre-tax',
      balance: 50000,
      annualContribution: 6000,
      employerMatchValue: 0,
      employerMatchType: '$',
      allocationPresetId: defaultPresetId,
      allocation: getDefaultAllocation(defaultPresetId),
    });
    setShowAccountModal(true);
  };

  const openEditAccountModal = (acc: AccountItem) => {
    setEditingAccountId(acc.id);
    const presetId = acc.allocationPresetId || 'preset-allweather';
    const alloc = acc.allocation || getDefaultAllocation(presetId);

    setAccountForm({
      name: acc.name,
      owner: acc.owner,
      type: acc.type,
      balance: acc.balance,
      annualContribution: acc.annualContribution,
      employerMatchValue: acc.employerMatchValue || 0,
      employerMatchType: acc.employerMatchType || '$',
      notes: acc.notes,
      allocationPresetId: presetId,
      allocation: alloc,
    });
    setShowAccountModal(true);
  };

  const handleSelectPresetForAccount = (presetId: string) => {
    if (presetId === 'custom') {
      setAccountForm(prev => ({
        ...prev,
        allocationPresetId: 'custom',
        allocation: prev.allocation || getDefaultAllocation('preset-allweather'),
      }));
    } else {
      const selectedAlloc = getDefaultAllocation(presetId);
      setAccountForm(prev => ({
        ...prev,
        allocationPresetId: presetId,
        allocation: selectedAlloc,
      }));
    }
  };

  const handleAllocationFieldChange = (field: keyof AccountAllocation, value: number) => {
    setAccountForm(prev => {
      const currentAlloc = prev.allocation || getDefaultAllocation('preset-allweather');
      const updatedAlloc = { ...currentAlloc, [field]: value };

      const currentPreset = availablePresets.find(p => p.id === prev.allocationPresetId);
      let nextPresetId = prev.allocationPresetId;

      if (currentPreset) {
        const matches =
          updatedAlloc.usEquityPct === currentPreset.usEquityPct &&
          updatedAlloc.intlEquityPct === currentPreset.intlEquityPct &&
          updatedAlloc.goldPct === (currentPreset.goldPct || 0) &&
          updatedAlloc.bondsPct === currentPreset.bondsPct &&
          updatedAlloc.cashPct === currentPreset.cashPct;

        if (!matches) {
          nextPresetId = 'custom';
        }
      } else {
        nextPresetId = 'custom';
      }

      return {
        ...prev,
        allocationPresetId: nextPresetId,
        allocation: updatedAlloc,
      };
    });
  };

  const handleSaveAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!accountForm.name.trim()) return;

    const currentAlloc = accountForm.allocation || getDefaultAllocation(accountForm.allocationPresetId || 'preset-allweather');
    const allocTotal =
      (currentAlloc.usEquityPct || 0) +
      (currentAlloc.intlEquityPct || 0) +
      (currentAlloc.goldPct || 0) +
      (currentAlloc.bondsPct || 0) +
      (currentAlloc.cashPct || 0);

    if (allocTotal !== 100) {
      alert(`Asset allocation target percentages must sum to 100%. Current total is ${allocTotal}%.`);
      return;
    }

    if (editingAccountId) {
      const updatedAccounts = plan.accounts.map(a =>
        a.id === editingAccountId ? { ...accountForm, id: editingAccountId } : a
      );
      onUpdatePlan({ ...plan, accounts: updatedAccounts });
    } else {
      const newAcc: AccountItem = {
        ...accountForm,
        id: `acc-${Date.now()}`,
      };
      onUpdatePlan({ ...plan, accounts: [...plan.accounts, newAcc] });
    }
    setShowAccountModal(false);
  };

  const handleDeleteAccount = (id: string) => {
    onUpdatePlan({
      ...plan,
      accounts: plan.accounts.filter(a => a.id !== id),
    });
  };

  const accountTotals = calculateAccountTotals(plan.accounts, plan);

  return (
    <div className="space-y-6">
      
      {/* SECTION 1: Comprehensive Accounts & Asset Register */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-3 border-b border-slate-100 gap-2">
          <div>
            <h3 className="text-base font-bold text-slate-900">1. Asset & Investment Accounts Register</h3>
            <p className="text-xs text-slate-500">
              Taxable brokerage, pre-tax 401(k)/IRAs, post-tax Roth accounts, cash, HSA, and real estate equity.
            </p>
          </div>

          <button
            onClick={openNewAccountModal}
            className="inline-flex items-center space-x-1.5 px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Add Asset Account</span>
          </button>
        </div>

        {/* Account Totals Summary Banner */}
        {plan.accounts.length > 0 && (
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs space-y-2">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="bg-white p-2.5 rounded-lg border border-emerald-200 shadow-2xs">
                <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block">Modeled Retirement Portfolio</span>
                <span className="text-lg font-extrabold text-slate-900">${Math.round(accountTotals.modeledPortfolioBalance).toLocaleString()}</span>
                <span className="text-[10px] text-slate-500 block mt-0.5">Pre-Tax, Roth, Taxable & Cash included in projections</span>
              </div>
              <div className={`bg-white p-2.5 rounded-lg border shadow-2xs ${accountTotals.hasUnmodeledAssets ? 'border-amber-300 bg-amber-50/50' : 'border-slate-200'}`}>
                <span className="text-[10px] font-bold text-amber-900 uppercase tracking-wider block">Recorded Assets (Not Modeled)</span>
                <span className="text-lg font-extrabold text-slate-900">${Math.round(accountTotals.recordedNotModeledBalance).toLocaleString()}</span>
                <span className="text-[10px] text-slate-500 block mt-0.5">HSA & Real Estate Equity recorded in register</span>
              </div>
              <div className="bg-white p-2.5 rounded-lg border border-slate-200 shadow-2xs">
                <span className="text-[10px] font-bold text-slate-600 uppercase tracking-wider block">Total Recorded Net Worth</span>
                <span className="text-lg font-extrabold text-slate-900">${Math.round(accountTotals.totalRecordedBalance).toLocaleString()}</span>
                <span className="text-[10px] text-slate-500 block mt-0.5">Across all {accountTotals.totalCount} active accounts</span>
              </div>
            </div>

            {accountTotals.hasUnmodeledAssets && (
              <div className="flex items-start gap-2 pt-1 text-[11px] text-amber-800">
                <Info className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
                <span>
                  <strong>Notice:</strong> Your register contains {accountTotals.recordedNotModeledCount} recorded asset(s) totaling <strong>${Math.round(accountTotals.recordedNotModeledBalance).toLocaleString()}</strong>.
                  {' '}<em>Recorded — not currently included in retirement projection.</em> Projections utilize your modeled liquid retirement capital (<strong>${Math.round(accountTotals.modeledPortfolioBalance).toLocaleString()}</strong>).
                </span>
              </div>
            )}
          </div>
        )}

        {/* Accounts Table */}
        <div className="overflow-x-auto border border-slate-200 rounded-xl">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 uppercase font-bold text-[10px] tracking-wider border-b border-slate-200">
              <tr>
                <th className="p-3">Account Name</th>
                <th className="p-3">Owner</th>
                <th className="p-3">Tax Treatment</th>
                <th className="p-3">Modeling Status</th>
                <th className="p-3">Asset Allocation</th>
                <th className="p-3 text-right">Current Balance</th>
                <th className="p-3 text-right">Annual Contrib.</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {plan.accounts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">
                    No accounts added yet. Click "Add Asset Account" above to start building your portfolio register.
                  </td>
                </tr>
              ) : (
                plan.accounts.map((acc) => {
                  const ownerLabel = acc.owner === 'primary' ? p.name : (acc.owner === 'spouse' ? s.name : 'Joint');
                  const capability = getAccountCapability(acc.type);
                  const taxBadge = 
                    acc.type === 'pre-tax' ? 'bg-amber-100 text-amber-800' :
                    acc.type === 'post-tax' ? 'bg-emerald-100 text-emerald-800' :
                    acc.type === 'hsa' ? 'bg-teal-100 text-teal-800' :
                    acc.type === 'taxable' ? 'bg-blue-100 text-blue-800' :
                    acc.type === 'real-estate' ? 'bg-purple-100 text-purple-800' : 'bg-slate-100 text-slate-800';

                  const presetId = acc.allocationPresetId || 'preset-allweather';
                  const foundPreset = availablePresets.find(p => p.id === presetId);
                  const presetLabel = presetId === 'custom' ? 'Custom Allocation' : (foundPreset?.name || 'All-Weather Target Risk');
                  const alloc = acc.allocation || getDefaultAllocation(presetId);

                  return (
                    <tr key={acc.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3 font-semibold text-slate-900">
                        {acc.name}
                        {!capability.isModeledInProjection && (
                          <span className="block text-[10px] font-normal text-amber-700 italic mt-0.5">
                            Recorded — not currently included in retirement projection.
                          </span>
                        )}
                      </td>
                      <td className="p-3 text-slate-700 font-medium">{ownerLabel}</td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${taxBadge}`}>
                          {acc.type}
                        </span>
                      </td>
                      <td className="p-3">
                        {capability.isModeledInProjection ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                            Fully Modeled
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300" title={capability.badgeTooltip}>
                            Recorded (Not Modeled)
                          </span>
                        )}
                      </td>
                      <td className="p-3 text-slate-700 font-medium">
                        <div className="space-y-1">
                          <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold ${
                            presetId === 'custom' ? 'bg-amber-100 text-amber-800 border border-amber-200' : 'bg-slate-100 text-slate-800 border border-slate-200'
                          }`}>
                            {presetLabel}
                          </span>
                          <div className="w-28 h-1.5 rounded-full overflow-hidden flex bg-slate-200" title={`US Eq: ${alloc.usEquityPct}%, Intl Eq: ${alloc.intlEquityPct}%, Gold: ${alloc.goldPct}%, Bonds: ${alloc.bondsPct}%, Cash: ${alloc.cashPct}%`}>
                            <div style={{ width: `${alloc.usEquityPct}%` }} className="bg-blue-600 h-full" />
                            <div style={{ width: `${alloc.intlEquityPct}%` }} className="bg-purple-600 h-full" />
                            <div style={{ width: `${alloc.goldPct}%` }} className="bg-amber-500 h-full" />
                            <div style={{ width: `${alloc.bondsPct}%` }} className="bg-emerald-600 h-full" />
                            <div style={{ width: `${alloc.cashPct}%` }} className="bg-slate-400 h-full" />
                          </div>
                        </div>
                      </td>
                      <td className="p-3 text-right font-bold text-slate-900">
                        ${acc.balance.toLocaleString()}
                      </td>
                      <td className="p-3 text-right font-semibold text-blue-700">
                        {(() => {
                          const ownerComp = getActiveW2Compensation(
                            plan,
                            acc.owner,
                            plan.primaryPerson.currentAge,
                            plan.hasSpouse ? plan.spousePerson.currentAge : undefined,
                            0
                          );
                          const breakdown = resolveAccountContribution(acc, {
                            ownerW2Compensation: ownerComp,
                            contributionScale: 1.0,
                          });
                          return (
                            <>
                              <div>+${breakdown.totalAccountContribution.toLocaleString()}/yr</div>
                              {breakdown.employerContribution > 0 && (
                                <div className="text-[10px] text-slate-500 font-normal">
                                  incl. ${breakdown.employerContribution.toLocaleString()} {acc.employerMatchType === '%' ? `(${acc.employerMatchValue}%)` : 'match'}
                                </div>
                              )}
                            </>
                          );
                        })()}
                      </td>
                      <td className="p-3 text-right space-x-1">
                        <button
                          onClick={() => openEditAccountModal(acc)}
                          className="p-1 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteAccount(acc.id)}
                          className="p-1 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* SECTION 2: Consolidated Portfolio Asset Class Allocation & Return Engine */}
      <div className="pt-4 border-t border-slate-200">
        <div className="mb-4">
          <h3 className="text-base font-bold text-slate-900 flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            <span>2. Portfolio Asset Class Allocation & Return Engine</span>
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Portfolio weighted asset class targets and expected geometric return breakdown across all accounts.
          </p>
        </div>

        <Step3InvestmentsStep
          plan={plan}
          onUpdatePlan={onUpdatePlan}
          onGoToValidations={onGoToValidations}
          onGoToNextStep={onGoToNextStep}
          hideHeader={true}
        />
      </div>

      {showAccountModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 border border-slate-200">
            <h3 className="text-base font-bold text-slate-900 mb-1">
              {editingAccountId ? 'Edit Asset Account' : 'Add New Asset Account'}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Categorize the tax status, owner, current balance, and annual savings parameters.
            </p>

            <form onSubmit={handleSaveAccount} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-medium mb-1">Account Title</label>
                <input
                  type="text"
                  required
                  value={accountForm.name}
                  onChange={(e) => setAccountForm({ ...accountForm, name: e.target.value })}
                  placeholder="e.g., Primary Vanguard 401(k) or Joint Brokerage"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Account Owner</label>
                  <select
                    value={accountForm.owner}
                    onChange={(e) => setAccountForm({ ...accountForm, owner: e.target.value as OwnerType })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="primary">{p.name || 'Primary'}</option>
                    {plan.hasSpouse && <option value="spouse">{s.name || 'Spouse'}</option>}
                    <option value="joint">Joint Household</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">Tax Treatment & Modeling Status</label>
                  <select
                    value={accountForm.type}
                    onChange={(e) => setAccountForm({ ...accountForm, type: e.target.value as AccountType })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="pre-tax">Pre-Tax (Traditional 401k/IRA) — Fully Modeled</option>
                    <option value="post-tax">Post-Tax (Roth 401k/IRA) — Fully Modeled</option>
                    <option value="taxable">Taxable Brokerage — Fully Modeled</option>
                    <option value="cash">Cash / HYSA / CD — Fully Modeled</option>
                    <option value="hsa">HSA (Health Savings Account) — Recorded (Not Modeled)</option>
                    <option value="real-estate">Real Estate Equity — Recorded (Not Modeled)</option>
                  </select>
                  <div className={`mt-1.5 p-2 rounded-lg text-[11px] font-medium flex items-center gap-1.5 ${
                    getAccountCapability(accountForm.type).isModeledInProjection
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : 'bg-amber-50 text-amber-900 border border-amber-300'
                  }`}>
                    {getAccountCapability(accountForm.type).isModeledInProjection ? (
                      <span>✓ Fully modeled in retirement cash flow & portfolio projections.</span>
                    ) : (
                      <span>⚠️ <strong>Recorded — not currently included in retirement projection.</strong></span>
                    )}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Current Balance ($)</label>
                  <NumericInput
                    value={accountForm.balance}
                    isFloat
                    min="0"
                    onChange={(val) => setAccountForm({ ...accountForm, balance: val })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-bold focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">Annual Contribution ($/yr)</label>
                  <NumericInput
                    value={accountForm.annualContribution}
                    isFloat
                    min="0"
                    onChange={(val) => setAccountForm({ ...accountForm, annualContribution: val })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-bold focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Employer Match / Contribution */}
              {(accountForm.type === 'pre-tax' || accountForm.type === 'post-tax') && (
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-800">Employer Match / Contribution</label>
                    <span className="text-[10px] text-slate-500 font-medium">Optional</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[11px] text-slate-600 font-medium mb-1">Match Type</label>
                      <select
                        value={accountForm.employerMatchType || '$'}
                        onChange={(e) => setAccountForm({ ...accountForm, employerMatchType: e.target.value as '$' | '%' })}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
                      >
                        <option value="$">Fixed Dollar ($/yr)</option>
                        <option value="%">% of Owner Salary</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-600 font-medium mb-1">
                        {accountForm.employerMatchType === '%' ? 'Match Percentage (%)' : 'Annual Match ($/yr)'}
                      </label>
                      <NumericInput
                        value={accountForm.employerMatchValue ?? 0}
                        isFloat
                        min="0"
                        onChange={(val) => setAccountForm({ ...accountForm, employerMatchValue: val })}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                  {accountForm.employerMatchType === '%' && (
                    <p className="text-[10px] text-slate-500">
                      Calculated on {accountForm.owner === 'primary' ? (plan.primaryPerson.name || 'Primary') : (plan.spousePerson?.name || 'Spouse')} active W-2 salary.
                    </p>
                  )}
                </div>
              )}

              {/* Asset Allocation Strategy Section */}
              {(() => {
                const currentAlloc = accountForm.allocation || getDefaultAllocation(accountForm.allocationPresetId || 'preset-allweather');
                const allocTotal =
                  (currentAlloc.usEquityPct || 0) +
                  (currentAlloc.intlEquityPct || 0) +
                  (currentAlloc.goldPct || 0) +
                  (currentAlloc.bondsPct || 0) +
                  (currentAlloc.cashPct || 0);

                return (
                  <div className="border-t border-slate-200 pt-3 mt-3 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div>
                        <label className="block text-slate-800 font-bold text-xs">Asset Allocation Strategy</label>
                        <p className="text-[11px] text-slate-500">
                          Select an asset allocation preset or set custom target weights for this specific asset.
                        </p>
                      </div>
                      {accountForm.allocationPresetId === 'custom' && (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                          Custom Allocation
                        </span>
                      )}
                    </div>

                    <div>
                      <label className="block text-slate-700 font-medium text-[11px] mb-1">Preset Allocation Model</label>
                      <select
                        value={accountForm.allocationPresetId || 'preset-allweather'}
                        onChange={(e) => handleSelectPresetForAccount(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500 font-medium"
                      >
                        {availablePresets.map((preset) => {
                          const eqLabel = `${preset.usEquityPct + preset.intlEquityPct}/${preset.goldPct || 0}/${preset.bondsPct}/${preset.cashPct}`;
                          return (
                            <option key={preset.id} value={preset.id}>
                              {preset.name} ({eqLabel})
                            </option>
                          );
                        })}
                        <option value="custom">Custom Allocation (Account-Specific)</option>
                      </select>
                    </div>

                    {/* Target Asset Breakdown Inputs */}
                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-2">
                      <div className="flex items-center justify-between pb-1 border-b border-slate-200">
                        <span className="text-[11px] font-bold text-slate-700">Target Asset Class Weights</span>
                        <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                          allocTotal === 100 ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                        }`}>
                          Total: {allocTotal}%
                        </span>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-[11px]">
                        <div>
                          <label className="block text-slate-600 font-medium mb-0.5 text-[10px]">US Equity %</label>
                          <NumericInput
                            value={currentAlloc.usEquityPct}
                            isFloat
                            min="0"
                            max="100"
                            onChange={(val) => handleAllocationFieldChange('usEquityPct', val)}
                            className="w-full px-2 py-1 border border-slate-300 rounded text-slate-900 font-bold focus:outline-none focus:ring-1 focus:ring-blue-500"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-600 font-medium mb-0.5 text-[10px]">Intl Equity %</label>
                          <NumericInput
                            value={currentAlloc.intlEquityPct}
                            isFloat
                            min="0"
                            max="100"
                            onChange={(val) => handleAllocationFieldChange('intlEquityPct', val)}
                            className="w-full px-2 py-1 border border-slate-300 rounded text-slate-900 font-bold focus:outline-none focus:ring-1 focus:ring-blue-500"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-600 font-medium mb-0.5 text-[10px]">Gold ETF %</label>
                          <NumericInput
                            value={currentAlloc.goldPct}
                            isFloat
                            min="0"
                            max="100"
                            onChange={(val) => handleAllocationFieldChange('goldPct', val)}
                            className="w-full px-2 py-1 border border-slate-300 rounded text-slate-900 font-bold focus:outline-none focus:ring-1 focus:ring-blue-500"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-600 font-medium mb-0.5 text-[10px]">Bonds %</label>
                          <NumericInput
                            value={currentAlloc.bondsPct}
                            isFloat
                            min="0"
                            max="100"
                            onChange={(val) => handleAllocationFieldChange('bondsPct', val)}
                            className="w-full px-2 py-1 border border-slate-300 rounded text-slate-900 font-bold focus:outline-none focus:ring-1 focus:ring-blue-500"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-600 font-medium mb-0.5 text-[10px]">Cash %</label>
                          <NumericInput
                            value={currentAlloc.cashPct}
                            isFloat
                            min="0"
                            max="100"
                            onChange={(val) => handleAllocationFieldChange('cashPct', val)}
                            className="w-full px-2 py-1 border border-slate-300 rounded text-slate-900 font-bold focus:outline-none focus:ring-1 focus:ring-blue-500"
                          />
                        </div>
                      </div>

                      <div className="w-full h-2 rounded-full overflow-hidden flex bg-slate-200 mt-2" title="Asset class visual breakdown bar">
                        <div style={{ width: `${currentAlloc.usEquityPct}%` }} className="bg-blue-600 h-full" />
                        <div style={{ width: `${currentAlloc.intlEquityPct}%` }} className="bg-purple-600 h-full" />
                        <div style={{ width: `${currentAlloc.goldPct}%` }} className="bg-amber-500 h-full" />
                        <div style={{ width: `${currentAlloc.bondsPct}%` }} className="bg-emerald-600 h-full" />
                        <div style={{ width: `${currentAlloc.cashPct}%` }} className="bg-slate-400 h-full" />
                      </div>

                      {allocTotal !== 100 && (
                        <p className="text-[10px] text-red-600 font-semibold pt-0.5">
                          Notice: Asset weights sum to {allocTotal}%. Total should equal 100%.
                        </p>
                      )}
                    </div>
                  </div>
                );
              })()}

              <div className="flex justify-end space-x-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAccountModal(false)}
                  className="px-4 py-2 font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
                >
                  Save Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Social Security Trust Fund Reduction Info & Official URL Source */}
      {showSsInfoModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 border border-slate-200 relative space-y-4">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2">
                <div className="p-2 bg-amber-100 text-amber-700 rounded-xl">
                  <Info className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Social Security Trust Fund Reduction Info
                  </h3>
                  <span className="text-xs text-slate-500 font-medium">SSA OASDI Solvency Outlook</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowSsInfoModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-700 leading-relaxed">
              <p>
                According to the annual reports published by the <strong>Social Security Board of Trustees</strong>, the Old-Age and Survivors Insurance (OASI) and Disability Insurance (DI) Trust Funds (OASDI) are projected to exhaust their cash reserves around <strong>2033 to 2035</strong>.
              </p>
              
              <div className="bg-amber-50 p-3 rounded-xl border border-amber-200 space-y-1">
                <span className="font-bold text-amber-900 block">Key Solvency Finding:</span>
                <p className="text-amber-800 text-[11px]">
                  If Congress does not pass legislative solvency reforms prior to trust fund depletion, incoming payroll tax revenues will still cover approximately <strong>79% to 80%</strong> of scheduled benefits. This translates to an estimated automatic payable benefit reduction of <strong>20% to 21%</strong> (~21% baseline).
                </p>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
                <span className="font-bold text-slate-900 block text-[11px] uppercase tracking-wider">
                  Verifiable Source URL & References:
                </span>
                
                <div className="flex items-start space-x-2 bg-white p-2.5 rounded-lg border border-slate-200">
                  <ArrowUpRight className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <a
                      href="https://www.ssa.gov/oact/TR/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-bold text-blue-600 hover:text-blue-800 underline inline-flex items-center space-x-1"
                    >
                      <span>SSA Board of Trustees Annual OASDI Report</span>
                      <ExternalLink className="w-3 h-3 ml-0.5" />
                    </a>
                    <p className="text-[11px] text-slate-500">
                      The official Annual Report of the Board of Trustees of the Federal Old-Age and Survivors Insurance and Federal Disability Insurance Trust Funds.
                    </p>
                    <div className="text-[10px] text-slate-600 bg-slate-100 px-2 py-0.5 rounded font-mono break-all font-semibold">
                      https://www.ssa.gov/oact/TR/
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-3 bg-blue-50 rounded-xl border border-blue-100 text-[11px] text-blue-900">
                <strong>Saved to Assumptions & Resource Table:</strong> Toggling this parameter updates your scenario's Social Security assumption baseline, preserving the source link for Step 2 Assumptions & Data Refresh.
              </div>
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowSsInfoModal(false)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold shadow-xs"
              >
                Got It, Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
