import React, { useState } from 'react';
import { 
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { orderedTabs, TabId } from '../constants/tabs';

interface SidebarNavigationProps {
  activeTab: TabId;
  setActiveTab: (tab: TabId) => void;
  validationCount: { pass: number; warning: number; fail: number };
}

export const SidebarNavigation: React.FC<SidebarNavigationProps> = ({
  activeTab,
  setActiveTab,
  validationCount,
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  // Tab identity, labels and order live in constants/tabs.ts — the single source of
  // truth. Only the validation badge is computed here, since it depends on live state.
  const tabs = orderedTabs().map((t) => ({
    ...t,
    badge:
      t.id !== 'validations'
        ? null
        : validationCount.fail > 0
          ? `${validationCount.fail} Error`
          : validationCount.warning > 0
            ? `${validationCount.warning} Warn`
            : `${validationCount.pass} Pass`,
    badgeColor:
      t.id !== 'validations'
        ? undefined
        : validationCount.fail > 0
          ? 'bg-red-200 text-red-900 border border-red-300'
          : validationCount.warning > 0
            ? 'bg-amber-100 text-amber-800 border border-amber-300'
            : 'bg-emerald-100 text-emerald-800 border border-emerald-300',
  }));

  return (
    <aside className={`flex-shrink-0 bg-[#ececec] border-r border-neutral-300 h-full overflow-y-auto flex flex-col justify-between select-none transition-all duration-200 ${
      isCollapsed ? 'w-14 sm:w-16' : 'w-56 lg:w-64'
    }`}>
      <div className="py-3">
        {/* Navigation Rail Header with Collapse/Expand Toggle */}
        <div className={`px-3 pb-3 mb-2 border-b border-neutral-200 flex items-center ${isCollapsed ? 'justify-center' : 'justify-between'}`}>
          {!isCollapsed && (
            <span className="text-[11px] font-mono uppercase tracking-wider font-bold text-neutral-500 truncate">
              Navigation Rail
            </span>
          )}
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            title={isCollapsed ? "Expand sidebar (Full labels)" : "Collapse sidebar (Icon rail for max table width)"}
            className="p-1 text-neutral-500 hover:text-neutral-900 hover:bg-neutral-200 rounded transition-colors"
          >
            {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        <nav className="space-y-0.5 px-1.5">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                title={tab.label}
                className={`w-full flex items-center px-2.5 py-2.5 text-left text-xs font-medium transition-colors relative rounded-sm ${
                  isCollapsed ? 'justify-center' : 'justify-between'
                } ${
                  isActive
                    ? 'bg-[#f8eeeb] text-[#9e2a1b] font-bold border-l-4 border-[#b92d1d] shadow-2xs'
                    : 'text-neutral-700 hover:text-neutral-900 hover:bg-neutral-200/70 border-l-4 border-transparent'
                }`}
              >
                <div className={`flex items-center ${isCollapsed ? '' : 'space-x-3'} min-w-0`}>
                  <Icon className={`w-4 h-4 flex-shrink-0 ${isActive ? 'text-[#b92d1d]' : 'text-neutral-500'}`} />
                  {!isCollapsed && <span className="truncate">{tab.label}</span>}
                </div>

                {!isCollapsed && tab.badge && (
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ml-1 ${tab.badgeColor}`}>
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Footer info in rail */}
      <div className={`p-3 border-t border-neutral-200 text-[11px] text-neutral-500 font-mono ${isCollapsed ? 'text-center' : ''}`}>
        {!isCollapsed ? (
          <>
            <div className="flex items-center justify-between">
              <span>Engine Status</span>
              <span className="inline-flex items-center space-x-1 text-emerald-700 font-semibold">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Active</span>
              </span>
            </div>
            <div className="mt-1 text-[10px] text-neutral-400">
              v2.4 Unified Tax & Cash Flow
            </div>
          </>
        ) : (
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse" title="Engine Active" />
        )}
      </div>
    </aside>
  );
};
