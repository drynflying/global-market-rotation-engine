import React, { useMemo, useState } from 'react';
import { Plan } from '../types';
import { getSimulation } from '../domain/simulation/simulationCache';
import { LayoutDashboard, TrendingUp, ShieldAlert, Info } from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
} from 'recharts';

interface DashboardStepProps {
  plan: Plan;
}

export const DashboardStep: React.FC<DashboardStepProps> = ({ plan }) => {
  const [displayMode, setDisplayMode] = useState<'nominal' | 'real'>('nominal');

  const simulation = useMemo(() => {
    return getSimulation(plan);
  }, [plan]);

  const primaryAge = plan.primaryPerson.currentAge;
  const macroInflation = plan.macroAssumptions?.generalInflation ?? 2.5;

  const chartData = useMemo(() => {
    return simulation.rows.map((row) => {
      const yearsFromStart = row.age - primaryAge;
      const deflator = Math.pow(1 + macroInflation / 100, yearsFromStart);
      const calendarYear = row.calendarYear;

      const isReal = displayMode === 'real' && deflator > 0;
      const preTax = isReal ? Math.round(row.preTaxBal / deflator) : row.preTaxBal;
      const postTax = isReal ? Math.round(row.postTaxBal / deflator) : row.postTaxBal;
      const taxable = isReal ? Math.round(row.taxableBal / deflator) : row.taxableBal;
      const total = isReal ? Math.round(row.totalPortfolio / deflator) : row.totalPortfolio;

      return {
        calendarYear,
        age: row.age,
        yearAge: `'${calendarYear.toString().slice(-2)} (Age ${row.age})`,
        isRetired: row.isRetired,
        phase: row.isRetired ? 'Retired' : 'Working',
        preTax,
        postTax,
        taxable,
        totalPortfolio: total,
        solvencyStatus: row.solvencyStatus,
        annotation: row.annotation,
      };
    });
  }, [simulation.rows, displayMode, primaryAge, macroInflation]);

  const retirementAge = plan.primaryPerson.retirementAge;
  const depletionAge = simulation.depletionAge;

  const maxY = useMemo(() => {
    const max = Math.max(...chartData.map(d => d.totalPortfolio), 0);
    return Math.max(200000, Math.ceil(max / 200000) * 200000);
  }, [chartData]);

  const yTicks = useMemo(() => {
    const ticks = [];
    for (let val = 0; val <= maxY; val += 200000) {
      ticks.push(val);
    }
    return ticks;
  }, [maxY]);

  // Custom Currency Formatter for Axis & Tooltips
  const formatCurrency = (val: number) => {
    if (val >= 1_000_000) {
      return `$${(val / 1_000_000).toFixed(1)}M`;
    }
    if (val >= 1_000) {
      return `$${(val / 1_000).toFixed(0)}k`;
    }
    return `$${val}`;
  };

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-neutral-900 text-white p-3 rounded shadow-lg border border-neutral-700 text-xs font-mono space-y-1.5 min-w-52">
          <div className="flex items-center justify-between border-b border-neutral-700 pb-1 font-bold text-neutral-200">
            <span>{data.calendarYear} (Age {data.age})</span>
            <span className={`px-1.5 py-0.5 text-[9px] rounded uppercase font-sans ${data.isRetired ? 'bg-emerald-800 text-emerald-100' : 'bg-slate-700 text-slate-200'}`}>
              {data.phase}
            </span>
          </div>

          <div className="pt-1 space-y-1 text-neutral-300">
            <div className="flex justify-between items-center text-sm font-bold text-white pt-0.5 border-b border-neutral-800 pb-1">
              <span>Total Portfolio:</span>
              <span className="text-emerald-400">${data.totalPortfolio.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="flex items-center space-x-1.5">
                <span className="w-2 h-2 rounded-full bg-[#1e40af]" />
                <span>Pre-Tax (401k/IRA):</span>
              </span>
              <span className="font-semibold">${data.preTax.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="flex items-center space-x-1.5">
                <span className="w-2 h-2 rounded-full bg-[#7e22ce]" />
                <span>Roth / Post-Tax:</span>
              </span>
              <span className="font-semibold">${data.postTax.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="flex items-center space-x-1.5">
                <span className="w-2 h-2 rounded-full bg-[#0284c7]" />
                <span>Taxable / Cash:</span>
              </span>
              <span className="font-semibold">${data.taxable.toLocaleString()}</span>
            </div>
          </div>

          {data.annotation && (
            <div className="mt-2 pt-1.5 border-t border-neutral-800 text-[10px] text-amber-300 font-sans italic">
              ✦ {data.annotation}
            </div>
          )}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="bg-white border border-neutral-300 rounded-md p-6 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-black text-neutral-900 tracking-tight flex items-center space-x-2">
              <LayoutDashboard className="w-5 h-5 text-[#b92d1d]" />
              <span>Portfolio Projection Chart</span>
            </h2>
          </div>

          {/* Controls Bar */}
          <div className="flex items-center space-x-3 flex-wrap gap-y-2">
            {/* Nominal vs Real Toggle */}
            <div className="inline-flex bg-neutral-100 p-1 rounded border border-neutral-200 text-xs font-semibold">
              <button
                onClick={() => setDisplayMode('nominal')}
                className={`px-3 py-1 rounded transition-colors ${displayMode === 'nominal' ? 'bg-[#b92d1d] text-white font-bold' : 'text-neutral-600 hover:text-neutral-900'}`}
              >
                Nominal $
              </button>
              <button
                onClick={() => setDisplayMode('real')}
                className={`px-3 py-1 rounded transition-colors ${displayMode === 'real' ? 'bg-[#b92d1d] text-white font-bold' : 'text-neutral-600 hover:text-neutral-900'}`}
              >
                Real Today's $
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Chart Container */}
      <div className="bg-white border border-neutral-300 rounded-md p-6 shadow-2xs">
        <div className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart
              data={chartData}
              margin={{ top: 20, right: 30, left: 15, bottom: 10 }}
            >
              <defs>
                <linearGradient id="colorPreTax" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#1e40af" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#1e40af" stopOpacity={0.2} />
                </linearGradient>
                <linearGradient id="colorPostTax" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#7e22ce" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#7e22ce" stopOpacity={0.2} />
                </linearGradient>
                <linearGradient id="colorTaxable" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0284c7" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#0284c7" stopOpacity={0.2} />
                </linearGradient>
              </defs>

              <CartesianGrid strokeDasharray="3 3" stroke="#e5e5e5" />
              <XAxis
                dataKey="age"
                stroke="#666"
                tick={{ fontSize: 11, fontFamily: 'monospace' }}
                tickFormatter={(age) => `${age}`}
                label={{ value: 'Age', position: 'insideBottom', offset: -5, fill: '#444', fontSize: 12, fontWeight: 'bold' }}
              />
              <YAxis
                stroke="#666"
                tick={{ fontSize: 11, fontFamily: 'monospace' }}
                tickFormatter={formatCurrency}
                ticks={yTicks}
                domain={[0, maxY]}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                verticalAlign="bottom"
                wrapperStyle={{ paddingTop: '8px', fontSize: '12px', fontFamily: 'sans-serif' }}
              />

              {/* Milestone Reference Line for Retirement */}
              <ReferenceLine
                x={retirementAge}
                stroke="#059669"
                strokeDasharray="4 4"
                label={{
                  value: `Retire (Age ${retirementAge})`,
                  position: 'top',
                  fill: '#059669',
                  fontSize: 11,
                  fontWeight: 'bold',
                }}
              />

              {/* Depletion Reference Line if applicable */}
              {depletionAge && (
                <ReferenceLine
                  x={depletionAge}
                  stroke="#dc2626"
                  strokeDasharray="3 3"
                  label={{
                    value: `Depleted (Age ${depletionAge})`,
                    position: 'top',
                    fill: '#dc2626',
                    fontSize: 11,
                    fontWeight: 'bold',
                  }}
                />
              )}

              <Area
                type="monotone"
                dataKey="taxable"
                name="Taxable / Cash"
                stackId="1"
                stroke="#0284c7"
                fill="url(#colorTaxable)"
              />
              <Area
                type="monotone"
                dataKey="postTax"
                name="Roth / Post-Tax"
                stackId="1"
                stroke="#7e22ce"
                fill="url(#colorPostTax)"
              />
              <Area
                type="monotone"
                dataKey="preTax"
                name="Pre-Tax (401k/IRA)"
                stackId="1"
                stroke="#1e40af"
                fill="url(#colorPreTax)"
              />
              <Line
                type="monotone"
                dataKey="totalPortfolio"
                name="Total Portfolio"
                stroke="none"
                legendType="none"
                dot={{ r: 2.25, fill: '#111827' }}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
