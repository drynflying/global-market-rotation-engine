import React, { useEffect, useState } from 'react';
import { Check, Cloud, CloudOff, RefreshCw } from 'lucide-react';
import { usePlanStore } from '../store/usePlanStore';

/**
 * Transient "saved" acknowledgement and cloud persistence status indicator.
 */
export const SaveIndicator: React.FC = () => {
  const lastSavedAt = usePlanStore((s) => s.lastSavedAt);
  const lastSavedLabel = usePlanStore((s) => s.lastSavedLabel);
  const syncStatus = usePlanStore((s) => s.syncStatus);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!lastSavedAt) return;
    setVisible(true);
    const timer = setTimeout(() => setVisible(false), 2000);
    return () => clearTimeout(timer);
  }, [lastSavedAt]);

  const renderStatusIcon = () => {
    if (syncStatus === 'syncing') {
      return <RefreshCw className="w-3 h-3 text-emerald-700 animate-spin" />;
    }
    if (syncStatus === 'synced') {
      return <Cloud className="w-3 h-3 text-emerald-700" />;
    }
    if (syncStatus === 'error') {
      return <CloudOff className="w-3 h-3 text-amber-700" />;
    }
    return <Check className="w-3 h-3 text-emerald-700" />;
  };

  const getLabelText = () => {
    if (lastSavedLabel === 'undo') return 'Undone';
    if (syncStatus === 'syncing') return 'Syncing...';
    if (syncStatus === 'pending') return 'Saved (Pending Cloud)';
    if (syncStatus === 'synced') return 'Saved & Synced';
    if (syncStatus === 'error') return 'Saved Offline';
    return 'Saved';
  };

  return (
    <span
      aria-live="polite"
      className={`hidden md:inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold
        ${syncStatus === 'error' ? 'bg-amber-100/80 text-amber-800 border border-amber-300' : 'bg-emerald-100/80 text-emerald-800 border border-emerald-300'}
        transition-opacity duration-500 ${visible || syncStatus === 'syncing' ? 'opacity-100' : 'opacity-0'}`}
    >
      {renderStatusIcon()}
      <span>{getLabelText()}</span>
    </span>
  );
};
