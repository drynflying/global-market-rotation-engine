import React, { useState } from 'react';
import { Plan } from '../types';
import { UpdateOptions } from '../store/usePlanStore';
import { getSimulation } from '../domain/simulation/simulationCache';
import { calculateAccountTotals } from '../domain/accounts/accountCapabilities';
import { resolveRetirementStrategy, getRothConversionPolicyLabel } from '../domain/strategy';
import { 
  FolderKanban, 
  Plus, 
  Copy, 
  Trash2, 
  CheckCircle2, 
  Edit2, 
  Download, 
  Upload, 
  TrendingUp, 
  ArrowRight,
  ShieldCheck,
  Check,
  X,
  FileText,
  User
} from 'lucide-react';

interface ScenarioManagerStepProps {
  plans: Plan[];
  activePlanId: string;
  onSelectPlan: (id: string) => void;
  onCreatePlan: (name: string, description?: string) => void;
  onDuplicatePlan: (plan: Plan, newName?: string) => void;
  onUpdatePlan: (plan: Plan, options?: UpdateOptions) => void;
  onDeletePlan: (id: string) => void;
  onImportPlan: (jsonStr: string) => boolean;
}

export const ScenarioManagerStep: React.FC<ScenarioManagerStepProps> = ({
  plans,
  activePlanId,
  onSelectPlan,
  onCreatePlan,
  onDuplicatePlan,
  onUpdatePlan,
  onDeletePlan,
  onImportPlan,
}) => {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newPlanName, setNewPlanName] = useState('');
  const [newPlanDesc, setNewPlanDesc] = useState('');
  
  const [editingPlanId, setEditingPlanId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');

  const [importError, setImportError] = useState<string | null>(null);

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlanName.trim()) return;
    onCreatePlan(newPlanName.trim(), newPlanDesc.trim());
    setNewPlanName('');
    setNewPlanDesc('');
    setShowCreateModal(false);
  };

  const startRename = (plan: Plan) => {
    setEditingPlanId(plan.id);
    setEditingTitle(plan.name);
  };

  const saveRename = (plan: Plan) => {
    if (editingTitle.trim()) {
      onUpdatePlan({
        ...plan,
        name: editingTitle.trim(),
        updatedAt: new Date().toISOString()
      });
    }
    setEditingPlanId(null);
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const ok = onImportPlan(text);
        if (!ok) {
          setImportError('Invalid scenario JSON file schema.');
        } else {
          setImportError(null);
        }
      } catch (err) {
        setImportError('Failed to parse scenario JSON file.');
      }
    };
    reader.readAsText(file);
  };

  const exportPlanJson = (plan: Plan) => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(plan, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `MERIDIAN_Scenario_${plan.name.replace(/[^a-zA-Z0-9]/g, '_')}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white border border-neutral-300 rounded-md p-5 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start space-x-3">
            <div className="w-10 h-10 rounded bg-[#f8eeeb] border border-[#e5bfb8] text-[#b92d1d] flex items-center justify-center flex-shrink-0 font-bold">
              <FolderKanban className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-lg font-bold text-neutral-900 tracking-tight">
                  Scenario Management & Strategy Workbench
                </h2>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-neutral-100 text-neutral-700 border border-neutral-300">
                  {plans.length} {plans.length === 1 ? 'Scenario' : 'Scenarios'}
                </span>
              </div>
              <p className="text-xs text-neutral-600 mt-0.5">
                Create, compare, and stress-test alternative planning strategies (e.g. Early Retirement, Aggressive Roth Conversions, Conservative Asset Allocation).
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <label className="inline-flex items-center space-x-1.5 px-3 py-1.5 text-xs font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 border border-neutral-300 rounded cursor-pointer transition-colors">
              <Upload className="w-3.5 h-3.5 text-neutral-600" />
              <span>Import Scenario</span>
              <input type="file" accept=".json" onChange={handleFileImport} className="hidden" />
            </label>

            <button
              onClick={() => setShowCreateModal(true)}
              className="inline-flex items-center space-x-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-[#b92d1d] hover:bg-[#9e2a1b] rounded shadow-2xs transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>New Scenario</span>
            </button>
          </div>
        </div>

        {importError && (
          <div className="mt-3 p-2 bg-red-50 border border-red-200 rounded text-xs text-red-700 font-medium">
            {importError}
          </div>
        )}
      </div>

      {/* Grid of Scenarios */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {plans.map((plan) => {
          const isActive = plan.id === activePlanId;
          const simResult = getSimulation(plan);
          const lastRow = simResult.rows[simResult.rows.length - 1];
          const endingNetWorth = lastRow ? lastRow.totalPortfolio : 0;
          const accTotals = calculateAccountTotals(plan.accounts, plan);

          return (
            <div
              key={plan.id}
              className={`bg-white rounded-md border transition-all flex flex-col justify-between relative ${
                isActive
                  ? 'border-[#b92d1d] ring-1 ring-[#b92d1d] shadow-xs'
                  : 'border-neutral-300 hover:border-neutral-400'
              }`}
            >
              {/* Active Badge Banner */}
              {isActive && (
                <div className="bg-[#b92d1d] text-white text-[10px] font-mono font-bold uppercase tracking-wider px-3 py-1 rounded-t-md flex items-center justify-between">
                  <span className="flex items-center space-x-1">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Active Working Scenario</span>
                  </span>
                  <span>Primary</span>
                </div>
              )}

              <div className="p-4 space-y-3">
                {/* Scenario Title Header */}
                <div className="flex items-start justify-between gap-2">
                  {editingPlanId === plan.id ? (
                    <div className="flex items-center space-x-1 flex-1">
                      <input
                        type="text"
                        value={editingTitle}
                        onChange={(e) => setEditingTitle(e.target.value)}
                        className="px-2 py-1 text-xs font-bold border border-neutral-300 rounded w-full focus:outline-none focus:ring-1 focus:ring-[#b92d1d]"
                        autoFocus
                      />
                      <button
                        onClick={() => saveRename(plan)}
                        className="p-1 text-emerald-700 hover:bg-emerald-50 rounded"
                      >
                        <Check className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setEditingPlanId(null)}
                        className="p-1 text-neutral-500 hover:bg-neutral-100 rounded"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2 flex-1 min-w-0">
                      <h3 className="text-sm font-bold text-neutral-900 truncate">
                        {plan.name}
                      </h3>
                      <button
                        onClick={() => startRename(plan)}
                        title="Rename scenario"
                        className="p-1 text-neutral-400 hover:text-neutral-700 rounded transition-colors"
                      >
                        <Edit2 className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>

                {/* Updated timestamp & User Owner */}
                <div className="flex items-center justify-between text-[10px] font-mono text-neutral-500">
                  <span>Last edited: {new Date(plan.updatedAt || Date.now()).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                  <span className="flex items-center space-x-1 bg-neutral-100 border border-neutral-200 px-1.5 py-0.5 rounded text-neutral-700 font-sans font-semibold">
                    <User className="w-2.5 h-2.5 text-neutral-500" />
                    <span>{plan.userDisplayName || 'Profile'}</span>
                  </span>
                </div>

                {/* Key Metrics Summary */}
                <div className="grid grid-cols-2 gap-2 text-xs bg-neutral-50 p-2.5 rounded border border-neutral-200">
                  <div>
                    <span className="text-[10px] font-mono uppercase text-neutral-500 block">Retirement Age</span>
                    <span className="font-bold text-neutral-800">
                      Primary {plan.primaryPerson.retirementAge}
                      {plan.hasSpouse && plan.spousePerson ? ` / Spouse ${plan.spousePerson.retirementAge}` : ''}
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] font-mono uppercase text-neutral-500 block">Modeled Capital</span>
                    <span className="font-bold text-neutral-800">
                      ${Math.round(accTotals.modeledPortfolioBalance / 1000).toLocaleString()}K
                    </span>
                    {accTotals.hasUnmodeledAssets && (
                      <span className="block text-[9px] font-mono text-amber-700">
                        (+${Math.round(accTotals.recordedNotModeledBalance / 1000).toLocaleString()}K rec)
                      </span>
                    )}
                  </div>

                  <div>
                    <span className="text-[10px] font-mono uppercase text-neutral-500 block">Roth Conversion Policy</span>
                    <span className="font-bold text-[#b92d1d]">
                      {getRothConversionPolicyLabel(resolveRetirementStrategy(plan).rothConversion)}
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] font-mono uppercase text-neutral-500 block">Projected Net Worth (Age 92)</span>
                    <span className="font-bold text-emerald-700">
                      ${(endingNetWorth / 1000000).toFixed(2)}M
                    </span>
                  </div>
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="p-3 bg-neutral-50/80 border-t border-neutral-200 rounded-b-md flex items-center justify-between">
                <div>
                  {!isActive ? (
                    <button
                      onClick={() => onSelectPlan(plan.id)}
                      className="inline-flex items-center space-x-1 px-3 py-1 text-xs font-bold text-neutral-800 bg-white hover:bg-neutral-100 border border-neutral-300 rounded shadow-2xs transition-colors"
                    >
                      <span>Activate</span>
                      <ArrowRight className="w-3 h-3 text-[#b92d1d]" />
                    </button>
                  ) : (
                    <span className="text-[11px] font-mono font-bold text-emerald-700 flex items-center space-x-1">
                      <Check className="w-3.5 h-3.5" />
                      <span>Loaded</span>
                    </span>
                  )}
                </div>

                <div className="flex items-center space-x-1">
                  <button
                    onClick={() => onDuplicatePlan(plan)}
                    title="Clone scenario"
                    className="p-1.5 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-200/60 rounded transition-colors"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => exportPlanJson(plan)}
                    title="Export JSON"
                    className="p-1.5 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-200/60 rounded transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>

                  {plans.length > 1 && (
                    <button
                      onClick={() => onDeletePlan(plan.id)}
                      title="Delete scenario"
                      className="p-1.5 text-red-600 hover:bg-red-100/60 rounded transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Side-by-Side Comparison Matrix */}
      <div className="bg-white border border-neutral-300 rounded-md p-5 shadow-2xs">
        <div className="flex items-center justify-between mb-4 border-b border-neutral-200 pb-3">
          <div>
            <h3 className="text-sm font-bold text-neutral-900 uppercase tracking-wider font-mono">
              Scenario Comparison Matrix
            </h3>
            <p className="text-xs text-neutral-500">
              Comparative view across key planning levers, tax strategies, and projected cash flow outcomes.
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-sans">
            <thead>
              <tr className="border-b border-neutral-300 bg-neutral-100 font-mono text-[11px] text-neutral-600 uppercase">
                <th className="py-2.5 px-3">Metric / Lever</th>
                {plans.map(p => (
                  <th key={p.id} className={`py-2.5 px-3 ${p.id === activePlanId ? 'bg-[#f8eeeb] text-[#9e2a1b] font-bold border-l-2 border-[#b92d1d]' : ''}`}>
                    <div className="flex items-center space-x-1">
                      <span>{p.name}</span>
                      {p.id === activePlanId && <span className="text-[9px] bg-[#b92d1d] text-white px-1 rounded">Active</span>}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200 text-neutral-800">
              <tr>
                <td className="py-2 px-3 font-semibold text-neutral-600 bg-neutral-50">Primary Retirement Age</td>
                {plans.map(p => (
                  <td key={p.id} className={`py-2 px-3 font-mono ${p.id === activePlanId ? 'bg-[#f8eeeb]/40 font-bold' : ''}`}>
                    {p.primaryPerson.retirementAge} yrs
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-2 px-3 font-semibold text-neutral-600 bg-neutral-50">Primary SS Claim Age</td>
                {plans.map(p => (
                  <td key={p.id} className={`py-2 px-3 font-mono ${p.id === activePlanId ? 'bg-[#f8eeeb]/40 font-bold' : ''}`}>
                    {p.primaryPerson.ssClaimAge} yrs
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-2 px-3 font-semibold text-neutral-600 bg-neutral-50">Modeled Retirement Capital</td>
                {plans.map(p => {
                  const totals = calculateAccountTotals(p.accounts, p);
                  return (
                    <td key={p.id} className={`py-2 px-3 font-mono ${p.id === activePlanId ? 'bg-[#f8eeeb]/40 font-bold' : ''}`}>
                      ${Math.round(totals.modeledPortfolioBalance).toLocaleString()}
                    </td>
                  );
                })}
              </tr>
              {plans.some(p => calculateAccountTotals(p.accounts, p).hasUnmodeledAssets) && (
                <>
                  <tr>
                    <td className="py-2 px-3 font-semibold text-amber-800 bg-amber-50/50">Recorded Non-Modeled Assets</td>
                    {plans.map(p => {
                      const totals = calculateAccountTotals(p.accounts, p);
                      return (
                        <td key={p.id} className={`py-2 px-3 font-mono text-amber-900 ${p.id === activePlanId ? 'bg-[#f8eeeb]/40 font-bold' : ''}`}>
                          ${Math.round(totals.recordedNotModeledBalance).toLocaleString()}
                        </td>
                      );
                    })}
                  </tr>
                  <tr>
                    <td className="py-2 px-3 font-semibold text-neutral-600 bg-neutral-50">Total Recorded Net Worth</td>
                    {plans.map(p => {
                      const totals = calculateAccountTotals(p.accounts, p);
                      return (
                        <td key={p.id} className={`py-2 px-3 font-mono ${p.id === activePlanId ? 'bg-[#f8eeeb]/40 font-bold' : ''}`}>
                          ${Math.round(totals.totalRecordedBalance).toLocaleString()}
                        </td>
                      );
                    })}
                  </tr>
                </>
              )}
              <tr>
                <td className="py-2 px-3 font-semibold text-neutral-600 bg-neutral-50">Desired Annual Living Expenses</td>
                {plans.map(p => (
                  <td key={p.id} className={`py-2 px-3 font-mono ${p.id === activePlanId ? 'bg-[#f8eeeb]/40 font-bold' : ''}`}>
                    ${Math.round(p.spendingAssumptions?.desiredAnnualLivingExpenses || 0).toLocaleString()}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-2 px-3 font-semibold text-neutral-600 bg-neutral-50">Roth Conversion Strategy</td>
                {plans.map(p => (
                  <td key={p.id} className={`py-2 px-3 font-mono text-[#b92d1d] ${p.id === activePlanId ? 'bg-[#f8eeeb]/40 font-bold' : ''}`}>
                    {getRothConversionPolicyLabel(resolveRetirementStrategy(p).rothConversion)}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-2 px-3 font-semibold text-neutral-600 bg-neutral-50">Projected Ending Portfolio (Age 92)</td>
                {plans.map(p => {
                  const sim = getSimulation(p);
                  const lastRow = sim.rows[sim.rows.length - 1];
                  const endNw = lastRow ? lastRow.totalPortfolio : 0;
                  return (
                    <td key={p.id} className={`py-2 px-3 font-mono font-bold text-emerald-700 ${p.id === activePlanId ? 'bg-[#f8eeeb]/40' : ''}`}>
                      ${Math.round(endNw).toLocaleString()}
                    </td>
                  );
                })}
              </tr>
              <tr>
                <td className="py-2 px-3 font-semibold text-neutral-600 bg-neutral-50">Lifetime Roth Conversion Tax Paid (Nominal)</td>
                {plans.map(p => {
                  const sim = getSimulation(p);
                  return (
                    <td key={p.id} className={`py-2 px-3 font-mono ${p.id === activePlanId ? 'bg-[#f8eeeb]/40 font-bold' : ''}`}>
                      ${Math.round(sim.lifetimeConversionTaxPaidNominal).toLocaleString()}
                    </td>
                  );
                })}
              </tr>
              <tr>
                <td className="py-2 px-3 font-semibold text-neutral-600 bg-neutral-50">Lifetime Total Tax Liability (Nominal)</td>
                {plans.map(p => {
                  const sim = getSimulation(p);
                  return (
                    <td key={p.id} className={`py-2 px-3 font-mono ${p.id === activePlanId ? 'bg-[#f8eeeb]/40 font-bold' : ''}`}>
                      ${Math.round(sim.lifetimeTotalTaxNominal).toLocaleString()}
                    </td>
                  );
                })}
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Create New Scenario Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-neutral-900/40 backdrop-blur-2xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-md shadow-xl max-w-md w-full p-6 border border-neutral-300">
            <h3 className="text-base font-bold text-neutral-900 mb-1">Create New Scenario</h3>
            <p className="text-xs text-neutral-500 mb-4">
              Enter a descriptive title for your alternative financial planning scenario.
            </p>
            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">Scenario Title</label>
                <input
                  type="text"
                  value={newPlanName}
                  onChange={(e) => setNewPlanName(e.target.value)}
                  placeholder="e.g. Early Retirement at 58, Conservative Growth"
                  className="w-full px-3 py-2 border border-neutral-300 rounded text-xs focus:outline-none focus:ring-1 focus:ring-[#b92d1d]"
                  autoFocus
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">Description (Optional)</label>
                <textarea
                  value={newPlanDesc}
                  onChange={(e) => setNewPlanDesc(e.target.value)}
                  placeholder="Notes on levers or assumptions tested..."
                  className="w-full px-3 py-2 border border-neutral-300 rounded text-xs focus:outline-none focus:ring-1 focus:ring-[#b92d1d] h-20"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-neutral-200">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 text-xs font-medium text-neutral-600 hover:bg-neutral-100 rounded"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-[#b92d1d] hover:bg-[#9e2a1b] rounded shadow-2xs"
                >
                  Create Scenario
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
