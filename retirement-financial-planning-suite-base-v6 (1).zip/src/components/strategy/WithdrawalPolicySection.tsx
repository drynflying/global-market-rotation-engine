import React from 'react';
import { WithdrawalPolicyId, WITHDRAWAL_POLICIES } from '../../domain/strategy/strategyTypes';
import { Layers, ArrowRight } from 'lucide-react';

interface WithdrawalPolicySectionProps {
  currentPolicyId: WithdrawalPolicyId;
  onUpdateWithdrawalPolicy: (policyId: WithdrawalPolicyId) => void;
}

export const WithdrawalPolicySection: React.FC<WithdrawalPolicySectionProps> = ({
  currentPolicyId,
  onUpdateWithdrawalPolicy,
}) => {
  return (
    <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs space-y-4">
      <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
        <div>
          <h2 className="text-sm font-bold text-neutral-900 flex items-center gap-2">
            <Layers className="w-4 h-4 text-indigo-600" />
            1. Portfolio Withdrawal Sequence Policy
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Determines the account drawdown order when living expenses exceed guaranteed income.
          </p>
        </div>
        <span className="text-xs font-semibold px-2.5 py-1 bg-indigo-50 text-indigo-700 rounded-full border border-indigo-200">
          Order Control
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {(Object.keys(WITHDRAWAL_POLICIES) as WithdrawalPolicyId[]).map((policyKey) => {
          const policy = WITHDRAWAL_POLICIES[policyKey];
          const isSelected = currentPolicyId === policyKey;

          return (
            <button
              key={policyKey}
              type="button"
              onClick={() => onUpdateWithdrawalPolicy(policyKey)}
              className={`p-4 rounded-xl border text-left transition-all flex flex-col justify-between cursor-pointer ${
                isSelected
                  ? 'bg-indigo-50/80 border-indigo-300 ring-2 ring-indigo-500/20 text-indigo-950 shadow-xs'
                  : 'bg-neutral-50 border-neutral-200 text-neutral-700 hover:bg-neutral-100'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-bold text-xs">{policy.name}</span>
                  {isSelected && (
                    <span className="text-[10px] bg-indigo-600 text-white font-bold px-2 py-0.5 rounded">
                      Active
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-neutral-500 leading-snug mb-3">
                  {policy.description}
                </p>
              </div>

              <div className="pt-2 border-t border-neutral-200/60 flex flex-wrap items-center gap-1">
                {policy.order.map((acct, idx) => (
                  <React.Fragment key={acct}>
                    <span
                      className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                        isSelected
                          ? 'bg-indigo-100 text-indigo-900 border border-indigo-200'
                          : 'bg-neutral-200/70 text-neutral-700'
                      }`}
                    >
                      {acct === 'cash'
                        ? 'Cash'
                        : acct === 'taxable_brokerage'
                        ? 'Taxable'
                        : acct === 'pre_tax'
                        ? 'Pre-Tax'
                        : 'Roth'}
                    </span>
                    {idx < policy.order.length - 1 && (
                      <ArrowRight className="w-2.5 h-2.5 text-neutral-400 shrink-0" />
                    )}
                  </React.Fragment>
                ))}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
