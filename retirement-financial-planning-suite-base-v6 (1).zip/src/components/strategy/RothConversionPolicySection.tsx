import React from 'react';
import { ConversionStrategyType } from '../../domain/strategy/strategyTypes';
import { NumericInput } from '../NumericInput';
import { Zap, AlertCircle } from 'lucide-react';

interface RothConversionPolicySectionProps {
  currentConversionType: ConversionStrategyType;
  annualTarget: number;
  startAge: number;
  endAge: number;
  onUpdateConversionStrategy: (strategyType: ConversionStrategyType) => void;
  onUpdateAnnualTarget: (target: number) => void;
  onUpdateStartAge: (startAge: number) => void;
  onUpdateEndAge: (endAge: number) => void;
}

export const RothConversionPolicySection: React.FC<RothConversionPolicySectionProps> = ({
  currentConversionType,
  annualTarget,
  startAge,
  endAge,
  onUpdateConversionStrategy,
  onUpdateAnnualTarget,
  onUpdateStartAge,
  onUpdateEndAge,
}) => {
  const isBracketFill = currentConversionType.startsWith('fill_');

  return (
    <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs space-y-4">
      <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
        <div>
          <h2 className="text-sm font-bold text-neutral-900 flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-500" />
            2. Roth Conversion Strategy & Bracket Fill Policy
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Configure whether conversions execute via fixed manual targets or dynamic federal bracket-filling solvers.
          </p>
        </div>
        <span className="text-xs font-semibold px-2.5 py-1 bg-amber-50 text-amber-800 rounded-full border border-amber-200">
          Decision Engine
        </span>
      </div>

      {/* Strategy Selection Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Manual Target */}
        <button
          type="button"
          onClick={() => onUpdateConversionStrategy('manual')}
          className={`p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between cursor-pointer ${
            currentConversionType === 'manual'
              ? 'bg-amber-50/80 border-amber-300 ring-2 ring-amber-500/20 text-amber-950 shadow-xs'
              : 'bg-neutral-50 border-neutral-200 text-neutral-700 hover:bg-neutral-100'
          }`}
        >
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-xs">Manual Dollar Target</span>
              {currentConversionType === 'manual' && (
                <span className="text-[10px] bg-amber-600 text-white font-bold px-1.5 py-0.5 rounded">
                  Active
                </span>
              )}
            </div>
            <p className="text-[11px] text-neutral-500 leading-snug">
              Fixed annual conversion amount executed every year within the conversion window.
            </p>
          </div>
        </button>

        {/* Fill 12% Bracket */}
        <button
          type="button"
          onClick={() => onUpdateConversionStrategy('fill_12')}
          className={`p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between cursor-pointer ${
            currentConversionType === 'fill_12'
              ? 'bg-amber-50/80 border-amber-300 ring-2 ring-amber-500/20 text-amber-950 shadow-xs'
              : 'bg-neutral-50 border-neutral-200 text-neutral-700 hover:bg-neutral-100'
          }`}
        >
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-xs">Fill 12% Bracket</span>
              {currentConversionType === 'fill_12' && (
                <span className="text-[10px] bg-amber-600 text-white font-bold px-1.5 py-0.5 rounded">
                  Active
                </span>
              )}
            </div>
            <p className="text-[11px] text-neutral-500 leading-snug">
              Dynamically fills taxable ordinary income up to the top of the 12% federal marginal bracket.
            </p>
          </div>
        </button>

        {/* Fill 22% Bracket */}
        <button
          type="button"
          onClick={() => onUpdateConversionStrategy('fill_22')}
          className={`p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between cursor-pointer ${
            currentConversionType === 'fill_22'
              ? 'bg-amber-50/80 border-amber-300 ring-2 ring-amber-500/20 text-amber-950 shadow-xs'
              : 'bg-neutral-50 border-neutral-200 text-neutral-700 hover:bg-neutral-100'
          }`}
        >
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-xs">Fill 22% Bracket</span>
              {currentConversionType === 'fill_22' && (
                <span className="text-[10px] bg-amber-600 text-white font-bold px-1.5 py-0.5 rounded">
                  Active
                </span>
              )}
            </div>
            <p className="text-[11px] text-neutral-500 leading-snug">
              Dynamically fills taxable ordinary income up to the top of the 22% federal marginal bracket.
            </p>
          </div>
        </button>

        {/* Fill 24% Bracket */}
        <button
          type="button"
          onClick={() => onUpdateConversionStrategy('fill_24')}
          className={`p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between cursor-pointer ${
            currentConversionType === 'fill_24'
              ? 'bg-amber-50/80 border-amber-300 ring-2 ring-amber-500/20 text-amber-950 shadow-xs'
              : 'bg-neutral-50 border-neutral-200 text-neutral-700 hover:bg-neutral-100'
          }`}
        >
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-xs">Fill 24% Bracket</span>
              {currentConversionType === 'fill_24' && (
                <span className="text-[10px] bg-amber-600 text-white font-bold px-1.5 py-0.5 rounded">
                  Active
                </span>
              )}
            </div>
            <p className="text-[11px] text-neutral-500 leading-snug">
              Dynamically fills taxable ordinary income up to the top of the 24% federal marginal bracket.
            </p>
          </div>
        </button>
      </div>

      {/* Target Parameters Panel */}
      <div className="p-4 bg-neutral-50 rounded-xl border border-neutral-200 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Conversion Window Start Age */}
          <div>
            <label className="text-xs font-bold text-neutral-700 block mb-1">
              Conversion Window Start Age
            </label>
            <NumericInput
              value={startAge}
              min={50}
              max={95}
              fallbackOnBlur={60}
              onChange={onUpdateStartAge}
              className="w-full px-3 py-1.5 text-xs font-semibold bg-white border border-neutral-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
            />
          </div>

          {/* Conversion Window End Age */}
          <div>
            <label className="text-xs font-bold text-neutral-700 block mb-1">
              Conversion Window End Age
            </label>
            <NumericInput
              value={endAge}
              min={50}
              max={95}
              fallbackOnBlur={70}
              onChange={onUpdateEndAge}
              className="w-full px-3 py-1.5 text-xs font-semibold bg-white border border-neutral-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
            />
          </div>

          {/* Annual Target or Bracket Note */}
          <div>
            {currentConversionType === 'manual' ? (
              <div>
                <label className="text-xs font-bold text-neutral-700 block mb-1">
                  Annual Conversion Target ($/yr)
                </label>
                <NumericInput
                  value={annualTarget}
                  onChange={onUpdateAnnualTarget}
                  step={5000}
                  min={0}
                  prefix="$"
                  className="w-full px-3 py-1.5 text-xs font-bold text-amber-900 bg-white border border-amber-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
                />
              </div>
            ) : (
              <div>
                <label className="text-xs font-bold text-neutral-700 block mb-1">
                  Annual Conversion Target
                </label>
                <div className="px-3 py-1.5 bg-amber-100/60 border border-amber-300/80 rounded-lg text-xs font-bold text-amber-950 flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                  <span>Calculated each year from tax context</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {isBracketFill && (
          <p className="text-xs text-amber-900 bg-amber-50/80 p-2.5 rounded-lg border border-amber-200/80">
            <strong>Bracket-Fill Policy Notice:</strong> When bracket-fill strategy is active (
            {currentConversionType === 'fill_12'
              ? '12%'
              : currentConversionType === 'fill_22'
              ? '22%'
              : '24%'}
            ), the engine calculates exact headroom between current taxable ordinary income and the top of the selected tax bracket in each year. Manual dollar targets are bypassed during bracket filling.
          </p>
        )}
      </div>
    </div>
  );
};
