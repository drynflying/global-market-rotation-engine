import React from 'react';
import { Plan } from '../../types';
import { resolveRetirementStrategy } from '../../domain/strategy';
import { Info, AlertTriangle, ShieldCheck } from 'lucide-react';

interface StrategyTradeoffSummaryProps {
  plan: Plan;
}

export const StrategyTradeoffSummary: React.FC<StrategyTradeoffSummaryProps> = ({
  plan,
}) => {
  const activeStrategy = resolveRetirementStrategy(plan);
  const conversionType = activeStrategy.rothConversion.type;
  const taxSource = activeStrategy.taxPayment.conversionTaxSource;

  return (
    <div className="bg-neutral-900 text-neutral-100 p-5 rounded-xl border border-neutral-800 space-y-3">
      <div className="flex items-center gap-2 border-b border-neutral-800 pb-2">
        <Info className="w-4 h-4 text-indigo-400" />
        <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-300">
          Strategy Tradeoffs & Structural Insight
        </h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs leading-relaxed text-neutral-300">
        <div className="space-y-1.5">
          <div className="font-bold text-white flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            Conversion Window Strategy
          </div>
          <p>
            {conversionType === 'none'
              ? 'Zero Roth conversions are planned. Pre-tax balances will compound tax-deferred until mandatory RMDs begin at age 73/75.'
              : conversionType === 'manual'
              ? `A manual annual target of $${activeStrategy.rothConversion.annualTarget.toLocaleString()}/yr executes between ages ${activeStrategy.rothConversion.startAge} and ${activeStrategy.rothConversion.endAge}.`
              : `A bracket-filling solver dynamically computes conversions between ages ${activeStrategy.rothConversion.startAge} and ${activeStrategy.rothConversion.endAge} to fill up to the top of the ${
                  activeStrategy.rothConversion.bracket * 100
                }% federal bracket.`}
          </p>
        </div>

        <div className="space-y-1.5">
          <div className="font-bold text-white flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            Tax Liability Funding Source
          </div>
          <p>
            {taxSource === 'taxable_brokerage'
              ? 'Taxes are paid out of non-retirement cash or brokerage assets, preserving 100% of converted assets inside the tax-free Roth wrapper.'
              : 'Taxes are withheld directly from converted funds, reducing the net capital entering the tax-free Roth wrapper. (Potential early-distribution tax penalties prior to age 59½ are not currently modeled).'}
          </p>
        </div>
      </div>
    </div>
  );
};
