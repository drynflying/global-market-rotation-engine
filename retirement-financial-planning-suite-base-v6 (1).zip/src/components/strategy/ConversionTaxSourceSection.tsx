import React from 'react';
import { ConversionTaxPaymentSource } from '../../domain/strategy/strategyTypes';
import { Wallet } from 'lucide-react';

interface ConversionTaxSourceSectionProps {
  currentTaxSource: ConversionTaxPaymentSource;
  onUpdateTaxSource: (source: ConversionTaxPaymentSource) => void;
}

export const ConversionTaxSourceSection: React.FC<ConversionTaxSourceSectionProps> = ({
  currentTaxSource,
  onUpdateTaxSource,
}) => {
  return (
    <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs space-y-4">
      <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
        <div>
          <h2 className="text-sm font-bold text-neutral-900 flex items-center gap-2">
            <Wallet className="w-4 h-4 text-indigo-600" />
            3. Conversion Tax Liability Payment Source
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Select whether tax liabilities from Roth conversions are paid from non-retirement taxable brokerage capital or deducted directly from converted funds.
          </p>
        </div>
        <span className="text-xs font-semibold px-2.5 py-1 bg-indigo-50 text-indigo-700 rounded-full border border-indigo-200">
          Tax Drag Factor
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Taxable Brokerage */}
        <button
          type="button"
          onClick={() => onUpdateTaxSource('taxable_brokerage')}
          className={`p-4 rounded-xl border text-left transition-all flex flex-col justify-between cursor-pointer ${
            currentTaxSource === 'taxable_brokerage'
              ? 'bg-indigo-50/80 border-indigo-300 ring-2 ring-indigo-500/20 text-indigo-950 shadow-xs'
              : 'bg-neutral-50 border-neutral-200 text-neutral-700 hover:bg-neutral-100'
          }`}
        >
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="font-bold text-xs">Outside Taxable Brokerage Assets</span>
              {currentTaxSource === 'taxable_brokerage' && (
                <span className="text-[10px] bg-indigo-600 text-white font-bold px-2 py-0.5 rounded">
                  Recommended
                </span>
              )}
            </div>
            <p className="text-[11px] text-neutral-500 leading-relaxed">
              Conversion taxes are paid out of non-retirement taxable brokerage or cash reserves. Preserves 100% of converted assets inside the tax-free Roth IRA wrapper to maximize compounding.
            </p>
          </div>
        </button>

        {/* Conversion Proceeds */}
        <button
          type="button"
          onClick={() => onUpdateTaxSource('conversion_proceeds')}
          className={`p-4 rounded-xl border text-left transition-all flex flex-col justify-between cursor-pointer ${
            currentTaxSource === 'conversion_proceeds'
              ? 'bg-amber-50/80 border-amber-300 ring-2 ring-amber-500/20 text-amber-950 shadow-xs'
              : 'bg-neutral-50 border-neutral-200 text-neutral-700 hover:bg-neutral-100'
          }`}
        >
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="font-bold text-xs">Withhold From Conversion Proceeds</span>
              {currentTaxSource === 'conversion_proceeds' && (
                <span className="text-[10px] bg-amber-600 text-white font-bold px-2 py-0.5 rounded">
                  Withholding Active
                </span>
              )}
            </div>
            <p className="text-[11px] text-neutral-500 leading-relaxed">
              Taxes are deducted directly from converted pre-tax IRA funds before transfer into Roth. Reduces net assets entering the tax-free Roth wrapper and lowers long-term tax-exempt compounding. (Note: Potential early-distribution penalties prior to age 59½ are outside the current model).
            </p>
          </div>
        </button>
      </div>
    </div>
  );
};
