import React from 'react';
import { Plan } from '../../types';
import { RetirementStrategy, WITHDRAWAL_POLICIES } from '../../domain/strategy/strategyTypes';
import { ArrowRight, CheckCircle2 } from 'lucide-react';

interface StrategySummaryProps {
  plan: Plan;
  activeStrategy: RetirementStrategy;
  displayFrame: 'nominal' | 'real';
  onToggleDisplayFrame: (frame: 'nominal' | 'real') => void;
}

export const StrategySummary: React.FC<StrategySummaryProps> = ({
  plan,
  activeStrategy,
  displayFrame,
  onToggleDisplayFrame,
}) => {
  const currentWithdrawalPolicy = activeStrategy.withdrawal.policyId;

  return (
    <div className="bg-gradient-to-r from-neutral-900 via-neutral-800 to-indigo-950 text-white p-5 rounded-xl shadow-md border border-neutral-800">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-4 mb-4">
        <div>
          <div className="text-[11px] uppercase tracking-wider text-indigo-300 font-bold mb-0.5">
            Resolved Strategy Contract — {plan.name}
          </div>
          <div className="text-base font-bold text-white flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            Active Policy Specification
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-neutral-300">Display Frame:</span>
          <div className="inline-flex p-0.5 bg-white/10 rounded-lg border border-white/15">
            <button
              type="button"
              onClick={() => onToggleDisplayFrame('nominal')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                displayFrame === 'nominal'
                  ? 'bg-white text-neutral-900 shadow-xs'
                  : 'text-neutral-300 hover:text-white'
              }`}
            >
              Nominal ($)
            </button>
            <button
              type="button"
              onClick={() => onToggleDisplayFrame('real')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                displayFrame === 'real'
                  ? 'bg-white text-neutral-900 shadow-xs'
                  : 'text-neutral-300 hover:text-white'
              }`}
            >
              Real (Today's $)
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        {/* Withdrawal Summary */}
        <div className="bg-white/5 p-3.5 rounded-lg border border-white/10">
          <div className="text-[10px] font-extrabold uppercase tracking-wider text-neutral-400 mb-1">
            Withdrawal Policy
          </div>
          <div className="font-bold text-sm text-white mb-1.5">
            {WITHDRAWAL_POLICIES[currentWithdrawalPolicy]?.name ?? 'Taxable First'}
          </div>
          <div className="flex flex-wrap items-center gap-1">
            {activeStrategy.withdrawal.order.map((acct, idx) => (
              <React.Fragment key={acct}>
                <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-200 border border-indigo-400/30 rounded text-[10px] font-semibold">
                  {acct === 'cash'
                    ? 'Cash'
                    : acct === 'taxable_brokerage'
                    ? 'Taxable'
                    : acct === 'pre_tax'
                    ? 'Pre-Tax'
                    : 'Roth'}
                </span>
                {idx < activeStrategy.withdrawal.order.length - 1 && (
                  <ArrowRight className="w-3 h-3 text-neutral-500 shrink-0" />
                )}
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* Roth Conversion Summary */}
        <div className="bg-white/5 p-3.5 rounded-lg border border-white/10">
          <div className="text-[10px] font-extrabold uppercase tracking-wider text-neutral-400 mb-1">
            Roth Conversion Strategy
          </div>
          <div className="font-bold text-sm text-white mb-1">
            {activeStrategy.rothConversion.type === 'manual'
              ? `Manual Target ($${activeStrategy.rothConversion.annualTarget.toLocaleString()}/yr)`
              : activeStrategy.rothConversion.type === 'none'
              ? 'No Conversions'
              : `Bracket Fill: Fill ${
                  activeStrategy.rothConversion.bracket * 100
                }% Federal Bracket`}
          </div>
          <div className="text-[11px] text-neutral-300">
            Window: Ages {activeStrategy.rothConversion.startAge}–{activeStrategy.rothConversion.endAge}
          </div>
        </div>

        {/* Tax Payment Source Summary */}
        <div className="bg-white/5 p-3.5 rounded-lg border border-white/10">
          <div className="text-[10px] font-extrabold uppercase tracking-wider text-neutral-400 mb-1">
            Conversion Tax Payment Source
          </div>
          <div className="font-bold text-sm text-white mb-1">
            {activeStrategy.taxPayment.conversionTaxSource === 'taxable_brokerage'
              ? 'Outside Taxable Brokerage Assets'
              : 'Withhold From Conversion Proceeds'}
          </div>
          <div className="text-[11px] text-neutral-300">
            {activeStrategy.taxPayment.conversionTaxSource === 'taxable_brokerage'
              ? 'Preserves 100% of converted funds in Roth'
              : 'Deducted directly from converted IRA funds'}
          </div>
        </div>
      </div>
    </div>
  );
};
