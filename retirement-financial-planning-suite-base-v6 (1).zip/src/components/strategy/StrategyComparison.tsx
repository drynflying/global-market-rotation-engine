import React from 'react';
import { Plan } from '../../types';
import { SimulationResult } from '../../domain/simulation/simulationTypes';
import { getSimulation } from '../../domain/simulation/simulationCache';
import {
  resolveRetirementStrategy,
  getRothConversionPolicyLabel,
  getWithdrawalPolicyLabel,
  getTaxPaymentSourceLabel,
} from '../../domain/strategy';
import { Scale, Sparkles, Layers, ArrowRight } from 'lucide-react';

interface StrategyComparisonProps {
  plan: Plan;
  currentSim: SimulationResult;
  otherPlans: Plan[];
  comparisonPlanId: string;
  onSelectComparisonPlanId: (planId: string) => void;
  displayFrame: 'nominal' | 'real';
}

export const StrategyComparison: React.FC<StrategyComparisonProps> = ({
  plan,
  currentSim,
  otherPlans,
  comparisonPlanId,
  onSelectComparisonPlanId,
  displayFrame,
}) => {
  // 1. Analytical Baseline: Same plan with zero Roth conversions
  const baselineSim = getSimulation(plan, {
    strategyOverride: { rothConversion: { type: 'none' } },
  });

  const activeStrategy = resolveRetirementStrategy(plan);

  // Active metrics
  const activeLifetimeConvTax =
    displayFrame === 'real'
      ? currentSim.lifetimeConversionTaxPaidReal
      : currentSim.lifetimeConversionTaxPaidNominal;
  const activeLifetimeRmdTax =
    displayFrame === 'real'
      ? currentSim.lifetimeRmdTaxesReal
      : currentSim.lifetimeRmdTaxesNominal;
  const activeLifetimeTotalTax =
    displayFrame === 'real'
      ? currentSim.lifetimeTotalTaxReal
      : currentSim.lifetimeTotalTaxNominal;

  // Baseline metrics
  const baselineLifetimeRmdTax =
    displayFrame === 'real'
      ? baselineSim.lifetimeRmdTaxesReal
      : baselineSim.lifetimeRmdTaxesNominal;
  const baselineLifetimeTotalTax =
    displayFrame === 'real'
      ? baselineSim.lifetimeTotalTaxReal
      : baselineSim.lifetimeTotalTaxNominal;

  // Lifetime tax savings: baseline total tax - active total tax
  const lifetimeTaxSavings = baselineLifetimeTotalTax - activeLifetimeTotalTax;

  const currentLastRow = currentSim.rows[currentSim.rows.length - 1];
  const baselineLastRow = baselineSim.rows[baselineSim.rows.length - 1];

  const currentEndNw = displayFrame === 'real' ? currentLastRow?.totalPortfolioReal ?? 0 : currentLastRow?.totalPortfolio ?? 0;
  const baselineEndNw = displayFrame === 'real' ? baselineLastRow?.totalPortfolioReal ?? 0 : baselineLastRow?.totalPortfolio ?? 0;

  // 2. Saved Scenario Comparison: Plan A vs Plan B
  const comparisonPlan = otherPlans.find((p) => p.id === comparisonPlanId) ?? (otherPlans.length > 0 ? otherPlans[0] : null);
  const comparisonSim = comparisonPlan ? getSimulation(comparisonPlan) : null;
  const comparisonStrategy = comparisonPlan ? resolveRetirementStrategy(comparisonPlan) : null;

  const compLastRow = comparisonSim?.rows[comparisonSim.rows.length - 1];
  const compEndNw = comparisonSim
    ? displayFrame === 'real'
      ? compLastRow?.totalPortfolioReal ?? 0
      : compLastRow?.totalPortfolio ?? 0
    : 0;

  const compLifetimeTotalTax = comparisonSim
    ? displayFrame === 'real'
      ? comparisonSim.lifetimeTotalTaxReal
      : comparisonSim.lifetimeTotalTaxNominal
    : 0;
  const compLifetimeConvTax = comparisonSim
    ? displayFrame === 'real'
      ? comparisonSim.lifetimeConversionTaxPaidReal
      : comparisonSim.lifetimeConversionTaxPaidNominal
    : 0;
  const compLifetimeRmdTax = comparisonSim
    ? displayFrame === 'real'
      ? comparisonSim.lifetimeRmdTaxesReal
      : comparisonSim.lifetimeRmdTaxesNominal
    : 0;

  const activeTotalConverted = currentSim.rows.reduce((sum, r) => sum + (r.rothConversion ?? 0), 0);
  const compTotalConverted = comparisonSim ? comparisonSim.rows.reduce((sum, r) => sum + (r.rothConversion ?? 0), 0) : 0;

  const nwDelta = compEndNw - currentEndNw;
  const taxDelta = compLifetimeTotalTax - activeLifetimeTotalTax;

  return (
    <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs space-y-8">
      {/* Header */}
      <div className="border-b border-neutral-200 pb-3">
        <h2 className="text-sm font-bold text-neutral-900 flex items-center gap-2">
          <Scale className="w-4 h-4 text-indigo-600" />
          5. Strategy Impact & Scenario Comparison
        </h2>
        <p className="text-xs text-neutral-500 mt-0.5">
          Evaluate active conversion strategy impact against an analytical baseline, and compare against other saved scenarios.
        </p>
      </div>

      {/* SECTION A: Strategy Impact (Active vs No-Conversion Baseline) */}
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-indigo-600" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-800">
            A. Strategy Impact: Active Strategy vs. Zero-Conversion Baseline
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Baseline Card */}
          <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-200 space-y-3">
            <div className="flex items-center justify-between border-b border-neutral-200 pb-2">
              <span className="font-bold text-neutral-800 text-xs">
                Analytical Baseline (No Conversions)
              </span>
              <span className="px-2 py-0.5 text-[10px] bg-neutral-200 text-neutral-700 font-bold rounded-full">
                Baseline
              </span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-neutral-600">Roth Conversion Policy:</span>
                <span className="font-bold text-neutral-900">No Conversions</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Conversion Taxes Paid:</span>
                <span className="font-bold text-emerald-700">$0</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Mandatory RMD Tax Drag:</span>
                <span className="font-bold text-rose-700">
                  ${Math.round(baselineLifetimeRmdTax).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between border-t border-neutral-200 pt-1.5">
                <span className="font-bold text-neutral-900">Total Lifetime Tax Paid:</span>
                <span className="font-bold text-neutral-900">
                  ${Math.round(baselineLifetimeTotalTax).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Ending Net Worth (Age {currentLastRow?.age ?? 90}):</span>
                <span className="font-extrabold text-neutral-900">
                  ${Math.round(baselineEndNw).toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          {/* Active Strategy Card */}
          <div className="bg-amber-50/50 p-4 rounded-xl border border-amber-200 space-y-3">
            <div className="flex items-center justify-between border-b border-amber-200 pb-2">
              <span className="font-bold text-amber-950 text-xs">
                Active Strategy ({plan.name})
              </span>
              <span className="px-2 py-0.5 text-[10px] bg-amber-200 text-amber-900 font-bold rounded-full">
                Active
              </span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-neutral-600">Roth Conversion Policy:</span>
                <span className="font-bold text-amber-950">
                  {getRothConversionPolicyLabel(activeStrategy.rothConversion)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Conversion Taxes Paid:</span>
                <span className="font-bold text-amber-900">
                  ${Math.round(activeLifetimeConvTax).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Mandatory RMD Tax Drag:</span>
                <span className="font-bold text-emerald-800">
                  ${Math.round(activeLifetimeRmdTax).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between border-t border-amber-200 pt-1.5">
                <span className="font-bold text-neutral-900">Total Lifetime Tax Paid:</span>
                <span className="font-bold text-neutral-900">
                  ${Math.round(activeLifetimeTotalTax).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Ending Net Worth (Age {currentLastRow?.age ?? 90}):</span>
                <span className="font-extrabold text-emerald-900">
                  ${Math.round(currentEndNw).toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Net Benefit Banner */}
        <div className="p-4 rounded-xl bg-indigo-50 border border-indigo-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <span className="text-xs font-extrabold uppercase tracking-wider text-indigo-950">
                Lifetime Tax Difference vs. No-Conversion Baseline
              </span>
            </div>
            <p className="text-xs text-neutral-600">
              {lifetimeTaxSavings >= 0
                ? `By paying ~$${Math.round(activeLifetimeConvTax).toLocaleString()} in Roth conversion taxes during gap years, mandatory RMD taxes are reduced, generating ~$${Math.round(lifetimeTaxSavings).toLocaleString()} in net lifetime tax savings.`
                : `Roth conversions increase upfront tax liabilities by more than they reduce future RMD taxes, resulting in ~$${Math.round(Math.abs(lifetimeTaxSavings)).toLocaleString()} higher net lifetime tax liability.`}
            </p>
          </div>

          <div className="bg-white px-4 py-2 rounded-xl border border-indigo-200 text-right shrink-0">
            <span className="text-[10px] font-bold text-neutral-500 uppercase block">
              Net Tax Difference
            </span>
            <span className={`text-lg font-extrabold ${lifetimeTaxSavings >= 0 ? 'text-indigo-900' : 'text-rose-700'}`}>
              {lifetimeTaxSavings >= 0
                ? `+$${Math.round(lifetimeTaxSavings).toLocaleString()}`
                : `-$${Math.round(Math.abs(lifetimeTaxSavings)).toLocaleString()}`}
            </span>
          </div>
        </div>
      </div>

      {/* SECTION B: Compare Saved Plan Scenarios */}
      {otherPlans.length > 0 && comparisonPlan && comparisonSim && comparisonStrategy ? (
        <div className="space-y-4 pt-4 border-t border-neutral-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-purple-600" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-800">
                B. Compare Saved Plan Scenarios
              </h3>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="text-xs font-semibold text-neutral-600">Compare With:</span>
              <select
                value={comparisonPlan.id}
                onChange={(e) => onSelectComparisonPlanId(e.target.value)}
                className="px-2.5 py-1 text-xs font-semibold bg-neutral-100 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-purple-500"
              >
                {otherPlans.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Plan A Card */}
            <div className="bg-white p-4 rounded-xl border border-neutral-200 space-y-3">
              <div className="flex items-center justify-between border-b border-neutral-200 pb-2">
                <span className="font-bold text-neutral-900 text-xs">
                  {plan.name} (Active)
                </span>
                <span className="px-2 py-0.5 text-[10px] bg-neutral-100 text-neutral-700 font-bold rounded-full">
                  Current
                </span>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-neutral-500">Withdrawal Policy:</span>
                  <span className="font-semibold text-neutral-900">
                    {getWithdrawalPolicyLabel(activeStrategy.withdrawal.policyId)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Roth Conversion Policy:</span>
                  <span className="font-semibold text-neutral-900">
                    {getRothConversionPolicyLabel(activeStrategy.rothConversion)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Tax Payment Source:</span>
                  <span className="font-semibold text-neutral-900">
                    {getTaxPaymentSourceLabel(activeStrategy.taxPayment.conversionTaxSource)}
                  </span>
                </div>
                <div className="flex justify-between border-t border-neutral-100 pt-1.5">
                  <span className="text-neutral-500">Ending Portfolio:</span>
                  <span className="font-bold text-neutral-900">
                    ${Math.round(currentEndNw).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Portfolio Depletion:</span>
                  <span className="font-bold text-neutral-900">
                    {currentSim.depletionAge ? `Age ${currentSim.depletionAge}` : 'None (Sustained)'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Lifetime Total Tax:</span>
                  <span className="font-bold text-neutral-900">
                    ${Math.round(activeLifetimeTotalTax).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Lifetime Conversion Tax:</span>
                  <span className="font-bold text-neutral-900">
                    ${Math.round(activeLifetimeConvTax).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Lifetime RMD Tax Drag:</span>
                  <span className="font-bold text-neutral-900">
                    ${Math.round(activeLifetimeRmdTax).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Lifetime Roth Converted:</span>
                  <span className="font-bold text-neutral-900">
                    ${Math.round(activeTotalConverted).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Ending Pre-Tax Balance:</span>
                  <span className="font-bold text-neutral-900">
                    ${Math.round(currentLastRow?.preTaxBal ?? 0).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Ending Roth Balance:</span>
                  <span className="font-bold text-neutral-900">
                    ${Math.round(currentLastRow?.postTaxBal ?? 0).toLocaleString()}
                  </span>
                </div>
              </div>
            </div>

            {/* Plan B Card */}
            <div className="bg-purple-50/30 p-4 rounded-xl border border-purple-200 space-y-3">
              <div className="flex items-center justify-between border-b border-purple-200 pb-2">
                <span className="font-bold text-purple-950 text-xs">
                  {comparisonPlan.name} (Variant)
                </span>
                <span className="px-2 py-0.5 text-[10px] bg-purple-100 text-purple-900 font-bold rounded-full">
                  Variant
                </span>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-neutral-500">Withdrawal Policy:</span>
                  <span className="font-semibold text-purple-950">
                    {getWithdrawalPolicyLabel(comparisonStrategy.withdrawal.policyId)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Roth Conversion Policy:</span>
                  <span className="font-semibold text-purple-950">
                    {getRothConversionPolicyLabel(comparisonStrategy.rothConversion)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Tax Payment Source:</span>
                  <span className="font-semibold text-purple-950">
                    {getTaxPaymentSourceLabel(comparisonStrategy.taxPayment.conversionTaxSource)}
                  </span>
                </div>
                <div className="flex justify-between border-t border-purple-100 pt-1.5">
                  <span className="text-neutral-500">Ending Portfolio:</span>
                  <span className="font-bold text-purple-950">
                    ${Math.round(compEndNw).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Portfolio Depletion:</span>
                  <span className="font-bold text-purple-950">
                    {comparisonSim.depletionAge ? `Age ${comparisonSim.depletionAge}` : 'None (Sustained)'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Lifetime Total Tax:</span>
                  <span className="font-bold text-purple-950">
                    ${Math.round(compLifetimeTotalTax).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Lifetime Conversion Tax:</span>
                  <span className="font-bold text-purple-950">
                    ${Math.round(compLifetimeConvTax).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Lifetime RMD Tax Drag:</span>
                  <span className="font-bold text-purple-950">
                    ${Math.round(compLifetimeRmdTax).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Lifetime Roth Converted:</span>
                  <span className="font-bold text-purple-950">
                    ${Math.round(compTotalConverted).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Ending Pre-Tax Balance:</span>
                  <span className="font-bold text-purple-950">
                    ${Math.round(compLastRow?.preTaxBal ?? 0).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Ending Roth Balance:</span>
                  <span className="font-bold text-purple-950">
                    ${Math.round(compLastRow?.postTaxBal ?? 0).toLocaleString()}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Plan A vs Plan B Delta Banner */}
          <div className="p-4 rounded-xl bg-purple-50 border border-purple-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <ArrowRight className="w-4 h-4 text-purple-600" />
                <span className="text-xs font-extrabold uppercase tracking-wider text-purple-950">
                  Variant vs. Current Plan Delta ({comparisonPlan.name} vs. {plan.name})
                </span>
              </div>
              <p className="text-xs text-neutral-600">
                {nwDelta >= 0
                  ? `${comparisonPlan.name} delivers +$${Math.round(nwDelta).toLocaleString()} higher ending net worth with ${taxDelta <= 0 ? `-$${Math.round(Math.abs(taxDelta)).toLocaleString()} lower` : `+$${Math.round(taxDelta).toLocaleString()} higher`} lifetime tax liability.`
                  : `${comparisonPlan.name} results in -$${Math.round(Math.abs(nwDelta)).toLocaleString()} lower ending net worth with ${taxDelta <= 0 ? `-$${Math.round(Math.abs(taxDelta)).toLocaleString()} lower` : `+$${Math.round(taxDelta).toLocaleString()} higher`} lifetime tax liability.`}
              </p>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <div className="bg-white px-3 py-2 rounded-xl border border-purple-200 text-right">
                <span className="text-[10px] font-bold text-neutral-500 uppercase block">
                  Ending Portfolio Delta
                </span>
                <span className={`text-sm font-extrabold ${nwDelta >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                  {nwDelta >= 0 ? `+$${Math.round(nwDelta).toLocaleString()}` : `-$${Math.round(Math.abs(nwDelta)).toLocaleString()}`}
                </span>
              </div>
              <div className="bg-white px-3 py-2 rounded-xl border border-purple-200 text-right">
                <span className="text-[10px] font-bold text-neutral-500 uppercase block">
                  Lifetime Tax Delta
                </span>
                <span className={`text-sm font-extrabold ${taxDelta <= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                  {taxDelta <= 0 ? `-$${Math.round(Math.abs(taxDelta)).toLocaleString()}` : `+$${Math.round(taxDelta).toLocaleString()}`}
                </span>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};
