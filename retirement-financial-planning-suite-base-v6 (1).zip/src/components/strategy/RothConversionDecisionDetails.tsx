import React from 'react';
import { SimulationRow } from '../../domain/simulation/simulationTypes';
import { getRothConversionPolicyBadge } from '../../domain/strategy/strategyTypes';
import { resolveRetirementStrategy } from '../../domain/strategy/strategyResolver';
import { Plan } from '../../types';
import { Table } from 'lucide-react';

interface RothConversionDecisionDetailsProps {
  plan: Plan;
  explainabilityRows: SimulationRow[];
  explainFilter: 'window' | 'all';
  onSetExplainFilter: (filter: 'window' | 'all') => void;
  startAge: number;
  endAge: number;
}

export const RothConversionDecisionDetails: React.FC<RothConversionDecisionDetailsProps> = ({
  plan,
  explainabilityRows,
  explainFilter,
  onSetExplainFilter,
  startAge,
  endAge,
}) => {
  const activeStrategy = resolveRetirementStrategy(plan);

  return (
    <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-200 pb-3">
        <div>
          <h2 className="text-sm font-bold text-neutral-900 flex items-center gap-2">
            <Table className="w-4 h-4 text-indigo-600" />
            4. Roth Conversion Decision Audit & Explainability
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Year-by-year inspection of ordinary taxable income, bracket headroom, available pre-tax assets, and actual executed conversions.
          </p>
        </div>

        {/* Filter Toggle */}
        <div className="flex items-center gap-2 shrink-0">
          <span className="text-xs text-neutral-500 font-medium">Show Years:</span>
          <div className="inline-flex p-0.5 bg-neutral-100 rounded-lg border border-neutral-200">
            <button
              type="button"
              onClick={() => onSetExplainFilter('window')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                explainFilter === 'window'
                  ? 'bg-white text-indigo-900 shadow-xs font-bold'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Active Window (Ages {startAge}–{endAge})
            </button>
            <button
              type="button"
              onClick={() => onSetExplainFilter('all')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                explainFilter === 'all'
                  ? 'bg-white text-indigo-900 shadow-xs font-bold'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              All Projection Years
            </button>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-neutral-50 border-b border-neutral-200 text-neutral-600 uppercase text-[10px] tracking-wider font-extrabold">
              <th className="py-2.5 px-3">Age (Year)</th>
              <th className="py-2.5 px-3">Policy</th>
              <th className="py-2.5 px-3 text-right">Taxable Ordinary Income</th>
              <th className="py-2.5 px-3 text-right">Bracket Headroom</th>
              <th className="py-2.5 px-3 text-right">Available Pre-Tax</th>
              <th className="py-2.5 px-3 text-right">Requested</th>
              <th className="py-2.5 px-3 text-right">Executed Conversion</th>
              <th className="py-2.5 px-3 text-right">Tax Paid</th>
              <th className="py-2.5 px-3">Audit Reason / Limiting Factor</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-200/80">
            {explainabilityRows.map((row) => {
              const audit = row.rothConversionDecision;
              const isOutsideWindow = row.age < startAge || row.age > endAge;
              const executed = row.rothConversion ?? 0;
              const preTaxAvail = row.preTaxAvailableBeforeConversion ?? 0;
              const taxableBefore = audit?.taxableIncomeBeforeConversion ?? row.taxableIncomeAfterDeduction;

              let badgeText = getRothConversionPolicyBadge(activeStrategy.rothConversion);
              let badgeColor = 'bg-neutral-100 text-neutral-700 border-neutral-200';
              let detailText = '';

              if (isOutsideWindow) {
                badgeText = 'Outside Window';
                badgeColor = 'bg-neutral-100 text-neutral-500 border-neutral-200';
                detailText = `Age ${row.age} is outside the active conversion window (Ages ${startAge}–${endAge}).`;
              } else if (preTaxAvail <= 0) {
                badgeText = 'Pre-Tax $0';
                badgeColor = 'bg-amber-50 text-amber-800 border-amber-200';
                detailText = 'Pre-tax retirement accounts are fully depleted ($0 available balance).';
              } else if (executed > 0) {
                if (audit?.limitedByAvailablePreTax) {
                  badgeText = 'Capped by Pre-Tax';
                  badgeColor = 'bg-amber-50 text-amber-900 border-amber-300';
                  detailText = `Requested $${audit.requestedConversion.toLocaleString()}, but capped at $${executed.toLocaleString()} by available pre-tax balance.`;
                } else if (audit?.remainingBracketCapacity !== undefined && audit.remainingBracketCapacity > 0) {
                  badgeText = `Filled Bracket (${Math.round((audit.bracketRate ?? 0) * 100)}%)`;
                  badgeColor = 'bg-emerald-50 text-emerald-900 border-emerald-300';
                  detailText = `Converted $${executed.toLocaleString()} to fill remaining capacity up to top of ${Math.round(
                    (audit.bracketRate ?? 0) * 100
                  )}% bracket ($${Math.round(audit.bracketCeiling ?? 0).toLocaleString()}).`;
                } else {
                  badgeText = 'Target Executed';
                  badgeColor = 'bg-emerald-50 text-emerald-900 border-emerald-300';
                  detailText = `Executed $${executed.toLocaleString()} conversion.`;
                }
              } else {
                badgeText = 'Zero Conversion';
                badgeColor = 'bg-neutral-100 text-neutral-600 border-neutral-200';
                if (activeStrategy.rothConversion.type === 'manual') {
                  detailText = 'Manual conversion target is set to $0 / year.';
                } else {
                  detailText = 'Taxable ordinary income already fills or exceeds the target bracket ceiling.';
                }
              }

              return (
                <tr
                  key={row.age}
                  className={`hover:bg-neutral-50/80 transition-colors ${
                    executed > 0 ? 'bg-purple-50/20' : ''
                  }`}
                >
                  <td className="py-2.5 px-3 font-semibold text-neutral-900">
                    Age {row.age} ({row.calendarYear})
                  </td>
                  <td className="py-2.5 px-3">
                    <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full border ${badgeColor}`}>
                      {badgeText}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-neutral-700">
                    ${Math.round(taxableBefore).toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-neutral-700">
                    {audit?.remainingBracketCapacity !== undefined
                      ? `$${Math.round(audit.remainingBracketCapacity).toLocaleString()}`
                      : `$${Math.round(row.ordinaryHeadroom ?? 0).toLocaleString()}`}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-neutral-700">
                    ${Math.round(preTaxAvail).toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-neutral-700">
                    ${Math.round(audit?.requestedConversion ?? executed).toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold text-purple-900">
                    ${Math.round(executed).toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-amber-900">
                    ${Math.round(row.conversionTaxPaid).toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 text-[11px] text-neutral-600 max-w-xs leading-snug">
                    {detailText}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
