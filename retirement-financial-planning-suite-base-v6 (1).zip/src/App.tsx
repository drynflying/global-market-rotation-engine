import React, { useEffect } from 'react';
import { usePlanStore } from './store/usePlanStore';
import { Header } from './components/Header';
import { SidebarNavigation } from './components/SidebarNavigation';
import { ScenarioManagerStep } from './components/ScenarioManagerStep';
import { PersonaProfileStep } from './components/PersonaProfileStep';
import { ProfileStep } from './components/ProfileStep';
import { AssumptionsStatutoryStep } from './components/AssumptionsStatutoryStep';
import { SpendingStep } from './components/SpendingStep';
import { Step4CashFlowStep } from './components/Step4CashFlowStep';
import { YearlyTimelineStep } from './components/YearlyTimelineStep';
import { DashboardStep } from './components/DashboardStep';
import { ValidationsStep } from './components/ValidationsStep';
import { StrategyStep } from './components/StrategyStep';
import { PlannedModule } from './components/PlannedModule';

export default function App() {
  const {
    plans,
    activePlan,
    activeTab,
    validations,
    validationSummary,
    loadPlans,
    selectPlan,
    updatePlan,
    createPlan,
    duplicatePlan,
    removePlan,
    resetSample,
    exportPlan,
    importPlan,
    setActiveTab,
  } = usePlanStore();

  const [showResetConfirm, setShowResetConfirm] = React.useState(false);

  // Load plans on mount
  useEffect(() => {
    loadPlans();
  }, [loadPlans]);

  if (!activePlan) {
    return (
      <div className="min-h-screen bg-[#f4f4f4] flex items-center justify-center text-neutral-600 text-sm font-mono">
        Initializing MERIDIAN Engine...
      </div>
    );
  }

  // Handle reset confirmation
  const handleResetSample = () => {
    setShowResetConfirm(true);
  };

  return (
    <div className="h-screen bg-[#f4f4f4] text-neutral-900 flex flex-col font-sans antialiased selection:bg-[#f8eeeb] selection:text-[#9e2a1b] overflow-hidden">
      
      {/* Top Header */}
      <Header
        plans={plans}
        activePlan={activePlan}
        onSelectPlan={selectPlan}
        onCreatePlan={createPlan}
        onClonePlan={duplicatePlan}
        onDeletePlan={removePlan}
        onResetSample={handleResetSample}
        onExportPlan={exportPlan}
        onImportPlan={importPlan}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        validationCount={validationSummary}
      />

      {/* Main Workspace Body with Flush Left Navigation Rail */}
      <div className="flex-1 w-full flex overflow-hidden">
        
        {/* Left Sidebar Rail */}
        <SidebarNavigation
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          validationCount={validationSummary}
        />

        {/* Right Main Content Panel */}
        <main className="flex-1 p-3 sm:p-5 lg:p-6 overflow-y-auto min-w-0 w-full">
          <div className="w-full max-w-[1800px] mx-auto">
            {activeTab === 'dashboard' && (
              <DashboardStep plan={activePlan} />
            )}

            {activeTab === 'scenarios' && (
              <ScenarioManagerStep
                plans={plans}
                activePlanId={activePlan.id}
                onSelectPlan={selectPlan}
                onCreatePlan={createPlan}
                onDuplicatePlan={duplicatePlan}
                onUpdatePlan={updatePlan}
                onDeletePlan={removePlan}
                onImportPlan={importPlan}
              />
            )}

            {activeTab === 'profile' && (
              <PersonaProfileStep
                plan={activePlan}
                onUpdatePlan={updatePlan}
                onGoToValidations={() => setActiveTab('validations')}
                onGoToScenarios={() => setActiveTab('scenarios')}
              />
            )}

            {activeTab === 'investments' && (
              <ProfileStep
                plan={activePlan}
                onUpdatePlan={updatePlan}
                onGoToValidations={() => setActiveTab('validations')}
                onGoToNextStep={() => setActiveTab('spending')}
              />
            )}

            {activeTab === 'spending' && (
              <SpendingStep
                plan={activePlan}
                onUpdatePlan={updatePlan}
                onGoToValidations={() => setActiveTab('validations')}
                onGoToNextStep={() => setActiveTab('income-tax')}
              />
            )}

            {activeTab === 'strategy' && (
              <StrategyStep
                plan={activePlan}
                plans={plans}
                onUpdatePlan={updatePlan}
                onDuplicatePlan={duplicatePlan}
                onGoToValidations={() => setActiveTab('validations')}
                onGoToScenarios={() => setActiveTab('scenarios')}
              />
            )}

            {activeTab === 'simulations' && (
              <PlannedModule
                title="Simulations & Stress Testing"
                subtitle="Historical backtests, Monte Carlo, and sequence-of-returns risk."
                features={[
                  'Historical backtesting against real return sequences (1929, 1966, 2000 starts) — preserves the autocorrelation and the shape of bad decades that Monte Carlo draws away',
                  'Monte Carlo simulation with success probability distribution across 1,000+ paths',
                  'Sequence-of-returns stress tests: forced drawdowns in the first three retirement years, when the portfolio is most vulnerable',
                  'Guyton-Klinger spending guardrails and dynamic withdrawal rate adjustment',
                ]}
                note="This is a prerequisite for the optimizer, not an add-on. Optimising against a single deterministic return path overfits to that path — a strategy that only works on one sequence is worse than a robust rule of thumb. Success probability is only computable once this exists."
              />
            )}

            {activeTab === 'income-tax' && (
              <Step4CashFlowStep
                plan={activePlan}
                onUpdatePlan={updatePlan}
                onGoToValidations={() => setActiveTab('validations')}
                onGoToStrategy={() => setActiveTab('strategy')}
                onGoToNextStep={() => setActiveTab('timeline')}
              />
            )}

            {activeTab === 'timeline' && (
              <YearlyTimelineStep
                plan={activePlan}
                onGoToValidations={() => setActiveTab('validations')}
              />
            )}

            {activeTab === 'assumptions' && (
              <AssumptionsStatutoryStep
                plan={activePlan}
                onUpdatePlan={updatePlan}
                onGoToValidations={() => setActiveTab('validations')}
              />
            )}

            {activeTab === 'validations' && (
              <ValidationsStep
                plan={activePlan}
                validations={validations}
                onNavigateTab={(tab) => setActiveTab(tab)}
              />
            )}
          </div>
        </main>
      </div>

      {showResetConfirm && (
        <div className="fixed inset-0 bg-neutral-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6 border border-neutral-200">
            <h3 className="text-base font-bold text-neutral-900 mb-2">Reset Scenario to Sample Data?</h3>
            <p className="text-xs text-neutral-600 mb-6 leading-relaxed">
              Are you sure you want to reset <strong>{activePlan.name}</strong>? Custom edits will be replaced with default template values.
            </p>
            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => setShowResetConfirm(false)}
                className="px-3 py-1.5 text-xs font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  resetSample();
                  setShowResetConfirm(false);
                }}
                className="px-3 py-1.5 text-xs font-semibold text-white bg-[#b92d1d] hover:bg-[#9e2a1b] rounded transition-colors cursor-pointer"
              >
                Reset Scenario
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
