import { Plan, SpendingAssumptions, SpecialExpense } from '../../types';
import { DEFAULT_PLAN } from '../../constants/defaultPlan';
import { IRMAA_REGISTRY, resolveIrmaaContext } from '../registry/statutoryRegistry';
import {
  bracketCeilingsFor,
  ADDL_STD_DEDUCTION_65,
} from '../tax/taxConstants';
import { findStateRule } from '../tax/stateTaxConstants';
import { calculateAcaPremium } from '../health/acaSubsidy';
import {
  calculateFederalTax,
  getMarginalTaxBracket,
  getMarginalRate,
  calculateCapGainsTax,
  calculateFicaTax,
  getSsAnnualBenefit,
  calculateTaxableSs,
  getSmileMultiplier,
  statutoryRmdStartAge,
  getRmdStartAge,
  getRmdFactor,
  DELAYED_CREDIT_RATE,
  DELAYED_CREDIT_MAX_AGE,
} from '../kernel';
import { computeSimulationSummary } from '../analysis/simulationSummary';
import { initializeAccountBuckets } from '../portfolio/accountBuckets';
import { calculateCategoryGrowthRates, calculateBlendedReturnPct } from '../portfolio/portfolioReturn';
import { projectWorkingYear } from '../projection/projectWorkingYear';
import { projectRetirementYear } from '../projection/projectRetirementYear';
import { resolveRetirementStrategy } from '../strategy/strategyResolver';

export {
  calculateFederalTax,
  getMarginalTaxBracket,
  getMarginalRate,
  calculateCapGainsTax,
  calculateFicaTax,
  getSsAnnualBenefit,
  calculateTaxableSs,
  getSmileMultiplier,
  statutoryRmdStartAge,
  getRmdStartAge,
  getRmdFactor,
  DELAYED_CREDIT_RATE,
  DELAYED_CREDIT_MAX_AGE,
};

import { SimulationRow, SimulationResult, SimulationOptions } from './simulationTypes';
export type { SimulationRow, SimulationResult, SimulationOptions };

export function getIrmaaTier(
  magi: number,
  isJoint: boolean,
  deflator: number = 1.0,
  isMedicareEligible: boolean = true
): { tier: string; surcharge: number } {
  return IRMAA_REGISTRY.calculateTier(magi, isJoint, deflator, isMedicareEligible);
}

/**
 * The ACA premium is re-resolved each solver pass until the WITHDRAWAL MIX stops moving,
 * then held fixed so the remaining passes converge against a constant cost.
 *
 * Freezing is necessary because the 400% FPL cliff is a discontinuity: left floating for
 * the whole loop it produces a LIMIT CYCLE rather than convergence — drawing more crosses
 * the cliff, which raises the premium, which requires drawing more, which lands back
 * under the cliff once the give-back fires. Adding iterations does not help.
 *
 * But freezing after a FIXED NUMBER of passes was wrong. With the conventional draw order
 * the solver settles in three or four passes, so a fixed count looked fine. Any slower
 * convergence leaves the mix still moving when the counter fires, freezing the premium
 * against an early, wrong MAGI.
 *
 */

/**
 * Unified Cash Flow and Net Worth Projection Simulation Engine
 */
export function runSimulation(
  plan: Plan,
  optionsOrConversionTarget?: number | SimulationOptions,
  referenceCalendarYearParam?: number
): SimulationResult {
  const overrideConversionTarget =
    typeof optionsOrConversionTarget === 'number'
      ? optionsOrConversionTarget
      : optionsOrConversionTarget?.overrideConversionTarget;

  const strategyOverride =
    typeof optionsOrConversionTarget === 'object'
      ? optionsOrConversionTarget?.strategyOverride
      : undefined;

  const referenceCalendarYear =
    (typeof optionsOrConversionTarget === 'object' ? optionsOrConversionTarget?.referenceCalendarYear : undefined) ??
    referenceCalendarYearParam ??
    plan.startCalendarYear ??
    2026;

  // The plan is the source of truth. DEFAULT_PLAN is NOT spread underneath. Fields that
  // carry schema defaults are guaranteed present by z.parse(); optional fields are
  // genuinely optional. Spreading DEFAULT_PLAN here caused user plans to silently inherit
  // sample specialExpenses, pre65AcaBridgeSurcharge, and spending models when omitted,
  // making it impossible for a user to clear a field back to zero.
  const spending: SpendingAssumptions = plan.spendingAssumptions ?? DEFAULT_PLAN.spendingAssumptions!;
  const strategy = resolveRetirementStrategy(plan, { overrideConversionTarget, strategyOverride });

  const primary = plan.primaryPerson;
  const spouse = plan.spousePerson;
  const macro = plan.macroAssumptions || DEFAULT_PLAN.macroAssumptions!;
  const statutory = plan.statutoryParams || DEFAULT_PLAN.statutoryParams!;
  const cma = plan.cmaAssumptions || DEFAULT_PLAN.cmaAssumptions!;
  const aca = plan.acaAssumptions || DEFAULT_PLAN.acaAssumptions!;
  const feeDrag = (cma.annualPortfolioFeeDrag ?? 0.10) / 100;

  const isJoint = plan.filingStatus === 'joint';
  const stateRule = findStateRule(plan.stateOfResidence);
  const customStateRatePct = plan.customStateRatePct;

  const currentCalendarYear = referenceCalendarYear;
  const primaryBirthYear = currentCalendarYear - primary.currentAge;

  // Determine SECURE 2.0 RMD start age
  const rmdStartAge = getRmdStartAge(primaryBirthYear, statutory.rmdStartAge);

  const rows: SimulationRow[] = [];
  const startAge = primary.currentAge;
  const endAge = Math.max(primary.lifeExpectancy, spouse?.lifeExpectancy || 95);

  const {
    initialCashTarget,
    preTaxBal: initPreTaxBal,
    postTaxBal: initPostTaxBal,
    taxableBrokerageBal: initTaxableBrokerageBal,
    cashBal: initCashBal,
    taxableBal: initTaxableBal,
    taxableBrokerageCostBasis: initTaxableBrokerageCostBasis,
    preTaxAccs,
    postTaxAccs,
    taxableBrokerageAccs,
    cashAccs,
  } = initializeAccountBuckets(plan);

  let preTaxBal = initPreTaxBal;
  let postTaxBal = initPostTaxBal;
  let taxableBrokerageBal = initTaxableBrokerageBal;
  let cashBal = initCashBal;
  let taxableBal = initTaxableBal;
  let taxableBrokerageCostBasis = initTaxableBrokerageCostBasis;

  const portfolioGrowthRates = calculateCategoryGrowthRates(
    preTaxAccs,
    postTaxAccs,
    taxableBrokerageAccs,
    cashAccs,
    cma,
    feeDrag
  );
  const { growthPreTax, growthPostTax, growthTaxableBrokerage, growthCash } = portfolioGrowthRates;

  const convTarget = overrideConversionTarget !== undefined 
    ? overrideConversionTarget 
    : spending.annualRothConversionTarget;

  const primaryRetAge = primary.retirementAge;
  const magiHistory: Record<number, number> = {};

  for (let age = startAge; age <= endAge; age++) {
    const yearsFromStart = age - startAge;
    const calendarYear = currentCalendarYear + yearsFromStart;
    const deflator = Math.pow(1 + macro.generalInflation / 100, yearsFromStart);

    // Blended return actually applied this year, weighted by BEGINNING-of-year bucket
    // balances. Exposed on the row so the growth figure can be checked rather than
    // inferred. Reports 0 only when the year starts with no assets.
    const blendedReturnPct = calculateBlendedReturnPct(
      preTaxBal,
      postTaxBal,
      taxableBrokerageBal,
      cashBal,
      portfolioGrowthRates
    );
    const spouseAge = spouse ? (spouse.currentAge + yearsFromStart) : age;

    let stdDeduction = (isJoint ? statutory.standardDeductionJoint : statutory.standardDeductionSingle) * deflator;
    if (age >= 65) {
      stdDeduction +=
        (isJoint ? ADDL_STD_DEDUCTION_65.joint : ADDL_STD_DEDUCTION_65.single) * deflator;
    }
    if (spouse && spouseAge >= 65 && isJoint) {
      stdDeduction += ADDL_STD_DEDUCTION_65.joint * deflator;
    }

    const bracketCeilings = bracketCeilingsFor(isJoint, deflator);

    const isRetired = age >= primaryRetAge;
    const beginningPortfolio = Math.round(preTaxBal + postTaxBal + taxableBal);

    // Living Expenses Calculation
    const smileMult = getSmileMultiplier(age, primaryRetAge, spending.spendingModel || 'blanchett_smile');
    const baseLiving = isRetired
      ? spending.desiredAnnualLivingExpenses * deflator * smileMult
      : 0;

    const essentialPct = (spending.essentialLivingPct ?? 65) / 100;
    // Healthcare, in today's dollars, inflated by MEDICAL CPI.
    //
    // Before Medicare starts at 65, an early retiree also carries the marketplace
    // premium gap. That gap is the user's pre65AcaBridgeSurcharge, ADDED to the baseline
    // healthcare budget — matching how the Spending tab presents it as its own line item.
    //
    // This previously ignored the stored field entirely and used a hardcoded
    // `desiredAnnualHealthcareExpenses * 1.5`, so editing the ACA bridge input changed
    // nothing in the projection. The multiplier was also redundant: medical inflation
    // already escalates the figure year over year, and the pre-65 premium gap is a level
    // difference, not a growth-rate difference.
    const medicalEscalation = Math.pow(1 + macro.medicalInflation / 100, yearsFromStart);

    // The marketplace premium is DERIVED from MAGI rather than entered flat, which makes
    // the Roth-conversion trade-off visible: converting raises MAGI, and above 400% FPL
    // the premium tax credit vanishes as a cliff rather than tapering.
    //
    // The premium depends on MAGI, MAGI depends on withdrawals, and withdrawals depend
    // on the cash need that includes the premium. That circularity resolves inside the
    // withdrawal solver — see acaPremiumFor below and ACA_PREMIUM_FREEZE_AFTER.
    //
    // Anyone already 65 is on Medicare and leaves the marketplace policy, so a couple
    // spanning 65 has only the younger spouse covered.
    const acaCoveredAges = !isRetired
      ? []
      : [age, ...(spouse && plan.hasSpouse ? [spouseAge] : [])].filter((a) => a < 65);

    const useAca =
      aca.useSubsidyModel && acaCoveredAges.length > 0 && aca.baseMonthlyPremiumAge21 > 0;

    const acaPremiumFor = (magiForYear: number): number => {
      if (!useAca) return 0;
      return calculateAcaPremium({
        magi: Math.max(0, magiForYear),
        coveredAges: acaCoveredAges,
        householdSize: aca.householdSize,
        baseMonthlyPremiumAge21: aca.baseMonthlyPremiumAge21,
        regime: aca.subsidyRegime,
        yearsOfTrend: yearsFromStart,
        premiumTrendPct: aca.premiumTrendPct,
        // FPL is indexed to CPI-U, not medical CPI — the cliff rises more slowly than
        // premiums, so the household drifts over it in real terms.
        fplInflationPct: macro.generalInflation,
      }).netAnnualPremium;
    };

    // The manual surcharge means different things by mode: with the subsidy model ON it
    // is additive extras (dental, vision, out-of-pocket); with it OFF it is the whole
    // pre-65 premium gap, as before.
    const manualBridge = age < 65 && !useAca ? (spending.pre65AcaBridgeSurcharge ?? 0) : 0;
    const extrasWithAca = useAca ? (spending.pre65AcaExtras ?? 0) : 0;

    const baseHealthExpenseExAca = !isRetired
      ? 0
      : (spending.desiredAnnualHealthcareExpenses + manualBridge + extrasWithAca) *
        medicalEscalation;

    // IRMAA 2-Year Lookback Calculation
    const primaryEligible = age >= 65;
    const spouseEligible = Boolean(spouse && spouseAge >= 65);
    const isMedicareEligible = primaryEligible || spouseEligible;
    const enrolledCount = (isJoint && primaryEligible && spouseEligible) ? 2 : (isMedicareEligible ? 1 : 0);
    const lookbackMagi = magiHistory[age - 2] ?? 0;
    const lookbackTaxYear = calendarYear - 2;

    const irmaaContext = resolveIrmaaContext({
      premiumYear: calendarYear,
      lookbackTaxYear,
      lookbackMagi,
      isJoint,
      deflator,
      isMedicareEligible,
      enrolledCount,
    });
    const irmaaSurcharge = irmaaContext.totalAnnualSurcharge;
    const healthExpenseExAca = baseHealthExpenseExAca + irmaaSurcharge;

    let specialEssentialNominal = 0;
    let specialDiscretionaryNominal = 0;
    const specialExpenses = spending.specialExpenses || [];
    specialExpenses.forEach((sp: SpecialExpense) => {
      if (age >= sp.startAge && age <= sp.endAge) {
        const amountNominal = sp.amount * deflator;
        if (sp.isEssential) {
          specialEssentialNominal += amountNominal;
        } else {
          specialDiscretionaryNominal += amountNominal;
        }
      }
    });

    const totalSpecialNominal = specialEssentialNominal + specialDiscretionaryNominal;
    const expenseNeedExAca = isRetired ? Math.round(baseLiving + healthExpenseExAca + totalSpecialNominal) : 0;

    // essentialExpense and totalExpenseNeed are finalised AFTER the solver, once the
    // ACA premium is known. Healthcare is essential, so the premium lands in that bucket.

    // Income Streams Calculation
    let primarySalaryIncome = 0;
    let spouseSalaryIncome = 0;
    let annualSalaryIncome = 0;
    let primarySs = 0;
    let spouseSs = 0;
    let pensionIncome = 0;
    let otherGuaranteedIncome = 0;

    if (plan.incomeStreams && plan.incomeStreams.length > 0) {
      plan.incomeStreams.forEach(stream => {
        let personAgeAtStep = age;
        if (stream.owner === 'spouse' && spouse) {
          personAgeAtStep = spouseAge;
        }

        if (stream.type === 'salary') {
          if (personAgeAtStep >= stream.startAge && personAgeAtStep <= stream.endAge) {
            const streamGrowth = Math.pow(1 + (stream.growthRatePct ?? 3.0) / 100, yearsFromStart);
            const streamAmount = stream.amount * streamGrowth;
            if (stream.owner === 'spouse') {
              spouseSalaryIncome += streamAmount;
            } else if (stream.owner === 'joint') {
              primarySalaryIncome += streamAmount / 2;
              spouseSalaryIncome += streamAmount / 2;
            } else {
              primarySalaryIncome += streamAmount;
            }
          }
        } else if (stream.type === 'business') {
          if (personAgeAtStep >= stream.startAge && personAgeAtStep <= stream.endAge) {
            const streamGrowth = Math.pow(1 + (stream.growthRatePct ?? 3.0) / 100, yearsFromStart);
            const streamAmount = stream.amount * streamGrowth;
            if (stream.owner === 'spouse') {
              spouseSalaryIncome += streamAmount;
            } else if (stream.owner === 'joint') {
              primarySalaryIncome += streamAmount / 2;
              spouseSalaryIncome += streamAmount / 2;
            } else {
              primarySalaryIncome += streamAmount;
            }
          }
        } else if (stream.type === 'social_security') {
          const person = stream.owner === 'spouse' ? (spouse || primary) : primary;
          if (personAgeAtStep >= person.ssClaimAge) {
            const ssBenefit = getSsAnnualBenefit(person, personAgeAtStep, statutory);
            if (stream.owner === 'spouse') spouseSs += ssBenefit;
            else primarySs += ssBenefit;
          }
        } else if (stream.type === 'pension' || stream.type === 'annuity') {
          if (personAgeAtStep >= stream.startAge && personAgeAtStep <= stream.endAge) {
            const streamGrowth = Math.pow(1 + (stream.growthRatePct ?? 0) / 100, yearsFromStart);
            pensionIncome += stream.amount * streamGrowth;
          }
        } else {
          if (personAgeAtStep >= stream.startAge && personAgeAtStep <= stream.endAge) {
            const streamGrowth = Math.pow(1 + (stream.growthRatePct ?? 2.5) / 100, yearsFromStart);
            otherGuaranteedIncome += stream.amount * streamGrowth;
          }
        }
      });
      annualSalaryIncome = primarySalaryIncome + spouseSalaryIncome;
    } else {
      primarySs = getSsAnnualBenefit(primary, age, statutory);
      spouseSs = (plan.hasSpouse && spouse) ? getSsAnnualBenefit(spouse, spouseAge, statutory) : 0;
      pensionIncome = spending.otherGuaranteedAnnualIncome * deflator;
    }

    const totalSs = primarySs + spouseSs;
    const guaranteedIncome = Math.round(totalSs + pensionIncome + otherGuaranteedIncome);

    // Working Accumulation Phase
    if (!isRetired) {
      const workingResult = projectWorkingYear({
        plan,
        age,
        calendarYear,
        yearsFromStart,
        deflator,
        startAge,
        primaryRetAge,
        spouseAge,
        isJoint,
        stdDeduction,
        bracketCeilings,
        macro,
        spending,
        preTaxAccs,
        postTaxAccs,
        taxableBrokerageAccs,
        cashAccs,
        preTaxBal,
        postTaxBal,
        taxableBrokerageBal,
        cashBal,
        taxableBrokerageCostBasis,
        growthPreTax,
        growthPostTax,
        growthTaxableBrokerage,
        growthCash,
        blendedReturnPct,
        beginningPortfolio,
        annualSalaryIncome,
        primarySalaryIncome,
        spouseSalaryIncome,
        pensionIncome,
        otherGuaranteedIncome,
        totalSpecialNominal,
        stateRule,
        customStateRatePct,
        magiHistory,
      });

      preTaxBal = workingResult.preTaxBal;
      postTaxBal = workingResult.postTaxBal;
      taxableBrokerageBal = workingResult.taxableBrokerageBal;
      cashBal = workingResult.cashBal;
      taxableBrokerageCostBasis = workingResult.taxableBrokerageCostBasis;
      taxableBal = workingResult.taxableBal;

      rows.push(workingResult.row);
      continue;
    }

    // RETIRED DEACCUMULATION PHASE
    const retirementResult = projectRetirementYear({
      plan,
      strategy,
      age,
      calendarYear,
      yearsFromStart,
      deflator,
      primaryRetAge,
      spouseAge,
      isJoint,
      stdDeduction,
      bracketCeilings,
      macro,
      spending,
      rmdStartAge,
      convTarget,
      primary,
      spouse,
      preTaxBal,
      postTaxBal,
      taxableBrokerageBal,
      cashBal,
      taxableBrokerageCostBasis,
      taxableBal,
      growthPreTax,
      growthPostTax,
      growthTaxableBrokerage,
      growthCash,
      blendedReturnPct,
      beginningPortfolio,
      annualSalaryIncome,
      primarySalaryIncome,
      spouseSalaryIncome,
      pensionIncome,
      otherGuaranteedIncome,
      totalSs,
      primarySs,
      spouseSs,
      guaranteedIncome,
      baseLiving,
      essentialPct,
      healthExpenseExAca,
      specialEssentialNominal,
      specialDiscretionaryNominal,
      totalSpecialNominal,
      expenseNeedExAca,
      initialCashTarget,
      irmaaSurcharge,
      acaPremiumFor,
      stateRule,
      customStateRatePct,
      magiHistory,
      previousRows: rows,
    });

    preTaxBal = retirementResult.preTaxBal;
    postTaxBal = retirementResult.postTaxBal;
    taxableBrokerageBal = retirementResult.taxableBrokerageBal;
    cashBal = retirementResult.cashBal;
    taxableBrokerageCostBasis = retirementResult.taxableBrokerageCostBasis;
    taxableBal = retirementResult.taxableBal;

    rows.push(retirementResult.row);
  }

  return computeSimulationSummary(rows, undefined, strategy);
}
