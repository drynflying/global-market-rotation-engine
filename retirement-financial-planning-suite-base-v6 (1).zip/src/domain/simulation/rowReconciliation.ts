/**
 * Reconciliation and invariant checks for simulation rows and full engine projections.
 *
 * These accounting identities ensure every dollar has an identifiable source and
 * destination. They are exposed to the UI for auditing and checked in test suites
 * to detect inconsistent financial results.
 */
import { SimulationRow, SimulationResult } from './simulationTypes';
import { ROW_FIELDS } from './rowFields';

export interface ReconciliationCheck {
  label: string;
  /** Human-readable form of the identity, e.g. "pre-tax + post-tax + taxable". */
  formula: string;
  expected: number;
  actual: number;
  tolerance: number;
  passed: boolean;
  /** False when the identity does not apply to this row (e.g. working years). */
  applicable: boolean;
  code?: string;
  details?: string;
}

export interface InvariantViolation {
  code: string;
  label: string;
  message: string;
  expected?: number | string;
  actual?: number | string;
  rowAge?: number;
  calendarYear?: number;
}

export interface InvariantReport {
  passed: boolean;
  violations: InvariantViolation[];
  checks: ReconciliationCheck[];
}

const check = (
  label: string,
  formula: string,
  expected: number,
  actual: number,
  tolerance = 2,
  applicable = true,
  code?: string,
  details?: string,
): ReconciliationCheck => {
  const diff = Math.abs(expected - actual);
  const maxVal = Math.max(Math.abs(expected), Math.abs(actual));
  const effectiveTolerance = maxVal > 1_000_000 ? Math.max(tolerance, maxVal * 0.0001) : tolerance;
  const passed = !applicable || diff <= effectiveTolerance;

  return {
    label,
    formula,
    expected,
    actual,
    tolerance: effectiveTolerance,
    passed,
    applicable,
    code,
    details,
  };
};

/**
 * Authoritative list of SimulationRow fields that contractually MUST be non-negative (>= 0).
 * Note: Intentionally signed fields are excluded:
 * - netCashFlow (positive for surplus, negative for deficit before shortfall)
 * - portfolioGrowth (can be negative during market drops)
 * - realizedCapGains (can represent realized capital losses)
 * - percentages & deflators (handled separately)
 */
export const NON_NEGATIVE_ROW_FIELDS: Array<keyof SimulationRow> = [
  'beginningPortfolio',
  'totalPortfolio',
  'preTaxBal',
  'postTaxBal',
  'taxableBal',
  'totalPortfolioReal',
  'taxableCostBasis',
  'baseLiving',
  'essentialExpense',
  'discretionaryExpense',
  'healthExpense',
  'specialExpense',
  'debtService',
  'totalExpenseNeed',
  'w2Income',
  'guaranteedIncome',
  'primarySs',
  'spouseSs',
  'pensionIncome',
  'rmdAmount',
  'rothConversion',
  'taxableWd',
  'preTaxWd',
  'postTaxWd',
  'totalWithdrawals',
  'preTaxContrib',
  'postTaxContrib',
  'taxableContrib',
  'fedTaxPaid',
  'capGainsTaxPaid',
  'stateTaxPaid',
  'ficaTaxPaid',
  'conversionTaxPaid',
  'conversionTaxPortfolioOutflow',
  'rmdTaxPaid',
  'totalEstimatedTax',
  'unfundedShortfall',
  'surplusReinvested',
  'irmaaSurcharge',
  'rmdEligibleBalance',
  'preTaxAvailableBeforeConversion',
];

export function reconcileRow(r: SimulationRow): ReconciliationCheck[] {
  // 1. Portfolio Buckets
  const portfolioBucketsCheck = check(
    'Portfolio buckets',
    'pre-tax + post-tax + taxable',
    r.preTaxBal + r.postTaxBal + r.taxableBal,
    r.totalPortfolio,
    1,
    true,
    'INV_PORTFOLIO_BUCKETS',
    'Total portfolio must equal sum of pre-tax, post-tax (Roth), and taxable balances',
  );

  // 2. Tax Components
  const taxComponentsCheck = check(
    'Tax components',
    'federal + capital gains + state + FICA',
    r.fedTaxPaid + r.capGainsTaxPaid + r.stateTaxPaid + r.ficaTaxPaid,
    r.totalEstimatedTax,
    1,
    true,
    'INV_TAX_COMPONENTS',
    'Total estimated tax must equal federal + capital gains + state + FICA taxes',
  );

  // 3. Withdrawal Sources
  const withdrawalSourcesCheck = check(
    'Withdrawal sources',
    'taxable + pre-tax + Roth',
    r.taxableWd + r.preTaxWd + r.postTaxWd,
    r.totalWithdrawals,
    1,
    true,
    'INV_WITHDRAWAL_SOURCES',
    'Total withdrawals must equal sum of taxable, pre-tax, and Roth withdrawals',
  );

  // 4. Guaranteed Income
  const guaranteedIncomeCheck = check(
    'Guaranteed income',
    'primary SS + spouse SS + pension',
    r.primarySs + r.spouseSs + r.pensionIncome,
    r.guaranteedIncome,
    1,
    true,
    'INV_GUARANTEED_INCOME',
    'Guaranteed income must equal primary SS + spouse SS + pension income',
  );

  // 5. Expense Split
  const expenseSplitCheck = check(
    'Expense split',
    'essential + discretionary',
    r.essentialExpense + r.discretionaryExpense,
    r.totalExpenseNeed,
    2,
    r.isRetired, // Working years report the split as zero by design.
    'INV_EXPENSE_SPLIT',
    'Total expense need must equal essential expense + discretionary expense',
  );

  // 6. Cash Flow Conservation
  /**
   * Household Cash-Flow Conservation Identity:
   * totalCashInflow + unfundedShortfall = totalCashOutflow + surplus
   *
   * Field Definitions:
   * - Household Cash Inflows (totalCashInflow): Guaranteed income + W2 salary + portfolio withdrawals
   * - Household Cash Outflows (totalCashOutflow): Total expense need + total estimated tax + savings contributions
   * - Financing Shortfall (unfundedShortfall): Deficit remaining after all income and available portfolio withdrawals
   * - Surplus Cash (surplus): Reinvested surplus in retirement or unspent net income in working years
   */
  const effectiveSurplus = r.isRetired ? r.surplusReinvested : Math.max(0, r.netCashFlow);
  const expectedCashSide = r.totalCashInflow + r.unfundedShortfall;
  const actualCashSide = r.totalCashOutflow + effectiveSurplus;

  const cashFlowCheck = check(
    'Cash flow conservation',
    'inflow + shortfall = outflow + surplus',
    expectedCashSide,
    actualCashSide,
    2,
    true,
    'INV_CASH_FLOW',
    'Every cash dollar must reconcile between inflows, shortfalls, outflows, and surplus reinvestments',
  );

  // 7. Portfolio Roll-Forward Accounting
  /**
   * Single Deterministic Portfolio Roll-Forward Accounting Identity:
   * endingPortfolio = beginningPortfolio + portfolioGrowth + totalContributions - totalWithdrawals - conversionTaxPortfolioOutflow + portfolioSurplus
   *
   * Accounting Treatment:
   * - conversionTaxPortfolioOutflow represents the exact conversion tax paid that directly reduces portfolio assets
   *   outside of standard withdrawal amounts (totalWithdrawals).
   * - portfolioSurplus represents reinvested retirement surplus (in working years, savings contributions are captured via totalContributions).
   */
  const totalContribs = r.preTaxContrib + r.postTaxContrib + r.taxableContrib;
  const conversionTaxOutflow = r.conversionTaxPortfolioOutflow;
  const portfolioSurplus = r.isRetired ? r.surplusReinvested : 0;
  const expectedRollForward = r.beginningPortfolio + r.portfolioGrowth + totalContribs - r.totalWithdrawals - conversionTaxOutflow + portfolioSurplus;

  const rollForwardCheck = check(
    'Portfolio roll-forward',
    'beginning + growth + contributions - withdrawals - conversionTaxOutflow + surplus = ending',
    expectedRollForward,
    r.totalPortfolio,
    3,
    true,
    'INV_PORTFOLIO_ROLLFORWARD',
    'Ending portfolio must roll forward from beginning portfolio, growth, contributions, withdrawals, conversion tax portfolio outflow, and reinvested surplus',
  );

  // 8. Non-Negative Balances & Quantities
  let lowestNegativeVal = 0;
  let negativeFieldKey = '';
  for (const fieldKey of NON_NEGATIVE_ROW_FIELDS) {
    const val = r[fieldKey];
    if (typeof val === 'number' && val < -0.01) {
      if (val < lowestNegativeVal) {
        lowestNegativeVal = val;
        negativeFieldKey = fieldKey;
      }
    }
  }

  const nonNegativeCheck = check(
    'Non-negative balances & quantities',
    'contractually non-negative fields >= 0',
    0,
    lowestNegativeVal < -0.01 ? lowestNegativeVal : 0,
    0.01,
    true,
    'INV_NON_NEGATIVE',
    negativeFieldKey ? `Field ${negativeFieldKey} must be non-negative (received ${r[negativeFieldKey as keyof SimulationRow]})` : 'Financial account balances and transaction values must remain non-negative',
  );

  // 9. Surplus Reinvestment Consistency
  const surplusConflict = r.surplusReinvested > 0.5 && r.unfundedShortfall > 0.5;
  const surplusCheck = check(
    'Surplus reinvestment consistency',
    'surplus > 0 implies shortfall = 0',
    0,
    surplusConflict ? r.surplusReinvested : 0,
    0.5,
    true,
    'INV_SURPLUS_CONSISTENCY',
    'A projection year cannot report both a cash surplus and an unfunded cash shortfall',
  );

  // 10. RMD Bounds
  /**
   * RMD Bounds Identity:
   * rmdAmount <= rmdEligibleBalance
   *
   * Validates against authoritative pre-tax balance available at start of RMD processing (rmdEligibleBalance).
   */
  const rmdEligibleBal = r.rmdEligibleBalance;
  const rmdExceeded = r.rmdAmount > 0 && r.rmdAmount > rmdEligibleBal + 2;
  const zeroBalRmd = r.beginningPortfolio === 0 && r.rmdAmount > 0 && r.preTaxBal === 0;
  const rmdCheck = check(
    'RMD eligible balance bound',
    'rmdAmount <= rmdEligibleBalance',
    0,
    rmdExceeded || zeroBalRmd ? r.rmdAmount : 0,
    1,
    true,
    'INV_RMD_BOUNDS',
    'RMD amount must not exceed eligible pre-tax balances or occur with zero pre-tax portfolio',
  );

  // 11. Roth Conversion Consistency
  /**
   * Roth Conversion Bounds Identity:
   * rothConversion <= preTaxAvailableBeforeConversion
   *
   * Validates against authoritative pre-tax balance available immediately before conversion (preTaxAvailableBeforeConversion).
   */
  const availForConv = r.preTaxAvailableBeforeConversion;
  const convExceeded = r.rothConversion > 0 && r.rothConversion > availForConv + 2;
  const rothConvCheck = check(
    'Roth conversion consistency',
    'rothConversion <= preTaxAvailableBeforeConversion',
    0,
    convExceeded ? r.rothConversion : 0,
    1,
    true,
    'INV_ROTH_CONVERSION',
    'Roth conversion amount cannot exceed available pre-tax account balance',
  );

  // 12. Finite Output Numbers Validation
  let hasNonFinite = false;
  let nonFiniteField = '';
  for (const field of ROW_FIELDS) {
    if (field.numeric) {
      const val = r[field.key as keyof SimulationRow];
      if (typeof val !== 'number' || !Number.isFinite(val) || Number.isNaN(val)) {
        hasNonFinite = true;
        nonFiniteField = field.key;
        break;
      }
    }
  }
  const finiteCheck = check(
    'Finite financial outputs',
    'no NaN, Infinity, or undefined numbers',
    0,
    hasNonFinite ? 1 : 0,
    0,
    true,
    'INV_FINITE_NUMBERS',
    hasNonFinite ? `Field ${nonFiniteField} is non-finite or NaN` : 'All row numeric fields must be valid finite numbers',
  );

  // 13. Deflation Consistency
  const validDeflator = typeof r.inflationDeflator === 'number' && Number.isFinite(r.inflationDeflator) && r.inflationDeflator > 0;
  const expectedReal = validDeflator ? Math.round(r.totalPortfolio / r.inflationDeflator) : 0;
  const deflationCheck = check(
    'Real-dollar deflation consistency',
    'totalPortfolioReal = totalPortfolio / inflationDeflator (inflationDeflator > 0)',
    validDeflator ? expectedReal : 0,
    validDeflator ? r.totalPortfolioReal : 9999,
    validDeflator ? 2 : 0,
    true,
    'INV_DEFLATION_CONSISTENCY',
    !validDeflator ? 'inflationDeflator must be greater than zero' : 'Real dollar total portfolio must equal nominal portfolio divided by cumulative inflation deflator',
  );

  return [
    portfolioBucketsCheck,
    taxComponentsCheck,
    withdrawalSourcesCheck,
    guaranteedIncomeCheck,
    expenseSplitCheck,
    cashFlowCheck,
    rollForwardCheck,
    nonNegativeCheck,
    surplusCheck,
    rmdCheck,
    rothConvCheck,
    finiteCheck,
    deflationCheck,
  ];
}

export function auditRowInvariants(r: SimulationRow): InvariantReport {
  const checks = reconcileRow(r);
  const violations: InvariantViolation[] = [];

  for (const c of checks) {
    if (c.applicable && !c.passed) {
      violations.push({
        code: c.code || 'INV_CHECK_FAILED',
        label: c.label,
        message: `${c.label} failed: expected ${c.expected}, actual ${c.actual} (formula: ${c.formula}). ${c.details || ''}`.trim(),
        expected: c.expected,
        actual: c.actual,
        rowAge: r.age,
        calendarYear: r.calendarYear,
      });
    }
  }

  return {
    passed: violations.length === 0,
    violations,
    checks,
  };
}

export function auditSimulationInvariants(result: SimulationResult): InvariantReport {
  const allViolations: InvariantViolation[] = [];
  const allChecks: ReconciliationCheck[] = [];

  for (const row of result.rows) {
    const rowReport = auditRowInvariants(row);
    allChecks.push(...rowReport.checks);
    if (!rowReport.passed) {
      allViolations.push(...rowReport.violations);
    }
  }

  return {
    passed: allViolations.length === 0,
    violations: allViolations,
    checks: allChecks,
  };
}

export function allChecksPassed(r: SimulationRow): boolean {
  return reconcileRow(r).every((c) => c.passed);
}

/**
 * Optional development/test helper to strictly assert invariants.
 * Throws an Error if any invariant check fails.
 */
export function assertSimulationInvariants(result: SimulationResult): void {
  const report = auditSimulationInvariants(result);
  if (!report.passed) {
    const details = report.violations.map((v) => `[${v.code}] ${v.message} (age ${v.rowAge})`).join('\n');
    throw new Error(`Simulation invariant assertion failed with ${report.violations.length} violation(s):\n${details}`);
  }
}

