/**
 * Memoized access to runSimulation.
 *
 * Six components call runSimulation independently on the same plan, and
 * ScenarioManagerStep calls it inside render loops (three times per plan, per render).
 * At ~1ms per 41-year projection that is ~6ms of duplicated work per keystroke and
 * ~15ms per render on a five-plan comparison.
 *
 * The cache is keyed on the Plan OBJECT IDENTITY, not its contents. Every store action
 * creates a new plan object, so an edit naturally produces a cache miss and a fresh
 * projection. A WeakMap means cached results for discarded plan objects are collected
 * automatically — there is nothing to invalidate and no way for a stale result to
 * outlive the object it was computed from.
 *
 * IMPORTANT: this relies on plans being treated as immutable. If any code mutates a
 * plan in place rather than replacing it, the cache will return the previous result.
 * The store already replaces rather than mutates (see usePlanStore.updatePlan), and
 * createDefaultPlan hands out deep clones.
 */
import { Plan } from '../../types';
import { runSimulation } from './simulationEngine';
import { SimulationResult, SimulationOptions } from './simulationTypes';

const cache = new WeakMap<Plan, Map<string | number, SimulationResult>>();

/** Sentinel for "no override" key. */
const NO_OVERRIDE_KEY = '__NO_OVERRIDE__';

function getCacheKey(optionsOrConversionTarget?: number | SimulationOptions): string | number {
  if (optionsOrConversionTarget === undefined) {
    return NO_OVERRIDE_KEY;
  }
  if (typeof optionsOrConversionTarget === 'number') {
    return Number.isNaN(optionsOrConversionTarget) ? NO_OVERRIDE_KEY : optionsOrConversionTarget;
  }
  if (optionsOrConversionTarget.strategyOverride?.rothConversion?.type === 'none') {
    return 'no_conversion';
  }
  return JSON.stringify(optionsOrConversionTarget);
}

export function getSimulation(
  plan: Plan,
  optionsOrConversionTarget?: number | SimulationOptions
): SimulationResult {
  const key = getCacheKey(optionsOrConversionTarget);

  let byOverride = cache.get(plan);
  if (!byOverride) {
    byOverride = new Map();
    cache.set(plan, byOverride);
  }

  const hit = byOverride.get(key);
  if (hit) return hit;

  const result = runSimulation(plan, optionsOrConversionTarget);
  byOverride.set(key, result);
  return result;
}

/** Test-only escape hatch; not used by application code. */
export function isCached(
  plan: Plan,
  optionsOrConversionTarget?: number | SimulationOptions
): boolean {
  const key = getCacheKey(optionsOrConversionTarget);
  return cache.get(plan)?.has(key) ?? false;
}
