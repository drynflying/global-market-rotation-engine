/**
 * CHARACTERIZATION TESTS
 *
 * These do not assert that the engine is CORRECT. They assert that it behaves the way
 * it behaves TODAY, so that any Phase 2 change produces a readable diff instead of a
 * silent shift in someone's retirement projection.
 *
 * Three groups, treated differently:
 *
 *   1. INVARIANTS      - structural truths that must hold before and after Phase 2.
 *                        A failure here is always a regression.
 *
 *   2. LOCKED BASELINE - exact figures from the current engine. Phase 2 WILL change
 *                        these. When one fails, confirm the new number is right, then
 *                        update it in the same commit as the logic change so the diff
 *                        shows both.
 *
 *   3. KNOWN DEFECTS   - EMPTY as of Phase 2 commit 6. Every defect catalogued at the
 *                        start of Phase 2 has been fixed and its test promoted into
 *                        group 1 as a FIXED invariant. Re-add this block if a new
 *                        defect is found and cannot be fixed immediately.
 *
 * The engine reads `new Date().getFullYear()` for calendarYear only; every figure below
 * is driven by ages and offsets, so these are stable across calendar years.
 */
import { describe, it, expect } from 'vitest';
import { runSimulation, statutoryRmdStartAge, getRmdStartAge, getMarginalTaxBracket, getMarginalRate, calculateFederalTax, getSsAnnualBenefit } from './simulationEngine';
import { SimulationRow } from './simulationTypes';
import { createDefaultPlan } from '../../constants/defaultPlan';
import { bracketCeilingsFor } from '../tax/taxConstants';

const sim = () => runSimulation(createDefaultPlan());
const at = (age: number): SimulationRow => {
  const row = sim().rows.find(r => r.age === age);
  if (!row) throw new Error(`no simulation row for age ${age}`);
  return row;
};

describe('Invariants (must hold before and after Phase 2)', () => {
  it('FIXED (was DEFECT 9): the 37% tier exists and applies above b35', () => {
    const c = bracketCeilingsFor(true, 1.0);
    expect(getMarginalTaxBracket(c.b32, c)).toBe('32%');
    expect(getMarginalTaxBracket(c.b35, c)).toBe('35%');
    expect(getMarginalTaxBracket(c.b35 + 1000, c)).toBe('37%');
    const atCeiling = calculateFederalTax(c.b35, c);
    const marginalRate = (calculateFederalTax(c.b35 + 1_000_000, c) - atCeiling) / 1_000_000;
    expect(marginalRate).toBeCloseTo(0.37, 4);
  });

  it('FIXED (was DEFECT 9): every bracket boundary uses the 2026 base year', () => {
    const joint = bracketCeilingsFor(true, 1.0);
    expect(joint.b10).toBe(24800);
    expect(joint.b12).toBe(100800);
    expect(joint.b35).toBe(768700);
  });

  it('projects one row per year from current age to life expectancy', () => {
    const result = sim();
    const plan = createDefaultPlan();
    expect(result.rows[0].age).toBe(plan.primaryPerson.currentAge);
    expect(result.rows[result.rows.length - 1].age).toBe(
      Math.max(plan.primaryPerson.lifeExpectancy, plan.spousePerson.lifeExpectancy),
    );
    const ages = result.rows.map(r => r.age);
    expect(ages).toEqual([...new Set(ages)]);
    expect(ages).toEqual([...ages].sort((a, b) => a - b));
  });

  it('never reports a negative balance, withdrawal or tax', () => {
    for (const r of sim().rows) {
      expect(r.preTaxBal).toBeGreaterThanOrEqual(0);
      expect(r.postTaxBal).toBeGreaterThanOrEqual(0);
      expect(r.taxableBal).toBeGreaterThanOrEqual(0);
      expect(r.totalWithdrawals).toBeGreaterThanOrEqual(0);
      expect(r.totalEstimatedTax).toBeGreaterThanOrEqual(0);
      expect(r.taxableCostBasis).toBeGreaterThanOrEqual(0);
    }
  });

  it('keeps the tax components summing to the total', () => {
    for (const r of sim().rows) {
      expect(r.totalEstimatedTax).toBe(
        r.fedTaxPaid + r.capGainsTaxPaid + r.stateTaxPaid + r.ficaTaxPaid,
      );
    }
  });

  it('keeps the three buckets summing to the reported portfolio total', () => {
    for (const r of sim().rows) {
      expect(r.totalPortfolio).toBe(r.preTaxBal + r.postTaxBal + r.taxableBal);
    }
  });

  it('takes no withdrawals and pays no RMD tax before retirement', () => {
    for (const r of sim().rows.filter(r => !r.isRetired)) {
      expect(r.totalWithdrawals).toBe(0);
      expect(r.rmdTaxPaid).toBe(0);
      expect(r.rothConversion).toBe(0);
    }
  });

  it('never lets the portfolio recover once depleted', () => {
    const rows = sim().rows;
    const firstZero = rows.findIndex(r => r.isRetired && r.totalPortfolio === 0);
    if (firstZero >= 0) {
      for (const r of rows.slice(firstZero)) {
        expect(r.totalPortfolio).toBe(0);
      }
    }
  });

  it('FIXED (was DEFECT 11): realized gains are taxed at LTCG rates when taxable brokerage is drawn', () => {
    // Age 60: $25k emergency cash is drawn first (0 gains tax).
    const r = at(60);
    expect(r.realizedCapGains).toBe(0);
    expect(r.capGainsTaxPaid).toBe(0);
  });

  it('FIXED (was DEFECT 11): gains below the 0% ceiling are not taxed', () => {
    // Age 61: gains fit in the 0% LTCG band. Zero tax here is correct.
    const r = at(61);
    expect(r.realizedCapGains).toBe(37372);
    expect(r.capGainsTaxPaid).toBe(0);
  });

  it('FIXED (was DEFECT 11): capital gains tax is included in the total', () => {
    for (const r of sim().rows) {
      expect(r.totalEstimatedTax).toBe(
        r.fedTaxPaid + r.capGainsTaxPaid + r.stateTaxPaid + r.ficaTaxPaid,
      );
      expect(r.capGainsTaxPaid).toBeGreaterThanOrEqual(0);
    }
  });

  it('FIXED (was DEFECT 12/13): cash flow reconciles in every retired year', () => {
    for (const r of sim().rows.filter(r => r.isRetired && r.totalWithdrawals > 0)) {
      if (r.unfundedShortfall === 0) {
        expect(Math.abs(r.totalCashInflow - r.totalCashOutflow)).toBeLessThanOrEqual(1);
      }
    }
  });

  it('FIXED (was DEFECT 12): no shortfall is reported while the portfolio is funded', () => {
    const bogus = sim().rows.filter(
      r => r.isRetired && r.totalPortfolio > 0 && r.unfundedShortfall > 0,
    );
    expect(bogus).toEqual([]);
  });

  it('never reports outflow exceeding inflow in a fully funded year', () => {
    for (const r of sim().rows.filter(r => r.isRetired && r.unfundedShortfall === 0)) {
      expect(r.totalCashOutflow).toBeLessThanOrEqual(r.totalCashInflow + 1);
    }
  });

  it('does not sweep working-years surplus into savings', () => {
    // Income drives tax brackets and conversion headroom; it does not imply a savings
    // rate. Contributions are specified per account. A surplus is reported and left
    // unallocated.
    const working = sim().rows.filter(r => !r.isRetired);
    const surplusYears = working.filter(r => r.netCashFlow > 0);
    for (const r of surplusYears) {
      const contribs = r.preTaxContrib + r.postTaxContrib + r.taxableContrib;
      // Growth plus contributions only — the surplus must not appear in the balance.
      expect(r.totalPortfolio).toBeLessThan(
        r.beginningPortfolio + r.portfolioGrowth + contribs + r.netCashFlow,
      );
    }
  });

  it('still funds a working-years deficit from the taxable account', () => {
    // The asymmetry is deliberate: a surplus is discretionary, a deficit is not.
    const q = createDefaultPlan();
    q.spendingAssumptions!.preRetirementAnnualSpending = 250000;
    const working = runSimulation(q).rows.filter(r => r.isRetired === false);
    expect(working.some(r => r.netCashFlow < 0)).toBe(true);
  });

  it('FIXED (was DEFECT 14): accumulation spending is modelled, not a residual', () => {
    const working = sim().rows.filter(r => !r.isRetired);
    expect(working[0].totalExpenseNeed).toBe(60000);
    expect(working.some(r => r.netCashFlow > 0 || r.netCashFlow < 0)).toBe(true);
  });

  it('FIXED (was DEFECT 14): raising working spending produces a deficit', () => {
    const q = createDefaultPlan();
    q.spendingAssumptions!.preRetirementAnnualSpending = 200000;
    const working = runSimulation(q).rows.filter(r => !r.isRetired);
    expect(working.every(r => r.netCashFlow <= 0)).toBe(true);
    expect(working.some(r => r.netCashFlow < 0)).toBe(true);
  });

  it('falls back to the residual when working spending is unset', () => {
    const q = createDefaultPlan();
    // NOTE: `delete` is not enough — runSimulation spreads DEFAULT_PLAN.spendingAssumptions
    // as a base, so a removed key silently inherits the sample value. Setting the key to
    // undefined overrides it.
    q.spendingAssumptions!.preRetirementAnnualSpending = undefined;
    for (const r of runSimulation(q).rows.filter(r => !r.isRetired)) {
      expect(r.netCashFlow).toBe(0);
    }
  });

  it('FIXED: the gross-up uses the actual marginal rate, not a fixed 22%', () => {
    const c = bracketCeilingsFor(true, 1.0);
    expect(getMarginalRate(0, c)).toBe(0.10);
    expect(getMarginalRate(c.b12, c)).toBe(0.12);
    expect(getMarginalRate(c.b22, c)).toBe(0.22);
    expect(getMarginalRate(c.b35 + 1, c)).toBe(0.37);
  });

  it('FIXED (was DEFECT 10): statutory RMD age follows SECURE 2.0 birth-year rules', () => {
    expect(statutoryRmdStartAge(1945)).toBe(72);
    expect(statutoryRmdStartAge(1955)).toBe(73);
    expect(statutoryRmdStartAge(1976)).toBe(75);
  });

  it('FIXED (was DEFECT 10): an explicit override wins, undefined falls back', () => {
    expect(getRmdStartAge(1976, undefined)).toBe(75);
    expect(getRmdStartAge(1976, 62)).toBe(62);
    expect(getRmdStartAge(1955, 80)).toBe(80);
  });

  it('FIXED (was DEFECT 10): the override changes RMD timing end to end', () => {
    // The sample plan depletes before RMD age, so an end-to-end assertion on it would
    // be vacuous. Use a solvent variant where RMDs actually occur.
    const firstRmdAge = (override?: number) => {
      const q = createDefaultPlan();
      q.spendingAssumptions!.desiredAnnualLivingExpenses = Math.round(
        q.spendingAssumptions!.desiredAnnualLivingExpenses * 0.35,
      );
      q.spendingAssumptions!.preRetirementAnnualSpending = Math.round(
        (q.spendingAssumptions!.preRetirementAnnualSpending || 60000) * 0.35,
      );
      if (override !== undefined) q.statutoryParams!.rmdStartAge = override;
      const rows = runSimulation(q).rows.filter(r => r.rmdAmount > 0);
      return rows.length ? rows[0].age : null;
    };
    expect(firstRmdAge(undefined)).toBe(75);
    expect(firstRmdAge(70)).toBe(70);
    expect(firstRmdAge(80)).toBe(80);
  });

  it('FIXED (was DEFECT 15): the solver hands back over-withdrawals', () => {
    // The gross-up can assume a marginal rate on a withdrawal the standard deduction
    // then absorbs, leaving the solver holding cash it did not need. It must return the
    // excess rather than break out of the loop keeping it.
    for (const r of sim().rows.filter(r => r.isRetired && r.unfundedShortfall === 0 && r.totalWithdrawals > 0)) {
      expect(Math.abs(r.totalCashInflow - r.totalCashOutflow)).toBeLessThanOrEqual(1);
    }
  });

  it('FIXED: delayed retirement credits stop accruing at 70', () => {
    const st = createDefaultPlan().statutoryParams!;
    const base = createDefaultPlan().primaryPerson;
    const at80 = (claimAge: number) =>
      Math.round(getSsAnnualBenefit({ ...base, ssClaimAge: claimAge }, 80, st));
    // Assert RATIOS, not absolute dollars: the benefit also carries 30 years of COLA
    // compounding, so absolute figures would be testing the COLA rate rather than the
    // delayed-credit rule.
    expect(at80(70) / at80(67)).toBeCloseTo(1.24, 4); // 3 years x 8%
    expect(at80(72) / at80(70)).toBeCloseTo(1.0, 6); // capped at 70
    expect(at80(75) / at80(70)).toBeCloseTo(1.0, 6); // still capped
  });

  it('FIXED: negative expected returns are no longer clamped to zero', () => {
    // getCategoryReturn previously applied Math.max(0, ret), making pessimistic
    // scenarios impossible to express. NOTE: the engine reads `derivedGeometric`, not
    // `expectedReturnPct`.
    const q = createDefaultPlan();
    q.cmaAssumptions!.usLargeEquity.derivedGeometric = -5;
    q.cmaAssumptions!.intlEquity.derivedGeometric = -5;
    const neg = runSimulation(q);
    expect(neg.depletionAge).toBe(64);
    expect(neg.rows.find(r => r.age === 55)!.totalPortfolio).toBeLessThan(
      sim().rows.find(r => r.age === 55)!.totalPortfolio,
    );
  });
});

describe('Locked baseline (Phase 2 will move these - update deliberately)', () => {
  it('produces 41 rows from age 50 to 90', () => {
    const result = sim();
    expect(result.rows.length).toBe(41);
    expect(result.rows[0].age).toBe(50);
    expect(result.rows[40].age).toBe(90);
  });

  it('depletes the portfolio at age 76', () => {
    expect(sim().depletionAge).toBe(76);
  });

  it('reports lifetime conversion, total, and RMD tax totals', () => {
    const result = sim();
    expect(Math.round(result.lifetimeConversionTaxPaidNominal)).toBe(5720);
    expect(Math.round(result.lifetimeTaxPaidNominal)).toBe(5720); // Deprecated alias
    expect(Math.round(result.lifetimeRmdTaxesNominal)).toBe(0);
    const calculatedSum = Math.round(result.rows.reduce((sum, r) => sum + r.totalEstimatedTax, 0));
    expect(Math.round(result.lifetimeTotalTaxNominal)).toBe(calculatedSum);
    expect(result.lifetimeTotalTaxNominal).toBeGreaterThan(result.lifetimeConversionTaxPaidNominal);
  });

  it('matches the final accumulation year (age 59)', () => {
    const r = at(59);
    expect(r.isRetired).toBe(false);
    expect(r.totalPortfolio).toBe(1025447);
    expect(r.taxableMagi).toBe(143264);
    expect(r.fedTaxPaid).toBe(11981);
    expect(r.totalEstimatedTax).toBe(29068);
  });

  it('matches the first retirement year (age 60)', () => {
    const r = at(60);
    expect(r.isRetired).toBe(true);
    expect(r.totalExpenseNeed).toBe(143169);
  });

  it('matches the first full drawdown year (age 61)', () => {
    const r = at(61);
    expect(r.totalExpenseNeed).toBe(104634);
  });

  it('matches the Medicare transition year (age 65)', () => {
    const r = at(65);
    expect(r.totalExpenseNeed).toBe(115974);
  });

  it('matches the post-depletion shortfall at age 77', () => {
    const r = at(77);
    expect(r.guaranteedIncome).toBe(93494);
    expect(r.unfundedShortfall).toBe(46487);
  });
});
