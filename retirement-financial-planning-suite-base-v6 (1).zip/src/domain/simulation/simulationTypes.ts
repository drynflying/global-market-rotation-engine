/**
 * Simulation Result & Row Contracts
 *
 * Shared type definitions for simulation output rows, summary results, and engine options.
 * Extracted to a neutral layer to prevent inverted dependency directions.
 */

import { RetirementStrategyOverride, RetirementStrategy } from '../strategy/strategyTypes';
import { RothConversionDecision } from '../strategy/rothConversionPolicy';

export interface SimulationRow {
  age: number;
  calendarYear: number;
  isRetired: boolean;
  baseLiving: number;
  essentialExpense: number;
  discretionaryExpense: number;
  healthExpense: number;
  specialExpense: number;
  debtService: number;
  totalExpenseNeed: number;
  w2Income: number;
  guaranteedIncome: number;
  primarySs: number;
  spouseSs: number;
  pensionIncome: number;
  rmdAmount: number;
  rothConversion: number;
  taxableWd: number;
  preTaxWd: number;
  postTaxWd: number;
  totalWithdrawals: number;
  preTaxContrib: number;
  postTaxContrib: number;
  taxableContrib: number;
  beginningPortfolio: number;
  portfolioGrowth: number;
  preTaxBal: number;
  postTaxBal: number;
  taxableBal: number;
  totalPortfolio: number;
  provisionalIncome: number;
  taxableSs: number;
  taxableMagi: number;
  taxBracket: string;
  irmaaBracket: string;
  effectiveTaxRate: number;
  fedTaxPaid: number;
  capGainsTaxPaid: number;
  // --- Transparency: drivers the engine applies, exposed so a year can be audited ---
  /** General inflation applied to expenses and thresholds this year (%). */
  inflationRatePct: number;
  /** Cumulative inflation deflator applied this year. */
  inflationDeflator: number;
  /** Blended portfolio return applied this year (%). */
  portfolioReturnPct: number;
  /** Standard deduction used, inflated to this year's dollars. */
  standardDeductionUsed: number;
  /**
   * Ordinary taxable income AFTER the standard deduction.
   */
  taxableIncomeAfterDeduction: number;
  /** End portfolio expressed in today's purchasing power. */
  totalPortfolioReal: number;
  /** Ordinary income dollars before the next marginal bracket. */
  ordinaryHeadroom: number;
  /** Income dollars before long-term gains leave their current LTCG band. */
  ltcgHeadroom: number;
  /** MAGI dollars before the next IRMAA tier. Zero before Medicare eligibility. */
  irmaaHeadroom: number;
  stateTaxPaid: number;
  ficaTaxPaid: number;
  conversionTaxPaid: number;
  rmdTaxPaid: number;
  conversionTaxPortfolioOutflow: number;
  rmdEligibleBalance: number;
  preTaxAvailableBeforeConversion: number;
  totalEstimatedTax: number;
  totalCashInflow: number;
  totalCashOutflow: number;
  netCashFlow: number;
  unfundedShortfall: number;
  /**
   * Retirement-year income that exceeded spending plus tax and was reinvested into the taxable account.
   */
  surplusReinvested: number;
  withdrawalRatePct: number;
  spouseAge?: number;
  irmaaSurcharge: number;
  /** Tax year of the MAGI used to determine IRMAA tier, surcharge, and headroom (typically calendarYear - 2). */
  irmaaLookbackYear?: number;
  /** Lookback MAGI from tax year (N-2) evaluated against IRMAA thresholds. */
  irmaaLookbackMagi?: number;
  realizedCapGains: number;
  taxableCostBasis: number;
  solvencyStatus: 'Solvent' | 'Insolvent' | 'Depleted';
  annotation?: string;
  rothConversionDecision?: RothConversionDecision;
}

export interface SimulationResult {
  rows: SimulationRow[];
  effectiveStrategy?: RetirementStrategy;
  /** Total tax paid attributable specifically to Roth conversions across all simulation years (Nominal $) */
  lifetimeConversionTaxPaidNominal: number;
  /** Total tax paid attributable specifically to Roth conversions across all simulation years (Real $) */
  lifetimeConversionTaxPaidReal: number;
  /** Total tax paid attributable specifically to mandatory RMDs across all simulation years (Nominal $) */
  lifetimeRmdTaxesNominal: number;
  /** Total tax paid attributable specifically to mandatory RMDs across all simulation years (Real $) */
  lifetimeRmdTaxesReal: number;
  /**
   * Total lifetime tax liability (Federal + State + FICA + Cap Gains) (Nominal $).
   */
  lifetimeTotalTaxNominal: number;
  /** Total lifetime tax liability (Federal + State + FICA + Cap Gains) (Real $) */
  lifetimeTotalTaxReal: number;

  /** Deprecated alias for `lifetimeConversionTaxPaidNominal` */
  lifetimeTaxPaidNominal: number;
  /** Deprecated alias for `lifetimeConversionTaxPaidReal` */
  lifetimeTaxPaidReal: number;

  depletionAge?: number;
}

export interface SimulationOptions {
  /** @deprecated Use strategyOverride instead */
  overrideConversionTarget?: number;
  referenceCalendarYear?: number;
  strategyOverride?: RetirementStrategyOverride;
}
