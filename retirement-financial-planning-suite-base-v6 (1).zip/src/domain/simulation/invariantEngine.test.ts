import { describe, it, expect } from 'vitest';
import { runSimulation } from './simulationEngine';
import { auditSimulationInvariants, auditRowInvariants } from './rowReconciliation';
import { createDefaultPlan } from '../../constants/defaultPlan';

describe('Financial Engine Invariants & Reconciliation Test Suite', () => {
  it('1. Normal retirement plan passes all invariant checks', () => {
    const plan = createDefaultPlan();
    const result = runSimulation(plan);
    const report = auditSimulationInvariants(result);

    expect(report.violations).toEqual([]);
    expect(report.passed).toBe(true);
  });

  it('2. No-spouse plan passes all invariant checks', () => {
    const plan = createDefaultPlan();
    plan.hasSpouse = false;
    plan.filingStatus = 'single';
    if (plan.incomeStreams) {
      plan.incomeStreams = plan.incomeStreams.filter((s) => s.owner !== 'spouse');
    }

    const result = runSimulation(plan);
    const report = auditSimulationInvariants(result);
    expect(report.violations).toEqual([]);
    expect(report.passed).toBe(true);
  });

  it('3. Zero investment balance plan passes all invariant checks', () => {
    const plan = createDefaultPlan();
    plan.accounts = [];

    const result = runSimulation(plan);
    const report = auditSimulationInvariants(result);

    expect(report.violations).toEqual([]);
    expect(report.passed).toBe(true);
  });

  it('4. High-spending depletion plan passes all invariant checks', () => {
    const plan = createDefaultPlan();
    plan.spendingAssumptions!.desiredAnnualLivingExpenses = 350000;

    const result = runSimulation(plan);
    const report = auditSimulationInvariants(result);

    expect(result.depletionAge).toBeDefined();
    expect(report.violations).toEqual([]);
    expect(report.passed).toBe(true);
  });

  it('5. Roth conversion scenario passes all invariant checks', () => {
    const plan = createDefaultPlan();
    plan.spendingAssumptions!.annualRothConversionTarget = 60000;
    plan.spendingAssumptions!.rothConversionStartAge = 60;
    plan.spendingAssumptions!.rothConversionEndAge = 70;

    const result = runSimulation(plan);
    const report = auditSimulationInvariants(result);

    const convRows = result.rows.filter((r) => r.rothConversion > 0);
    expect(convRows.length).toBeGreaterThan(0);
    expect(report.violations).toEqual([]);
    expect(report.passed).toBe(true);
  });

  it('6. RMD scenario passes all invariant checks', () => {
    const plan = createDefaultPlan();
    plan.primaryPerson.currentAge = 72;
    plan.primaryPerson.retirementAge = 65;

    const result = runSimulation(plan);
    const report = auditSimulationInvariants(result);

    const rmdRows = result.rows.filter((r) => r.rmdAmount > 0);
    expect(rmdRows.length).toBeGreaterThan(0);
    expect(report.violations).toEqual([]);
    expect(report.passed).toBe(true);
  });

  it('7. ACA subsidy model scenario passes all invariant checks', () => {
    const plan = createDefaultPlan();
    plan.primaryPerson.currentAge = 60;
    plan.primaryPerson.retirementAge = 60;
    if (plan.acaAssumptions) {
      plan.acaAssumptions.useSubsidyModel = true;
      plan.acaAssumptions.baseMonthlyPremiumAge21 = 450;
      plan.acaAssumptions.householdSize = 2;
    }

    const result = runSimulation(plan);
    const report = auditSimulationInvariants(result);

    expect(report.violations).toEqual([]);
    expect(report.passed).toBe(true);
  });

  it('8. IRMAA surcharge scenario passes all invariant checks', () => {
    const plan = createDefaultPlan();
    plan.primaryPerson.currentAge = 66;
    plan.primaryPerson.retirementAge = 65;
    plan.spendingAssumptions!.annualRothConversionTarget = 250000;
    plan.spendingAssumptions!.rothConversionStartAge = 66;
    plan.spendingAssumptions!.rothConversionEndAge = 75;

    const result = runSimulation(plan);
    const report = auditSimulationInvariants(result);

    const irmaaRows = result.rows.filter((r) => r.irmaaSurcharge > 0);
    expect(irmaaRows.length).toBeGreaterThan(0);
    expect(report.violations).toEqual([]);
    expect(report.passed).toBe(true);
  });

  it('9. Retirement-year surplus scenario passes all invariant checks', () => {
    const plan = createDefaultPlan();
    plan.spendingAssumptions!.desiredAnnualLivingExpenses = 12000;
    plan.spendingAssumptions!.desiredAnnualHealthcareExpenses = 1000;

    const result = runSimulation(plan);
    const report = auditSimulationInvariants(result);

    const surplusRows = result.rows.filter((r) => r.isRetired && r.surplusReinvested > 0);
    expect(surplusRows.length).toBeGreaterThan(0);
    expect(report.violations).toEqual([]);
    expect(report.passed).toBe(true);
  });

  it('10. Zero-income year scenario passes all invariant checks', () => {
    const plan = createDefaultPlan();
    plan.incomeStreams = [];
    plan.primaryPerson.ssMonthlyBenefit = 0;
    if (plan.spousePerson) plan.spousePerson.ssMonthlyBenefit = 0;

    const result = runSimulation(plan);
    const report = auditSimulationInvariants(result);

    expect(report.violations).toEqual([]);
    expect(report.passed).toBe(true);
  });

  it('11. Unusually large portfolio and income values scenario passes all invariant checks', () => {
    const plan = createDefaultPlan();
    plan.accounts = [
      {
        id: 'mega-1',
        name: 'Mega PreTax',
        owner: 'primary',
        type: 'pre-tax',
        balance: 500000000,
        annualContribution: 0,
        isCatchUpEligible: false,
      },
      {
        id: 'mega-2',
        name: 'Mega Taxable',
        owner: 'primary',
        type: 'taxable',
        balance: 200000000,
        annualContribution: 0,
        isCatchUpEligible: false,
      },
    ];
    plan.spendingAssumptions!.desiredAnnualLivingExpenses = 10000000;

    const result = runSimulation(plan);
    const report = auditSimulationInvariants(result);

    expect(report.violations).toEqual([]);
    expect(report.passed).toBe(true);
  });

  describe('Deliberate Invariant Violation Negative Tests', () => {
    it('detects INV_PORTFOLIO_BUCKETS violation', () => {
      const plan = createDefaultPlan();
      const result = runSimulation(plan);
      const badRow = { ...result.rows[0], totalPortfolio: result.rows[0].totalPortfolio + 100000 };
      const report = auditRowInvariants(badRow);
      expect(report.passed).toBe(false);
      expect(report.violations.some((v) => v.code === 'INV_PORTFOLIO_BUCKETS')).toBe(true);
    });

    it('detects INV_TAX_COMPONENTS violation', () => {
      const plan = createDefaultPlan();
      const result = runSimulation(plan);
      const badRow = { ...result.rows[0], fedTaxPaid: result.rows[0].fedTaxPaid + 5000 };
      const report = auditRowInvariants(badRow);
      expect(report.passed).toBe(false);
      expect(report.violations.some((v) => v.code === 'INV_TAX_COMPONENTS')).toBe(true);
    });

    it('detects INV_WITHDRAWAL_SOURCES violation', () => {
      const plan = createDefaultPlan();
      const result = runSimulation(plan);
      const badRow = { ...result.rows[0], taxableWd: result.rows[0].taxableWd + 5000 };
      const report = auditRowInvariants(badRow);
      expect(report.passed).toBe(false);
      expect(report.violations.some((v) => v.code === 'INV_WITHDRAWAL_SOURCES')).toBe(true);
    });

    it('detects INV_GUARANTEED_INCOME violation', () => {
      const plan = createDefaultPlan();
      const result = runSimulation(plan);
      const badRow = { ...result.rows[0], primarySs: result.rows[0].primarySs + 5000 };
      const report = auditRowInvariants(badRow);
      expect(report.passed).toBe(false);
      expect(report.violations.some((v) => v.code === 'INV_GUARANTEED_INCOME')).toBe(true);
    });

    it('detects INV_EXPENSE_SPLIT violation', () => {
      const plan = createDefaultPlan();
      const result = runSimulation(plan);
      const retiredRow = result.rows.find((r) => r.isRetired) ?? { ...result.rows[0], isRetired: true };
      const badRow = { ...retiredRow, essentialExpense: retiredRow.essentialExpense + 5000 };
      const report = auditRowInvariants(badRow);
      expect(report.passed).toBe(false);
      expect(report.violations.some((v) => v.code === 'INV_EXPENSE_SPLIT')).toBe(true);
    });

    it('detects INV_CASH_FLOW violation', () => {
      const plan = createDefaultPlan();
      const result = runSimulation(plan);
      const badRow = { ...result.rows[0], totalCashInflow: result.rows[0].totalCashInflow + 5000 };
      const report = auditRowInvariants(badRow);
      expect(report.passed).toBe(false);
      expect(report.violations.some((v) => v.code === 'INV_CASH_FLOW')).toBe(true);
    });

    it('detects INV_PORTFOLIO_ROLLFORWARD violation when totalPortfolio is corrupted while bucket reconciliation passes', () => {
      const plan = createDefaultPlan();
      const result = runSimulation(plan);
      const row = result.rows[0];
      // Corrupt ending totalPortfolio AND preTaxBal equally so bucket sum matches totalPortfolio
      const badRow = {
        ...row,
        totalPortfolio: row.totalPortfolio + 10000,
        preTaxBal: row.preTaxBal + 10000,
      };
      const report = auditRowInvariants(badRow);
      expect(report.passed).toBe(false);
      // Buckets pass because sum(preTax, postTax, taxable) == totalPortfolio
      expect(report.violations.some((v) => v.code === 'INV_PORTFOLIO_BUCKETS')).toBe(false);
      // Rollforward fails because ending portfolio does not match rollforward equation
      expect(report.violations.some((v) => v.code === 'INV_PORTFOLIO_ROLLFORWARD')).toBe(true);
    });

    it('detects INV_PORTFOLIO_ROLLFORWARD violation when conversionTaxPortfolioOutflow is corrupted in Roth conversion row', () => {
      const plan = createDefaultPlan();
      plan.spendingAssumptions!.annualRothConversionTarget = 60000;
      plan.spendingAssumptions!.rothConversionStartAge = 60;
      plan.spendingAssumptions!.rothConversionEndAge = 70;
      const result = runSimulation(plan);
      const convRow = result.rows.find((r) => r.rothConversion > 0);
      expect(convRow).toBeDefined();

      const badRow = {
        ...convRow!,
        conversionTaxPortfolioOutflow: convRow!.conversionTaxPortfolioOutflow + 5000,
      };
      const report = auditRowInvariants(badRow);
      expect(report.passed).toBe(false);
      expect(report.violations.some((v) => v.code === 'INV_PORTFOLIO_ROLLFORWARD')).toBe(true);
    });

    it('detects INV_NON_NEGATIVE violation', () => {
      const plan = createDefaultPlan();
      const result = runSimulation(plan);
      const badRow = { ...result.rows[0], preTaxBal: -100 };
      const report = auditRowInvariants(badRow);
      expect(report.passed).toBe(false);
      expect(report.violations.some((v) => v.code === 'INV_NON_NEGATIVE')).toBe(true);
    });

    it('detects INV_SURPLUS_CONSISTENCY violation', () => {
      const plan = createDefaultPlan();
      const result = runSimulation(plan);
      const badRow = { ...result.rows[0], surplusReinvested: 5000, unfundedShortfall: 5000 };
      const report = auditRowInvariants(badRow);
      expect(report.passed).toBe(false);
      expect(report.violations.some((v) => v.code === 'INV_SURPLUS_CONSISTENCY')).toBe(true);
    });

    it('detects INV_RMD_BOUNDS violation', () => {
      const plan = createDefaultPlan();
      plan.primaryPerson.currentAge = 72;
      plan.primaryPerson.retirementAge = 65;
      const result = runSimulation(plan);
      const rmdRow = result.rows.find((r) => r.rmdAmount > 0);
      expect(rmdRow).toBeDefined();

      const badRow = { ...rmdRow!, rmdAmount: rmdRow!.rmdEligibleBalance + 10000 };
      const report = auditRowInvariants(badRow);
      expect(report.passed).toBe(false);
      expect(report.violations.some((v) => v.code === 'INV_RMD_BOUNDS')).toBe(true);
    });

    it('detects INV_ROTH_CONVERSION violation', () => {
      const plan = createDefaultPlan();
      plan.spendingAssumptions!.annualRothConversionTarget = 60000;
      plan.spendingAssumptions!.rothConversionStartAge = 60;
      plan.spendingAssumptions!.rothConversionEndAge = 70;
      const result = runSimulation(plan);
      const convRow = result.rows.find((r) => r.rothConversion > 0);
      expect(convRow).toBeDefined();

      const badRow = { ...convRow!, rothConversion: convRow!.preTaxAvailableBeforeConversion + 10000 };
      const report = auditRowInvariants(badRow);
      expect(report.passed).toBe(false);
      expect(report.violations.some((v) => v.code === 'INV_ROTH_CONVERSION')).toBe(true);
    });

    it('detects INV_FINITE_NUMBERS for NaN, Infinity, -Infinity, and new audit fields', () => {
      const plan = createDefaultPlan();
      const result = runSimulation(plan);
      const baseRow = result.rows[0];

      // NaN
      const nanRow = { ...baseRow, fedTaxPaid: NaN };
      expect(auditRowInvariants(nanRow).violations.some((v) => v.code === 'INV_FINITE_NUMBERS')).toBe(true);

      // Infinity
      const infRow = { ...baseRow, totalPortfolio: Infinity };
      expect(auditRowInvariants(infRow).violations.some((v) => v.code === 'INV_FINITE_NUMBERS')).toBe(true);

      // -Infinity
      const negInfRow = { ...baseRow, preTaxBal: -Infinity };
      expect(auditRowInvariants(negInfRow).violations.some((v) => v.code === 'INV_FINITE_NUMBERS')).toBe(true);

      // New audit fields: rmdEligibleBalance
      const nanRmdRow = { ...baseRow, rmdEligibleBalance: NaN };
      expect(auditRowInvariants(nanRmdRow).violations.some((v) => v.code === 'INV_FINITE_NUMBERS')).toBe(true);

      // New audit fields: preTaxAvailableBeforeConversion
      const infConvRow = { ...baseRow, preTaxAvailableBeforeConversion: Infinity };
      expect(auditRowInvariants(infConvRow).violations.some((v) => v.code === 'INV_FINITE_NUMBERS')).toBe(true);

      // Audit field: conversionTaxPortfolioOutflow
      const nanOutflowRow = { ...baseRow, conversionTaxPortfolioOutflow: NaN };
      expect(auditRowInvariants(nanOutflowRow).violations.some((v) => v.code === 'INV_FINITE_NUMBERS')).toBe(true);
    });

    it('validates INV_DEFLATION_CONSISTENCY across edge cases', () => {
      const plan = createDefaultPlan();
      const result = runSimulation(plan);
      const baseRow = result.rows[0];

      // inflationDeflator = 1
      const deflator1Row = { ...baseRow, inflationDeflator: 1, totalPortfolioReal: baseRow.totalPortfolio };
      expect(auditRowInvariants(deflator1Row).violations.some((v) => v.code === 'INV_DEFLATION_CONSISTENCY')).toBe(false);

      // inflationDeflator > 1
      const deflator105Row = { ...baseRow, inflationDeflator: 1.05, totalPortfolioReal: Math.round(baseRow.totalPortfolio / 1.05) };
      expect(auditRowInvariants(deflator105Row).violations.some((v) => v.code === 'INV_DEFLATION_CONSISTENCY')).toBe(false);

      // inflationDeflator = 0 (fails without crashing)
      const deflator0Row = { ...baseRow, inflationDeflator: 0 };
      const report0 = auditRowInvariants(deflator0Row);
      expect(report0.passed).toBe(false);
      expect(report0.violations.some((v) => v.code === 'INV_DEFLATION_CONSISTENCY')).toBe(true);

      // inflationDeflator < 0 (fails without crashing)
      const deflatorNegRow = { ...baseRow, inflationDeflator: -0.5 };
      const reportNeg = auditRowInvariants(deflatorNegRow);
      expect(reportNeg.passed).toBe(false);
      expect(reportNeg.violations.some((v) => v.code === 'INV_DEFLATION_CONSISTENCY')).toBe(true);

      // Corrupted totalPortfolioReal
      const corruptedRealRow = { ...deflator105Row, totalPortfolioReal: deflator105Row.totalPortfolioReal + 5000 };
      const reportCorrupt = auditRowInvariants(corruptedRealRow);
      expect(reportCorrupt.passed).toBe(false);
      expect(reportCorrupt.violations.some((v) => v.code === 'INV_DEFLATION_CONSISTENCY')).toBe(true);
    });
  });
});
