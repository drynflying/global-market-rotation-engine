/**
 * Declarative registry of every SimulationRow field, for export and display.
 *
 * The CSV export was previously a hand-maintained list of headers paired with a
 * hand-maintained list of value expressions. It drifted: capGainsTaxPaid (added when
 * capital gains became taxable), baseLiving, essentialExpense, discretionaryExpense and
 * debtService were all missing from the audit export while being present on the row.
 *
 * Declaring the columns once, here, makes that drift a test failure instead of a silent
 * omission — rowFields.test.ts asserts every key of SimulationRow is either exported or
 * explicitly listed as excluded.
 *
 * To add a field to the export: add it to the row, then add it here. Nothing else.
 */
import { SimulationRow } from './simulationTypes';

export type FieldGroup =
  | 'Identity'
  | 'Expenses'
  | 'Income'
  | 'Withdrawals'
  | 'Contributions'
  | 'Balances'
  | 'Tax'
  | 'Cash flow'
  | 'Drivers';

export interface RowField {
  key: keyof SimulationRow;
  label: string;
  group: FieldGroup;
  /** Included in the default ("as shown") export that mirrors the on-screen table. */
  summary: boolean;
  /** Numeric columns are deflated when exporting in real dollars; text is not. */
  numeric: boolean;
}

export const ROW_FIELDS: readonly RowField[] = [
  { key: 'calendarYear', label: 'Calendar Year', group: 'Identity', summary: true, numeric: false },
  { key: 'age', label: 'Age', group: 'Identity', summary: true, numeric: false },
  { key: 'isRetired', label: 'Is Retired', group: 'Identity', summary: false, numeric: false },
  { key: 'spouseAge', label: 'Spouse Age', group: 'Identity', summary: true, numeric: false },
  { key: 'solvencyStatus', label: 'Solvency Status', group: 'Identity', summary: true, numeric: false },
  { key: 'annotation', label: 'Milestone Annotation', group: 'Identity', summary: true, numeric: false },

  // Drivers — the percentages and thresholds the engine applied, exposed so a year can
  // be audited without inferring them from the arithmetic.
  { key: 'inflationRatePct', label: 'Inflation Rate (%)', group: 'Drivers', summary: false, numeric: false },
  { key: 'inflationDeflator', label: 'Inflation Deflator', group: 'Drivers', summary: false, numeric: false },
  { key: 'portfolioReturnPct', label: 'Portfolio Return (%)', group: 'Drivers', summary: false, numeric: false },
  { key: 'standardDeductionUsed', label: 'Standard Deduction ($)', group: 'Drivers', summary: false, numeric: true },
  { key: 'taxableIncomeAfterDeduction', label: 'Taxable Income After Deduction ($)', group: 'Drivers', summary: true, numeric: true },
  { key: 'totalPortfolioReal', label: 'End Portfolio (Real $)', group: 'Drivers', summary: true, numeric: false },
  { key: 'ordinaryHeadroom', label: 'Ordinary Bracket Headroom ($)', group: 'Drivers', summary: false, numeric: true },
  { key: 'ltcgHeadroom', label: 'LTCG Band Headroom ($)', group: 'Drivers', summary: false, numeric: true },
  { key: 'irmaaHeadroom', label: 'IRMAA Tier Headroom ($)', group: 'Drivers', summary: false, numeric: true },
  { key: 'rmdEligibleBalance', label: 'RMD Eligible Balance ($)', group: 'Drivers', summary: false, numeric: true },
  { key: 'preTaxAvailableBeforeConversion', label: 'Pre-Tax Available Before Conversion ($)', group: 'Drivers', summary: false, numeric: true },

  { key: 'baseLiving', label: 'Base Living ($)', group: 'Expenses', summary: false, numeric: true },
  { key: 'essentialExpense', label: 'Essential Expense ($)', group: 'Expenses', summary: false, numeric: true },
  { key: 'discretionaryExpense', label: 'Discretionary Expense ($)', group: 'Expenses', summary: false, numeric: true },
  { key: 'healthExpense', label: 'Healthcare Expense ($)', group: 'Expenses', summary: true, numeric: true },
  { key: 'specialExpense', label: 'Special Expense ($)', group: 'Expenses', summary: true, numeric: true },
  { key: 'debtService', label: 'Debt Service ($)', group: 'Expenses', summary: false, numeric: true },
  { key: 'totalExpenseNeed', label: 'Total Expense Need ($)', group: 'Expenses', summary: true, numeric: true },

  { key: 'w2Income', label: 'W-2 Salary Income ($)', group: 'Income', summary: true, numeric: true },
  { key: 'guaranteedIncome', label: 'Guaranteed Income ($)', group: 'Income', summary: true, numeric: true },
  { key: 'primarySs', label: 'Primary SS ($)', group: 'Income', summary: true, numeric: true },
  { key: 'spouseSs', label: 'Spouse SS ($)', group: 'Income', summary: true, numeric: true },
  { key: 'pensionIncome', label: 'Pension Income ($)', group: 'Income', summary: true, numeric: true },

  { key: 'rmdAmount', label: 'RMD Amount ($)', group: 'Withdrawals', summary: true, numeric: true },
  { key: 'rothConversion', label: 'Roth Conversion ($)', group: 'Withdrawals', summary: true, numeric: true },
  { key: 'taxableWd', label: 'Taxable Withdrawal ($)', group: 'Withdrawals', summary: true, numeric: true },
  { key: 'preTaxWd', label: 'Pre-Tax Withdrawal ($)', group: 'Withdrawals', summary: true, numeric: true },
  { key: 'postTaxWd', label: 'Roth Withdrawal ($)', group: 'Withdrawals', summary: true, numeric: true },
  { key: 'totalWithdrawals', label: 'Total Withdrawals ($)', group: 'Withdrawals', summary: true, numeric: true },
  { key: 'withdrawalRatePct', label: 'Withdrawal Rate (%)', group: 'Withdrawals', summary: true, numeric: false },

  { key: 'preTaxContrib', label: 'Pre-Tax Contribution ($)', group: 'Contributions', summary: true, numeric: true },
  { key: 'postTaxContrib', label: 'Roth Contribution ($)', group: 'Contributions', summary: true, numeric: true },
  { key: 'taxableContrib', label: 'Taxable Contribution ($)', group: 'Contributions', summary: true, numeric: true },

  { key: 'beginningPortfolio', label: 'Beginning Portfolio ($)', group: 'Balances', summary: true, numeric: true },
  { key: 'portfolioGrowth', label: 'Portfolio Growth ($)', group: 'Balances', summary: true, numeric: true },
  { key: 'preTaxBal', label: 'Pre-Tax Balance ($)', group: 'Balances', summary: true, numeric: true },
  { key: 'postTaxBal', label: 'Roth Balance ($)', group: 'Balances', summary: true, numeric: true },
  { key: 'taxableBal', label: 'Taxable Balance ($)', group: 'Balances', summary: true, numeric: true },
  { key: 'taxableCostBasis', label: 'Taxable Cost Basis ($)', group: 'Balances', summary: true, numeric: true },
  { key: 'totalPortfolio', label: 'End Total Portfolio ($)', group: 'Balances', summary: true, numeric: true },

  { key: 'provisionalIncome', label: 'Provisional Income ($)', group: 'Tax', summary: true, numeric: true },
  { key: 'taxableSs', label: 'Taxable SS ($)', group: 'Tax', summary: true, numeric: true },
  { key: 'realizedCapGains', label: 'Realized Cap Gains ($)', group: 'Tax', summary: true, numeric: true },
  { key: 'taxableMagi', label: 'MAGI Before Deduction ($)', group: 'Tax', summary: true, numeric: true },
  { key: 'taxBracket', label: 'Marginal Tax Bracket', group: 'Tax', summary: true, numeric: false },
  { key: 'irmaaBracket', label: 'IRMAA Bracket', group: 'Tax', summary: true, numeric: false },
  { key: 'irmaaSurcharge', label: 'IRMAA Surcharge ($)', group: 'Tax', summary: true, numeric: true },
  { key: 'irmaaLookbackYear', label: 'IRMAA Lookback Tax Year', group: 'Tax', summary: false, numeric: true },
  { key: 'irmaaLookbackMagi', label: 'IRMAA Lookback MAGI ($)', group: 'Tax', summary: false, numeric: true },
  { key: 'effectiveTaxRate', label: 'Effective Tax Rate (%)', group: 'Tax', summary: true, numeric: false },
  { key: 'fedTaxPaid', label: 'Federal Tax ($)', group: 'Tax', summary: true, numeric: true },
  { key: 'capGainsTaxPaid', label: 'Capital Gains Tax ($)', group: 'Tax', summary: false, numeric: true },
  { key: 'stateTaxPaid', label: 'State Income Tax ($)', group: 'Tax', summary: true, numeric: true },
  { key: 'ficaTaxPaid', label: 'FICA Tax ($)', group: 'Tax', summary: true, numeric: true },
  { key: 'totalEstimatedTax', label: 'Total Estimated Tax ($)', group: 'Tax', summary: true, numeric: true },
  { key: 'conversionTaxPaid', label: 'Conversion Tax Paid ($)', group: 'Tax', summary: true, numeric: true },
  { key: 'conversionTaxPortfolioOutflow', label: 'Conversion Tax Portfolio Outflow ($)', group: 'Tax', summary: false, numeric: true },
  { key: 'rmdTaxPaid', label: 'RMD Tax Paid ($)', group: 'Tax', summary: true, numeric: true },

  { key: 'totalCashInflow', label: 'Total Cash Inflow ($)', group: 'Cash flow', summary: true, numeric: true },
  { key: 'totalCashOutflow', label: 'Total Cash Outflow ($)', group: 'Cash flow', summary: true, numeric: true },
  { key: 'netCashFlow', label: 'Net Cash Flow ($)', group: 'Cash flow', summary: true, numeric: true },
  { key: 'unfundedShortfall', label: 'Unfunded Shortfall ($)', group: 'Cash flow', summary: true, numeric: true },
  { key: 'surplusReinvested', label: 'Surplus Reinvested ($)', group: 'Cash flow', summary: true, numeric: true },
] as const;

/**
 * Row keys deliberately kept out of the export, with the reason.
 * rowFields.test.ts fails if a SimulationRow key is in neither this list nor ROW_FIELDS.
 */
export const EXCLUDED_ROW_KEYS: Readonly<Record<string, string>> = {
  // (none currently — every field is exported)
};

export const SUMMARY_FIELDS = ROW_FIELDS.filter((f) => f.summary);

export type ExportScope = 'summary' | 'all';

export function fieldsForScope(scope: ExportScope): readonly RowField[] {
  return scope === 'all' ? ROW_FIELDS : SUMMARY_FIELDS;
}
