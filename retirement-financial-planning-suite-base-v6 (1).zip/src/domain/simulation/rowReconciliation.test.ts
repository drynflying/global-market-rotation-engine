import { describe, it, expect } from 'vitest';
import { reconcileRow, allChecksPassed } from './rowReconciliation';
import { runSimulation } from './simulationEngine';
import { getSimulation } from './simulationCache';
import { createDefaultPlan } from '../../constants/defaultPlan';

const rows = () => getSimulation(createDefaultPlan()).rows;

describe('rowReconciliation', () => {
  it('passes all accounting identity checks for every projection row', () => {
    const simulationRows = rows();
    expect(simulationRows.length).toBeGreaterThan(0);
    for (const row of simulationRows) {
      const checks = reconcileRow(row);
      const failed = checks.filter((c) => !c.passed);
      expect(
        failed,
        `Row age ${row.age} failed checks: ${failed.map((f) => f.label).join(', ')}`
      ).toEqual([]);
      expect(allChecksPassed(row)).toBe(true);
    }
  });

  it('reconciles portfolio buckets correctly', () => {
    const row = rows()[0];
    const checks = reconcileRow(row);
    const bucketCheck = checks.find((c) => c.label === 'Portfolio buckets');
    expect(bucketCheck).toBeDefined();
    expect(bucketCheck?.passed).toBe(true);
    expect(bucketCheck?.expected).toBe(
      row.preTaxBal + row.postTaxBal + row.taxableBal
    );
    expect(bucketCheck?.actual).toBe(row.totalPortfolio);
  });
});

describe('surplus is accounted for, not hidden', () => {
  it('closes the cash flow identity in a surplus year', () => {
    // Constructed rather than taken from the sample plan: whether the sample happens
    // to run a surplus depends on its spending level, and that moves as assumptions
    // change. A very low spending target guarantees one.
    const q = createDefaultPlan();
    q.spendingAssumptions!.desiredAnnualLivingExpenses = 20000;
    q.spendingAssumptions!.desiredAnnualHealthcareExpenses = 2000;
    const surplusYears = runSimulation(q).rows.filter(
      r => r.isRetired && r.surplusReinvested > 0,
    );
    expect(surplusYears.length).toBeGreaterThan(0);
    for (const r of surplusYears) {
      expect(r.totalCashInflow - (r.totalCashOutflow + r.surplusReinvested)).toBeLessThanOrEqual(1);
    }
  });

  it('applies the cash flow check to every funded retired year', () => {
    // Guards against the check being narrowed again. It must not be conditional on
    // withdrawals being present.
    const funded = rows().filter(r => r.isRetired && r.unfundedShortfall === 0);
    const zeroWithdrawalYears = funded.filter(r => r.totalWithdrawals === 0);
    for (const r of zeroWithdrawalYears) {
      const cash = reconcileRow(r).find(c => c.label === 'Cash flow')!;
      expect(cash.applicable).toBe(true);
      expect(cash.passed).toBe(true);
    }
  });

  it('never reinvests a surplus in a year with a shortfall', () => {
    for (const r of rows()) {
      if (r.unfundedShortfall > 0) expect(r.surplusReinvested).toBe(0);
    }
  });
});
