import { describe, it, expect } from 'vitest';
import { 
  getSsAnnualBenefit, 
  getRmdFactor, 
  getSmileMultiplier, 
  calculateFederalTax, 
  calculateTaxableSs,
  getRmdStartAge,
  runSimulation 
} from './simulationEngine';
import { DEFAULT_PLAN } from '../../constants/defaultPlan';
import { bracketCeilingsFor } from '../tax/taxConstants';

describe('Financial Simulation Engine', () => {
  const statutoryParams = DEFAULT_PLAN.statutoryParams!;
  
  describe('Account Return Weighting (Zero-Balance Exclusion)', () => {
    it('uses funded account allocation exclusively when a zero-balance account exists', () => {
      const plan = {
        ...DEFAULT_PLAN,
        accounts: [
          {
            id: 'funded-pretax',
            name: 'Funded IRA',
            type: 'pre-tax' as const,
            owner: 'primary' as const,
            balance: 100000,
            annualContribution: 0,
            allocation: { usEquityPct: 100, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 0 },
          },
          {
            id: 'zero-pretax',
            name: 'Zero IRA',
            type: 'pre-tax' as const,
            owner: 'primary' as const,
            balance: 0,
            annualContribution: 0,
            allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 100 },
          },
        ],
      };

      const result = runSimulation(plan);
      const row1 = result.rows[0];
      // US Equity derived geometric return minus fee drag (5.70% - 0.10% = 5.60%)
      const usEqReturn = (DEFAULT_PLAN.cmaAssumptions?.usLargeEquity.derivedGeometric ?? 5.70) - 0.10;
      expect(row1.portfolioReturnPct).toBeCloseTo(usEqReturn, 2);
    });

    it('ignores several zero-balance accounts alongside a funded account', () => {
      const plan = {
        ...DEFAULT_PLAN,
        accounts: [
          {
            id: 'funded-taxable',
            name: 'Funded Brokerage',
            type: 'taxable' as const,
            owner: 'primary' as const,
            balance: 500000,
            annualContribution: 0,
            allocation: { usEquityPct: 0, intlEquityPct: 100, goldPct: 0, bondsPct: 0, cashPct: 0 },
          },
          {
            id: 'zero-1',
            name: 'Zero 1',
            type: 'taxable' as const,
            owner: 'primary' as const,
            balance: 0,
            annualContribution: 0,
            allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 100 },
          },
          {
            id: 'zero-2',
            name: 'Zero 2',
            type: 'taxable' as const,
            owner: 'primary' as const,
            balance: -100, // Negative balance edge case
            annualContribution: 0,
            allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 100, bondsPct: 0, cashPct: 0 },
          },
        ],
      };

      const result = runSimulation(plan);
      const row1 = result.rows[0];
      // Intl Equity derived geometric return minus fee drag (7.00% - 0.10% = 6.90%)
      const intlEqReturn = (DEFAULT_PLAN.cmaAssumptions?.intlEquity.derivedGeometric ?? 7.00) - 0.10;
      expect(row1.portfolioReturnPct).toBeCloseTo(intlEqReturn, 2);
    });

    it('returns zero overall portfolio return when all accounts have zero balance', () => {
      const plan = {
        ...DEFAULT_PLAN,
        accounts: [
          {
            id: 'zero-pretax-1',
            name: 'Zero IRA 1',
            type: 'pre-tax' as const,
            owner: 'primary' as const,
            balance: 0,
            annualContribution: 0,
            allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 100 },
          },
          {
            id: 'zero-pretax-2',
            name: 'Zero IRA 2',
            type: 'pre-tax' as const,
            owner: 'primary' as const,
            balance: 0,
            annualContribution: 0,
            allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 100, bondsPct: 0, cashPct: 0 },
          },
        ],
      };

      const result = runSimulation(plan);
      // Overall portfolio return is 0 when starting portfolio is $0
      expect(result.rows[0].portfolioReturnPct).toBe(0);
    });
  });

  describe('Social Security Benefit Calculations', () => {
    const primaryPerson = DEFAULT_PLAN.primaryPerson;

    it('returns 0 prior to claim age', () => {
      const benefit = getSsAnnualBenefit(primaryPerson, 62, statutoryParams);
      expect(benefit).toBe(0); // Claim age is 67 in default plan
    });

    it('calculates full benefit at Full Retirement Age (67)', () => {
      const benefit = getSsAnnualBenefit(primaryPerson, 67, statutoryParams);
      expect(benefit).toBeGreaterThan(38000);
    });

    it('applies early claim reduction at age 62', () => {
      const earlyPerson = { ...primaryPerson, ssClaimAge: 62, currentAge: 62, includeSsProjectedReduction: false };
      const benefit = getSsAnnualBenefit(earlyPerson, 62, statutoryParams);
      expect(benefit).toBeLessThan(2500 * 12);
      expect(Math.round(benefit)).toBe(21000);
    });

    it('applies delayed retirement credits at age 70', () => {
      const delayedPerson = { ...primaryPerson, ssClaimAge: 70, currentAge: 70, includeSsProjectedReduction: false };
      const benefit = getSsAnnualBenefit(delayedPerson, 70, statutoryParams);
      expect(Math.round(benefit)).toBe(37200);
    });
  });

  describe('IRS Provisional Income & SS Taxation', () => {
    it('returns 0 taxable SS when provisional income is below base threshold ($32k joint)', () => {
      const taxableSs = calculateTaxableSs(30000, 10000, true);
      expect(taxableSs).toBe(0);
    });

    it('calculates progressive taxable SS between $32k and $44k joint threshold', () => {
      const taxableSs = calculateTaxableSs(30000, 20000, true); // Prov inc = 20k + 15k = 35k
      expect(taxableSs).toBe(1500); // 50% of (35k - 32k)
    });

    it('caps taxable SS at 85% of gross SS for higher provisional incomes', () => {
      const taxableSs = calculateTaxableSs(40000, 80000, true); // Prov inc = 80k + 20k = 100k
      expect(taxableSs).toBe(34000); // 85% of 40,000
    });
  });

  describe('SECURE 2.0 RMD Rules', () => {
    it('determines RMD age 75 for cohorts born in 1960 or later', () => {
      expect(getRmdStartAge(1965)).toBe(75);
    });

    it('determines RMD age 73 for cohorts born 1951-1959', () => {
      expect(getRmdStartAge(1955)).toBe(73);
    });

    it('returns 0 for age prior to RMD start age', () => {
      expect(getRmdFactor(72, 75)).toBe(0);
    });

    it('returns correct uniform lifetime divisors at milestone ages', () => {
      expect(getRmdFactor(75, 75)).toBe(24.6);
      expect(getRmdFactor(80, 75)).toBe(20.2);
    });
  });

  describe('Blanchett Retirement Smile Multiplier', () => {
    it('applies 1.05 for Go-Go years (first 7 years of retirement)', () => {
      expect(getSmileMultiplier(62, 57, 'blanchett_smile')).toBe(1.05);
    });

    it('applies 0.82 for Slow-Go years (years 8-17 of retirement)', () => {
      expect(getSmileMultiplier(70, 57, 'blanchett_smile')).toBe(0.82);
    });

    it('applies 1.10 for No-Go healthcare years (years 18+)', () => {
      expect(getSmileMultiplier(80, 57, 'blanchett_smile')).toBe(1.10);
    });

    it('handles constant spending model', () => {
      expect(getSmileMultiplier(80, 57, 'constant')).toBe(1.0);
    });
  });

  describe('Federal Tax Estimation', () => {
    const brackets = bracketCeilingsFor(true, 1.0);

    it('returns 0 tax for taxable income at or below zero', () => {
      expect(calculateFederalTax(0, brackets)).toBe(0);
    });

    it('calculates progressive federal bracket taxes', () => {
      const tax10k = calculateFederalTax(10000, brackets);
      expect(tax10k).toBe(1000); // 10% bracket
    });
  });

  describe('Full Simulation Engine Execution', () => {
    it('runs multi-year projection without throwing', () => {
      const result = runSimulation(DEFAULT_PLAN);
      expect(result.rows.length).toBeGreaterThan(20);
      expect(result.lifetimeTaxPaidNominal).toBeGreaterThanOrEqual(0);
      expect(result.rows[0].age).toBe(DEFAULT_PLAN.primaryPerson.currentAge);
    });

    it('audits years 2033 through 2036 ensuring withdrawals, income, tax and MAGI align', () => {
      const startYear = 2026;
      const currentAge = DEFAULT_PLAN.primaryPerson.currentAge; // 52
      
      const sim = runSimulation(DEFAULT_PLAN);

      [2033, 2034, 2035, 2036].forEach(targetYear => {
        const targetAge = currentAge + (targetYear - startYear);
        const row = sim.rows.find(r => r.age === targetAge);
        expect(row).toBeDefined();

        if (row) {
          if (row.isRetired) {
            const totalWd = row.taxableWd + row.preTaxWd + row.postTaxWd;
            expect(totalWd).toBeGreaterThanOrEqual(0);
            expect(row.taxableMagi).toBeGreaterThanOrEqual(0);
          } else {
            expect(row.taxableWd).toBe(0);
            expect(row.preTaxWd).toBe(0);
            expect(row.postTaxWd).toBe(0);
            expect(row.totalExpenseNeed).toBeGreaterThanOrEqual(0);
          }
        }
      });
    });
    it('verifies RMD tax is 0 in pre-RMD years and separate tax components exist', () => {
      const sim = runSimulation(DEFAULT_PLAN);
      const preRmdRows = sim.rows.filter(r => r.rmdAmount === 0);
      preRmdRows.forEach(r => {
        expect(r.rmdTaxPaid).toBe(0);
      });

      // Verify tax component separation
      sim.rows.forEach(r => {
        expect(r.fedTaxPaid).toBeGreaterThanOrEqual(0);
        expect(r.stateTaxPaid).toBeGreaterThanOrEqual(0);
        expect(r.ficaTaxPaid).toBeGreaterThanOrEqual(0);
        expect(r.totalEstimatedTax).toBe(
          r.fedTaxPaid + r.capGainsTaxPaid + r.stateTaxPaid + r.ficaTaxPaid,
        );
      });
    });

    it('verifies FICA tax is calculated when salary income is non-zero in transition/retirement year', () => {
      const customPlan = {
        ...DEFAULT_PLAN,
        incomeStreams: [
          {
            id: 'salary1',
            name: 'Consulting Income',
            type: 'salary' as const,
            owner: 'primary' as const,
            amount: 100000,
            startAge: 60,
            endAge: 62,
            growthRatePct: 0,
            taxability: 'fully_taxable' as const
          }
        ]
      };
      const sim = runSimulation(customPlan);
      const rowAt60 = sim.rows.find(r => r.age === 60);
      expect(rowAt60).toBeDefined();
      if (rowAt60) {
        expect(rowAt60.w2Income).toBeGreaterThan(0);
        expect(rowAt60.ficaTaxPaid).toBeGreaterThan(0);
      }
    });

    it('verifies P3 fields: spouseAge, taxableCostBasis, realizedCapGains, irmaaSurcharge', () => {
      const spousePlan = {
        ...DEFAULT_PLAN,
        hasSpouse: true,
        spousePerson: {
          name: 'Jane Doe',
          currentAge: 52, // 3 years younger than primary age 55
          retirementAge: 65,
          lifeExpectancy: 95,
          ssClaimAge: 67,
          ssMonthlyBenefit: 2500,
        }
      };
      const sim = runSimulation(spousePlan);
      const rowAt50 = sim.rows.find(r => r.age === 50);
      expect(rowAt50).toBeDefined();
      if (rowAt50) {
        expect(rowAt50.spouseAge).toBe(52);
        expect(rowAt50.taxableCostBasis).toBeGreaterThanOrEqual(0);
        expect(rowAt50.irmaaSurcharge).toBeGreaterThanOrEqual(0);
      }

      sim.rows.forEach(r => {
        expect(r.realizedCapGains).toBeGreaterThanOrEqual(0);
        expect(r.taxableCostBasis).toBeGreaterThanOrEqual(0);
      });
    });

    describe('Engine Determinism (Phase 3)', () => {
      it('produces identical outputs regardless of wall-clock time when plan input is fixed', () => {
        const res1 = runSimulation(DEFAULT_PLAN, { referenceCalendarYear: 2026 });
        const res2 = runSimulation(DEFAULT_PLAN, { referenceCalendarYear: 2026 });

        expect(res1.lifetimeTaxPaidNominal).toBe(res2.lifetimeTaxPaidNominal);
        expect(res1.rows.length).toBe(res2.rows.length);
        expect(res1.rows[0].calendarYear).toBe(2026);
      });

      it('allows custom reference calendar year via startCalendarYear or options', () => {
        const customPlan = { ...DEFAULT_PLAN, startCalendarYear: 2028 };
        const res = runSimulation(customPlan);
        expect(res.rows[0].calendarYear).toBe(2028);

        const resOverride = runSimulation(DEFAULT_PLAN, { referenceCalendarYear: 2030 });
        expect(resOverride.rows[0].calendarYear).toBe(2030);
      });
    });
  });
});
