import { describe, it, expect } from 'vitest';
import { runSimulation } from './simulationEngine';
import { DEFAULT_PLAN } from '../../constants/defaultPlan';
import { Plan, AccountItem } from '../../types';

describe('Cash Account Behavior & Return Isolation', () => {
  const createTestPlan = (accounts: AccountItem[], overrides: Partial<Plan> = {}): Plan => {
    return {
      ...DEFAULT_PLAN,
      primaryPerson: {
        ...DEFAULT_PLAN.primaryPerson,
        currentAge: 60,
        retirementAge: 65,
        lifeExpectancy: 70,
      },
      hasSpouse: false,
      accounts,
      spendingAssumptions: {
        ...DEFAULT_PLAN.spendingAssumptions!,
        desiredAnnualLivingExpenses: 0,
      },
      cmaAssumptions: {
        ...DEFAULT_PLAN.cmaAssumptions!,
        usLargeEquity: { arithmeticReturn: 8.0, volatility: 15.0, volatilityDrag: -1.0, derivedGeometric: 7.0 },
        intlEquity: { arithmeticReturn: 7.0, volatility: 18.0, volatilityDrag: -1.0, derivedGeometric: 6.0 },
        intermediateBonds: { arithmeticReturn: 4.0, volatility: 6.0, volatilityDrag: -0.5, derivedGeometric: 3.5 },
        cashEquivalents: { arithmeticReturn: 3.0, volatility: 1.0, volatilityDrag: 0.0, derivedGeometric: 3.0 },
        annualPortfolioFeeDrag: 0.10,
      },
      ...overrides,
    };
  };

  it('Case 1: $100,000 taxable brokerage, no cash', () => {
    const plan = createTestPlan([
      {
        id: 'acc-taxable-1',
        name: 'Brokerage',
        owner: 'primary',
        type: 'taxable',
        balance: 100000,
        annualContribution: 0,
        employerMatchValue: 0,
        allocation: { usEquityPct: 100, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 0 },
      },
    ]);

    const result = runSimulation(plan);
    const row1 = result.rows[0];

    // US Large Equity derivedGeometric = 7.0% minus 0.10% fee drag = 6.90%
    // Expected growth = 6,900
    expect(row1.taxableBal).toBe(106900);
    expect(row1.portfolioGrowth).toBe(6900);
    expect(row1.portfolioReturnPct).toBeCloseTo(6.9, 2);
  });

  it('Case 2: $100,000 cash, no taxable brokerage', () => {
    const plan = createTestPlan([
      {
        id: 'acc-cash-1',
        name: 'High Yield Savings',
        owner: 'primary',
        type: 'cash',
        balance: 100000,
        annualContribution: 0,
        employerMatchValue: 0,
        allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 100 },
      },
    ]);

    const result = runSimulation(plan);
    const row1 = result.rows[0];

    // Cash Equivalents derivedGeometric = 3.0% minus 0.10% fee drag = 2.90%
    // Expected growth = 2,900
    expect(row1.taxableBal).toBe(102900);
    expect(row1.portfolioGrowth).toBe(2900);
    expect(row1.portfolioReturnPct).toBeCloseTo(2.9, 2);
  });

  it('Case 3: Mixed taxable brokerage ($100k @ 7%) and cash ($100k @ 3%)', () => {
    const plan = createTestPlan([
      {
        id: 'acc-taxable-1',
        name: 'Brokerage',
        owner: 'primary',
        type: 'taxable',
        balance: 100000,
        annualContribution: 0,
        employerMatchValue: 0,
        allocation: { usEquityPct: 100, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 0 },
      },
      {
        id: 'acc-cash-1',
        name: 'Savings',
        owner: 'primary',
        type: 'cash',
        balance: 100000,
        annualContribution: 0,
        employerMatchValue: 0,
        allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 100 },
      },
    ]);

    const result = runSimulation(plan);
    const row1 = result.rows[0];

    // Taxable growth = 100,000 * 6.9% = 6,900
    // Cash growth = 100,000 * 2.9% = 2,900
    // Total growth = 9,800
    // Blended return = 9,800 / 200,000 = 4.9%
    expect(row1.taxableBal).toBe(209800);
    expect(row1.portfolioGrowth).toBe(9800);
    expect(row1.portfolioReturnPct).toBeCloseTo(4.9, 2);
  });

  it('Case 4: Zero cash account', () => {
    const plan = createTestPlan([
      {
        id: 'acc-taxable-1',
        name: 'Brokerage',
        owner: 'primary',
        type: 'taxable',
        balance: 50000,
        annualContribution: 0,
        employerMatchValue: 0,
        allocation: { usEquityPct: 100, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 0 },
      },
      {
        id: 'acc-cash-1',
        name: 'Empty Checking',
        owner: 'primary',
        type: 'cash',
        balance: 0,
        annualContribution: 0,
        employerMatchValue: 0,
        allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 100 },
      },
    ]);

    const result = runSimulation(plan);
    const row1 = result.rows[0];

    // Growth on 50k at 6.9% = 3,450
    expect(row1.taxableBal).toBe(53450);
    expect(row1.portfolioGrowth).toBe(3450);
    expect(row1.portfolioReturnPct).toBeCloseTo(6.9, 2);
  });

  it('Case 5: Cash with explicit updated cash return assumption', () => {
    const plan = createTestPlan(
      [
        {
          id: 'acc-cash-1',
          name: 'High Yield Savings',
          owner: 'primary',
          type: 'cash',
          balance: 100000,
          annualContribution: 0,
          employerMatchValue: 0,
          allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 100 },
        },
      ],
      {
        cmaAssumptions: {
          ...DEFAULT_PLAN.cmaAssumptions!,
          cashEquivalents: { arithmeticReturn: 4.5, volatility: 1.0, volatilityDrag: 0.0, derivedGeometric: 4.5 },
          annualPortfolioFeeDrag: 0.10,
        },
      }
    );

    const result = runSimulation(plan);
    const row1 = result.rows[0];

    // Cash growth at updated 4.5% rate minus 0.10% fee drag = 4.4% (4,400)
    expect(row1.taxableBal).toBe(104400);
    expect(row1.portfolioGrowth).toBe(4400);
    expect(row1.portfolioReturnPct).toBeCloseTo(4.4, 2);
  });

  it('Case 6: Withdrawal ordering - Cash is drawn first before brokerage with zero capital gains tax', () => {
    const plan = createTestPlan([
      {
        id: 'acc-taxable-1',
        name: 'Appreciated Brokerage',
        owner: 'primary',
        type: 'taxable',
        balance: 100000,
        annualContribution: 0,
        employerMatchValue: 0,
        allocation: { usEquityPct: 100, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 0 },
      },
      {
        id: 'acc-cash-1',
        name: 'Emergency Savings',
        owner: 'primary',
        type: 'cash',
        balance: 50000,
        annualContribution: 0,
        employerMatchValue: 0,
        allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 100 },
      },
    ]);

    // Force a retirement year withdrawal of $20,000 net living expenses
    plan.incomeStreams = [];
    plan.primaryPerson.currentAge = 65; // Retired
    plan.spendingAssumptions = {
      ...plan.spendingAssumptions!,
      desiredAnnualLivingExpenses: 20000,
    };
    const result = runSimulation(plan);
    const row1 = result.rows[0];

    // Living expenses ($20,000 * 1.05) + healthcare ($15,000) = $36,000 gross withdrawal needed.
    // Liquid cash available ($50,000) fully covers the $36,000 withdrawal.
    // Because cash has basis ratio 1.0, realized capital gains = 0.
    expect(row1.realizedCapGains).toBe(0);
    expect(row1.taxableWd).toBe(36000);
  });

  it('Case 7: Taxable Brokerage Cost Basis Separation (Release Blocker)', () => {
    // $100k brokerage (basis $100k) + $100k cash.
    // In year 1, brokerage grows from $100k to $150k (basis stays $100k).
    // Cash stays at $100k.
    // If $100k cash is withdrawn, brokerage basis MUST remain $100k.
    // When $30k brokerage is subsequently withdrawn, basis ratio must be 100k/150k = 66.67%,
    // realized gain = $10k ($30k - $20k basis).
    const plan = createTestPlan([
      {
        id: 'acc-taxable-1',
        name: 'Brokerage',
        owner: 'primary',
        type: 'taxable',
        balance: 100000,
        annualContribution: 0,
        employerMatchValue: 0,
        allocation: { usEquityPct: 100, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 0 },
      },
      {
        id: 'acc-cash-1',
        name: 'Cash',
        owner: 'primary',
        type: 'cash',
        balance: 100000,
        annualContribution: 0,
        employerMatchValue: 0,
        allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 100 },
      },
    ]);

    const result = runSimulation(plan);
    const row1 = result.rows[0];

    // Starting brokerage basis is $100,000 (NOT $200,000).
    expect(row1.taxableCostBasis).toBe(100000);
  });

  it('Case 8: Unmodeled accounts (HSA, Real Estate) are excluded from modeled investment buckets', () => {
    const plan = createTestPlan([
      {
        id: 'acc-re-1',
        name: 'Rental Property',
        owner: 'primary',
        type: 'real-estate',
        balance: 500000,
        annualContribution: 0,
        employerMatchValue: 0,
        allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 0 },
      },
      {
        id: 'acc-hsa-1',
        name: 'HSA',
        owner: 'primary',
        type: 'hsa',
        balance: 50000,
        annualContribution: 0,
        employerMatchValue: 0,
        allocation: { usEquityPct: 100, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 0 },
      },
      {
        id: 'acc-taxable-1',
        name: 'Brokerage',
        owner: 'primary',
        type: 'taxable',
        balance: 100000,
        annualContribution: 0,
        employerMatchValue: 0,
        allocation: { usEquityPct: 100, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 0 },
      },
    ]);

    const result = runSimulation(plan);
    const row1 = result.rows[0];

    // Modeled liquid taxable bucket should only contain the $100k taxable brokerage, not real estate or HSA.
    expect(row1.taxableBal).toBe(106900); // $100k + 6.9% growth
  });

  it('Case 9: Retirement surplus routing - Case A (Cash at target, surplus goes to brokerage)', () => {
    const plan = createTestPlan(
      [
        {
          id: 'acc-taxable-1',
          name: 'Brokerage',
          owner: 'primary',
          type: 'taxable',
          balance: 1000000,
          annualContribution: 0,
          employerMatchValue: 0,
          allocation: { usEquityPct: 100, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 0 },
        },
        {
          id: 'acc-cash-1',
          name: 'Reserve Cash',
          owner: 'primary',
          type: 'cash',
          balance: 10000,
          annualContribution: 0,
          employerMatchValue: 0,
          allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 100 },
        },
      ],
      {
        primaryPerson: {
          ...DEFAULT_PLAN.primaryPerson,
          currentAge: 65,
          retirementAge: 65,
          lifeExpectancy: 70,
        },
        incomeStreams: [
          {
            id: 'pension-1',
            name: 'Pension',
            owner: 'primary',
            type: 'pension',
            amount: 80000,
            startAge: 65,
            endAge: 90,
            growthRatePct: 0,
            taxability: 'fully_taxable',
          },
        ],
        spendingAssumptions: {
          ...DEFAULT_PLAN.spendingAssumptions!,
          desiredAnnualLivingExpenses: 20000,
          preRetirementAnnualSpending: 0,
        },
      }
    );

    const result = runSimulation(plan);
    const row1 = result.rows[0];

    expect(row1.surplusReinvested).toBeGreaterThan(0);
    // Because initial cash target is $10,000 and starting cash is $10,000, surplus must go to brokerage, not cash.
    // Cash balance after growth: $10,000 * 1.03 = $10,300.
    // Check that surplus went to taxable brokerage balance.
    expect(row1.taxableBal).toBeGreaterThan(1000000);
  });

  it('Case 10: Working-year brokerage sale calculates realized capital gains and basis removed', () => {
    const plan = createTestPlan(
      [
        {
          id: 'acc-cash-1',
          name: 'Checking',
          owner: 'primary',
          type: 'cash',
          balance: 5000,
          annualContribution: 0,
          employerMatchValue: 0,
          allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 100 },
        },
        {
          id: 'acc-taxable-1',
          name: 'Brokerage',
          owner: 'primary',
          type: 'taxable',
          balance: 100000,
          annualContribution: 0,
          employerMatchValue: 0,
          allocation: { usEquityPct: 100, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 0 },
        },
      ],
      {
        primaryPerson: {
          ...DEFAULT_PLAN.primaryPerson,
          currentAge: 50,
          retirementAge: 65,
          lifeExpectancy: 85,
        },
        incomeStreams: [
          {
            id: 'inc-1',
            name: 'Salary',
            owner: 'primary',
            type: 'salary',
            amount: 60000,
            startAge: 50,
            endAge: 65,
            growthRatePct: 0,
            taxability: 'fully_taxable',
          },
        ],
        spendingAssumptions: {
          ...DEFAULT_PLAN.spendingAssumptions!,
          preRetirementAnnualSpending: 120000, // Explicit high spending forces working deficit
        },
      }
    );

    const result = runSimulation(plan);
    const row1 = result.rows[0];

    // Working deficit forces cash draw first ($5,000 + growth), then brokerage draw
    expect(row1.isRetired).toBe(false);
    expect(row1.netCashFlow).toBeLessThan(0);
    expect(row1.realizedCapGains).toBeGreaterThan(0);
    expect(row1.taxableCostBasis).toBeLessThan(100000);
    expect(row1.taxableMagi).toBeGreaterThan(row1.w2Income);
  });

  it('Case 11: Retirement surplus replenishes cash to target first, then routes remainder to brokerage', () => {
    const plan = createTestPlan(
      [
        {
          id: 'acc-cash-1',
          name: 'Low Cash',
          owner: 'primary',
          type: 'cash',
          balance: 2000, // Below target cash reserve
          annualContribution: 0,
          employerMatchValue: 0,
          allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 100 },
        },
        {
          id: 'acc-taxable-1',
          name: 'Brokerage',
          owner: 'primary',
          type: 'taxable',
          balance: 50000,
          annualContribution: 0,
          employerMatchValue: 0,
          allocation: { usEquityPct: 100, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 0 },
        },
      ],
      {
        primaryPerson: {
          ...DEFAULT_PLAN.primaryPerson,
          currentAge: 65,
          retirementAge: 65,
          lifeExpectancy: 70,
        },
        incomeStreams: [
          {
            id: 'pension-1',
            name: 'Pension',
            owner: 'primary',
            type: 'pension',
            amount: 100000,
            startAge: 65,
            endAge: 90,
            growthRatePct: 0,
            taxability: 'fully_taxable',
          },
        ],
        spendingAssumptions: {
          ...DEFAULT_PLAN.spendingAssumptions!,
          desiredAnnualLivingExpenses: 20000,
          preRetirementAnnualSpending: 0,
        },
      }
    );

    const result = runSimulation(plan);
    const row1 = result.rows[0];

    expect(row1.surplusReinvested).toBeGreaterThan(0);
    // Cash balance should be replenished
    expect(row1.taxableBal).toBeGreaterThan(52000);
  });

  it('Case 12: Working-year tax gross-up on brokerage sales', () => {
    const plan = createTestPlan(
      [
        {
          id: 'acc-cash-1',
          name: 'Checking',
          owner: 'primary',
          type: 'cash',
          balance: 0,
          annualContribution: 0,
          employerMatchValue: 0,
          allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 100 },
        },
        {
          id: 'acc-taxable-1',
          name: 'Appreciated Brokerage',
          owner: 'primary',
          type: 'taxable',
          balance: 500000,
          annualContribution: 0,
          employerMatchValue: 0,
          allocation: { usEquityPct: 100, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 0 },
        },
      ],
      {
        primaryPerson: {
          ...DEFAULT_PLAN.primaryPerson,
          currentAge: 50,
          retirementAge: 65,
          lifeExpectancy: 85,
        },
        incomeStreams: [
          {
            id: 'inc-1',
            name: 'Salary',
            owner: 'primary',
            type: 'salary',
            amount: 150000,
            startAge: 50,
            endAge: 65,
            growthRatePct: 0,
            taxability: 'fully_taxable',
          },
        ],
        spendingAssumptions: {
          ...DEFAULT_PLAN.spendingAssumptions!,
          preRetirementAnnualSpending: 250000, // Deficit forces brokerage draw
        },
      }
    );

    const result = runSimulation(plan);
    const row1 = result.rows[0];

    expect(row1.isRetired).toBe(false);
    expect(row1.taxableWd).toBeGreaterThan(0);
    expect(row1.totalWithdrawals).toBe(row1.taxableWd);
    expect(row1.capGainsTaxPaid).toBeGreaterThan(0);
    // Shortfall should be 0 because brokerage has $500k to fund both deficit and taxes
    expect(row1.unfundedShortfall).toBe(0);
  });
});
