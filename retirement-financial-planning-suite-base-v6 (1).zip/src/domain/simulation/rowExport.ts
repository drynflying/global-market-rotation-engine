/**
 * CSV generation for the projection timeline.
 *
 * Two scopes:
 *   'summary' — mirrors the columns shown in the app's table
 *   'all'     — every field on SimulationRow, for auditing a year in a spreadsheet
 *
 * Values are emitted UNFORMATTED: raw numbers, no currency symbols, no thousands
 * separators. Excel and Sheets parse those as numbers; "$1,234" arrives as text and
 * cannot be summed, which defeats the point of exporting for validation.
 */
import { SimulationRow } from './simulationTypes';
import { ExportScope, fieldsForScope, RowField } from './rowFields';

/** Escape a value for CSV: quote when it contains a comma, quote or newline. */
export function csvEscape(value: string | number | boolean): string {
  const s = String(value);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export interface CsvOptions {
  scope: ExportScope;
  /** Divide numeric columns by this to express real (today's) dollars. */
  deflatorFor?: (row: SimulationRow) => number;
}

function cell(row: SimulationRow, field: RowField, deflator: number): string {
  const raw = row[field.key];
  if (raw === undefined || raw === null) return '';
  if (typeof raw === 'boolean') return raw ? 'TRUE' : 'FALSE';
  if (typeof raw === 'number') {
    const scaled = field.numeric && deflator !== 1 ? raw / deflator : raw;
    return csvEscape(Math.round(scaled * 100) / 100);
  }
  return csvEscape(raw as string);
}

export function buildCsv(rows: readonly SimulationRow[], options: CsvOptions): string {
  const fields = fieldsForScope(options.scope);
  const header = fields.map((f) => csvEscape(f.label)).join(',');
  const body = rows.map((row) => {
    const deflator = options.deflatorFor ? options.deflatorFor(row) : 1;
    return fields.map((f) => cell(row, f, deflator)).join(',');
  });
  return [header, ...body].join('\n');
}

export function csvFilename(planName: string, scope: ExportScope, mode: string): string {
  const slug = planName.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
  return `${slug}_timeline_${scope}_${mode}.csv`;
}

export function downloadCsv(content: string, filename: string): void {
  // Excel on Windows needs a BOM to read UTF-8 correctly.
  const blob = new Blob(['\uFEFF' + content], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
