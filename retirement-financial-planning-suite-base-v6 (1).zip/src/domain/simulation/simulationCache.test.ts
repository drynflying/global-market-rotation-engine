import { describe, it, expect } from 'vitest';
import { getSimulation, isCached } from './simulationCache';
import { runSimulation } from './simulationEngine';
import { createDefaultPlan } from '../../constants/defaultPlan';

describe('simulation cache', () => {
  it('returns the identical object on repeat calls for the same plan', () => {
    const plan = createDefaultPlan();
    const a = getSimulation(plan);
    const b = getSimulation(plan);
    expect(a).toBe(b);
  });

  it('produces the same result as calling the engine directly', () => {
    const plan = createDefaultPlan();
    expect(getSimulation(plan)).toEqual(runSimulation(plan));
  });

  it('treats a different plan object as a miss', () => {
    const a = createDefaultPlan();
    const b = createDefaultPlan();
    getSimulation(a);
    expect(isCached(a)).toBe(true);
    expect(isCached(b)).toBe(false);
    expect(getSimulation(a)).not.toBe(getSimulation(b));
  });

  it('keys separately on the conversion override', () => {
    const plan = createDefaultPlan();
    const normal = getSimulation(plan);
    const baseline = getSimulation(plan, 0);
    expect(normal).not.toBe(baseline);
    expect(getSimulation(plan, 0)).toBe(baseline);
    expect(baseline).toEqual(runSimulation(plan, 0));
  });

  it('does not serve a stale result after an edit produces a new object', () => {
    const before = createDefaultPlan();
    const cachedBefore = getSimulation(before);
    // Mirrors how the store updates: replace, never mutate.
    const after = {
      ...createDefaultPlan(),
      spendingAssumptions: {
        ...createDefaultPlan().spendingAssumptions!,
        desiredAnnualLivingExpenses: 40000,
      },
    };
    const cachedAfter = getSimulation(after);
    expect(cachedAfter).not.toBe(cachedBefore);
    expect(cachedAfter.depletionAge).not.toBe(cachedBefore.depletionAge);
  });
});

describe('no component calls runSimulation directly', () => {
  it('routes every component through the cache', async () => {
    const { readdirSync, readFileSync } = await import('fs');
    const offenders = readdirSync('src/components')
      .filter(f => f.endsWith('.tsx'))
      .filter(f => /\brunSimulation\s*\(/.test(readFileSync(`src/components/${f}`, 'utf8')));
    expect(offenders).toEqual([]);
  });
});
