import { describe, it, expect } from 'vitest';
import {
  ROW_FIELDS,
  EXCLUDED_ROW_KEYS,
  SUMMARY_FIELDS,
  fieldsForScope,
  RowField,
} from './rowFields';
import { buildCsv, csvEscape, csvFilename } from './rowExport';
import { getSimulation } from './simulationCache';
import { createDefaultPlan } from '../../constants/defaultPlan';

const rows = () => getSimulation(createDefaultPlan()).rows;

describe('field registry covers the row', () => {
  it('exports every key on SimulationRow or explicitly excludes it', () => {
    const sampleRow = rows()[0];
    const registeredKeys = new Set<string>([
      ...ROW_FIELDS.map((f: RowField) => f.key),
      ...Object.keys(EXCLUDED_ROW_KEYS),
    ]);

    const rowKeys = Object.keys(sampleRow);
    for (const key of rowKeys) {
      expect(registeredKeys.has(key), `SimulationRow key '${key}' missing from rowFields registry`).toBe(true);
    }
  });

  it('contains no duplicate field keys in ROW_FIELDS', () => {
    const keys = ROW_FIELDS.map((f) => f.key);
    const uniqueKeys = new Set(keys);
    expect(keys.length).toBe(uniqueKeys.size);
  });

  it('filters summary fields correctly', () => {
    expect(SUMMARY_FIELDS.every((f) => f.summary)).toBe(true);
    expect(fieldsForScope('summary')).toEqual(SUMMARY_FIELDS);
    expect(fieldsForScope('all')).toEqual(ROW_FIELDS);
  });
});

describe('csv escaping', () => {
  it('escapes quotes, commas, and newlines', () => {
    expect(csvEscape('normal')).toBe('normal');
    expect(csvEscape('hello, world')).toBe('"hello, world"');
    expect(csvEscape('quote "here"')).toBe('"quote ""here"""');
    expect(csvEscape('line1\nline2')).toBe('"line1\nline2"');
    expect(csvEscape(123)).toBe('123');
    expect(csvEscape(true)).toBe('true');
  });
});

describe('csv generation', () => {
  it('generates summary CSV with expected headers and row count', () => {
    const sampleRows = rows().slice(0, 3);
    const csv = buildCsv(sampleRows, { scope: 'summary' });
    const lines = csv.split('\n');

    expect(lines.length).toBe(4); // 1 header + 3 rows
    expect(lines[0]).toContain('Calendar Year');
    expect(lines[0]).toContain('Age');
    expect(lines[0]).not.toContain('Base Living ($)'); // Base living is summary: false
  });

  it('generates all-scope CSV including non-summary fields', () => {
    const sampleRows = rows().slice(0, 3);
    const csv = buildCsv(sampleRows, { scope: 'all' });
    const lines = csv.split('\n');

    expect(lines.length).toBe(4);
    expect(lines[0]).toContain('Base Living ($)');
    expect(lines[0]).toContain('Essential Expense ($)');
    expect(lines[0]).toContain('Capital Gains Tax ($)');
  });

  it('applies deflator to numeric fields when provided', () => {
    const sampleRows = rows().slice(0, 1);
    const row = sampleRows[0];
    const deflator = 2; // halving nominal values

    const nominalCsv = buildCsv(sampleRows, { scope: 'all' });
    const deflatedCsv = buildCsv(sampleRows, {
      scope: 'all',
      deflatorFor: () => deflator,
    });

    const nominalLine = nominalCsv.split('\n')[1].split(',');
    const deflatedLine = deflatedCsv.split('\n')[1].split(',');

    // Find index of a numeric field, e.g. baseLiving
    const fields = fieldsForScope('all');
    const baseLivingIndex = fields.findIndex((f) => f.key === 'baseLiving');
    expect(baseLivingIndex).toBeGreaterThan(-1);

    const nominalVal = Number(nominalLine[baseLivingIndex]);
    const deflatedVal = Number(deflatedLine[baseLivingIndex]);

    if (row.baseLiving > 0) {
      expect(deflatedVal).toBe(Math.round((row.baseLiving / deflator) * 100) / 100);
      expect(deflatedVal).not.toBe(nominalVal);
    }
  });

  it('generates formatted CSV filenames', () => {
    expect(csvFilename('My Retirement Plan 2026', 'summary', 'nominal')).toBe(
      'my_retirement_plan_2026_timeline_summary_nominal.csv'
    );
    expect(csvFilename('Test Plan!', 'all', 'real')).toBe(
      'test_plan_timeline_all_real.csv'
    );
  });
});

describe('csv is machine-readable', () => {
  it('emits raw numbers Excel can sum, not formatted currency', () => {
    // "$1,234" arrives in Excel as text and cannot be summed, which defeats the
    // purpose of exporting for validation. Nothing else guards this property.
    const line = buildCsv(rows(), { scope: 'all' }).split('\n')[1];
    expect(line).not.toMatch(/\$/);
    expect(line).not.toMatch(/\d,\d{3}(?!\d)/);
  });

  it('declares no field that is absent from the row', () => {
    const actual = new Set(Object.keys(rows()[0]));
    expect(ROW_FIELDS.map(f => f.key as string).filter(k => !actual.has(k))).toEqual([]);
  });
});

