import { SECURE_20_RMD_RULES } from '../registry/statutoryRegistry';

/**
 * SECURE 2.0 statutory RMD start age. Determined entirely by birth year.
 */
export function statutoryRmdStartAge(birthYear: number): number {
  return SECURE_20_RMD_RULES.statutoryStartAge(birthYear);
}

/**
 * RMD start age, with optional scenario override.
 */
export function getRmdStartAge(birthYear: number, override?: number): number {
  if (typeof override === 'number' && Number.isFinite(override) && override > 0) {
    return override;
  }
  return statutoryRmdStartAge(birthYear);
}

/**
 * Uniform Lifetime RMD Divisor Factor
 */
export function getRmdFactor(age: number, rmdStartAge: number = 73): number {
  return SECURE_20_RMD_RULES.getDivisorFactor(age, rmdStartAge);
}
