import { UserProfile, Plan } from '../../types';
import { SOCIAL_SECURITY_REGISTRY } from '../registry/statutoryRegistry';

export const DELAYED_CREDIT_RATE = SOCIAL_SECURITY_REGISTRY.delayedCreditRate;
export const DELAYED_CREDIT_MAX_AGE = SOCIAL_SECURITY_REGISTRY.delayedCreditMaxAge;

/**
 * Social Security Benefit Calculation
 */
export function getSsAnnualBenefit(
  person: UserProfile,
  age: number = person.ssClaimAge,
  statutory?: Partial<NonNullable<Plan['statutoryParams']>>,
  includeCola: boolean = true
): number {
  if (age < person.ssClaimAge) return 0;
  const fra = statutory?.fullRetirementAge ?? 67;
  const monthlyFra = person.ssMonthlyBenefit || 0;
  const claimAge = person.ssClaimAge || 67;

  let factor = 1.0;
  if (claimAge < fra) {
    const monthsEarly = (fra - claimAge) * 12;
    factor = 1.0 - SOCIAL_SECURITY_REGISTRY.earlyClaimReduction(monthsEarly);
  } else if (claimAge > fra) {
    const yearsDelayed = Math.min(claimAge, DELAYED_CREDIT_MAX_AGE) - fra;
    factor = 1.0 + Math.max(0, yearsDelayed) * DELAYED_CREDIT_RATE;
  }

  if (person.includeSsProjectedReduction) {
    const red = (person.ssProjectedReductionPct || 21) / 100;
    factor *= (1 - red);
  }

  const yearsOfCola = includeCola ? Math.max(0, age - person.currentAge) : 0;
  const colaRate = statutory?.ssColaRate ?? 2.5;
  const colaFactor = Math.pow(1 + (colaRate / 100), yearsOfCola);

  return Math.round(monthlyFra * 12 * factor * colaFactor);
}

/**
 * IRS Social Security Provisional Income Taxability Calculation
 */
export function calculateTaxableSs(grossSs: number, magiOther: number, isJoint: boolean): number {
  return SOCIAL_SECURITY_REGISTRY.calculateTaxableSs(grossSs, magiOther, isJoint);
}
