/**
 * Calculate Blanchett Retirement Smile multiplier based on retiree age
 */
export function getSmileMultiplier(
  age: number,
  retirementAge: number,
  model: string = 'blanchett_smile'
): number {
  if (model === 'constant') return 1.0;
  if (model === 'declining_real') {
    const yearsRetired = Math.max(0, age - retirementAge);
    return Math.max(0.70, 1.0 - (yearsRetired * 0.012));
  }
  if (age < retirementAge) return 1.0;
  if (age <= retirementAge + 7) {
    return 1.05; // Go-Go Years
  } else if (age <= retirementAge + 17) {
    return 0.82; // Slow-Go Years
  } else {
    return 1.10; // No-Go Years
  }
}
