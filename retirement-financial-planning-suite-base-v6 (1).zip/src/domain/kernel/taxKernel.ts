import { BracketCeilings, LTCG_RATES, NIIT_RATE, NIIT_THRESHOLD, FICA, ltcgCeilingsFor } from '../tax/taxConstants';

export {
  resolveFederalDeduction,
  calculateFederalTaxableOrdinaryIncome,
} from '../tax/federalDeduction';

export type {
  FederalDeductionBreakdown,
  ResolveFederalDeductionInput,
} from '../tax/federalDeduction';

/**
 * Progressive Federal Income Tax Calculation
 */
export function calculateFederalTax(
  taxableIncome: number,
  bracketCeilings: BracketCeilings
): number {
  if (taxableIncome <= 0) return 0;
  let tax = 0;
  let rem = taxableIncome;
  const { b10, b12, b22, b24, b32, b35 } = bracketCeilings;

  if (rem > b35) {
    tax += (rem - b35) * 0.37;
    rem = b35;
  }
  if (rem > b32) {
    tax += (rem - b32) * 0.35;
    rem = b32;
  }
  if (rem > b24) {
    tax += (rem - b24) * 0.32;
    rem = b24;
  }
  if (rem > b22) {
    tax += (rem - b22) * 0.24;
    rem = b22;
  }
  if (rem > b12) {
    tax += (rem - b12) * 0.22;
    rem = b12;
  }
  if (rem > b10) {
    tax += (rem - b10) * 0.12;
    rem = b10;
  }
  tax += rem * 0.10;
  return Math.round(tax);
}

/**
 * Determine Marginal Federal Income Tax Bracket
 */
export function getMarginalTaxBracket(
  taxableIncome: number,
  bracketCeilings: BracketCeilings
): string {
  if (taxableIncome <= 0) return '0%';
  const { b10, b12, b22, b24, b32, b35 } = bracketCeilings;
  if (taxableIncome <= b10) return '10%';
  if (taxableIncome <= b12) return '12%';
  if (taxableIncome <= b22) return '22%';
  if (taxableIncome <= b24) return '24%';
  if (taxableIncome <= b32) return '32%';
  if (taxableIncome <= b35) return '35%';
  return '37%';
}

/**
 * Marginal ordinary rate as a decimal.
 */
export function getMarginalRate(
  taxableIncome: number,
  bracketCeilings: BracketCeilings
): number {
  if (taxableIncome <= 0) return 0.10;
  const { b10, b12, b22, b24, b32, b35 } = bracketCeilings;
  if (taxableIncome <= b10) return 0.10;
  if (taxableIncome <= b12) return 0.12;
  if (taxableIncome <= b22) return 0.22;
  if (taxableIncome <= b24) return 0.24;
  if (taxableIncome <= b32) return 0.32;
  if (taxableIncome <= b35) return 0.35;
  return 0.37;
}

/**
 * Long-term capital gains tax stacked on top of ordinary taxable income, plus NIIT.
 */
export function calculateCapGainsTax(
  realizedGains: number,
  ordinaryTaxableIncome: number,
  isJoint: boolean,
  deflator: number
): number {
  if (realizedGains <= 0) return 0;
  const c = ltcgCeilingsFor(isJoint, deflator);
  let tax = 0;
  let remaining = realizedGains;

  const zeroRoom = Math.max(0, c.zero - ordinaryTaxableIncome);
  const inZero = Math.min(remaining, zeroRoom);
  remaining -= inZero;

  const fifteenRoom = Math.max(0, c.fifteen - Math.max(ordinaryTaxableIncome, c.zero));
  const inFifteen = Math.min(remaining, fifteenRoom);
  tax += inFifteen * LTCG_RATES.fifteen;
  remaining -= inFifteen;

  tax += remaining * LTCG_RATES.twenty;

  const threshold = isJoint ? NIIT_THRESHOLD.joint : NIIT_THRESHOLD.single;
  const magi = ordinaryTaxableIncome + realizedGains;
  const overThreshold = Math.max(0, magi - threshold);
  tax += Math.min(realizedGains, overThreshold) * NIIT_RATE;

  return Math.round(tax);
}

export interface FicaTaxBreakdown {
  socialSecurityTax: number;
  medicareTax: number;
  additionalMedicareTax: number;
  totalFicaTax: number;
}

export interface FicaTaxInput {
  primaryWages: number;
  spouseWages?: number;
  isJoint?: boolean;
  deflator?: number;
}

/**
 * Calculate FICA Tax (Social Security + Medicare + Additional Medicare).
 *
 * CRITICAL FINANCIAL RULES:
 * 1. Social Security wage base applies separately to each modeled employee.
 * 2. Base Medicare tax (1.45%) applies to uncapped combined wages.
 * 3. Additional Medicare tax (0.9%) applies to combined household wages exceeding
 *    the statutory threshold ($250k joint / $200k single). Threshold is NOT indexed for inflation.
 * 4. FICA applies to gross W-2 wages (employee 401(k) pre-tax deferrals do NOT reduce FICA wages).
 */
export function calculateFicaTax(
  primaryWagesOrInput: number | FicaTaxInput,
  spouseWagesOrIsJoint: number | boolean = 0,
  isJointOrDeflator: boolean | number = false,
  deflatorParam: number = 1.0
): FicaTaxBreakdown {
  let primaryWages = 0;
  let spouseWages = 0;
  let isJoint = false;
  let deflator = 1.0;

  if (typeof primaryWagesOrInput === 'object' && primaryWagesOrInput !== null) {
    primaryWages = Math.max(0, primaryWagesOrInput.primaryWages || 0);
    spouseWages = Math.max(0, primaryWagesOrInput.spouseWages || 0);
    isJoint = primaryWagesOrInput.isJoint ?? false;
    deflator = primaryWagesOrInput.deflator ?? 1.0;
  } else if (typeof primaryWagesOrInput === 'number') {
    primaryWages = Math.max(0, primaryWagesOrInput || 0);
    if (typeof spouseWagesOrIsJoint === 'boolean') {
      // Legacy 3-arg call: (salary, isJoint, deflator)
      spouseWages = 0;
      isJoint = spouseWagesOrIsJoint;
      deflator = typeof isJointOrDeflator === 'number' ? isJointOrDeflator : 1.0;
    } else {
      // 4-arg call: (primaryWages, spouseWages, isJoint, deflator)
      spouseWages = Math.max(0, spouseWagesOrIsJoint || 0);
      isJoint = typeof isJointOrDeflator === 'boolean' ? isJointOrDeflator : false;
      deflator = typeof deflatorParam === 'number' ? deflatorParam : 1.0;
    }
  }

  if (primaryWages <= 0 && spouseWages <= 0) {
    return {
      socialSecurityTax: 0,
      medicareTax: 0,
      additionalMedicareTax: 0,
      totalFicaTax: 0,
    };
  }

  const ssLimit = FICA.ssWageBase * deflator;
  const primarySsTax = Math.min(primaryWages, ssLimit) * FICA.ssRate;
  const spouseSsTax = Math.min(spouseWages, ssLimit) * FICA.ssRate;
  const totalSsTax = primarySsTax + spouseSsTax;

  const totalWages = primaryWages + spouseWages;
  const medicareTax = totalWages * FICA.medicareRate;

  const addMedicareThreshold = isJoint
    ? FICA.addMedicareThreshold.joint
    : FICA.addMedicareThreshold.single;
  const addMedicareTax = Math.max(0, totalWages - addMedicareThreshold) * FICA.addMedicareRate;

  const totalFica = Math.round(totalSsTax + medicareTax + addMedicareTax);

  return {
    socialSecurityTax: Math.round(totalSsTax),
    medicareTax: Math.round(medicareTax),
    additionalMedicareTax: Math.round(addMedicareTax),
    totalFicaTax: totalFica,
  };
}
