import { describe, it, expect } from 'vitest';
import {
  calculateFederalTax,
  getMarginalTaxBracket,
  getMarginalRate,
  calculateCapGainsTax,
  calculateFicaTax,
  calculateTaxableSs,
  getSsAnnualBenefit,
  getSmileMultiplier,
  statutoryRmdStartAge,
  getRmdStartAge,
  getRmdFactor,
} from './index';
import { BRACKET_CEILINGS_2026 } from '../tax/taxConstants';

describe('Kernel Modules', () => {
  describe('taxKernel', () => {
    it('calculates federal tax progressively', () => {
      const taxZero = calculateFederalTax(0, BRACKET_CEILINGS_2026.joint);
      expect(taxZero).toBe(0);

      const taxLow = calculateFederalTax(20000, BRACKET_CEILINGS_2026.joint);
      expect(taxLow).toBe(2000); // 10% of 20000

      const bracket = getMarginalTaxBracket(50000, BRACKET_CEILINGS_2026.joint);
      expect(bracket).toBe('12%');

      const rate = getMarginalRate(50000, BRACKET_CEILINGS_2026.joint);
      expect(rate).toBe(0.12);
    });

    it('calculates capital gains tax including NIIT', () => {
      const tax = calculateCapGainsTax(10000, 30000, true, 1.0);
      expect(tax).toBe(0); // Under zero-rate threshold
    });

    it('calculates FICA tax correctly for single worker below wage base', () => {
      const fica = calculateFicaTax({ primaryWages: 100000, isJoint: false, deflator: 1.0 });
      expect(fica.socialSecurityTax).toBe(6200); // 6.2% of 100k
      expect(fica.medicareTax).toBe(1450); // 1.45% of 100k
      expect(fica.additionalMedicareTax).toBe(0);
      expect(fica.totalFicaTax).toBe(7650);
    });

    it('calculates FICA tax correctly for single worker above wage base', () => {
      const fica = calculateFicaTax({ primaryWages: 200000, isJoint: false, deflator: 1.0 });
      // SS wage base = 184,500 * 1.0 = 184,500. SS tax = 184,500 * 0.062 = 11,439
      expect(fica.socialSecurityTax).toBe(11439);
      // Medicare = 200,000 * 0.0145 = 2,900
      expect(fica.medicareTax).toBe(2900);
      // Single threshold is 200,000 -> Additional Medicare = 0
      expect(fica.additionalMedicareTax).toBe(0);
      expect(fica.totalFicaTax).toBe(14339);
    });

    it('calculates FICA tax correctly for single worker above Additional Medicare threshold', () => {
      const fica = calculateFicaTax({ primaryWages: 250000, isJoint: false, deflator: 1.0 });
      expect(fica.socialSecurityTax).toBe(11439);
      expect(fica.medicareTax).toBe(3625); // 250k * 1.45%
      expect(fica.additionalMedicareTax).toBe(450); // (250k - 200k) * 0.9%
      expect(fica.totalFicaTax).toBe(15514);
    });

    it('calculates FICA tax correctly for two-earner household, both below wage base', () => {
      const fica = calculateFicaTax({
        primaryWages: 100000,
        spouseWages: 80000,
        isJoint: true,
        deflator: 1.0,
      });
      expect(fica.socialSecurityTax).toBe(11160); // 6.2% * (100k + 80k) = 6200 + 4960
      expect(fica.medicareTax).toBe(2610); // 1.45% * 180k
      expect(fica.additionalMedicareTax).toBe(0); // 180k < 250k MFJ threshold
      expect(fica.totalFicaTax).toBe(13770);
    });

    it('calculates FICA tax correctly for two-earner household, one above and one below wage base', () => {
      const fica = calculateFicaTax({
        primaryWages: 200000,
        spouseWages: 100000,
        isJoint: true,
        deflator: 1.0,
      });
      // Primary SS = min(200k, 184.5k) * 6.2% = 11,439
      // Spouse SS = min(100k, 184.5k) * 6.2% = 6,200
      // Total SS = 17,639 (demonstrating independent per-worker wage base application)
      expect(fica.socialSecurityTax).toBe(17639);
      // Combined Medicare = 300,000 * 1.45% = 4,350
      expect(fica.medicareTax).toBe(4350);
      // Additional Medicare = (300,000 - 250,000) * 0.9% = 450
      expect(fica.additionalMedicareTax).toBe(450);
      expect(fica.totalFicaTax).toBe(22439);
    });

    it('calculates FICA tax correctly for two-earner household, both above wage base', () => {
      const fica = calculateFicaTax({
        primaryWages: 200000,
        spouseWages: 200000,
        isJoint: true,
        deflator: 1.0,
      });
      // Primary SS = 11,439; Spouse SS = 11,439; Total SS = 22,878
      expect(fica.socialSecurityTax).toBe(22878);
      // Combined Medicare = 400,000 * 1.45% = 5,800
      expect(fica.medicareTax).toBe(5800);
      // Additional Medicare = (400,000 - 250,000) * 0.9% = 1,350
      expect(fica.additionalMedicareTax).toBe(1350);
      expect(fica.totalFicaTax).toBe(30028);
    });

    it('handles zero or negative wages safely', () => {
      const zeroFica = calculateFicaTax({ primaryWages: 0, spouseWages: 0, isJoint: true });
      expect(zeroFica.totalFicaTax).toBe(0);
      expect(zeroFica.socialSecurityTax).toBe(0);
      expect(zeroFica.medicareTax).toBe(0);
      expect(zeroFica.additionalMedicareTax).toBe(0);
    });

    it('supports legacy positional arguments for backward compatibility', () => {
      const fica3Arg = calculateFicaTax(100000, true, 1.0);
      expect(fica3Arg.totalFicaTax).toBe(7650);

      const fica4Arg = calculateFicaTax(100000, 50000, true, 1.0);
      expect(fica4Arg.totalFicaTax).toBe(11475); // (100k+50k)*7.65%
    });

    it('applies fixed statutory Additional Medicare Tax thresholds without inflating them', () => {
      // Base FICA tax rates: SS 6.2% (capped at ssWageBase * deflator), Medicare 1.45% (uncapped), Addl Medicare 0.9% above threshold.
      
      // MFJ threshold: $250,000
      const mfjBelow = calculateFicaTax(249999, true, 1.0).totalFicaTax;
      const mfjExact = calculateFicaTax(250000, true, 1.0).totalFicaTax;
      const mfjAbove = calculateFicaTax(260000, true, 1.0).totalFicaTax;
      expect(mfjExact - mfjBelow).toBe(Math.round(1 * 0.0145)); // Medicare only, as SS is capped
      // Delta from 250k to 260k should be 10,000 * (1.45% + 0.9%) = $235 (since SS is capped at 184.5k)
      expect(mfjAbove - mfjExact).toBe(Math.round(10000 * (0.0145 + 0.009)));

      // Single threshold: $200,000
      const singleBelow = calculateFicaTax(199999, false, 1.0).totalFicaTax;
      const singleExact = calculateFicaTax(200000, false, 1.0).totalFicaTax;
      const singleAbove = calculateFicaTax(210000, false, 1.0).totalFicaTax;
      expect(singleExact - singleBelow).toBe(Math.round(1 * 0.0145)); // Medicare only, as SS is capped
      expect(singleAbove - singleExact).toBe(Math.round(10000 * (0.0145 + 0.009)));

      // With deflator > 1.0 (e.g. 1.5), SS wage base inflates (184,500 * 1.5 = 276,750), BUT Addl Medicare threshold stays fixed ($250k joint / $200k single)
      const mfjInflated249k = calculateFicaTax(249999, true, 1.5).totalFicaTax;
      const mfjInflated250k = calculateFicaTax(250000, true, 1.5).totalFicaTax;
      const mfjInflated260k = calculateFicaTax(260000, true, 1.5).totalFicaTax;
      // Below or at 250k, rate delta is just FICA rate (6.2% + 1.45% = 7.65%).
      expect(mfjInflated250k - mfjInflated249k).toBe(Math.round(1 * 0.0765));
      // Above 250k, rate includes 0.9% Additional Medicare tax (6.2% + 1.45% + 0.9% = 8.55%).
      expect(mfjInflated260k - mfjInflated250k).toBe(Math.round(10000 * (0.062 + 0.0145 + 0.009)));

      const singleInflated199k = calculateFicaTax(199999, false, 1.5).totalFicaTax;
      const singleInflated200k = calculateFicaTax(200000, false, 1.5).totalFicaTax;
      const singleInflated210k = calculateFicaTax(210000, false, 1.5).totalFicaTax;
      expect(singleInflated200k - singleInflated199k).toBe(Math.round(1 * 0.0765));
      expect(singleInflated210k - singleInflated200k).toBe(Math.round(10000 * (0.062 + 0.0145 + 0.009)));
    });
  });

  describe('incomeKernel', () => {
    it('calculates SS taxable income accurately', () => {
      const taxable = calculateTaxableSs(20000, 10000, true);
      expect(taxable).toBe(0);
    });

    it('calculates SS annual benefit identically whether statutory is passed or omitted', () => {
      const person = {
        name: 'John',
        currentAge: 60,
        retirementAge: 65,
        lifeExpectancy: 90,
        ssClaimAge: 67,
        ssMonthlyBenefit: 3000,
        includeSsProjectedReduction: false,
      };

      const explicitStatutory = { fullRetirementAge: 67, ssColaRate: 2.5 };
      const withPassed = getSsAnnualBenefit(person, 67, explicitStatutory, true);
      const withOmitted = getSsAnnualBenefit(person, 67, undefined, true);

      expect(withPassed).toBe(withOmitted);
      expect(withOmitted).toBeGreaterThan(0);
    });
  });

  describe('spendingKernel', () => {
    it('provides smile multipliers by age phase', () => {
      expect(getSmileMultiplier(60, 65, 'blanchett_smile')).toBe(1.0);
      expect(getSmileMultiplier(67, 65, 'blanchett_smile')).toBe(1.05); // Go-Go
      expect(getSmileMultiplier(75, 65, 'blanchett_smile')).toBe(0.82); // Slow-Go
      expect(getSmileMultiplier(88, 65, 'blanchett_smile')).toBe(1.10); // No-Go
    });
  });

  describe('rmdKernel', () => {
    it('calculates statutory RMD ages and divisors', () => {
      expect(statutoryRmdStartAge(1962)).toBe(75);
      expect(getRmdStartAge(1962, 73)).toBe(73); // Override
      expect(getRmdFactor(75, 75)).toBe(24.6);
    });
  });
});
