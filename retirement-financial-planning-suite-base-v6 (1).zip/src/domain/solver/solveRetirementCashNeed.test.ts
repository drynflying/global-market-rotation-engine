import { describe, it, expect, vi } from 'vitest';
import { solveRetirementCashNeed, SolverInput } from './solveRetirementCashNeed';
import { SpendingAssumptions } from '../../types';
import { BRACKET_CEILINGS_2026 } from '../tax/taxConstants';
import { NO_STATE_TAX_RULE } from '../tax/stateTaxConstants';

describe('solveRetirementCashNeed', () => {
  const baseInput: SolverInput = {
    rmdDraw: 0,
    rothConversion: 0,
    preTaxBalAvail: 100000,
    taxableBalAvail: 50000,
    postTaxBalAvail: 50000,
    pensionIncome: 0,
    annualSalaryIncome: 0,
    otherGuaranteedIncome: 0,
    totalSs: 0,
    age: 62,
    hasSpouse: false,
    isJoint: false,
    deflator: 1.0,
    stdDeduction: 15000,
    bracketCeilings: BRACKET_CEILINGS_2026.single,
    cashBal: 20000,
    taxableBrokerageBal: 30000,
    taxableBrokerageCostBasis: 30000,
    spending: { taxPaymentSource: 'taxable_brokerage' } as SpendingAssumptions,
    conversionTaxPaid: 0,
    stateRule: NO_STATE_TAX_RULE,
    expenseNeedExAca: 30000,
    guaranteedIncome: 0,
    acaPremiumFor: () => 0,
  };

  it('uses taxable assets before extra pre-tax withdrawals', () => {
    const input: SolverInput = {
      ...baseInput,
      taxableBalAvail: 50000,
      preTaxBalAvail: 100000,
      postTaxBalAvail: 50000,
      expenseNeedExAca: 20000,
    };

    const res = solveRetirementCashNeed(input);

    expect(res.iteratedTaxableWd).toBeGreaterThan(0);
    expect(res.iteratedPreTaxWdExtra).toBe(0);
    expect(res.iteratedPostTaxWd).toBe(0);
  });

  it('uses pre-tax gross-up when taxable assets are exhausted', () => {
    const input: SolverInput = {
      ...baseInput,
      taxableBalAvail: 10000, // Not enough to cover 30,000 need
      preTaxBalAvail: 100000,
      expenseNeedExAca: 30000,
    };

    const res = solveRetirementCashNeed(input);

    expect(res.iteratedTaxableWd).toBe(10000);
    expect(res.iteratedPreTaxWdExtra).toBeGreaterThan(20000); // Grossed up for tax
    expect(res.iteratedPostTaxWd).toBe(0);
  });

  it('uses Roth/post-tax assets after taxable and pre-tax assets are exhausted', () => {
    const input: SolverInput = {
      ...baseInput,
      taxableBalAvail: 5000,
      preTaxBalAvail: 5000,
      postTaxBalAvail: 50000,
      expenseNeedExAca: 30000,
    };

    const res = solveRetirementCashNeed(input);

    expect(res.iteratedTaxableWd).toBe(5000);
    expect(res.iteratedPreTaxWdExtra).toBe(5000);
    expect(res.iteratedPostTaxWd).toBeGreaterThan(0);
  });

  it('unwinds excess withdrawals with give-back logic when cash provided exceeds need', () => {
    // High guaranteed income that covers expense need
    const input: SolverInput = {
      ...baseInput,
      guaranteedIncome: 50000,
      expenseNeedExAca: 20000,
    };

    const res = solveRetirementCashNeed(input);

    expect(res.iteratedTaxableWd).toBe(0);
    expect(res.iteratedPreTaxWdExtra).toBe(0);
    expect(res.iteratedPostTaxWd).toBe(0);
  });

  it('re-evaluates ACA premium callback while mix moves and freezes when converged', () => {
    const acaFn = vi.fn((magi: number) => (magi > 30000 ? 5000 : 2000));

    const input: SolverInput = {
      ...baseInput,
      acaPremiumFor: acaFn,
    };

    const res = solveRetirementCashNeed(input);

    expect(acaFn).toHaveBeenCalled();
    expect(res.acaNetPremium).toBeGreaterThan(0);
  });

  it('terminates safely under pathological cases (e.g., zero assets available)', () => {
    const input: SolverInput = {
      ...baseInput,
      taxableBalAvail: 0,
      preTaxBalAvail: 0,
      postTaxBalAvail: 0,
      expenseNeedExAca: 100000,
    };

    const res = solveRetirementCashNeed(input);

    expect(res.iteratedTaxableWd).toBe(0);
    expect(res.iteratedPreTaxWdExtra).toBe(0);
    expect(res.iteratedPostTaxWd).toBe(0);
  });
});
