import { SpendingAssumptions } from '../../types';
import { RetirementStrategy, ConversionTaxPaymentSource } from '../strategy/strategyTypes';
import { StateTaxRule, calculateStateTax, NO_STATE_TAX_RULE } from '../tax/stateTaxConstants';
import { BracketCeilings } from '../tax/taxConstants';
import {
  calculateFederalTax,
  getMarginalRate,
  calculateCapGainsTax,
  calculateFicaTax,
  calculateTaxableSs,
  resolveFederalDeduction,
} from '../kernel';

const ACA_MIX_SETTLED_DOLLARS = 1;
const ACA_PREMIUM_MAX_RESOLVES = 12;

export interface SolverInput {
  rmdDraw: number;
  rothConversion: number;
  preTaxBalAvail: number;
  taxableBalAvail: number;
  postTaxBalAvail: number;
  pensionIncome: number;
  annualSalaryIncome: number;
  primarySalaryIncome?: number;
  spouseSalaryIncome?: number;
  otherGuaranteedIncome: number;
  totalSs: number;
  age: number;
  spouseAge?: number;
  hasSpouse: boolean;
  isJoint: boolean;
  calendarYear?: number;
  taxYear?: number;
  deflator: number;
  stdDeduction: number;
  statutoryStandardDeductionJoint?: number;
  statutoryStandardDeductionSingle?: number;
  statutoryAddlStdDeduction65Joint?: number;
  statutoryAddlStdDeduction65Single?: number;
  bracketCeilings: BracketCeilings;
  cashBal: number;
  taxableBrokerageBal: number;
  taxableBrokerageCostBasis: number;
  spending?: SpendingAssumptions;
  strategy?: RetirementStrategy;
  taxPaymentSource?: ConversionTaxPaymentSource;
  conversionTaxPaid: number;
  stateRule?: StateTaxRule;
  customStateRatePct?: number;
  expenseNeedExAca: number;
  guaranteedIncome: number;
  acaPremiumFor: (magi: number) => number;
}

export interface SolverResult {
  iteratedPreTaxWdExtra: number;
  iteratedTaxableWd: number;
  iteratedPostTaxWd: number;
  acaNetPremium: number;
  currentEstimatedTax: number;
}

/**
 * Iteratively solves for the gross retirement withdrawals required to cover
 * living expenses, ACA health premiums, and total federal/state/FICA/capital gains taxes.
 */
export function solveRetirementCashNeed(input: SolverInput): SolverResult {
  const {
    rmdDraw,
    rothConversion,
    preTaxBalAvail,
    taxableBalAvail,
    postTaxBalAvail,
    pensionIncome,
    annualSalaryIncome,
    otherGuaranteedIncome,
    totalSs,
    age,
    spouseAge,
    hasSpouse,
    isJoint,
    deflator,
    stdDeduction,
    bracketCeilings,
    cashBal,
    taxableBrokerageBal,
    taxableBrokerageCostBasis,
    spending,
    strategy,
    taxPaymentSource: explicitTaxPaymentSource,
    conversionTaxPaid,
    stateRule = NO_STATE_TAX_RULE,
    customStateRatePct,
    expenseNeedExAca,
    guaranteedIncome,
    acaPremiumFor,
  } = input;

  const taxPaymentSource: ConversionTaxPaymentSource =
    strategy?.taxPayment.conversionTaxSource ??
    explicitTaxPaymentSource ??
    spending?.taxPaymentSource ??
    'taxable_brokerage';

  const order = strategy?.withdrawal.order ?? ['cash', 'taxable_brokerage', 'pre_tax', 'post_tax'];
  const reverseOrder = [...order].reverse();

  const cashAvail = Math.max(0, Math.min(cashBal, taxableBalAvail));
  const brokerageAvail = Math.max(0, taxableBalAvail - cashAvail);

  let iteratedCashWd = 0;
  let iteratedBrokerageWd = 0;
  let iteratedPreTaxWdExtra = 0;
  let iteratedPostTaxWd = 0;

  let lastMixTaxable = -1;
  let lastMixPreTax = -1;
  let lastMixPostTax = -1;
  let acaPremiumFrozen = false;
  let acaResolveCount = 0;
  let currentEstimatedTax = 0;
  let acaNetPremium = 0;

  for (let iter = 0; iter < 25; iter++) {
    const iteratedTaxableWd = iteratedCashWd + iteratedBrokerageWd;
    const totalPreTaxWd = rmdDraw + iteratedPreTaxWdExtra;
    const currentOtherMagi = pensionIncome + annualSalaryIncome + otherGuaranteedIncome + totalPreTaxWd + rothConversion;
    const currentTaxableSs = calculateTaxableSs(totalSs, currentOtherMagi, isJoint);
    const currentMagi = currentOtherMagi + currentTaxableSs;
    const currentDeduction = resolveFederalDeduction({
      taxYear: input.taxYear ?? input.calendarYear ?? 2026,
      isJoint,
      primaryAge: age,
      spouseAge: hasSpouse ? spouseAge : undefined,
      magi: currentMagi,
      deflator,
      statutoryStandardDeductionJoint: input.statutoryStandardDeductionJoint,
      statutoryStandardDeductionSingle: input.statutoryStandardDeductionSingle,
      statutoryAddlStdDeduction65Joint: input.statutoryAddlStdDeduction65Joint,
      statutoryAddlStdDeduction65Single: input.statutoryAddlStdDeduction65Single,
    });
    const currentNetTaxable = Math.max(0, currentMagi - currentDeduction.totalDeduction);
    const fedTax = calculateFederalTax(currentNetTaxable, bracketCeilings);

    const solverTaxableOut =
      iteratedTaxableWd +
      (taxPaymentSource === 'taxable_brokerage' ? conversionTaxPaid : 0);
    let solverGains = 0;
    if (solverTaxableOut > 0) {
      const solverDrawCash = Math.min(cashBal, solverTaxableOut);
      const solverDrawBrokerage = Math.max(0, solverTaxableOut - solverDrawCash);
      if (solverDrawBrokerage > 0) {
        const basisRatio =
          taxableBrokerageBal > 0 ? Math.min(1, Math.max(0, taxableBrokerageCostBasis) / taxableBrokerageBal) : 1;
        solverGains = Math.max(0, solverDrawBrokerage * (1 - basisRatio));
      }
    }
    const capGainsTaxEst = calculateCapGainsTax(
      solverGains,
      currentNetTaxable,
      isJoint,
      deflator,
    );

    const stateTax = calculateStateTax({
      ordinaryTaxable: currentNetTaxable,
      realizedCapGains: solverGains,
      taxableSocialSecurity: currentTaxableSs,
      rule: stateRule,
      customRatePct: customStateRatePct,
      primaryAge: age,
      pensionIncome,
      preTaxWithdrawals: rmdDraw + iteratedPreTaxWdExtra,
      agi: currentMagi,
      isJoint,
    });
    const ficaTax = calculateFicaTax({
      primaryWages: input.primarySalaryIncome ?? annualSalaryIncome,
      spouseWages: input.spouseSalaryIncome ?? 0,
      isJoint,
      deflator,
    }).totalFicaTax;
    currentEstimatedTax = fedTax + capGainsTaxEst + stateTax + ficaTax;

    const mixMoved =
      Math.abs(iteratedTaxableWd - lastMixTaxable) > ACA_MIX_SETTLED_DOLLARS ||
      Math.abs(iteratedPreTaxWdExtra - lastMixPreTax) > ACA_MIX_SETTLED_DOLLARS ||
      Math.abs(iteratedPostTaxWd - lastMixPostTax) > ACA_MIX_SETTLED_DOLLARS;

    if (!acaPremiumFrozen && acaResolveCount < ACA_PREMIUM_MAX_RESOLVES) {
      acaNetPremium = acaPremiumFor(currentMagi);
      acaResolveCount += 1;
      if (!mixMoved && iter > 0) acaPremiumFrozen = true;
    } else {
      acaPremiumFrozen = true;
    }

    lastMixTaxable = iteratedTaxableWd;
    lastMixPreTax = iteratedPreTaxWdExtra;
    lastMixPostTax = iteratedPostTaxWd;

    const totalCashNeeded = expenseNeedExAca + acaNetPremium + currentEstimatedTax;
    const currentCashProvided = guaranteedIncome + annualSalaryIncome + rmdDraw + iteratedPreTaxWdExtra + iteratedTaxableWd + iteratedPostTaxWd;
    const cashGap = totalCashNeeded - currentCashProvided;

    if (Math.abs(cashGap) < 1) break;

    if (cashGap > 0) {
      let filled = false;
      for (const accountClass of order) {
        if (accountClass === 'cash') {
          if (cashAvail > iteratedCashWd) {
            const draw = Math.min(cashAvail - iteratedCashWd, cashGap);
            iteratedCashWd += draw;
            filled = true;
            break;
          }
        } else if (accountClass === 'taxable_brokerage') {
          if (brokerageAvail > iteratedBrokerageWd) {
            const draw = Math.min(brokerageAvail - iteratedBrokerageWd, cashGap);
            iteratedBrokerageWd += draw;
            filled = true;
            break;
          }
        } else if (accountClass === 'pre_tax') {
          if (preTaxBalAvail > iteratedPreTaxWdExtra) {
            const marginalRate = getMarginalRate(currentNetTaxable, bracketCeilings);
            const grossNeeded = cashGap / Math.max(0.5, 1 - marginalRate);
            const draw = Math.min(preTaxBalAvail - iteratedPreTaxWdExtra, grossNeeded);
            iteratedPreTaxWdExtra += draw;
            filled = true;
            break;
          }
        } else if (accountClass === 'post_tax') {
          if (postTaxBalAvail > iteratedPostTaxWd) {
            const draw = Math.min(postTaxBalAvail - iteratedPostTaxWd, cashGap);
            iteratedPostTaxWd += draw;
            filled = true;
            break;
          }
        }
      }
      if (!filled) break;
    } else {
      let excess = -cashGap;
      if (excess <= 1) break;

      for (const accountClass of reverseOrder) {
        if (accountClass === 'post_tax') {
          if (iteratedPostTaxWd > 0) {
            const giveBack = Math.min(iteratedPostTaxWd, excess);
            iteratedPostTaxWd -= giveBack;
            excess -= giveBack;
            if (excess <= 1) break;
          }
        } else if (accountClass === 'pre_tax') {
          if (iteratedPreTaxWdExtra > 0) {
            const giveBack = Math.min(iteratedPreTaxWdExtra, excess);
            iteratedPreTaxWdExtra -= giveBack;
            excess -= giveBack;
            if (excess <= 1) break;
          }
        } else if (accountClass === 'taxable_brokerage') {
          if (iteratedBrokerageWd > 0) {
            const giveBack = Math.min(iteratedBrokerageWd, excess);
            iteratedBrokerageWd -= giveBack;
            excess -= giveBack;
            if (excess <= 1) break;
          }
        } else if (accountClass === 'cash') {
          if (iteratedCashWd > 0) {
            const giveBack = Math.min(iteratedCashWd, excess);
            iteratedCashWd -= giveBack;
            excess -= giveBack;
            if (excess <= 1) break;
          }
        }
      }
      if (excess > 1) break;
    }
  }

  const finalIteratedTaxableWd = iteratedCashWd + iteratedBrokerageWd;

  return {
    iteratedPreTaxWdExtra,
    iteratedTaxableWd: finalIteratedTaxableWd,
    iteratedPostTaxWd,
    acaNetPremium,
    currentEstimatedTax,
  };
}
