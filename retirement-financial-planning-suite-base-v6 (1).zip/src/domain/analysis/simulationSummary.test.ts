import { describe, it, expect } from 'vitest';
import { buildMilestoneAnnotation, computeSimulationSummary } from './simulationSummary';
import { SimulationRow } from '../simulation/simulationTypes';

describe('simulationSummary', () => {
  describe('buildMilestoneAnnotation', () => {
    it('annotates retirement start', () => {
      const res = buildMilestoneAnnotation({
        age: 65,
        primaryRetAge: 65,
        primarySsClaimAge: 67,
        primarySs: 30000,
        rmdStartAge: 75,
        solvencyStatus: 'Solvent',
        firstNonSolventAlreadyAnnotated: false,
      });
      expect(res.annotation).toBe('Retirement Start (Go-Go Phase) / Medicare 65');
    });

    it('annotates Social Security claim age', () => {
      const res = buildMilestoneAnnotation({
        age: 67,
        primaryRetAge: 65,
        primarySsClaimAge: 67,
        primarySs: 30000,
        rmdStartAge: 75,
        solvencyStatus: 'Solvent',
        firstNonSolventAlreadyAnnotated: false,
      });
      expect(res.annotation).toBe('Primary SS Claim (Age 67)');
    });

    it('annotates portfolio depletion on first non-solvent year', () => {
      const res = buildMilestoneAnnotation({
        age: 72,
        primaryRetAge: 65,
        primarySsClaimAge: 67,
        primarySs: 30000,
        rmdStartAge: 75,
        solvencyStatus: 'Insolvent',
        firstNonSolventAlreadyAnnotated: false,
      });
      expect(res.annotation).toBe('Portfolio Depleted');
      expect(res.isFirstNonSolvent).toBe(true);
    });
  });

  describe('computeSimulationSummary', () => {
    it('aggregates lifetime conversion taxes and total tax liabilities correctly without double counting', () => {
      const mockRows: Partial<SimulationRow>[] = [
        {
          age: 60,
          inflationDeflator: 1.0,
          totalPortfolio: 1000000,
          totalPortfolioReal: 1000000,
          fedTaxPaid: 10000,
          capGainsTaxPaid: 2000,
          stateTaxPaid: 3000,
          ficaTaxPaid: 1000,
          totalEstimatedTax: 16000, // fed + capGains + state + fica = 16000
          conversionTaxPaid: 5000, // sub-component of fedTax
          rmdTaxPaid: 0,
        },
        {
          age: 61,
          inflationDeflator: 1.02,
          totalPortfolio: 1020000,
          totalPortfolioReal: 1000000, // deflator = 1.02
          fedTaxPaid: 12000,
          capGainsTaxPaid: 1000,
          stateTaxPaid: 3500,
          ficaTaxPaid: 1500,
          totalEstimatedTax: 18000, // fed + capGains + state + fica = 18000
          conversionTaxPaid: 5000, // sub-component of fedTax
          rmdTaxPaid: 2000, // sub-component of fedTax
        },
      ];

      const summary = computeSimulationSummary(mockRows as SimulationRow[], undefined);

      // A. Lifetime conversion tax equals sum of conversionTaxPaid
      expect(summary.lifetimeConversionTaxPaidNominal).toBe(10000);
      expect(summary.lifetimeTaxPaidNominal).toBe(10000); // Backward-compatibility alias

      // B. Lifetime total tax equals sum of totalEstimatedTax
      expect(summary.lifetimeTotalTaxNominal).toBe(34000);

      // C. Nominal and Real accumulation
      // Row 1 deflator = 1.0, Row 2 deflator = 1.02
      // Real conversion tax = 5000/1.0 + 5000/1.02 = 5000 + 4901.96078 = 9901.96078
      expect(summary.lifetimeConversionTaxPaidReal).toBeCloseTo(9901.96, 1);
      expect(summary.lifetimeTaxPaidReal).toBeCloseTo(9901.96, 1);

      // Real total tax = 16000/1.0 + 18000/1.02 = 16000 + 17647.0588 = 33647.06
      expect(summary.lifetimeTotalTaxReal).toBeCloseTo(33647.06, 1);

      // D. Verify no double counting: totalEstimatedTax sum is 34000, NOT 34000 + conversionTaxPaid
      expect(summary.lifetimeTotalTaxNominal).not.toBe(34000 + 10000);
    });

    it('handles empty/short simulations gracefully', () => {
      const summary = computeSimulationSummary([]);
      expect(summary.rows).toEqual([]);
      expect(summary.lifetimeConversionTaxPaidNominal).toBe(0);
      expect(summary.lifetimeConversionTaxPaidReal).toBe(0);
      expect(summary.lifetimeRmdTaxesNominal).toBe(0);
      expect(summary.lifetimeRmdTaxesReal).toBe(0);
      expect(summary.lifetimeTotalTaxNominal).toBe(0);
      expect(summary.lifetimeTotalTaxReal).toBe(0);
      expect(summary.depletionAge).toBeUndefined();
    });

    it('derives depletionAge correctly in depletion scenarios', () => {
      const mockRows: Partial<SimulationRow>[] = [
        { age: 60, totalPortfolio: 500000, totalPortfolioReal: 500000, solvencyStatus: 'Solvent', conversionTaxPaid: 0, rmdTaxPaid: 0, totalEstimatedTax: 5000 },
        { age: 61, totalPortfolio: 200000, totalPortfolioReal: 190000, solvencyStatus: 'Solvent', conversionTaxPaid: 0, rmdTaxPaid: 0, totalEstimatedTax: 5000 },
        { age: 62, totalPortfolio: 0, totalPortfolioReal: 0, solvencyStatus: 'Depleted', conversionTaxPaid: 0, rmdTaxPaid: 0, totalEstimatedTax: 2000 },
        { age: 63, totalPortfolio: 0, totalPortfolioReal: 0, solvencyStatus: 'Insolvent', conversionTaxPaid: 0, rmdTaxPaid: 0, totalEstimatedTax: 1000 },
      ];

      const summary = computeSimulationSummary(mockRows as SimulationRow[]);
      expect(summary.depletionAge).toBe(62);
      expect(summary.lifetimeTotalTaxNominal).toBe(13000);
    });

    it('ensures nominal/real totals match row data exactly', () => {
      const mockRows: Partial<SimulationRow>[] = [
        { age: 65, inflationRatePct: 2.5, totalPortfolio: 1000000, totalPortfolioReal: 1000000, conversionTaxPaid: 2000, rmdTaxPaid: 1000, totalEstimatedTax: 15000 },
        { age: 66, inflationRatePct: 2.5, totalPortfolio: 1025000, totalPortfolioReal: 1000000, conversionTaxPaid: 3000, rmdTaxPaid: 1500, totalEstimatedTax: 16000 },
      ];

      const summary = computeSimulationSummary(mockRows as SimulationRow[]);
      const sumConversion = mockRows.reduce((acc, r) => acc + (r.conversionTaxPaid || 0), 0);
      const sumRmd = mockRows.reduce((acc, r) => acc + (r.rmdTaxPaid || 0), 0);
      const sumTotal = mockRows.reduce((acc, r) => acc + (r.totalEstimatedTax || 0), 0);

      expect(summary.lifetimeConversionTaxPaidNominal).toBe(sumConversion);
      expect(summary.lifetimeRmdTaxesNominal).toBe(sumRmd);
      expect(summary.lifetimeTotalTaxNominal).toBe(sumTotal);
    });
  });
});
