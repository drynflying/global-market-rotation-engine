import type { SimulationRow, SimulationResult } from '../simulation/simulationTypes';

import type { RetirementStrategy } from '../strategy/strategyTypes';

export interface MilestoneParams {
  age: number;
  primaryRetAge: number;
  primarySsClaimAge: number;
  primarySs: number;
  spouseSs?: number;
  spouseSsClaimAge?: number;
  spouseAge?: number;
  hasSpouse?: boolean;
  rmdStartAge: number;
  solvencyStatus: 'Solvent' | 'Insolvent' | 'Depleted';
  firstNonSolventAlreadyAnnotated: boolean;
}

/**
 * Builds milestone annotation strings for timeline years
 */
export function buildMilestoneAnnotation(params: MilestoneParams): {
  annotation?: string;
  isFirstNonSolvent: boolean;
} {
  const {
    age,
    primaryRetAge,
    primarySsClaimAge,
    primarySs,
    spouseSs = 0,
    spouseSsClaimAge,
    spouseAge,
    hasSpouse = false,
    rmdStartAge,
    solvencyStatus,
    firstNonSolventAlreadyAnnotated,
  } = params;

  let annotation: string | undefined = undefined;
  if (age === primaryRetAge) annotation = 'Retirement Start (Go-Go Phase)';
  else if (age === primaryRetAge + 8) annotation = 'Slow-Go Spending Phase';
  else if (age === primaryRetAge + 18) annotation = 'No-Go Spending Phase';

  if (primarySs > 0 && age === primarySsClaimAge) {
    annotation = annotation ? `${annotation} / Primary SS Claim (Age ${primarySsClaimAge})` : `Primary SS Claim (Age ${primarySsClaimAge})`;
  }
  if (hasSpouse && spouseSs > 0 && spouseAge === spouseSsClaimAge) {
    annotation = annotation ? `${annotation} / Spouse SS Claim (Age ${spouseSsClaimAge})` : `Spouse SS Claim (Age ${spouseSsClaimAge})`;
  }
  if (age === 65) {
    annotation = annotation ? `${annotation} / Medicare 65` : 'Medicare 65';
  }
  if (age === rmdStartAge) {
    annotation = annotation ? `${annotation} / RMD Start (Age ${rmdStartAge})` : `RMD Start (Age ${rmdStartAge})`;
  }

  let isFirstNonSolvent = false;
  if (solvencyStatus !== 'Solvent' && !firstNonSolventAlreadyAnnotated) {
    annotation = annotation ? `${annotation} / Portfolio Depleted` : 'Portfolio Depleted';
    isFirstNonSolvent = true;
  }

  return { annotation, isFirstNonSolvent };
}

/**
 * Aggregates lifetime simulation summary statistics from rows
 */
export function computeSimulationSummary(
  rows: SimulationRow[],
  depletionAge?: number,
  effectiveStrategy?: RetirementStrategy
): SimulationResult {
  let lifetimeConversionTaxPaidNominal = 0;
  let lifetimeConversionTaxPaidReal = 0;
  let lifetimeRmdTaxesNominal = 0;
  let lifetimeRmdTaxesReal = 0;
  let lifetimeTotalTaxNominal = 0;
  let lifetimeTotalTaxReal = 0;

  const startAge = rows.length > 0 ? rows[0].age : 0;

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    const yearsFromStart = row.age !== undefined ? row.age - startAge : i;
    const fallbackDeflator = Math.pow(1 + (row.inflationRatePct ?? 0) / 100, yearsFromStart);
    const deflator = row.inflationDeflator || fallbackDeflator || 1.0;

    lifetimeConversionTaxPaidNominal += row.conversionTaxPaid || 0;
    lifetimeConversionTaxPaidReal += (row.conversionTaxPaid || 0) / deflator;
    lifetimeRmdTaxesNominal += row.rmdTaxPaid || 0;
    lifetimeRmdTaxesReal += (row.rmdTaxPaid || 0) / deflator;
    lifetimeTotalTaxNominal += row.totalEstimatedTax || 0;
    lifetimeTotalTaxReal += (row.totalEstimatedTax || 0) / deflator;
  }

  const derivedDepletionAge =
    depletionAge !== undefined
      ? depletionAge
      : rows.find((r) => r.solvencyStatus && r.solvencyStatus !== 'Solvent')?.age;

  return {
    rows,
    lifetimeConversionTaxPaidNominal,
    lifetimeConversionTaxPaidReal,
    lifetimeRmdTaxesNominal,
    lifetimeRmdTaxesReal,
    lifetimeTotalTaxNominal,
    lifetimeTotalTaxReal,
    lifetimeTaxPaidNominal: lifetimeConversionTaxPaidNominal,
    lifetimeTaxPaidReal: lifetimeConversionTaxPaidReal,
    depletionAge: derivedDepletionAge,
    effectiveStrategy,
  };
}
