/**
 * Rolls per-category essential percentages up into a single household essential floor.
 *
 * The category table in SpendingStep is a decision aid: the user enters one total spend
 * figure, the table splits it by BLS national weights, and the user tunes the
 * essential/discretionary percentage per line item. The ONLY thing the simulation
 * engine consumes from that exercise is this single number, written to
 * spendingAssumptions.essentialLivingPct.
 *
 * That write was previously missing: the component displayed a floor derived from the
 * user's inputs while the engine kept using its stored default of 65, so the Spending
 * tab and the Income & Tax charts disagreed about the same concept.
 *
 * Kept as a pure function outside the component so it can be tested directly and so a
 * future replacement for the BLS model has an explicit contract to satisfy: produce a
 * percentage, hand it to essentialLivingPct.
 */

export interface EssentialFloorCategory {
  id: string;
  blsSharePct: number;
  defaultEssentialPct: number;
}

/** Categories excluded from the floor because they are not part of the base budget. */
export const NON_BUDGET_CATEGORY_IDS = ['pre65_bridge'];

export function computeEssentialFloorPct(
  categories: readonly EssentialFloorCategory[],
  overrides: Record<string, number> = {},
): number {
  let weightedEssential = 0;
  let totalWeight = 0;

  for (const cat of categories) {
    if (NON_BUDGET_CATEGORY_IDS.includes(cat.id)) continue;
    const essentialPct = overrides[cat.id] ?? cat.defaultEssentialPct;
    weightedEssential += cat.blsSharePct * (essentialPct / 100);
    totalWeight += cat.blsSharePct;
  }

  if (totalWeight <= 0) return 0;
  const pct = (weightedEssential / totalWeight) * 100;
  return Math.min(100, Math.max(0, Math.round(pct * 10) / 10));
}
