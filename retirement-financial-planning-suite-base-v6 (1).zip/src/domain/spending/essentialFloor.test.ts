import { describe, it, expect } from 'vitest';
import { readFileSync } from 'fs';
import { computeEssentialFloorPct, EssentialFloorCategory } from './essentialFloor';
import { runSimulation } from '../simulation/simulationEngine';
import { createDefaultPlan } from '../../constants/defaultPlan';

const cats: EssentialFloorCategory[] = [
  { id: 'food_home', blsSharePct: 50, defaultEssentialPct: 100 },
  { id: 'entertainment', blsSharePct: 50, defaultEssentialPct: 0 },
  { id: 'pre65_bridge', blsSharePct: 999, defaultEssentialPct: 100 },
];

describe('computeEssentialFloorPct', () => {
  it('weights each category by its budget share', () => {
    expect(computeEssentialFloorPct(cats)).toBe(50);
  });

  it('applies user overrides in place of the defaults', () => {
    expect(computeEssentialFloorPct(cats, { entertainment: 100 })).toBe(100);
    expect(computeEssentialFloorPct(cats, { food_home: 0 })).toBe(0);
  });

  it('excludes the pre-65 bridge from the base budget', () => {
    // The bridge carries an absurd share above; if it were included the result would
    // be dominated by it.
    expect(computeEssentialFloorPct(cats)).toBeLessThan(60);
  });

  it('clamps to 0-100 and handles an empty table', () => {
    expect(computeEssentialFloorPct([])).toBe(0);
    expect(computeEssentialFloorPct(cats, { food_home: 100, entertainment: 100 })).toBe(100);
  });
});

describe('essentialLivingPct reaches the engine', () => {
  it('changes the reported essential/discretionary split', () => {
    const low = createDefaultPlan();
    low.spendingAssumptions!.essentialLivingPct = 20;
    const high = createDefaultPlan();
    high.spendingAssumptions!.essentialLivingPct = 90;

    const rowLow = runSimulation(low).rows.find(r => r.age === 65)!;
    const rowHigh = runSimulation(high).rows.find(r => r.age === 65)!;

    expect(rowHigh.essentialExpense).toBeGreaterThan(rowLow.essentialExpense);
    expect(rowHigh.discretionaryExpense).toBeLessThan(rowLow.discretionaryExpense);
  });

  it('does not change total spending, only its classification', () => {
    const low = createDefaultPlan();
    low.spendingAssumptions!.essentialLivingPct = 20;
    const high = createDefaultPlan();
    high.spendingAssumptions!.essentialLivingPct = 90;
    const a = runSimulation(low).rows.find(r => r.age === 65)!;
    const b = runSimulation(high).rows.find(r => r.age === 65)!;
    expect(a.totalExpenseNeed).toBe(b.totalExpenseNeed);
  });

  it('stores a default matching the untouched BLS rollup', () => {
    expect(createDefaultPlan().spendingAssumptions!.essentialLivingPct).toBe(70.2);
  });
});

describe('SpendingStep persists the rollup', () => {
  it('writes essentialLivingPct alongside every category override change', () => {
    const src = readFileSync('src/components/SpendingStep.tsx', 'utf8');
    const writes = src.match(/essentialLivingPct:\s*computeEssentialFloorPct/g) || [];
    // One in the per-category handler, one in the reset handler.
    expect(writes.length).toBeGreaterThanOrEqual(2);
  });
});
