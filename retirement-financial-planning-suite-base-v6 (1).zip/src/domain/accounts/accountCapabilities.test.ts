import { describe, it, expect } from 'vitest';
import {
  getAccountCapability,
  calculateAccountTotals,
} from './accountCapabilities';
import { AccountItem, Plan } from '../../types';
import { runSimulation } from '../simulation/simulationEngine';
import { DEFAULT_PLAN } from '../../constants/defaultPlan';

describe('accountCapabilities & account type auditing', () => {
  it('maps every AccountType to an authoritative capability definition', () => {
    expect(getAccountCapability('pre-tax')).toMatchObject({
      type: 'pre-tax',
      status: 'FULLY_MODELED',
      label: 'Pre-Tax (401k / IRA)',
      statusLabel: 'Fully Modeled',
      isModeledInProjection: true,
    });

    expect(getAccountCapability('post-tax')).toMatchObject({
      type: 'post-tax',
      status: 'FULLY_MODELED',
      statusLabel: 'Fully Modeled',
      isModeledInProjection: true,
    });

    expect(getAccountCapability('taxable')).toMatchObject({
      type: 'taxable',
      status: 'FULLY_MODELED',
      statusLabel: 'Fully Modeled',
      isModeledInProjection: true,
    });

    expect(getAccountCapability('cash')).toMatchObject({
      type: 'cash',
      status: 'FULLY_MODELED',
      statusLabel: 'Fully Modeled',
      isModeledInProjection: true,
    });

    expect(getAccountCapability('hsa')).toMatchObject({
      type: 'hsa',
      status: 'RECORDED_NOT_MODELED',
      statusLabel: 'Recorded — Not Modeled',
      badgeText: 'Recorded (Not Modeled)',
      isModeledInProjection: false,
    });

    expect(getAccountCapability('real-estate')).toMatchObject({
      type: 'real-estate',
      status: 'RECORDED_NOT_MODELED',
      statusLabel: 'Recorded — Not Modeled',
      badgeText: 'Recorded (Not Modeled)',
      isModeledInProjection: false,
    });
  });

  describe('calculateAccountTotals', () => {
    it('handles plan with only HSA accounts', () => {
      const accounts: AccountItem[] = [
        { id: '1', name: 'Family HSA', owner: 'primary', type: 'hsa', balance: 15000, annualContribution: 3000 },
      ];

      const totals = calculateAccountTotals(accounts);

      expect(totals.totalRecordedBalance).toBe(15000);
      expect(totals.modeledPortfolioBalance).toBe(0);
      expect(totals.recordedNotModeledBalance).toBe(15000);
      expect(totals.hasUnmodeledAssets).toBe(true);
      expect(totals.modeledCount).toBe(0);
      expect(totals.unmodeledCount).toBe(1);
      expect(totals.modeledAnnualContributions).toBe(0);
    });

    it('handles plan with only Real Estate accounts', () => {
      const accounts: AccountItem[] = [
        { id: '1', name: 'Primary Residence Equity', owner: 'joint', type: 'real-estate', balance: 500000, annualContribution: 0 },
      ];

      const totals = calculateAccountTotals(accounts);

      expect(totals.totalRecordedBalance).toBe(500000);
      expect(totals.modeledPortfolioBalance).toBe(0);
      expect(totals.recordedNotModeledBalance).toBe(500000);
      expect(totals.hasUnmodeledAssets).toBe(true);
      expect(totals.modeledCount).toBe(0);
      expect(totals.unmodeledCount).toBe(1);
    });

    it('handles plan with Taxable + HSA', () => {
      const accounts: AccountItem[] = [
        { id: '1', name: 'Brokerage', owner: 'primary', type: 'taxable', balance: 200000, annualContribution: 10000 },
        { id: '2', name: 'Health Savings Account', owner: 'primary', type: 'hsa', balance: 25000, annualContribution: 4000 },
      ];

      const totals = calculateAccountTotals(accounts);

      expect(totals.totalRecordedBalance).toBe(225000);
      expect(totals.modeledPortfolioBalance).toBe(200000);
      expect(totals.recordedNotModeledBalance).toBe(25000);
      expect(totals.hasUnmodeledAssets).toBe(true);
      expect(totals.modeledCount).toBe(1);
      expect(totals.unmodeledCount).toBe(1);
      expect(totals.modeledAnnualContributions).toBe(10000);
    });

    it('handles plan with Taxable + Real Estate', () => {
      const accounts: AccountItem[] = [
        { id: '1', name: 'Vanguard Brokerage', owner: 'primary', type: 'taxable', balance: 100000, annualContribution: 0 },
        { id: '2', name: 'Rental Property Equity', owner: 'joint', type: 'real-estate', balance: 300000, annualContribution: 0 },
      ];

      const totals = calculateAccountTotals(accounts);

      expect(totals.totalRecordedBalance).toBe(400000);
      expect(totals.modeledPortfolioBalance).toBe(100000);
      expect(totals.recordedNotModeledBalance).toBe(300000);
      expect(totals.hasUnmodeledAssets).toBe(true);
    });

    it('handles plan with ALL account types', () => {
      const accounts: AccountItem[] = [
        { id: '1', name: 'Pre-Tax 401k', owner: 'primary', type: 'pre-tax', balance: 300000, annualContribution: 0 },
        { id: '2', name: 'Roth IRA', owner: 'primary', type: 'post-tax', balance: 150000, annualContribution: 0 },
        { id: '3', name: 'Brokerage', owner: 'joint', type: 'taxable', balance: 100000, annualContribution: 0 },
        { id: '4', name: 'Emergency Cash', owner: 'primary', type: 'cash', balance: 50000, annualContribution: 0 },
        { id: '5', name: 'HSA', owner: 'primary', type: 'hsa', balance: 20000, annualContribution: 0 },
        { id: '6', name: 'Home Equity', owner: 'joint', type: 'real-estate', balance: 400000, annualContribution: 0 },
      ];

      const totals = calculateAccountTotals(accounts);

      expect(totals.totalRecordedBalance).toBe(1020000);
      expect(totals.modeledPortfolioBalance).toBe(600000);
      expect(totals.recordedNotModeledBalance).toBe(420000);
      expect(totals.hasUnmodeledAssets).toBe(true);
      expect(totals.modeledCount).toBe(4);
      expect(totals.unmodeledCount).toBe(2);
    });

    it('resolves 3% employer match to correct dollar amount when plan with W-2 salary is provided', () => {
      const plan: Plan = {
        ...DEFAULT_PLAN,
        incomeStreams: [
          { id: '1', name: 'Salary', owner: 'primary', type: 'salary', amount: 100000, startAge: 50, endAge: 65, growthRatePct: 0, taxability: 'fully_taxable' },
        ],
        accounts: [
          { id: '1', name: '401k', owner: 'primary', type: 'pre-tax', balance: 200000, annualContribution: 10000, employerMatchType: '%', employerMatchValue: 3.0 },
        ],
      };

      const totals = calculateAccountTotals(plan.accounts, plan);

      // Employee $10,000 + Employer 3% of $100,000 ($3,000) = $13,000
      expect(totals.modeledAnnualContributions).toBe(13000);
    });
  });

  describe('simulation engine isolation', () => {
    it('does not falsely include non-modeled HSA or Real Estate in retirement projection starting portfolio', () => {
      const basePlan: Plan = {
        ...DEFAULT_PLAN,
        accounts: [
          { id: '1', name: 'Taxable Acct', owner: 'primary', type: 'taxable', balance: 100000, annualContribution: 0, employerMatchValue: 0, allocation: { usEquityPct: 100, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 0 } },
          { id: '2', name: 'Primary Residence', owner: 'joint', type: 'real-estate', balance: 500000, annualContribution: 0, employerMatchValue: 0, allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 100 } },
          { id: '3', name: 'HSA', owner: 'primary', type: 'hsa', balance: 50000, annualContribution: 0, employerMatchValue: 0, allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 100 } },
        ],
      };

      const result = runSimulation(basePlan);
      const startingRow = result.rows[0];

      // Starting portfolio in row 0 reflects growth on modeled taxable account ($100k -> $105.6k), while HSA ($50k) and Real Estate ($500k) are strictly excluded from liquid portfolio
      expect(startingRow.totalPortfolio).toBe(startingRow.taxableBal);
      expect(startingRow.preTaxBal).toBe(0);
      expect(startingRow.postTaxBal).toBe(0);
    });
  });
});
