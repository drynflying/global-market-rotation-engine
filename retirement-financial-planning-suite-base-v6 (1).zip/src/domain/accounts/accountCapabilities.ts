import { AccountType, AccountItem, Plan } from '../../types';
import { getActiveW2Compensation, resolveAccountContribution } from '../contributions/contributionResolver';

export type AccountModelingStatus =
  | 'FULLY_MODELED'
  | 'PARTIALLY_MODELED'
  | 'RECORDED_NOT_MODELED'
  | 'UNSUPPORTED';

export interface AccountCapability {
  type: AccountType;
  label: string;
  status: AccountModelingStatus;
  isModeledInProjection: boolean;
  statusLabel: string;
  badgeText: string;
  badgeTooltip: string;
  description: string;
}

export const ACCOUNT_CAPABILITIES: Record<AccountType, AccountCapability> = {
  'taxable': {
    type: 'taxable',
    label: 'Taxable Brokerage',
    status: 'FULLY_MODELED',
    isModeledInProjection: true,
    statusLabel: 'Fully Modeled',
    badgeText: 'Modeled',
    badgeTooltip: 'Fully included in liquid portfolio cash flows, growth, tax drag, and retirement withdrawals.',
    description: 'Fully included in portfolio growth, tax drag, contributions, and retirement cash flow projections.',
  },
  'pre-tax': {
    type: 'pre-tax',
    label: 'Pre-Tax (401k / IRA)',
    status: 'FULLY_MODELED',
    isModeledInProjection: true,
    statusLabel: 'Fully Modeled',
    badgeText: 'Modeled',
    badgeTooltip: 'Fully included in retirement projections, RMD calculations, and income tax modeling.',
    description: 'Fully included in pre-tax growth, elective deferrals, RMDs, and taxable retirement distributions.',
  },
  'post-tax': {
    type: 'post-tax',
    label: 'Post-Tax / Roth',
    status: 'FULLY_MODELED',
    isModeledInProjection: true,
    statusLabel: 'Fully Modeled',
    badgeText: 'Modeled',
    badgeTooltip: 'Fully included in retirement projections, Roth conversions, and tax-free withdrawals.',
    description: 'Fully included in tax-free growth, Roth conversions, and tax-free retirement distributions.',
  },
  'cash': {
    type: 'cash',
    label: 'Cash & Equivalents',
    status: 'FULLY_MODELED',
    isModeledInProjection: true,
    statusLabel: 'Fully Modeled',
    badgeText: 'Modeled',
    badgeTooltip: 'Fully included in liquid cash reserves and retirement cash flow projections.',
    description: 'Fully included in liquid taxable portfolio balance and interest yield projections.',
  },
  'hsa': {
    type: 'hsa',
    label: 'HSA (Health Savings Account)',
    status: 'RECORDED_NOT_MODELED',
    isModeledInProjection: false,
    statusLabel: 'Recorded — Not Modeled',
    badgeText: 'Recorded (Not Modeled)',
    badgeTooltip: 'Recorded — not currently included in retirement projection.',
    description: 'Recorded — not currently included in retirement projection calculations or withdrawal sequence.',
  },
  'real-estate': {
    type: 'real-estate',
    label: 'Real Estate Equity',
    status: 'RECORDED_NOT_MODELED',
    isModeledInProjection: false,
    statusLabel: 'Recorded — Not Modeled',
    badgeText: 'Recorded (Not Modeled)',
    badgeTooltip: 'Recorded — not currently included in retirement projection.',
    description: 'Recorded — not currently included in retirement projection calculations or liquid portfolio math.',
  },
};

export function getAccountCapability(type: AccountType): AccountCapability {
  return ACCOUNT_CAPABILITIES[type] || {
    type,
    label: type,
    status: 'UNSUPPORTED',
    isModeledInProjection: false,
    statusLabel: 'Unsupported',
    badgeText: 'Unsupported',
    badgeTooltip: 'Recorded — not currently included in retirement projection.',
    description: 'Recorded — not currently included in retirement projection.',
  };
}

export function isAccountModeledInProjection(type: AccountType): boolean {
  return getAccountCapability(type).isModeledInProjection;
}

export interface AccountTotals {
  /** Modeled liquid retirement assets included in simulation projections (pre-tax + post-tax + taxable + cash) */
  modeledPortfolioBalance: number;
  /** Recorded assets not currently modeled in simulation projections (hsa + real-estate) */
  recordedNotModeledBalance: number;
  /** Total recorded net worth / asset value across all accounts */
  totalRecordedBalance: number;

  /** Modeled annual contributions */
  modeledAnnualContributions: number;
  /** Recorded annual contributions not included in projection */
  recordedAnnualContributions: number;
  /** Total annual contributions across all accounts */
  totalAnnualContributions: number;

  /** Count of modeled accounts */
  modeledCount: number;
  /** Count of recorded non-modeled accounts */
  recordedNotModeledCount: number;
  unmodeledCount: number;
  /** Total count of accounts */
  totalCount: number;

  /** True if there are recorded non-modeled accounts present */
  hasUnmodeledAssets: boolean;

  /** Breakdown of recorded non-modeled accounts by type */
  unmodeledBreakdown: { type: AccountType; name: string; balance: number; annualContribution: number }[];
}

export function calculateAccountTotals(accounts: AccountItem[] = [], plan?: Plan): AccountTotals {
  let modeledPortfolioBalance = 0;
  let recordedNotModeledBalance = 0;
  let modeledAnnualContributions = 0;
  let recordedAnnualContributions = 0;
  let modeledCount = 0;
  let recordedNotModeledCount = 0;
  const unmodeledBreakdown: { type: AccountType; name: string; balance: number; annualContribution: number }[] = [];

  for (const acc of accounts) {
    const capability = getAccountCapability(acc.type);
    const bal = acc.balance || 0;

    let ownerComp = 0;
    if (plan) {
      ownerComp = getActiveW2Compensation(
        plan,
        acc.owner,
        plan.primaryPerson.currentAge,
        plan.hasSpouse ? plan.spousePerson.currentAge : undefined,
        0
      );
    }
    const breakdown = resolveAccountContribution(acc, {
      ownerW2Compensation: ownerComp,
      contributionScale: 1.0,
    });
    const contrib = breakdown.totalAccountContribution;

    if (capability.isModeledInProjection) {
      modeledPortfolioBalance += bal;
      modeledAnnualContributions += contrib;
      modeledCount += 1;
    } else {
      recordedNotModeledBalance += bal;
      recordedAnnualContributions += contrib;
      recordedNotModeledCount += 1;
      unmodeledBreakdown.push({
        type: acc.type,
        name: acc.name,
        balance: bal,
        annualContribution: contrib,
      });
    }
  }

  const totalRecordedBalance = modeledPortfolioBalance + recordedNotModeledBalance;
  const totalAnnualContributions = modeledAnnualContributions + recordedAnnualContributions;
  const totalCount = accounts.length;

  return {
    modeledPortfolioBalance,
    recordedNotModeledBalance,
    totalRecordedBalance,
    modeledAnnualContributions,
    recordedAnnualContributions,
    totalAnnualContributions,
    modeledCount,
    recordedNotModeledCount,
    unmodeledCount: recordedNotModeledCount,
    totalCount,
    hasUnmodeledAssets: recordedNotModeledCount > 0 || recordedNotModeledBalance > 0,
    unmodeledBreakdown,
  };
}
