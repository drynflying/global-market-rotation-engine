import { describe, it, expect } from 'vitest';
import {
  resolveAccountContribution,
  getActiveW2Compensation,
  resolveWorkingYearContributions,
} from './contributionResolver';
import { AccountItem, Plan } from '../../types';
import { createDefaultPlan } from '../../constants/defaultPlan';

describe('contributionResolver', () => {
  describe('resolveAccountContribution', () => {
    it('handles fixed dollar employer match correctly', () => {
      const acc: AccountItem = {
        id: 'acc-1',
        name: '401k',
        type: 'pre-tax',
        balance: 100000,
        annualContribution: 10000,
        owner: 'primary',
        employerMatchType: '$',
        employerMatchValue: 5000,
      };

      const result = resolveAccountContribution(acc, {
        ownerW2Compensation: 100000,
        contributionScale: 1.0,
      });

      expect(result.employeeContribution).toBe(10000);
      expect(result.employerContribution).toBe(5000);
      expect(result.totalAccountContribution).toBe(15000);
      expect(result.taxableWageReduction).toBe(10000); // Only employee deferral reduces taxable wages
    });

    it('handles percentage-of-salary employer match correctly', () => {
      const acc: AccountItem = {
        id: 'acc-2',
        name: '401k',
        type: 'pre-tax',
        balance: 50000,
        annualContribution: 11400,
        owner: 'primary',
        employerMatchType: '%',
        employerMatchValue: 3.0, // 3%
      };

      const result = resolveAccountContribution(acc, {
        ownerW2Compensation: 100000,
        contributionScale: 1.0,
      });

      expect(result.employeeContribution).toBe(11400);
      expect(result.employerContribution).toBe(3000); // 3% of 100k
      expect(result.totalAccountContribution).toBe(14400);
      expect(result.taxableWageReduction).toBe(11400);
    });

    it('applies contribution wage growth scaling to both employee and employer fixed matches', () => {
      const acc: AccountItem = {
        id: 'acc-3',
        name: '401k',
        type: 'pre-tax',
        balance: 50000,
        annualContribution: 10000,
        owner: 'primary',
        employerMatchType: '$',
        employerMatchValue: 3000,
      };

      const scale = 1.15; // 15% wage growth
      const result = resolveAccountContribution(acc, {
        ownerW2Compensation: 115000,
        contributionScale: scale,
      });

      expect(result.employeeContribution).toBeCloseTo(11500, 2);
      expect(result.employerContribution).toBeCloseTo(3450, 2);
      expect(result.totalAccountContribution).toBeCloseTo(14950, 2);
      expect(result.taxableWageReduction).toBeCloseTo(11500, 2);
    });

    it('does not reduce taxable wages for post-tax (Roth) or taxable accounts', () => {
      const rothAcc: AccountItem = {
        id: 'acc-roth',
        name: 'Roth IRA',
        type: 'post-tax',
        balance: 30000,
        annualContribution: 7000,
        owner: 'primary',
      };

      const result = resolveAccountContribution(rothAcc, {
        ownerW2Compensation: 100000,
      });

      expect(result.employeeContribution).toBe(7000);
      expect(result.employerContribution).toBe(0);
      expect(result.totalAccountContribution).toBe(7000);
      expect(result.taxableWageReduction).toBe(0);
    });

    it('yields 0 employer match if owner compensation is 0 for percentage matches', () => {
      const acc: AccountItem = {
        id: 'acc-pct',
        name: '401k',
        type: 'pre-tax',
        balance: 10000,
        annualContribution: 5000,
        owner: 'spouse',
        employerMatchType: '%',
        employerMatchValue: 4.0,
      };

      const result = resolveAccountContribution(acc, {
        ownerW2Compensation: 0,
      });

      expect(result.employeeContribution).toBe(5000);
      expect(result.employerContribution).toBe(0);
      expect(result.totalAccountContribution).toBe(5000);
    });

    it('yields 0 employer match when employerMatchValue is 0', () => {
      const acc: AccountItem = {
        id: 'acc-zero',
        name: '401k',
        type: 'pre-tax',
        balance: 10000,
        annualContribution: 5000,
        owner: 'primary',
        employerMatchType: '%',
        employerMatchValue: 0,
      };

      const result = resolveAccountContribution(acc, {
        ownerW2Compensation: 100000,
      });

      expect(result.employeeContribution).toBe(5000);
      expect(result.employerContribution).toBe(0);
      expect(result.totalAccountContribution).toBe(5000);
    });

    it('correctly resolves default plan accounts with 3% percentage employer match', () => {
      const defaultPlan = createDefaultPlan();

      const primaryAcc = defaultPlan.accounts.find(a => a.id === 'acc-1')!;
      const primaryW2 = getActiveW2Compensation(defaultPlan, 'primary', 50, 50, 0);
      expect(primaryW2).toBe(75000);

      const primaryRes = resolveAccountContribution(primaryAcc, { ownerW2Compensation: primaryW2 });
      expect(primaryRes.employeeContribution).toBe(11400);
      expect(primaryRes.employerContribution).toBe(2250); // 3% of $75,000 = $2,250
      expect(primaryRes.totalAccountContribution).toBe(13650);

      const spouseAcc = defaultPlan.accounts.find(a => a.id === 'acc-2')!;
      const spouseW2 = getActiveW2Compensation(defaultPlan, 'spouse', 50, 50, 0);
      expect(spouseW2).toBe(50000);

      const spouseRes = resolveAccountContribution(spouseAcc, { ownerW2Compensation: spouseW2 });
      expect(spouseRes.employeeContribution).toBe(3800);
      expect(spouseRes.employerContribution).toBe(1500); // 3% of $50,000 = $1,500
      expect(spouseRes.totalAccountContribution).toBe(5300);
    });
  });

  describe('getActiveW2Compensation', () => {
    it('extracts owner-specific W-2 salary streams correctly', () => {
      const plan: Plan = createDefaultPlan();
      plan.incomeStreams = [
        {
          id: 'inc-p',
          name: 'Primary Job',
          type: 'salary',
          owner: 'primary',
          amount: 120000,
          startAge: 50,
          endAge: 65,
          growthRatePct: 3,
          taxability: 'fully_taxable',
        },
        {
          id: 'inc-s',
          name: 'Spouse Job',
          type: 'salary',
          owner: 'spouse',
          amount: 80000,
          startAge: 48,
          endAge: 62,
          growthRatePct: 3,
          taxability: 'fully_taxable',
        },
        {
          id: 'inc-pension',
          name: 'Pension',
          type: 'pension',
          owner: 'primary',
          amount: 20000,
          startAge: 60,
          endAge: 90,
          growthRatePct: 0,
          taxability: 'fully_taxable',
        },
      ];

      // At primary age 52, spouse age 50 (yearsFromStart = 2, wage growth = 3%)
      const primaryComp = getActiveW2Compensation(plan, 'primary', 52, 50, 2);
      const spouseComp = getActiveW2Compensation(plan, 'spouse', 52, 50, 2);

      const wageScale = Math.pow(1.03, 2);
      expect(primaryComp).toBeCloseTo(120000 * wageScale, 1);
      expect(spouseComp).toBeCloseTo(80000 * wageScale, 1);
    });

    it('returns 0 when worker is retired beyond income endAge', () => {
      const plan: Plan = createDefaultPlan();
      plan.incomeStreams = [
        {
          id: 'inc-p',
          name: 'Primary Job',
          type: 'salary',
          owner: 'primary',
          amount: 100000,
          startAge: 50,
          endAge: 60,
          growthRatePct: 0,
          taxability: 'fully_taxable',
        },
      ];

      const compAt62 = getActiveW2Compensation(plan, 'primary', 62, undefined, 12);
      expect(compAt62).toBe(0);
    });
  });

  describe('resolveWorkingYearContributions', () => {
    it('orchestrates contributions across multiple accounts and owners correctly', () => {
      const plan: Plan = createDefaultPlan();
      plan.incomeStreams = [
        {
          id: 'inc-1',
          name: 'Primary Salary',
          type: 'salary',
          owner: 'primary',
          amount: 100000,
          startAge: 50,
          endAge: 60,
          growthRatePct: 0,
          taxability: 'fully_taxable',
        },
        {
          id: 'inc-2',
          name: 'Spouse Salary',
          type: 'salary',
          owner: 'spouse',
          amount: 60000,
          startAge: 48,
          endAge: 60,
          growthRatePct: 0,
          taxability: 'fully_taxable',
        },
      ];

      const preTaxPrimary: AccountItem = {
        id: 'acc-pre-p',
        name: 'Primary 401k',
        type: 'pre-tax',
        owner: 'primary',
        balance: 200000,
        annualContribution: 10000,
        employerMatchType: '%',
        employerMatchValue: 4.0, // 4% of 100k = $4,000
      };

      const preTaxSpouse: AccountItem = {
        id: 'acc-pre-s',
        name: 'Spouse 403b',
        type: 'pre-tax',
        owner: 'spouse',
        balance: 100000,
        annualContribution: 6000,
        employerMatchType: '$',
        employerMatchValue: 2000, // Fixed $2,000
      };

      const rothAcc: AccountItem = {
        id: 'acc-roth',
        name: 'Roth IRA',
        type: 'post-tax',
        owner: 'primary',
        balance: 50000,
        annualContribution: 5000,
      };

      const result = resolveWorkingYearContributions({
        plan,
        preTaxAccs: [preTaxPrimary, preTaxSpouse],
        postTaxAccs: [rothAcc],
        taxableBrokerageAccs: [],
        cashAccs: [],
        primaryAge: 50,
        spouseAge: 48,
        yearsFromStart: 0,
        contributionScale: 1.0,
      });

      // Pre-tax inflow = (10000 + 4000) + (6000 + 2000) = 22000
      expect(result.annualSavePreTax).toBe(22000);
      expect(result.annualSavePostTax).toBe(5000);
      expect(result.annualSaveTaxable).toBe(0);

      // Taxable wage reduction = only employee deferrals (10000 + 6000) = 16000
      expect(result.taxableWageReduction).toBe(16000);

      // Total employee savings = 10000 + 6000 + 5000 = 21000
      expect(result.totalEmployeeSavings).toBe(21000);

      // Total employer contributions = 4000 + 2000 = 6000
      expect(result.totalEmployerContribution).toBe(6000);

      // Total account additions = 21000 + 6000 = 27000
      expect(result.totalAccountContribution).toBe(27000);
    });
  });
});
