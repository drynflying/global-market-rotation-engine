/**
 * @file contributionResolver.ts
 *
 * ARCHITECTURAL ROLE: Authoritative Domain Module for Contribution & Employer Match Resolution
 *
 * Provides a pure, single source of truth for:
 * 1. Employee elective contributions (pre-tax, post-tax, taxable, cash)
 * 2. Employer contributions & matches (percentage of owner W-2 compensation vs fixed dollar)
 * 3. Pre-tax wage reduction (strictly employee pre-tax deferrals; employer matches never reduce wages)
 * 4. Total account inflow (employee contributions + employer contributions)
 *
 * Pure domain logic: zero dependencies on React, Zustand, Firebase, or browser globals.
 */

import { AccountItem, Plan } from '../../types';

export interface AccountContributionBreakdown {
  /** Employee elective contribution amount for the account */
  employeeContribution: number;
  /** Employer match / contribution amount for the account */
  employerContribution: number;
  /** Total account inflow (employeeContribution + employerContribution) */
  totalAccountContribution: number;

  /** Portion of employee contribution that is pre-tax */
  employeePreTaxContribution: number;
  /** Portion of employee contribution that is post-tax / Roth */
  employeePostTaxContribution: number;

  /**
   * Amount that reduces the employee's taxable W-2 wages.
   * STRICT FINANCIAL RULE: Only employee pre-tax elective deferrals reduce taxable wages.
   * Employer contributions NEVER reduce employee taxable wages.
   */
  taxableWageReduction: number;
}

export interface ContributionContext {
  /** Active annual W-2 compensation for the account owner in the projection year */
  ownerW2Compensation: number;
  /** Optional wage indexation / contribution scale multiplier (default: 1.0) */
  contributionScale?: number;
}

/**
 * Resolves the annual active W-2 compensation for a given owner ('primary', 'spouse', 'joint')
 * from the plan's income streams in a specific projection year.
 * Only 'salary' income streams are treated as eligible employment compensation for employer matches.
 */
export function getActiveW2Compensation(
  plan: Plan,
  owner: 'primary' | 'spouse' | 'joint',
  primaryAge: number,
  spouseAge?: number,
  yearsFromStart = 0
): number {
  if (!plan.incomeStreams || plan.incomeStreams.length === 0) {
    return 0;
  }

  let totalComp = 0;

  for (const stream of plan.incomeStreams) {
    // Only W-2 salary streams count as eligible compensation for employer match
    if (stream.type !== 'salary') {
      continue;
    }

    const streamOwner = stream.owner || 'primary';

    // Filter by requested owner
    if (owner === 'primary' && streamOwner !== 'primary' && streamOwner !== 'joint') {
      continue;
    }
    if (owner === 'spouse' && streamOwner !== 'spouse' && streamOwner !== 'joint') {
      continue;
    }

    const personAgeAtStep = streamOwner === 'spouse' && typeof spouseAge === 'number'
      ? spouseAge
      : primaryAge;

    const startAge = typeof stream.startAge === 'number' ? stream.startAge : 0;
    const endAge = typeof stream.endAge === 'number' ? stream.endAge : 100;

    if (personAgeAtStep >= startAge && personAgeAtStep <= endAge) {
      const growthRate = stream.growthRatePct ?? 3.0;
      const streamGrowth = Math.pow(1 + growthRate / 100, yearsFromStart);
      const baseAmount = Math.max(0, stream.amount || 0);
      totalComp += baseAmount * streamGrowth;
    }
  }

  return Math.round(totalComp);
}

/**
 * Authoritatively calculates the contribution breakdown for a single account.
 */
export function resolveAccountContribution(
  account: AccountItem,
  context: ContributionContext
): AccountContributionBreakdown {
  const rawEmployee = typeof account.annualContribution === 'number' && Number.isFinite(account.annualContribution)
    ? Math.max(0, account.annualContribution)
    : 0;

  const scale = typeof context.contributionScale === 'number' && Number.isFinite(context.contributionScale) && context.contributionScale > 0
    ? context.contributionScale
    : 1.0;

  const employeeContribution = rawEmployee * scale;

  let employerContribution = 0;

  // Employer matches/contributions apply to pre-tax and post-tax retirement accounts
  // (e.g. 401(k), 403(b), workplace Roth 401(k)). Other account types (taxable brokerage,
  // cash, HSA, real estate) do not support workplace employer matching.
  const isRetirementAccount = account.type === 'pre-tax' || account.type === 'post-tax';

  if (isRetirementAccount && typeof account.employerMatchValue === 'number' && Number.isFinite(account.employerMatchValue) && account.employerMatchValue > 0) {
    if (account.employerMatchType === '%') {
      const matchPct = Math.max(0, account.employerMatchValue) / 100;
      const ownerComp = typeof context.ownerW2Compensation === 'number' && Number.isFinite(context.ownerW2Compensation)
        ? Math.max(0, context.ownerW2Compensation)
        : 0;
      employerContribution = ownerComp * matchPct;
    } else {
      // Default to fixed dollar match ('$')
      const matchDollar = Math.max(0, account.employerMatchValue);
      employerContribution = matchDollar * scale;
    }
  }

  const totalAccountContribution = employeeContribution + employerContribution;

  let employeePreTaxContribution = 0;
  let employeePostTaxContribution = 0;
  let taxableWageReduction = 0;

  if (account.type === 'pre-tax') {
    employeePreTaxContribution = employeeContribution;
    // Pre-tax employee elective deferrals reduce taxable wages.
    // Employer contributions do NOT reduce taxable wages.
    taxableWageReduction = employeeContribution;
  } else if (account.type === 'post-tax') {
    employeePostTaxContribution = employeeContribution;
    taxableWageReduction = 0;
  } else {
    // Taxable, cash, hsa, real-estate
    taxableWageReduction = 0;
  }

  return {
    employeeContribution,
    employerContribution,
    totalAccountContribution,
    employeePreTaxContribution,
    employeePostTaxContribution,
    taxableWageReduction,
  };
}

export interface PlanContributionsBreakdown {
  totalEmployeeContribution: number;
  totalEmployerContribution: number;
  totalAccountContribution: number;

  annualSavePreTax: number;
  annualSavePostTax: number;
  annualSaveTaxableBrokerage: number;
  annualSaveCash: number;
  annualSaveTaxable: number;
  totalSavings: number;

  employeeSavePreTax: number;
  employeeSavePostTax: number;
  employeeSaveTaxableBrokerage: number;
  employeeSaveCash: number;
  employeeSaveTaxable: number;
  totalEmployeeSavings: number;

  employerSavePreTax: number;
  employerSavePostTax: number;

  taxableWageReduction: number;

  byAccountId: Record<string, AccountContributionBreakdown>;
}

/**
 * Resolves contributions across all account buckets for a working projection year.
 */
export function resolveWorkingYearContributions(params: {
  plan: Plan;
  preTaxAccs: AccountItem[];
  postTaxAccs: AccountItem[];
  taxableBrokerageAccs: AccountItem[];
  cashAccs: AccountItem[];
  primaryAge: number;
  spouseAge?: number;
  yearsFromStart: number;
  contributionScale: number;
}): PlanContributionsBreakdown {
  const {
    plan,
    preTaxAccs,
    postTaxAccs,
    taxableBrokerageAccs,
    cashAccs,
    primaryAge,
    spouseAge,
    yearsFromStart,
    contributionScale,
  } = params;

  let totalEmployeeContribution = 0;
  let totalEmployerContribution = 0;
  let annualSavePreTax = 0;
  let annualSavePostTax = 0;
  let annualSaveTaxableBrokerage = 0;
  let annualSaveCash = 0;

  let employeeSavePreTax = 0;
  let employeeSavePostTax = 0;
  let employeeSaveTaxableBrokerage = 0;
  let employeeSaveCash = 0;

  let employerSavePreTax = 0;
  let employerSavePostTax = 0;

  let taxableWageReduction = 0;
  const byAccountId: Record<string, AccountContributionBreakdown> = {};

  const processAcc = (acc: AccountItem, category: 'pre-tax' | 'post-tax' | 'taxable' | 'cash') => {
    const ownerComp = getActiveW2Compensation(plan, acc.owner, primaryAge, spouseAge, yearsFromStart);
    const breakdown = resolveAccountContribution(acc, {
      ownerW2Compensation: ownerComp,
      contributionScale,
    });

    byAccountId[acc.id] = breakdown;
    totalEmployeeContribution += breakdown.employeeContribution;
    totalEmployerContribution += breakdown.employerContribution;

    if (category === 'pre-tax') {
      annualSavePreTax += breakdown.totalAccountContribution;
      employeeSavePreTax += breakdown.employeeContribution;
      employerSavePreTax += breakdown.employerContribution;
      taxableWageReduction += breakdown.taxableWageReduction;
    } else if (category === 'post-tax') {
      annualSavePostTax += breakdown.totalAccountContribution;
      employeeSavePostTax += breakdown.employeeContribution;
      employerSavePostTax += breakdown.employerContribution;
    } else if (category === 'taxable') {
      annualSaveTaxableBrokerage += breakdown.totalAccountContribution;
      employeeSaveTaxableBrokerage += breakdown.employeeContribution;
    } else if (category === 'cash') {
      annualSaveCash += breakdown.totalAccountContribution;
      employeeSaveCash += breakdown.employeeContribution;
    }
  };

  preTaxAccs.forEach(a => processAcc(a, 'pre-tax'));
  postTaxAccs.forEach(a => processAcc(a, 'post-tax'));
  taxableBrokerageAccs.forEach(a => processAcc(a, 'taxable'));
  cashAccs.forEach(a => processAcc(a, 'cash'));

  const annualSaveTaxable = annualSaveTaxableBrokerage + annualSaveCash;
  const employeeSaveTaxable = employeeSaveTaxableBrokerage + employeeSaveCash;
  const totalSavings = annualSavePreTax + annualSavePostTax + annualSaveTaxable;
  const totalEmployeeSavings = employeeSavePreTax + employeeSavePostTax + employeeSaveTaxable;
  const totalAccountContribution = totalEmployeeContribution + totalEmployerContribution;

  return {
    totalEmployeeContribution,
    totalEmployerContribution,
    totalAccountContribution,
    annualSavePreTax,
    annualSavePostTax,
    annualSaveTaxableBrokerage,
    annualSaveCash,
    annualSaveTaxable,
    totalSavings,
    employeeSavePreTax,
    employeeSavePostTax,
    employeeSaveTaxableBrokerage,
    employeeSaveCash,
    employeeSaveTaxable,
    totalEmployeeSavings,
    employerSavePreTax,
    employerSavePostTax,
    taxableWageReduction,
    byAccountId,
  };
}
