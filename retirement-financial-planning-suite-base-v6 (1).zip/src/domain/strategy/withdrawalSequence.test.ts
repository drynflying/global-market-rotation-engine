import { describe, it, expect } from 'vitest';
import { executeWithdrawalSequence } from './withdrawalSequence';
import { SpendingAssumptions } from '../../types';

describe('withdrawalSequence', () => {
  const defaultSpending = {
    taxPaymentSource: 'taxable_brokerage',
  } as unknown as SpendingAssumptions;

  it('draws cash before brokerage and computes realized capital gain & cost basis reduction proportionally', () => {
    const result = executeWithdrawalSequence({
      taxableWd: 30000,
      preTaxWd: 0,
      postTaxWd: 0,
      rothConversion: 0,
      conversionTaxPaid: 0,
      spending: defaultSpending,
      cashBal: 10000,
      taxableBrokerageBal: 50000,
      taxableBrokerageCostBasis: 25000, // 50% basis ratio
      preTaxBal: 100000,
      postTaxBal: 100000,
    });

    // 30,000 needed: 10,000 from cash, 20,000 from brokerage
    expect(result.cashBal).toBe(0);
    expect(result.taxableBrokerageBal).toBe(30000); // 50k - 20k

    // Basis ratio = 25k/50k = 0.5. Withdrawn basis = 20k * 0.5 = 10k.
    // Realized cap gain = 20k - 10k = 10k.
    expect(result.realizedCapGains).toBe(10000);
    expect(result.taxableBrokerageCostBasis).toBe(15000); // 25k - 10k
    expect(result.taxableBal).toBe(30000);
  });

  it('reduces pre-tax balance by preTaxWd and rothConversion', () => {
    const result = executeWithdrawalSequence({
      taxableWd: 0,
      preTaxWd: 15000,
      postTaxWd: 0,
      rothConversion: 10000,
      conversionTaxPaid: 2000,
      spending: defaultSpending,
      cashBal: 10000,
      taxableBrokerageBal: 0,
      taxableBrokerageCostBasis: 0,
      preTaxBal: 100000,
      postTaxBal: 50000,
    });

    // Pre-tax reduced by 15,000 + 10,000 = 25,000 -> 75,000
    expect(result.preTaxBal).toBe(75000);
  });

  it('handles conversion tax source = taxable_brokerage', () => {
    const result = executeWithdrawalSequence({
      taxableWd: 10000,
      preTaxWd: 0,
      postTaxWd: 0,
      rothConversion: 20000,
      conversionTaxPaid: 3000,
      spending: { taxPaymentSource: 'taxable_brokerage' } as unknown as SpendingAssumptions,
      cashBal: 20000, // covers 10k + 3k = 13k
      taxableBrokerageBal: 0,
      taxableBrokerageCostBasis: 0,
      preTaxBal: 100000,
      postTaxBal: 50000,
    });

    // Total taxable out = 10,000 + 3,000 = 13,000
    expect(result.cashBal).toBe(7000);
    // Roth balance receives full conversion 20,000 -> 70,000
    expect(result.postTaxBal).toBe(70000);
  });

  it('handles conversion tax source = conversion_proceeds', () => {
    const result = executeWithdrawalSequence({
      taxableWd: 0,
      preTaxWd: 0,
      postTaxWd: 0,
      rothConversion: 20000,
      conversionTaxPaid: 3000,
      spending: { taxPaymentSource: 'conversion_proceeds' } as unknown as SpendingAssumptions,
      cashBal: 10000,
      taxableBrokerageBal: 0,
      taxableBrokerageCostBasis: 0,
      preTaxBal: 100000,
      postTaxBal: 50000,
    });

    // Post-tax receives net conversion (20,000 - 3,000) = 17,000 -> 67,000
    expect(result.postTaxBal).toBe(67000);
  });

  it('reduces Roth balance by postTaxWd correctly', () => {
    const result = executeWithdrawalSequence({
      taxableWd: 0,
      preTaxWd: 0,
      postTaxWd: 15000,
      rothConversion: 0,
      conversionTaxPaid: 0,
      spending: defaultSpending,
      cashBal: 10000,
      taxableBrokerageBal: 0,
      taxableBrokerageCostBasis: 0,
      preTaxBal: 100000,
      postTaxBal: 50000,
    });

    expect(result.postTaxBal).toBe(35000);
    expect(result.totalWithdrawals).toBe(15000);
  });

  it('caps taxable draw at available cash + brokerage and reports actual executed withdrawal amounts', () => {
    const result = executeWithdrawalSequence({
      taxableWd: 50000,
      preTaxWd: 0,
      postTaxWd: 0,
      rothConversion: 20000,
      conversionTaxPaid: 5000,
      spending: { taxPaymentSource: 'taxable_brokerage' } as unknown as SpendingAssumptions,
      cashBal: 2000,
      taxableBrokerageBal: 8000,
      taxableBrokerageCostBasis: 4000,
      preTaxBal: 100000,
      postTaxBal: 50000,
    });

    // Requested taxable out = 50,000 + 5,000 = 55,000
    // Available = 2,000 cash + 8,000 brokerage = 10,000 total
    expect(result.cashBal).toBe(0);
    expect(result.taxableBrokerageBal).toBe(0);
    expect(result.taxableBal).toBe(0);
    expect(result.taxableBrokerageCostBasis).toBeGreaterThanOrEqual(0);
    expect(result.conversionTaxPortfolioOutflow).toBe(0);
    expect(result.taxableWd).toBe(10000);
    expect(result.totalWithdrawals).toBe(10000);
  });

  it('A: caps actual pre-tax withdrawal when requested pre-tax withdrawal exceeds available balance', () => {
    const result = executeWithdrawalSequence({
      taxableWd: 0,
      preTaxWd: 50000,
      postTaxWd: 0,
      rothConversion: 10000,
      conversionTaxPaid: 0,
      spending: defaultSpending,
      cashBal: 0,
      taxableBrokerageBal: 0,
      taxableBrokerageCostBasis: 0,
      preTaxBal: 25000,
      postTaxBal: 0,
    });

    // Starting preTaxBal = 25,000.
    // Roth conversion draws 10,000 -> remaining preTaxAvail = 15,000.
    // Requested preTaxWd = 50,000 -> capped at 15,000.
    expect(result.preTaxWd).toBe(15000);
    expect(result.preTaxBal).toBe(0);
    expect(result.totalWithdrawals).toBe(15000);
  });

  it('B: caps actual Roth withdrawal when requested Roth withdrawal exceeds available Roth balance', () => {
    const result = executeWithdrawalSequence({
      taxableWd: 0,
      preTaxWd: 0,
      postTaxWd: 40000,
      rothConversion: 10000,
      conversionTaxPaid: 0,
      spending: defaultSpending,
      cashBal: 0,
      taxableBrokerageBal: 0,
      taxableBrokerageCostBasis: 0,
      preTaxBal: 10000,
      postTaxBal: 15000,
    });

    // Starting preTaxBal = 10,000 -> actual Roth conversion = 10,000.
    // Starting postTaxBal = 15,000 + 10,000 rothConversion = 25,000 total available post-tax.
    // Requested postTaxWd = 40,000 -> capped at 25,000.
    expect(result.postTaxWd).toBe(25000);
    expect(result.postTaxBal).toBe(0);
    expect(result.totalWithdrawals).toBe(25000);
  });

  it('C & D: handles mixed withdrawal request where all account classes deplete and verifies totalWithdrawals equals sum of actual source withdrawals', () => {
    const result = executeWithdrawalSequence({
      taxableWd: 30000,
      preTaxWd: 40000,
      postTaxWd: 50000,
      rothConversion: 0,
      conversionTaxPaid: 0,
      spending: defaultSpending,
      cashBal: 5000,
      taxableBrokerageBal: 5000,
      taxableBrokerageCostBasis: 3000,
      preTaxBal: 12000,
      postTaxBal: 8000,
    });

    expect(result.taxableWd).toBe(10000); // 5k + 5k
    expect(result.preTaxWd).toBe(12000); // capped at preTaxBal
    expect(result.postTaxWd).toBe(8000); // capped at postTaxBal
    expect(result.taxableBal).toBe(0);
    expect(result.preTaxBal).toBe(0);
    expect(result.postTaxBal).toBe(0);

    const sumActual = result.taxableWd + result.preTaxWd + result.postTaxWd;
    expect(result.totalWithdrawals).toBe(sumActual);
    expect(result.totalWithdrawals).toBe(30000);
  });

  it('E: simulation depletion row cannot report a withdrawal larger than assets actually distributed', () => {
    // Starting with 0 assets everywhere
    const result = executeWithdrawalSequence({
      taxableWd: 100000,
      preTaxWd: 100000,
      postTaxWd: 100000,
      rothConversion: 0,
      conversionTaxPaid: 0,
      spending: defaultSpending,
      cashBal: 0,
      taxableBrokerageBal: 0,
      taxableBrokerageCostBasis: 0,
      preTaxBal: 0,
      postTaxBal: 0,
    });

    expect(result.taxableWd).toBe(0);
    expect(result.preTaxWd).toBe(0);
    expect(result.postTaxWd).toBe(0);
    expect(result.totalWithdrawals).toBe(0);
    expect(result.taxableBal).toBe(0);
    expect(result.preTaxBal).toBe(0);
    expect(result.postTaxBal).toBe(0);
  });
});
