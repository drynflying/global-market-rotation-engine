/**
 * @file rothConversionPolicy.test.ts
 *
 * Comprehensive unit and characterization tests for Phase 3:
 * Authoritative Roth Conversion Policy Engine.
 */

import { describe, it, expect } from 'vitest';
import {
  determineRothConversionTarget,
  RothConversionContext,
} from './rothConversionPolicy';
import { RothConversionStrategy } from './strategyTypes';
import { BRACKET_CEILINGS_2026, STANDARD_DEDUCTION_2026 } from '../tax/taxConstants';
import { runSimulation } from '../simulation/simulationEngine';
import { DEFAULT_PLAN } from '../../constants/defaultPlan';
import { Plan } from '../../types';
import { auditSimulationInvariants } from '../simulation/rowReconciliation';

describe('Roth Conversion Policy Engine (Phase 3)', () => {
  const jointBrackets = BRACKET_CEILINGS_2026.joint;
  const singleBrackets = BRACKET_CEILINGS_2026.single;
  const jointStdDeduction = STANDARD_DEDUCTION_2026.joint;
  const singleStdDeduction = STANDARD_DEDUCTION_2026.single;

  const defaultManualStrategy: RothConversionStrategy = {
    type: 'manual',
    annualTarget: 30000,
    startAge: 60,
    endAge: 70,
  };

  const fill12Strategy: RothConversionStrategy = {
    type: 'fill_bracket',
    bracket: 0.12,
    targetBracketName: 'fill_12',
    annualTarget: 0,
    startAge: 60,
    endAge: 70,
  };

  const fill22Strategy: RothConversionStrategy = {
    type: 'fill_bracket',
    bracket: 0.22,
    targetBracketName: 'fill_22',
    annualTarget: 0,
    startAge: 60,
    endAge: 70,
  };

  const fill24Strategy: RothConversionStrategy = {
    type: 'fill_bracket',
    bracket: 0.24,
    targetBracketName: 'fill_24',
    annualTarget: 0,
    startAge: 60,
    endAge: 70,
  };

  // -------------------------------------------------------------------------
  // 1. MANUAL POLICY TESTS
  // -------------------------------------------------------------------------
  describe('Manual Policy', () => {
    it('returns target within age window when assets are sufficient', () => {
      const ctx: RothConversionContext = {
        age: 65,
        isJoint: true,
        availablePreTaxBalance: 200000,
        ordinaryIncomeBeforeConversion: 40000,
        totalSs: 0,
        taxableSocialSecurityBeforeConversion: 0,
        standardDeduction: jointStdDeduction,
        rmdAmount: 0,
        bracketCeilings: jointBrackets,
      };

      const decision = determineRothConversionTarget(defaultManualStrategy, ctx);
      expect(decision.requestedConversion).toBe(30000);
      expect(decision.policy).toBe('manual');
      expect(decision.limitedByAvailablePreTax).toBe(false);
    });

    it('returns 0 when age is below startAge', () => {
      const ctx: RothConversionContext = {
        age: 59,
        isJoint: true,
        availablePreTaxBalance: 200000,
        ordinaryIncomeBeforeConversion: 40000,
        totalSs: 0,
        taxableSocialSecurityBeforeConversion: 0,
        standardDeduction: jointStdDeduction,
        rmdAmount: 0,
        bracketCeilings: jointBrackets,
      };

      const decision = determineRothConversionTarget(defaultManualStrategy, ctx);
      expect(decision.requestedConversion).toBe(0);
    });

    it('returns 0 when age is above endAge', () => {
      const ctx: RothConversionContext = {
        age: 71,
        isJoint: true,
        availablePreTaxBalance: 200000,
        ordinaryIncomeBeforeConversion: 40000,
        totalSs: 0,
        taxableSocialSecurityBeforeConversion: 0,
        standardDeduction: jointStdDeduction,
        rmdAmount: 0,
        bracketCeilings: jointBrackets,
      };

      const decision = determineRothConversionTarget(defaultManualStrategy, ctx);
      expect(decision.requestedConversion).toBe(0);
    });

    it('caps requested conversion when target exceeds available pre-tax balance', () => {
      const ctx: RothConversionContext = {
        age: 65,
        isJoint: true,
        availablePreTaxBalance: 15000,
        ordinaryIncomeBeforeConversion: 40000,
        totalSs: 0,
        taxableSocialSecurityBeforeConversion: 0,
        standardDeduction: jointStdDeduction,
        rmdAmount: 0,
        bracketCeilings: jointBrackets,
      };

      const decision = determineRothConversionTarget(defaultManualStrategy, ctx);
      expect(decision.requestedConversion).toBe(15000);
      expect(decision.limitedByAvailablePreTax).toBe(true);
    });
  });

  // -------------------------------------------------------------------------
  // 2. FILL 12 POLICY TESTS
  // -------------------------------------------------------------------------
  describe('Fill 12 Policy', () => {
    it('converts up to 12% ceiling with zero existing income', () => {
      const ctx: RothConversionContext = {
        age: 65,
        isJoint: true,
        availablePreTaxBalance: 500000,
        ordinaryIncomeBeforeConversion: 0,
        totalSs: 0,
        taxableSocialSecurityBeforeConversion: 0,
        standardDeduction: jointStdDeduction, // 32,200
        rmdAmount: 0,
        bracketCeilings: jointBrackets, // b12 = 100,800
      };

      const decision = determineRothConversionTarget(fill12Strategy, ctx);
      // Taxable income = conversion - stdDeduction <= 100800 => conv <= 100800 + 32200 = 133000
      expect(decision.requestedConversion).toBe(133000);
      expect(decision.policy).toBe('fill_12');
      expect(decision.bracketCeiling).toBe(100800);
    });

    it('partially fills remaining 12% bracket capacity', () => {
      const ctx: RothConversionContext = {
        age: 65,
        isJoint: true,
        availablePreTaxBalance: 500000,
        ordinaryIncomeBeforeConversion: 60000, // MAGI = 60000 -> Taxable = 60000 - 32200 = 27800
        totalSs: 0,
        taxableSocialSecurityBeforeConversion: 0,
        standardDeduction: jointStdDeduction,
        rmdAmount: 0,
        bracketCeilings: jointBrackets, // b12 = 100800
      };

      const decision = determineRothConversionTarget(fill12Strategy, ctx);
      // Remaining taxable capacity = 100800 - 27800 = 73000
      // Conversion = 73000
      expect(decision.requestedConversion).toBe(73000);
      expect(decision.taxableIncomeBeforeConversion).toBe(27800);
      expect(decision.remainingBracketCapacity).toBe(73000);
    });

    it('returns 0 conversion when already exactly at 12% ceiling', () => {
      const ctx: RothConversionContext = {
        age: 65,
        isJoint: true,
        availablePreTaxBalance: 500000,
        ordinaryIncomeBeforeConversion: 100800 + jointStdDeduction,
        totalSs: 0,
        taxableSocialSecurityBeforeConversion: 0,
        standardDeduction: jointStdDeduction,
        rmdAmount: 0,
        bracketCeilings: jointBrackets,
      };

      const decision = determineRothConversionTarget(fill12Strategy, ctx);
      expect(decision.requestedConversion).toBe(0);
      expect(decision.remainingBracketCapacity).toBe(0);
    });

    it('returns 0 conversion when already above 12% ceiling', () => {
      const ctx: RothConversionContext = {
        age: 65,
        isJoint: true,
        availablePreTaxBalance: 500000,
        ordinaryIncomeBeforeConversion: 150000,
        totalSs: 0,
        taxableSocialSecurityBeforeConversion: 0,
        standardDeduction: jointStdDeduction,
        rmdAmount: 0,
        bracketCeilings: jointBrackets,
      };

      const decision = determineRothConversionTarget(fill12Strategy, ctx);
      expect(decision.requestedConversion).toBe(0);
    });

    it('limits conversion when available pre-tax assets are less than remaining capacity', () => {
      const ctx: RothConversionContext = {
        age: 65,
        isJoint: true,
        availablePreTaxBalance: 25000,
        ordinaryIncomeBeforeConversion: 60000,
        totalSs: 0,
        taxableSocialSecurityBeforeConversion: 0,
        standardDeduction: jointStdDeduction,
        rmdAmount: 0,
        bracketCeilings: jointBrackets,
      };

      const decision = determineRothConversionTarget(fill12Strategy, ctx);
      expect(decision.requestedConversion).toBe(25000);
      expect(decision.limitedByAvailablePreTax).toBe(true);
    });
  });

  // -------------------------------------------------------------------------
  // 3. FILL 22 & FILL 24 POLICY TESTS
  // -------------------------------------------------------------------------
  describe('Fill 22 and Fill 24 Policies', () => {
    it('fill_22 fills up to 22% ceiling across 10%, 12%, and 22% brackets', () => {
      const ctx: RothConversionContext = {
        age: 65,
        isJoint: true,
        availablePreTaxBalance: 500000,
        ordinaryIncomeBeforeConversion: 50000, // Taxable = 50000 - 32200 = 17800
        totalSs: 0,
        taxableSocialSecurityBeforeConversion: 0,
        standardDeduction: jointStdDeduction,
        rmdAmount: 0,
        bracketCeilings: jointBrackets, // b22 = 211400
      };

      const decision = determineRothConversionTarget(fill22Strategy, ctx);
      // Remaining taxable capacity = 211400 - 17800 = 193600
      expect(decision.requestedConversion).toBe(193600);
      expect(decision.bracketCeiling).toBe(211400);
    });

    it('fill_24 fills up to 24% ceiling', () => {
      const ctx: RothConversionContext = {
        age: 65,
        isJoint: false,
        availablePreTaxBalance: 500000,
        ordinaryIncomeBeforeConversion: 30000, // Taxable = 30000 - 16100 = 13900
        totalSs: 0,
        taxableSocialSecurityBeforeConversion: 0,
        standardDeduction: singleStdDeduction,
        rmdAmount: 0,
        bracketCeilings: singleBrackets, // b24 = 201775
      };

      const decision = determineRothConversionTarget(fill24Strategy, ctx);
      // Remaining taxable capacity = 201775 - 13900 = 187875
      expect(decision.requestedConversion).toBe(187875);
      expect(decision.bracketCeiling).toBe(201775);
    });
  });

  // -------------------------------------------------------------------------
  // 4. SOCIAL SECURITY TAX-TORPEDO TEST
  // -------------------------------------------------------------------------
  describe('Social Security Tax-Torpedo Interaction', () => {
    it('correctly accounts for increasing taxable Social Security during bracket fill', () => {
      const ctx: RothConversionContext = {
        age: 65,
        isJoint: true,
        availablePreTaxBalance: 300000,
        ordinaryIncomeBeforeConversion: 20000,
        totalSs: 40000, // $40k SS gross
        taxableSocialSecurityBeforeConversion: 0, // Provisional = 20k + 20k = 40k <= 44k -> 0 taxable
        standardDeduction: jointStdDeduction, // 32,200
        rmdAmount: 0,
        bracketCeilings: jointBrackets, // b12 = 100,800
      };

      const decision = determineRothConversionTarget(fill12Strategy, ctx);
      expect(decision.requestedConversion).toBeGreaterThan(0);

      // Verify that with conversion, taxable income DOES NOT exceed b12 ceiling
      const conv = decision.requestedConversion;
      const convOtherMagi = 20000 + conv;
      // Provisional = convOtherMagi + 20000
      // Taxable SS calculated by IRS formula
      const prov = convOtherMagi + 20000;
      let taxableSs = 0;
      if (prov > 44000) {
        const tier1 = Math.min(0.5 * 40000, 6000);
        const tier2 = 0.85 * (prov - 44000);
        taxableSs = Math.min(0.85 * 40000, tier1 + tier2);
      } else if (prov > 32000) {
        taxableSs = Math.min(0.5 * 40000, 0.5 * (prov - 32000));
      }

      const netTaxableIncome = Math.max(0, convOtherMagi + taxableSs - jointStdDeduction);
      expect(netTaxableIncome).toBeLessThanOrEqual(jointBrackets.b12);

      // Verify converting $1 more WOULD exceed b12 ceiling
      const convPlus1 = conv + 1;
      const provPlus1 = 20000 + convPlus1 + 20000;
      let taxableSsPlus1 = 0;
      if (provPlus1 > 44000) {
        const tier1 = Math.min(0.5 * 40000, 6000);
        const tier2 = 0.85 * (provPlus1 - 44000);
        taxableSsPlus1 = Math.min(0.85 * 40000, tier1 + tier2);
      }
      const netTaxableIncomePlus1 = Math.max(0, 20000 + convPlus1 + taxableSsPlus1 - jointStdDeduction);
      expect(netTaxableIncomePlus1).toBeGreaterThan(jointBrackets.b12);
    });
  });

  // -------------------------------------------------------------------------
  // 5. RMD & SS COMBINED INTERACTION TEST
  // -------------------------------------------------------------------------
  describe('RMD and Social Security Interaction', () => {
    it('ensures RMD consumes bracket capacity before discretionary conversion', () => {
      const rmdDraw = 25000; // Mandatory RMD
      const ctx: RothConversionContext = {
        age: 75,
        isJoint: true,
        availablePreTaxBalance: 100000, // Pre-tax available after RMD
        ordinaryIncomeBeforeConversion: 15000 + rmdDraw, // $40k total ordinary before conversion
        totalSs: 30000,
        taxableSocialSecurityBeforeConversion: 8500,
        standardDeduction: jointStdDeduction + 1650, // Age 65+ addl deduction
        rmdAmount: rmdDraw,
        bracketCeilings: jointBrackets,
      };

      const decision = determineRothConversionTarget(fill12Strategy, ctx);

      // Verify that RMD is excluded from convertible assets and included in ordinary income
      expect(decision.requestedConversion).toBeLessThanOrEqual(100000);
      expect(decision.taxableIncomeBeforeConversion).toBeGreaterThan(0);
    });
  });

  // -------------------------------------------------------------------------
  // 6. TAX PAYMENT SOURCE COMPARISON TEST
  // -------------------------------------------------------------------------
  describe('Tax Payment Source Independence', () => {
    it('produces identical gross conversion targets regardless of tax payment source', () => {
      const planBrokerage: Plan = JSON.parse(JSON.stringify(DEFAULT_PLAN));
      planBrokerage.spendingAssumptions!.conversionStrategy = 'fill_22';
      planBrokerage.spendingAssumptions!.taxPaymentSource = 'taxable_brokerage';
      planBrokerage.spendingAssumptions!.rothConversionStartAge = 60;
      planBrokerage.spendingAssumptions!.rothConversionEndAge = 70;

      const planProceeds: Plan = JSON.parse(JSON.stringify(DEFAULT_PLAN));
      planProceeds.spendingAssumptions!.conversionStrategy = 'fill_22';
      planProceeds.spendingAssumptions!.taxPaymentSource = 'conversion_proceeds';
      planProceeds.spendingAssumptions!.rothConversionStartAge = 60;
      planProceeds.spendingAssumptions!.rothConversionEndAge = 70;

      const res1 = runSimulation(planBrokerage);
      const res2 = runSimulation(planProceeds);

      const row1_60 = res1.rows.find((r) => r.age === 60)!;
      const row2_60 = res2.rows.find((r) => r.age === 60)!;

      expect(row1_60).toBeDefined();
      expect(row2_60).toBeDefined();
      expect(row1_60.rothConversion).toBe(row2_60.rothConversion);
      expect(row1_60.rothConversion).toBeGreaterThan(0);
    });
  });

  // -------------------------------------------------------------------------
  // 7. ACA & IRMAA NON-OPTIMIZATION REGRESSION TESTS
  // -------------------------------------------------------------------------
  describe('ACA & IRMAA Interaction without Optimization Constraints', () => {
    it('allows MAGI to increase and ACA/IRMAA to calculate naturally without capping conversion', () => {
      const planFill22: Plan = JSON.parse(JSON.stringify(DEFAULT_PLAN));
      planFill22.spendingAssumptions!.conversionStrategy = 'fill_22';
      planFill22.spendingAssumptions!.rothConversionStartAge = 60;
      planFill22.spendingAssumptions!.rothConversionEndAge = 70;

      const simRes = runSimulation(planFill22);
      expect(simRes.rows.length).toBeGreaterThan(0);

      const convRows = simRes.rows.filter((r) => r.age >= 60 && r.age <= 70 && r.rothConversion > 0);
      expect(convRows.length).toBeGreaterThan(0);

      // Verify ACA / IRMAA calculations are present and react naturally
      convRows.forEach((r) => {
        expect(Number.isFinite(r.taxableMagi)).toBe(true);
        expect(Number.isFinite(r.effectiveTaxRate)).toBe(true);
      });
    });
  });

  // -------------------------------------------------------------------------
  // 8. BACKWARD COMPATIBILITY / MANUAL ZERO-DRIFT GATE
  // -------------------------------------------------------------------------
  describe('Manual Zero-Drift Characterization Gate', () => {
    it('produces identical simulation output for DEFAULT_PLAN with manual strategy', () => {
      const baselineRes = runSimulation(DEFAULT_PLAN);
      expect(baselineRes.rows.length).toBeGreaterThan(0);
      expect(baselineRes.effectiveStrategy?.rothConversion.type).toBe('manual');
    });
  });

  // -------------------------------------------------------------------------
  // 9. INVARIANT GATE
  // -------------------------------------------------------------------------
  describe('Financial Invariant Verification', () => {
    it('passes all portfolio, cash flow, and tax invariants for fill_12, fill_22, and fill_24', () => {
      const policies: Array<'fill_12' | 'fill_22' | 'fill_24'> = ['fill_12', 'fill_22', 'fill_24'];

      policies.forEach((policy) => {
        const plan: Plan = JSON.parse(JSON.stringify(DEFAULT_PLAN));
        plan.spendingAssumptions!.conversionStrategy = policy;
        plan.spendingAssumptions!.rothConversionStartAge = 60;
        plan.spendingAssumptions!.rothConversionEndAge = 70;

        const simRes = runSimulation(plan);
        const report = auditSimulationInvariants(simRes);

        expect(report.passed).toBe(true);
        expect(report.violations.length).toBe(0);
      });
    });
  });
});
