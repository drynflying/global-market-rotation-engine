/**
 * @file strategyTypes.ts
 *
 * Domain contracts for first-class retirement strategy rules.
 * Defines decision policy shapes separate from execution engines and financial balance caps.
 */

export type WithdrawalAccountClass =
  | 'cash'
  | 'taxable_brokerage'
  | 'pre_tax'
  | 'post_tax';

export type WithdrawalPolicyId =
  | 'taxable_first'
  | 'pretax_first'
  | 'roth_first';

export interface WithdrawalPolicyDefinition {
  id: WithdrawalPolicyId;
  name: string;
  description: string;
  order: WithdrawalAccountClass[];
}

export const WITHDRAWAL_POLICIES: Record<WithdrawalPolicyId, WithdrawalPolicyDefinition> = {
  taxable_first: {
    id: 'taxable_first',
    name: 'Taxable First',
    description:
      'Uses cash reserves first, then taxable brokerage, then traditional retirement assets, with Roth assets last.',
    order: ['cash', 'taxable_brokerage', 'pre_tax', 'post_tax'],
  },
  pretax_first: {
    id: 'pretax_first',
    name: 'Pre-Tax First',
    description:
      'Uses cash reserves first, then traditional retirement assets before taxable brokerage and Roth assets.',
    order: ['cash', 'pre_tax', 'taxable_brokerage', 'post_tax'],
  },
  roth_first: {
    id: 'roth_first',
    name: 'Roth First',
    description:
      'Uses cash reserves first, then Roth assets before taxable brokerage and traditional retirement assets.',
    order: ['cash', 'post_tax', 'taxable_brokerage', 'pre_tax'],
  },
};

export interface WithdrawalStrategy {
  type: 'ordered';
  policyId: WithdrawalPolicyId;
  order: WithdrawalAccountClass[];
}

export type ConversionStrategyType = 'manual' | 'fill_12' | 'fill_22' | 'fill_24' | 'none';

export type ConversionTaxPaymentSource = 'taxable_brokerage' | 'conversion_proceeds';

export type RothConversionStrategy =
  | {
      type: 'manual';
      annualTarget: number;
      startAge: number;
      endAge: number;
    }
  | {
      type: 'fill_bracket';
      bracket: 0.12 | 0.22 | 0.24;
      targetBracketName: 'fill_12' | 'fill_22' | 'fill_24';
      annualTarget: number;
      startAge: number;
      endAge: number;
    }
  | {
      type: 'none';
      annualTarget: 0;
      startAge: number;
      endAge: number;
    };

export interface TaxPaymentStrategy {
  conversionTaxSource: ConversionTaxPaymentSource;
}

export interface RetirementStrategy {
  withdrawal: WithdrawalStrategy;
  rothConversion: RothConversionStrategy;
  taxPayment: TaxPaymentStrategy;
}

export interface RetirementStrategyOverride {
  rothConversion?: { type: 'none' } | Partial<RothConversionStrategy>;
  withdrawal?: Partial<WithdrawalStrategy>;
  taxPayment?: Partial<TaxPaymentStrategy>;
}

/**
  * Shared presentation helpers for authoritative strategy display across views.
  */
export function getWithdrawalPolicyLabel(policyId: WithdrawalPolicyId): string {
  return WITHDRAWAL_POLICIES[policyId]?.name ?? 'Taxable First';
}

export function getRothConversionPolicyLabel(strategy: RothConversionStrategy): string {
  if (strategy.type === 'none') return 'No Conversions';
  if (strategy.type === 'manual') return `Manual ($${strategy.annualTarget.toLocaleString()}/yr)`;
  if (strategy.targetBracketName === 'fill_12') return 'Fill 12% Federal Bracket';
  if (strategy.targetBracketName === 'fill_22') return 'Fill 22% Federal Bracket';
  if (strategy.targetBracketName === 'fill_24') return 'Fill 24% Federal Bracket';
  return 'Manual';
}

export function getRothConversionPolicyBadge(strategy: RothConversionStrategy): string {
  if (strategy.type === 'none') return 'No Conversions';
  if (strategy.type === 'manual') {
    if (strategy.annualTarget > 0) {
      const kVal = Math.round(strategy.annualTarget / 1000);
      return `Manual ($${kVal}k/yr)`;
    }
    return 'Manual';
  }
  if (strategy.targetBracketName === 'fill_12') return 'Fill 12% Bracket';
  if (strategy.targetBracketName === 'fill_22') return 'Fill 22% Bracket';
  if (strategy.targetBracketName === 'fill_24') return 'Fill 24% Bracket';
  return 'Manual';
}

export function getTaxPaymentSourceLabel(source: ConversionTaxPaymentSource): string {
  if (source === 'conversion_proceeds') return 'Conversion Proceeds (Withheld)';
  return 'Taxable Brokerage Assets';
}

/**
 * Authoritative default strategy representing legacy baseline behavior.
 */
export const DEFAULT_RETIREMENT_STRATEGY: RetirementStrategy = {
  withdrawal: {
    type: 'ordered',
    policyId: 'taxable_first',
    order: ['cash', 'taxable_brokerage', 'pre_tax', 'post_tax'],
  },
  rothConversion: {
    type: 'manual',
    annualTarget: 0,
    startAge: 60,
    endAge: 70,
  },
  taxPayment: {
    conversionTaxSource: 'taxable_brokerage',
  },
};
