import { describe, it, expect } from 'vitest';
import { DEFAULT_RETIREMENT_STRATEGY } from './strategyTypes';
import { executeWithdrawalSequence } from './withdrawalSequence';

describe('withdrawalStrategy execution integration', () => {
  it('executes default order (cash -> brokerage -> pre-tax -> Roth) with sufficient balances', () => {
    const res = executeWithdrawalSequence({
      taxableWd: 30000,
      preTaxWd: 20000,
      postTaxWd: 10000,
      rothConversion: 0,
      conversionTaxPaid: 0,
      cashBal: 10000,
      taxableBrokerageBal: 50000,
      taxableBrokerageCostBasis: 25000,
      preTaxBal: 100000,
      postTaxBal: 50000,
      strategy: DEFAULT_RETIREMENT_STRATEGY,
    });

    // Cash: 10k drawn, leaving 0. Brokerage: 20k drawn, leaving 30k. Actual taxable wd: 30k.
    expect(res.cashBal).toBe(0);
    expect(res.taxableBrokerageBal).toBe(30000);
    expect(res.taxableWd).toBe(30000);
    // Pre-tax: 20k drawn from 100k -> 80k left
    expect(res.preTaxWd).toBe(20000);
    expect(res.preTaxBal).toBe(80000);
    // Post-tax: 10k drawn from 50k -> 40k left
    expect(res.postTaxWd).toBe(10000);
    expect(res.postTaxBal).toBe(40000);
    expect(res.totalWithdrawals).toBe(60000);
  });

  it('caps requested withdrawals when balances are insufficient', () => {
    const res = executeWithdrawalSequence({
      taxableWd: 50000, // requests 50k, only 5k cash + 15k brokerage = 20k available
      preTaxWd: 40000,  // requests 40k, only 25k available
      postTaxWd: 30000, // requests 30k, only 10k available
      rothConversion: 0,
      conversionTaxPaid: 0,
      cashBal: 50000 * 0.1, // 5k
      taxableBrokerageBal: 15000,
      taxableBrokerageCostBasis: 10000,
      preTaxBal: 25000,
      postTaxBal: 10000,
      strategy: DEFAULT_RETIREMENT_STRATEGY,
    });

    expect(res.taxableWd).toBe(20000);
    expect(res.preTaxWd).toBe(25000);
    expect(res.postTaxWd).toBe(10000);
    expect(res.totalWithdrawals).toBe(55000);
    expect(res.taxableBal).toBe(0);
    expect(res.preTaxBal).toBe(0);
    expect(res.postTaxBal).toBe(0);
  });

  it('handles conversion tax payment from taxable brokerage correctly', () => {
    const res = executeWithdrawalSequence({
      taxableWd: 20000,
      preTaxWd: 0,
      postTaxWd: 0,
      rothConversion: 30000,
      conversionTaxPaid: 6000,
      cashBal: 10000,
      taxableBrokerageBal: 40000,
      taxableBrokerageCostBasis: 20000,
      preTaxBal: 100000,
      postTaxBal: 10000,
      strategy: {
        ...DEFAULT_RETIREMENT_STRATEGY,
        taxPayment: { conversionTaxSource: 'taxable_brokerage' },
      },
    });

    // Total taxable out requested = 20k + 6k = 26k.
    // 10k from cash, 16k from brokerage.
    expect(res.cashBal).toBe(0);
    expect(res.taxableBrokerageBal).toBe(24000);
    expect(res.taxableWd).toBe(20000);
    expect(res.conversionTaxPortfolioOutflow).toBe(6000);
    expect(res.preTaxBal).toBe(70000); // 100k - 30k converted
    expect(res.postTaxBal).toBe(40000); // 10k + 30k added
  });

  it('handles conversion tax payment from conversion proceeds correctly', () => {
    const res = executeWithdrawalSequence({
      taxableWd: 20000,
      preTaxWd: 0,
      postTaxWd: 0,
      rothConversion: 30000,
      conversionTaxPaid: 6000,
      cashBal: 20000,
      taxableBrokerageBal: 0,
      taxableBrokerageCostBasis: 0,
      preTaxBal: 100000,
      postTaxBal: 10000,
      strategy: {
        ...DEFAULT_RETIREMENT_STRATEGY,
        taxPayment: { conversionTaxSource: 'conversion_proceeds' },
      },
    });

    expect(res.taxableWd).toBe(20000);
    expect(res.conversionTaxPortfolioOutflow).toBe(6000);
    expect(res.preTaxBal).toBe(70000); // 100k - 30k converted
    expect(res.postTaxBal).toBe(34000); // 10k + (30k - 6k) = 34k
  });
});
