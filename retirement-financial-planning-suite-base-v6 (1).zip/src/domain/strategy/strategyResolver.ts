/**
 * @file strategyResolver.ts
 *
 * Pure resolver that converts persisted Plan settings into one complete,
 * explicit RetirementStrategy contract.
 */

import { Plan } from '../../types';
import { DEFAULT_PLAN } from '../../constants/defaultPlan';
import {
  RetirementStrategy,
  ConversionTaxPaymentSource,
  RothConversionStrategy,
  WithdrawalPolicyId,
  WITHDRAWAL_POLICIES,
  RetirementStrategyOverride,
} from './strategyTypes';

export interface StrategyResolverOptions {
  /** @deprecated Use strategyOverride instead */
  overrideConversionTarget?: number;
  strategyOverride?: RetirementStrategyOverride;
}

/**
 * Resolves a persisted Plan (and optional overrides) into an authoritative,
 * explicit RetirementStrategy object.
 *
 * Pure function: does not mutate Plan.
 */
export function resolveRetirementStrategy(
  plan: Plan,
  options?: StrategyResolverOptions
): RetirementStrategy {
  const spending = plan.spendingAssumptions ?? DEFAULT_PLAN.spendingAssumptions!;

  const rawPolicyId =
    (options?.strategyOverride?.withdrawal?.policyId as WithdrawalPolicyId) ??
    (spending.withdrawalPolicy as WithdrawalPolicyId) ??
    'taxable_first';
  const policyDef = WITHDRAWAL_POLICIES[rawPolicyId] ?? WITHDRAWAL_POLICIES.taxable_first;

  const startAge = spending.rothConversionStartAge ?? 60;
  const endAge = spending.rothConversionEndAge ?? 70;
  const rawTarget = options?.overrideConversionTarget ?? spending.annualRothConversionTarget ?? 0;
  const annualTarget = Math.max(0, rawTarget);
  const conversionStrategyType = spending.conversionStrategy ?? 'manual';
  const conversionTaxSource: ConversionTaxPaymentSource =
    options?.strategyOverride?.taxPayment?.conversionTaxSource ??
    spending.taxPaymentSource ??
    'taxable_brokerage';

  let rothConversion: RothConversionStrategy;

  if (
    (conversionStrategyType as string) === 'none' ||
    options?.strategyOverride?.rothConversion?.type === 'none' ||
    (options?.overrideConversionTarget === 0 && !options?.strategyOverride)
  ) {
    rothConversion = {
      type: 'none',
      annualTarget: 0,
      startAge: 0,
      endAge: 120,
    };
  } else if (options?.strategyOverride?.rothConversion) {
    rothConversion = options.strategyOverride.rothConversion as RothConversionStrategy;
  } else if (conversionStrategyType === 'fill_12') {
    rothConversion = {
      type: 'fill_bracket',
      bracket: 0.12,
      targetBracketName: 'fill_12',
      annualTarget,
      startAge,
      endAge,
    };
  } else if (conversionStrategyType === 'fill_22') {
    rothConversion = {
      type: 'fill_bracket',
      bracket: 0.22,
      targetBracketName: 'fill_22',
      annualTarget,
      startAge,
      endAge,
    };
  } else if (conversionStrategyType === 'fill_24') {
    rothConversion = {
      type: 'fill_bracket',
      bracket: 0.24,
      targetBracketName: 'fill_24',
      annualTarget,
      startAge,
      endAge,
    };
  } else {
    rothConversion = {
      type: 'manual',
      annualTarget,
      startAge,
      endAge,
    };
  }

  return {
    withdrawal: {
      type: 'ordered',
      policyId: policyDef.id,
      order: policyDef.order,
    },
    rothConversion,
    taxPayment: {
      conversionTaxSource,
    },
  };
}
