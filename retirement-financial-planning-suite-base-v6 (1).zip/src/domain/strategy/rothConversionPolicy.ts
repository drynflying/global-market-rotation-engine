import { BracketCeilings } from '../tax/taxConstants';
import { resolveFederalDeduction, calculateTaxableSs } from '../kernel';
import { RothConversionStrategy } from './strategyTypes';

export interface RothConversionContext {
  age: number;
  spouseAge?: number;
  hasSpouse?: boolean;
  isJoint: boolean;
  calendarYear?: number;
  taxYear?: number;
  availablePreTaxBalance: number;
  ordinaryIncomeBeforeConversion: number;
  totalSs: number;
  taxableSocialSecurityBeforeConversion: number;
  standardDeduction?: number;
  statutoryStandardDeductionJoint?: number;
  statutoryStandardDeductionSingle?: number;
  statutoryAddlStdDeduction65Joint?: number;
  statutoryAddlStdDeduction65Single?: number;
  deflator?: number;
  rmdAmount: number;
  bracketCeilings: BracketCeilings;
}

export interface RothConversionDecision {
  policy: string;
  requestedConversion: number;
  actualConversion: number;
  bracketRate?: number;
  bracketCeiling?: number;
  taxableIncomeBeforeConversion: number;
  remainingBracketCapacity?: number;
  availablePreTaxBeforeConversion: number;
  limitedByAvailablePreTax: boolean;
  federalDeductionUsed?: number;
}

export function determineRothConversionTarget(
  strategy: RothConversionStrategy,
  ctx: RothConversionContext
): RothConversionDecision {
  const getDeduction = (magi: number): number => {
    if (ctx.taxYear !== undefined || ctx.calendarYear !== undefined) {
      return resolveFederalDeduction({
        taxYear: ctx.taxYear ?? ctx.calendarYear ?? 2026,
        isJoint: ctx.isJoint,
        primaryAge: ctx.age,
        spouseAge: ctx.hasSpouse ? ctx.spouseAge : undefined,
        magi,
        deflator: ctx.deflator ?? 1.0,
        statutoryStandardDeductionJoint: ctx.statutoryStandardDeductionJoint,
        statutoryStandardDeductionSingle: ctx.statutoryStandardDeductionSingle,
        statutoryAddlStdDeduction65Joint: ctx.statutoryAddlStdDeduction65Joint,
        statutoryAddlStdDeduction65Single: ctx.statutoryAddlStdDeduction65Single,
      }).totalDeduction;
    }
    return ctx.standardDeduction ?? 0;
  };

  const baseMagi = ctx.ordinaryIncomeBeforeConversion + ctx.taxableSocialSecurityBeforeConversion;
  const baseDeduction = getDeduction(baseMagi);
  const taxableIncomeBeforeConversion = Math.max(0, baseMagi - baseDeduction);

  const policyName =
    strategy.type === 'manual'
      ? 'manual'
      : strategy.type === 'none'
      ? 'none'
      : strategy.targetBracketName || 'fill_12';

  // Check age window and available pre-tax balance
  if (
    strategy.type === 'none' ||
    ctx.age < strategy.startAge ||
    ctx.age > strategy.endAge ||
    ctx.availablePreTaxBalance <= 0
  ) {
    return {
      policy: policyName,
      requestedConversion: 0,
      actualConversion: 0,
      taxableIncomeBeforeConversion,
      availablePreTaxBeforeConversion: ctx.availablePreTaxBalance,
      limitedByAvailablePreTax: false,
      federalDeductionUsed: baseDeduction,
    };
  }

  if (strategy.type === 'manual') {
    const target = strategy.annualTarget;
    const requestedConversion = Math.min(target, ctx.availablePreTaxBalance);
    const limitedByAvailablePreTax = target > ctx.availablePreTaxBalance;
    const manualOtherMagi = ctx.ordinaryIncomeBeforeConversion + requestedConversion;
    const manualTaxableSs = calculateTaxableSs(ctx.totalSs, manualOtherMagi, ctx.isJoint);
    const manualMagi = manualOtherMagi + manualTaxableSs;
    const manualDeduction = getDeduction(manualMagi);

    return {
      policy: 'manual',
      requestedConversion,
      actualConversion: requestedConversion,
      taxableIncomeBeforeConversion,
      availablePreTaxBeforeConversion: ctx.availablePreTaxBalance,
      limitedByAvailablePreTax,
      federalDeductionUsed: manualDeduction,
    };
  }

  // Bracket Fill Strategy
  const bracketRate = strategy.bracket ?? 0.12;
  const bracketCeiling =
    bracketRate === 0.22
      ? ctx.bracketCeilings.b22
      : bracketRate === 0.24
      ? ctx.bracketCeilings.b24
      : ctx.bracketCeilings.b12;

  const remainingBracketCapacity = Math.max(0, bracketCeiling - taxableIncomeBeforeConversion);

  // Binary search to find max conversion C <= availablePreTaxBalance such that taxable income <= bracketCeiling
  let low = 0;
  let high = Math.floor(ctx.availablePreTaxBalance);
  let bestC = 0;

  while (low <= high) {
    const mid = Math.floor((low + high) / 2);
    const otherMagi = ctx.ordinaryIncomeBeforeConversion + mid;
    const taxableSs = calculateTaxableSs(ctx.totalSs, otherMagi, ctx.isJoint);
    const candidateMagi = otherMagi + taxableSs;
    const candidateDeduction = getDeduction(candidateMagi);
    const netTaxable = Math.max(0, candidateMagi - candidateDeduction);

    if (netTaxable <= bracketCeiling) {
      bestC = mid;
      low = mid + 1;
    } else {
      high = mid - 1;
    }
  }

  // Check if limited by available pre-tax balance:
  // If converting 1 more dollar of pre-tax balance would still fit under bracketCeiling
  const testMorePreTax = bestC + 1;
  const testOtherMagi = ctx.ordinaryIncomeBeforeConversion + testMorePreTax;
  const testTaxableSs = calculateTaxableSs(ctx.totalSs, testOtherMagi, ctx.isJoint);
  const testMagi = testOtherMagi + testTaxableSs;
  const testDeduction = getDeduction(testMagi);
  const testNetTaxable = Math.max(0, testMagi - testDeduction);
  const limitedByAvailablePreTax =
    bestC === Math.floor(ctx.availablePreTaxBalance) && testNetTaxable <= bracketCeiling;

  const finalOtherMagi = ctx.ordinaryIncomeBeforeConversion + bestC;
  const finalTaxableSs = calculateTaxableSs(ctx.totalSs, finalOtherMagi, ctx.isJoint);
  const finalMagi = finalOtherMagi + finalTaxableSs;
  const finalDeduction = getDeduction(finalMagi);

  return {
    policy: policyName,
    requestedConversion: bestC,
    actualConversion: bestC,
    bracketRate,
    bracketCeiling,
    taxableIncomeBeforeConversion,
    remainingBracketCapacity,
    availablePreTaxBeforeConversion: ctx.availablePreTaxBalance,
    limitedByAvailablePreTax,
    federalDeductionUsed: finalDeduction,
  };
}
