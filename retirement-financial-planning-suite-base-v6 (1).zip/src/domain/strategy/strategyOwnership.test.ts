import { describe, it, expect } from 'vitest';
import { DEFAULT_PLAN } from '../../constants/defaultPlan';
import { Plan } from '../../types';
import { resolveRetirementStrategy, getRothConversionPolicyLabel, getRothConversionPolicyBadge } from './index';
import { runSimulation } from '../simulation/simulationEngine';

describe('Strategy Consolidation & Component Ownership', () => {
  it('resolves strategy strictly from plan spendingAssumptions defaults', () => {
    const plan: Plan = {
      ...DEFAULT_PLAN,
      spendingAssumptions: {
        ...DEFAULT_PLAN.spendingAssumptions!,
        conversionStrategy: 'fill_22',
        withdrawalPolicy: 'pretax_first',
        taxPaymentSource: 'taxable_brokerage',
        annualRothConversionTarget: 50000,
        rothConversionStartAge: 60,
        rothConversionEndAge: 70,
      },
    };

    const strategy = resolveRetirementStrategy(plan);
    expect(strategy.withdrawal.policyId).toBe('pretax_first');
    expect(strategy.rothConversion.type).toBe('fill_bracket');
    if (strategy.rothConversion.type === 'fill_bracket') {
      expect(strategy.rothConversion.bracket).toBe(0.22);
      expect(strategy.rothConversion.targetBracketName).toBe('fill_22');
    }
    expect(strategy.taxPayment.conversionTaxSource).toBe('taxable_brokerage');
    expect(strategy.rothConversion.startAge).toBe(60);
    expect(strategy.rothConversion.endAge).toBe(70);
    // Preserves annual target in state/plan
    expect(strategy.rothConversion.annualTarget).toBe(50000);
  });

  it('guarantees strategyOverride with type "none" produces zero Roth conversions', () => {
    const plan: Plan = {
      ...DEFAULT_PLAN,
      spendingAssumptions: {
        ...DEFAULT_PLAN.spendingAssumptions!,
        conversionStrategy: 'fill_24',
        annualRothConversionTarget: 100000,
        rothConversionStartAge: 60,
        rothConversionEndAge: 70,
      },
    };

    const sim = runSimulation(plan, {
      strategyOverride: { rothConversion: { type: 'none' } },
    });

    const totalConversions = sim.rows.reduce((sum, r) => sum + (r.rothConversion || 0), 0);
    expect(totalConversions).toBe(0);
    expect(sim.lifetimeConversionTaxPaidNominal).toBe(0);
  });

  it('formats policy labels and badges accurately across UI components', () => {
    const fill12Strategy = resolveRetirementStrategy({
      ...DEFAULT_PLAN,
      spendingAssumptions: {
        ...DEFAULT_PLAN.spendingAssumptions!,
        conversionStrategy: 'fill_12',
      },
    });

    expect(getRothConversionPolicyLabel(fill12Strategy.rothConversion)).toBe('Fill 12% Federal Bracket');
    expect(getRothConversionPolicyBadge(fill12Strategy.rothConversion)).toBe('Fill 12% Bracket');

    const manualStrategy = resolveRetirementStrategy({
      ...DEFAULT_PLAN,
      spendingAssumptions: {
        ...DEFAULT_PLAN.spendingAssumptions!,
        conversionStrategy: 'manual',
        annualRothConversionTarget: 35000,
      },
    });

    expect(getRothConversionPolicyLabel(manualStrategy.rothConversion)).toBe('Manual ($35,000/yr)');
    expect(getRothConversionPolicyBadge(manualStrategy.rothConversion)).toBe('Manual ($35k/yr)');

    const noneStrategy = resolveRetirementStrategy({
      ...DEFAULT_PLAN,
      spendingAssumptions: {
        ...DEFAULT_PLAN.spendingAssumptions!,
        conversionStrategy: 'none',
      },
    });

    expect(getRothConversionPolicyLabel(noneStrategy.rothConversion)).toBe('No Conversions');
    expect(getRothConversionPolicyBadge(noneStrategy.rothConversion)).toBe('No Conversions');
  });

  it('attaches rothConversionDecision audit logs to simulation rows for explainability', () => {
    const plan: Plan = {
      ...DEFAULT_PLAN,
      spendingAssumptions: {
        ...DEFAULT_PLAN.spendingAssumptions!,
        conversionStrategy: 'fill_12',
        rothConversionStartAge: 62,
        rothConversionEndAge: 65,
      },
    };

    const sim = runSimulation(plan);
    const rowInWindow = sim.rows.find((r) => r.age === 62);
    expect(rowInWindow).toBeDefined();
    expect(rowInWindow?.rothConversionDecision).toBeDefined();
    expect(rowInWindow?.rothConversionDecision?.policy).toBe('fill_12');
    expect(rowInWindow?.rothConversionDecision?.availablePreTaxBeforeConversion).toBeGreaterThanOrEqual(0);
  });

  it('enforces App.tsx routes strategy tab to StrategyStep and not PlannedModule', async () => {
    const fs = await import('fs');
    const path = await import('path');
    const appContent = fs.readFileSync(path.resolve(__dirname, '../../App.tsx'), 'utf-8');

    // StrategyStep must be imported
    expect(appContent).toContain("import { StrategyStep } from './components/StrategyStep'");

    // activeTab === 'strategy' must render StrategyStep
    expect(appContent).toMatch(/activeTab === 'strategy' && \(\s*<StrategyStep/);

    // Obsolete Strategy placeholder text must be absent
    expect(appContent).not.toContain('Withdrawal ordering — currently hardcoded');
  });

  it('enforces Cash Flow components are read-only for strategy configuration', async () => {
    const fs = await import('fs');
    const path = await import('path');
    const cashFlowContent = fs.readFileSync(path.resolve(__dirname, '../../components/Step4CashFlowStep.tsx'), 'utf-8');

    // Cash Flow must NOT contain strategy mutation handlers or bracket-fill buttons
    expect(cashFlowContent).not.toContain('handleAutoFillBracket');
    expect(cashFlowContent).not.toContain('handleAutoFill');

    // Must import ActiveStrategySummary or RothConversionImpactAnalysis
    expect(cashFlowContent).toContain('RothConversionImpactAnalysis');
  });
});
