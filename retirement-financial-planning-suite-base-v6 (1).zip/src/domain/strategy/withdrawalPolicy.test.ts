import { describe, it, expect } from 'vitest';
import { DEFAULT_PLAN } from '../../constants/defaultPlan';
import { resolveRetirementStrategy } from './strategyResolver';
import { executeWithdrawalSequence } from './withdrawalSequence';
import { solveRetirementCashNeed } from '../solver/solveRetirementCashNeed';
import { runSimulation } from '../simulation/simulationEngine';
import { Plan } from '../../types';
import { WITHDRAWAL_POLICIES, WithdrawalPolicyId } from './strategyTypes';
import { bracketCeilingsFor } from '../tax/taxConstants';

describe('Strategy Layer Phase 2: Configurable Withdrawal Ordering', () => {
  describe('Resolver and Policy Registry', () => {
    it('contains authoritative definitions for taxable_first, pretax_first, roth_first', () => {
      expect(WITHDRAWAL_POLICIES.taxable_first.order).toEqual([
        'cash',
        'taxable_brokerage',
        'pre_tax',
        'post_tax',
      ]);
      expect(WITHDRAWAL_POLICIES.pretax_first.order).toEqual([
        'cash',
        'pre_tax',
        'taxable_brokerage',
        'post_tax',
      ]);
      expect(WITHDRAWAL_POLICIES.roth_first.order).toEqual([
        'cash',
        'post_tax',
        'taxable_brokerage',
        'pre_tax',
      ]);
    });

    it('resolves withdrawalPolicy into Strategy with correct policyId and order', () => {
      const policies: WithdrawalPolicyId[] = ['taxable_first', 'pretax_first', 'roth_first'];
      for (const policyId of policies) {
        const plan: Plan = {
          ...DEFAULT_PLAN,
          spendingAssumptions: {
            ...DEFAULT_PLAN.spendingAssumptions!,
            withdrawalPolicy: policyId,
          },
        };
        const strategy = resolveRetirementStrategy(plan);
        expect(strategy.withdrawal.policyId).toBe(policyId);
        expect(strategy.withdrawal.order).toEqual(WITHDRAWAL_POLICIES[policyId].order);
      }
    });

    it('falls back safely to taxable_first when withdrawalPolicy is missing or invalid', () => {
      const planInvalid: Plan = {
        ...DEFAULT_PLAN,
        spendingAssumptions: {
          ...DEFAULT_PLAN.spendingAssumptions!,
          withdrawalPolicy: 'non_existent_policy' as unknown as WithdrawalPolicyId,
        },
      };
      const strategy = resolveRetirementStrategy(planInvalid);
      expect(strategy.withdrawal.policyId).toBe('taxable_first');
      expect(strategy.withdrawal.order).toEqual(WITHDRAWAL_POLICIES.taxable_first.order);
    });
  });

  describe('Solver & Executor Policy Execution', () => {
    it('pretax_first draws cash then pre-tax before taxable brokerage and post-tax', () => {
      const plan: Plan = {
        ...DEFAULT_PLAN,
        spendingAssumptions: {
          ...DEFAULT_PLAN.spendingAssumptions!,
          withdrawalPolicy: 'pretax_first',
        },
      };
      const strategy = resolveRetirementStrategy(plan);

      const solverRes = solveRetirementCashNeed({
        spending: plan.spendingAssumptions!,
        strategy,
        preTaxBalAvail: 100000,
        taxableBalAvail: 100000,
        postTaxBalAvail: 100000,
        cashBal: 10000,
        taxableBrokerageBal: 90000,
        taxableBrokerageCostBasis: 45000,
        rmdDraw: 0,
        totalSs: 0,
        pensionIncome: 0,
        annualSalaryIncome: 0,
        otherGuaranteedIncome: 0,
        age: 65,
        spouseAge: undefined,
        hasSpouse: false,
        isJoint: false,
        deflator: 1,
        bracketCeilings: bracketCeilingsFor(false, 1),
        stdDeduction: 14600,
        rothConversion: 0,
        conversionTaxPaid: 0,
        expenseNeedExAca: 30000,
        guaranteedIncome: 0,
        acaPremiumFor: () => 0,
      });

      // 30,000 cash gap needed:
      // First 10,000 drawn from cash.
      // Remaining cash gap (20,000 + tax gross up) drawn from pre-tax!
      // Taxable brokerage and post-tax should remain 0 extra.
        expect(solverRes.iteratedPreTaxWdExtra).toBeGreaterThanOrEqual(20000);
        expect(solverRes.iteratedTaxableWd).toBe(10000); // cash portion only
        expect(solverRes.iteratedPostTaxWd).toBe(0);
    });

    it('roth_first draws cash then post-tax (Roth) before taxable brokerage and pre-tax', () => {
      const plan: Plan = {
        ...DEFAULT_PLAN,
        spendingAssumptions: {
          ...DEFAULT_PLAN.spendingAssumptions!,
          withdrawalPolicy: 'roth_first',
        },
      };
      const strategy = resolveRetirementStrategy(plan);

      const solverRes = solveRetirementCashNeed({
        spending: plan.spendingAssumptions!,
        strategy,
        preTaxBalAvail: 100000,
        taxableBalAvail: 100000,
        postTaxBalAvail: 100000,
        cashBal: 10000,
        taxableBrokerageBal: 90000,
        taxableBrokerageCostBasis: 45000,
        rmdDraw: 0,
        totalSs: 0,
        pensionIncome: 0,
        annualSalaryIncome: 0,
        otherGuaranteedIncome: 0,
        age: 65,
        spouseAge: undefined,
        hasSpouse: false,
        isJoint: false,
        deflator: 1,
        bracketCeilings: bracketCeilingsFor(false, 1),
        stdDeduction: 14600,
        rothConversion: 0,
        conversionTaxPaid: 0,
        expenseNeedExAca: 30000,
        guaranteedIncome: 0,
        acaPremiumFor: () => 0,
      });

      // 30,000 cash gap needed:
      // First 10,000 drawn from cash.
      // Remaining 20,000 drawn from post-tax (Roth).
      // Pre-tax and brokerage remain 0 extra.
      expect(solverRes.iteratedPostTaxWd).toBe(20000);
      expect(solverRes.iteratedTaxableWd).toBe(10000); // cash portion only
      expect(solverRes.iteratedPreTaxWdExtra).toBe(0);
    });

    it('verifies solver estimated mix and executor actual mix are identical', () => {
      const plan: Plan = {
        ...DEFAULT_PLAN,
        spendingAssumptions: {
          ...DEFAULT_PLAN.spendingAssumptions!,
          withdrawalPolicy: 'pretax_first',
        },
      };
      const strategy = resolveRetirementStrategy(plan);

      const solverRes = solveRetirementCashNeed({
        spending: plan.spendingAssumptions!,
        strategy,
        preTaxBalAvail: 100000,
        taxableBalAvail: 100000,
        postTaxBalAvail: 100000,
        cashBal: 10000,
        taxableBrokerageBal: 90000,
        taxableBrokerageCostBasis: 45000,
        rmdDraw: 0,
        totalSs: 0,
        pensionIncome: 0,
        annualSalaryIncome: 0,
        otherGuaranteedIncome: 0,
        age: 65,
        spouseAge: undefined,
        hasSpouse: false,
        isJoint: false,
        deflator: 1,
        bracketCeilings: bracketCeilingsFor(false, 1),
        stdDeduction: 14600,
        rothConversion: 0,
        conversionTaxPaid: 0,
        expenseNeedExAca: 30000,
        guaranteedIncome: 0,
        acaPremiumFor: () => 0,
      });

        // solver/executor consistency test
        const execRes = executeWithdrawalSequence({
        taxableWd: solverRes.iteratedTaxableWd,
        preTaxWd: solverRes.iteratedPreTaxWdExtra,
        postTaxWd: solverRes.iteratedPostTaxWd,
        rothConversion: 0,
        conversionTaxPaid: 0,
        spending: plan.spendingAssumptions!,
        strategy,
        cashBal: 10000,
        taxableBrokerageBal: 90000,
        taxableBrokerageCostBasis: 45000,
        preTaxBal: 100000,
        postTaxBal: 100000,
      });

      expect(execRes.taxableWd).toBe(solverRes.iteratedTaxableWd);
      expect(execRes.preTaxWd).toBe(solverRes.iteratedPreTaxWdExtra);
      expect(execRes.postTaxWd).toBe(solverRes.iteratedPostTaxWd);
      expect(execRes.totalWithdrawals).toBe(
        solverRes.iteratedTaxableWd + solverRes.iteratedPreTaxWdExtra + solverRes.iteratedPostTaxWd
      );
    });
  });

  describe('Depletion & Insufficient Balance Safety', () => {
    it('caps actual withdrawals at available balance across all policies without negative balances', () => {
      const policies: WithdrawalPolicyId[] = ['taxable_first', 'pretax_first', 'roth_first'];
      for (const policyId of policies) {
        const plan: Plan = {
          ...DEFAULT_PLAN,
          spendingAssumptions: {
            ...DEFAULT_PLAN.spendingAssumptions!,
            withdrawalPolicy: policyId,
          },
        };
        const strategy = resolveRetirementStrategy(plan);

        const result = executeWithdrawalSequence({
          taxableWd: 50000,
          preTaxWd: 50000,
          postTaxWd: 50000,
          rothConversion: 0,
          conversionTaxPaid: 0,
          spending: plan.spendingAssumptions!,
          strategy,
          cashBal: 2000,
          taxableBrokerageBal: 3000,
          taxableBrokerageCostBasis: 1500,
          preTaxBal: 4000,
          postTaxBal: 5000,
        });

        expect(result.cashBal).toBe(0);
        expect(result.taxableBrokerageBal).toBe(0);
        expect(result.preTaxBal).toBe(0);
        expect(result.postTaxBal).toBe(0);
        expect(result.taxableWd).toBe(5000); // 2k + 3k
        expect(result.preTaxWd).toBe(4000);
        expect(result.postTaxWd).toBe(5000);
        expect(result.totalWithdrawals).toBe(14000);
      }
    });
  });

  describe('Cost Basis & Capital Gains Accounting', () => {
    it('computes proportional cost-basis reduction when brokerage is drawn under pretax_first', () => {
      const result = executeWithdrawalSequence({
        taxableWd: 20000, // 10k cash + 10k brokerage
        preTaxWd: 30000,
        postTaxWd: 0,
        rothConversion: 0,
        conversionTaxPaid: 0,
        spending: DEFAULT_PLAN.spendingAssumptions!,
        cashBal: 10000,
        taxableBrokerageBal: 50000,
        taxableBrokerageCostBasis: 25000, // 50% basis
        preTaxBal: 100000,
        postTaxBal: 100000,
      });

      // 10k drawn from brokerage with 50% basis ratio = 5k basis removed, 5k gain
      expect(result.realizedCapGains).toBe(5000);
      expect(result.taxableBrokerageCostBasis).toBe(20000); // 25k - 5k
      expect(result.taxableBrokerageBal).toBe(40000); // 50k - 10k
    });
  });

  describe('Full Simulation & Zero Drift Gate', () => {
    it('default plan with taxable_first produces identical simulation results', () => {
      const resDefault = runSimulation(DEFAULT_PLAN);

      const planTaxableFirst: Plan = {
        ...DEFAULT_PLAN,
        spendingAssumptions: {
          ...DEFAULT_PLAN.spendingAssumptions!,
          withdrawalPolicy: 'taxable_first',
        },
      };
      const resExplicit = runSimulation(planTaxableFirst);

      expect(resExplicit.rows.length).toBe(resDefault.rows.length);
      for (let i = 0; i < resDefault.rows.length; i++) {
        expect(resExplicit.rows[i].totalPortfolio).toBeCloseTo(
          resDefault.rows[i].totalPortfolio,
          5
        );
        expect(resExplicit.rows[i].preTaxWd).toBeCloseTo(
          resDefault.rows[i].preTaxWd,
          5
        );
        expect(resExplicit.rows[i].postTaxWd).toBeCloseTo(
          resDefault.rows[i].postTaxWd,
          5
        );
      }
    });

    it('pretax_first alters withdrawal order in full simulation without breaking engine invariants', () => {
      const planPretax: Plan = {
        ...DEFAULT_PLAN,
        spendingAssumptions: {
          ...DEFAULT_PLAN.spendingAssumptions!,
          withdrawalPolicy: 'pretax_first',
        },
      };
      const resPretax = runSimulation(planPretax);

      expect(resPretax.rows.length).toBeGreaterThan(0);
      // RMD, tax, net worth all computed without error
      for (const row of resPretax.rows) {
        expect(row.taxableBal).toBeGreaterThanOrEqual(0);
        expect(row.preTaxBal).toBeGreaterThanOrEqual(0);
        expect(row.postTaxBal).toBeGreaterThanOrEqual(0);
      }
    });

    it('roth_first alters withdrawal order in full simulation without breaking engine invariants', () => {
      const planRoth: Plan = {
        ...DEFAULT_PLAN,
        spendingAssumptions: {
          ...DEFAULT_PLAN.spendingAssumptions!,
          withdrawalPolicy: 'roth_first',
        },
      };
      const resRoth = runSimulation(planRoth);

      expect(resRoth.rows.length).toBeGreaterThan(0);
      for (const row of resRoth.rows) {
        expect(row.taxableBal).toBeGreaterThanOrEqual(0);
        expect(row.preTaxBal).toBeGreaterThanOrEqual(0);
        expect(row.postTaxBal).toBeGreaterThanOrEqual(0);
      }
    });
  });

  describe('Scenario Safety & Immutability', () => {
    it('cloning plan and changing withdrawalPolicy does not mutate original plan', () => {
      const originalPlan = JSON.parse(JSON.stringify(DEFAULT_PLAN));
      const clonedPlan: Plan = {
        ...DEFAULT_PLAN,
        spendingAssumptions: {
          ...DEFAULT_PLAN.spendingAssumptions!,
          withdrawalPolicy: 'roth_first',
        },
      };

      const originalStrategy = resolveRetirementStrategy(DEFAULT_PLAN);
      const clonedStrategy = resolveRetirementStrategy(clonedPlan);

      expect(originalStrategy.withdrawal.policyId).toBe('taxable_first');
      expect(clonedStrategy.withdrawal.policyId).toBe('roth_first');
      expect(JSON.parse(JSON.stringify(DEFAULT_PLAN))).toEqual(originalPlan);
    });
  });
});
