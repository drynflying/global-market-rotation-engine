import { describe, it, expect } from 'vitest';
import { DEFAULT_PLAN } from '../../constants/defaultPlan';
import { resolveRetirementStrategy } from './strategyResolver';
import { Plan } from '../../types';

describe('strategyResolver', () => {
  it('1. Default Plan resolves to current withdrawal order', () => {
    const strategy = resolveRetirementStrategy(DEFAULT_PLAN);
    expect(strategy.withdrawal).toEqual({
      type: 'ordered',
      policyId: 'taxable_first',
      order: ['cash', 'taxable_brokerage', 'pre_tax', 'post_tax'],
    });
  });

  it('2. Missing optional conversionStrategy resolves safely to manual', () => {
    const planNoConvStrat: Plan = {
      ...DEFAULT_PLAN,
      spendingAssumptions: {
        ...DEFAULT_PLAN.spendingAssumptions!,
        conversionStrategy: undefined,
      },
    };
    const strategy = resolveRetirementStrategy(planNoConvStrat);
    expect(strategy.rothConversion.type).toBe('manual');
  });

  it('3. manual preserves annualRothConversionTarget', () => {
    const planManual: Plan = {
      ...DEFAULT_PLAN,
      spendingAssumptions: {
        ...DEFAULT_PLAN.spendingAssumptions!,
        conversionStrategy: 'manual',
        annualRothConversionTarget: 45000,
      },
    };
    const strategy = resolveRetirementStrategy(planManual);
    expect(strategy.rothConversion).toEqual({
      type: 'manual',
      annualTarget: 45000,
      startAge: DEFAULT_PLAN.spendingAssumptions!.rothConversionStartAge,
      endAge: DEFAULT_PLAN.spendingAssumptions!.rothConversionEndAge,
    });
  });

  it('4. fill_12 resolves to the correct strategy type/metadata', () => {
    const planFill12: Plan = {
      ...DEFAULT_PLAN,
      spendingAssumptions: {
        ...DEFAULT_PLAN.spendingAssumptions!,
        conversionStrategy: 'fill_12',
        annualRothConversionTarget: 25000,
      },
    };
    const strategy = resolveRetirementStrategy(planFill12);
    expect(strategy.rothConversion).toEqual({
      type: 'fill_bracket',
      bracket: 0.12,
      targetBracketName: 'fill_12',
      annualTarget: 25000,
      startAge: DEFAULT_PLAN.spendingAssumptions!.rothConversionStartAge,
      endAge: DEFAULT_PLAN.spendingAssumptions!.rothConversionEndAge,
    });
  });

  it('5. fill_22 resolves correctly', () => {
    const planFill22: Plan = {
      ...DEFAULT_PLAN,
      spendingAssumptions: {
        ...DEFAULT_PLAN.spendingAssumptions!,
        conversionStrategy: 'fill_22',
        annualRothConversionTarget: 60000,
      },
    };
    const strategy = resolveRetirementStrategy(planFill22);
    expect(strategy.rothConversion.type).toBe('fill_bracket');
    if (strategy.rothConversion.type === 'fill_bracket') {
      expect(strategy.rothConversion.bracket).toBe(0.22);
      expect(strategy.rothConversion.targetBracketName).toBe('fill_22');
      expect(strategy.rothConversion.annualTarget).toBe(60000);
    }
  });

  it('6. fill_24 resolves correctly', () => {
    const planFill24: Plan = {
      ...DEFAULT_PLAN,
      spendingAssumptions: {
        ...DEFAULT_PLAN.spendingAssumptions!,
        conversionStrategy: 'fill_24',
        annualRothConversionTarget: 95000,
      },
    };
    const strategy = resolveRetirementStrategy(planFill24);
    expect(strategy.rothConversion.type).toBe('fill_bracket');
    if (strategy.rothConversion.type === 'fill_bracket') {
      expect(strategy.rothConversion.bracket).toBe(0.24);
      expect(strategy.rothConversion.targetBracketName).toBe('fill_24');
      expect(strategy.rothConversion.annualTarget).toBe(95000);
    }
  });

  it('7. Roth conversion start/end ages propagate correctly', () => {
    const planAges: Plan = {
      ...DEFAULT_PLAN,
      spendingAssumptions: {
        ...DEFAULT_PLAN.spendingAssumptions!,
        rothConversionStartAge: 62,
        rothConversionEndAge: 68,
      },
    };
    const strategy = resolveRetirementStrategy(planAges);
    expect(strategy.rothConversion.startAge).toBe(62);
    expect(strategy.rothConversion.endAge).toBe(68);
  });

  it('8. taxable-brokerage tax source resolves correctly', () => {
    const planTaxable: Plan = {
      ...DEFAULT_PLAN,
      spendingAssumptions: {
        ...DEFAULT_PLAN.spendingAssumptions!,
        taxPaymentSource: 'taxable_brokerage',
      },
    };
    const strategy = resolveRetirementStrategy(planTaxable);
    expect(strategy.taxPayment.conversionTaxSource).toBe('taxable_brokerage');
  });

  it('9. conversion-proceeds source resolves correctly', () => {
    const planProceeds: Plan = {
      ...DEFAULT_PLAN,
      spendingAssumptions: {
        ...DEFAULT_PLAN.spendingAssumptions!,
        taxPaymentSource: 'conversion_proceeds',
      },
    };
    const strategy = resolveRetirementStrategy(planProceeds);
    expect(strategy.taxPayment.conversionTaxSource).toBe('conversion_proceeds');
  });

  it('10. Resolver does not mutate Plan', () => {
    const planSnapshot = JSON.stringify(DEFAULT_PLAN);
    resolveRetirementStrategy(DEFAULT_PLAN, { overrideConversionTarget: 50000 });
    expect(JSON.stringify(DEFAULT_PLAN)).toBe(planSnapshot);
  });
});
