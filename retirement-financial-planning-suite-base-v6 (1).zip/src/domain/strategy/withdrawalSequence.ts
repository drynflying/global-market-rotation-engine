import { SpendingAssumptions } from '../../types';
import {
  RetirementStrategy,
  WithdrawalStrategy,
  ConversionTaxPaymentSource,
} from './strategyTypes';

export interface WithdrawalSequenceInput {
  taxableWd: number;
  preTaxWd: number;
  postTaxWd: number;
  rothConversion: number;
  conversionTaxPaid: number;
  spending?: SpendingAssumptions;
  cashBal: number;
  taxableBrokerageBal: number;
  taxableBrokerageCostBasis: number;
  preTaxBal: number;
  postTaxBal: number;
  strategy?: RetirementStrategy;
  taxPaymentSource?: ConversionTaxPaymentSource;
  withdrawalStrategy?: WithdrawalStrategy;
}

export interface WithdrawalSequenceResult {
  realizedCapGains: number;
  cashBal: number;
  taxableBrokerageBal: number;
  taxableBrokerageCostBasis: number;
  taxableBal: number;
  preTaxBal: number;
  postTaxBal: number;
  taxableWd: number;
  preTaxWd: number;
  postTaxWd: number;
  totalWithdrawals: number;
  conversionTaxPortfolioOutflow: number;
}

/**
 * Executes withdrawal sequencing across cash and taxable brokerage accounts,
 * calculates realized capital gains, updates cost basis, and updates portfolio bucket balances.
 */
export function executeWithdrawalSequence(input: WithdrawalSequenceInput): WithdrawalSequenceResult {
  const {
    taxableWd: reqTaxableWd,
    preTaxWd: reqPreTaxWd,
    postTaxWd: reqPostTaxWd,
    rothConversion: reqRothConversion,
    conversionTaxPaid,
    spending,
    strategy,
    taxPaymentSource: explicitTaxPaymentSource,
  } = input;

  const taxPaymentSource: ConversionTaxPaymentSource =
    strategy?.taxPayment.conversionTaxSource ??
    explicitTaxPaymentSource ??
    spending?.taxPaymentSource ??
    'taxable_brokerage';

  let cashBal = input.cashBal;
  let taxableBrokerageBal = input.taxableBrokerageBal;
  let taxableBrokerageCostBasis = input.taxableBrokerageCostBasis;
  let preTaxBal = input.preTaxBal;
  let postTaxBal = input.postTaxBal;

  const totalTaxableOutRequested = reqTaxableWd + (taxPaymentSource === 'taxable_brokerage' ? conversionTaxPaid : 0);
  let realizedCapGains = 0;
  let totalTaxableDrawn = 0;

  if (totalTaxableOutRequested > 0) {
    const drawCash = Math.min(cashBal, totalTaxableOutRequested);
    const drawBrokerage = Math.min(taxableBrokerageBal, Math.max(0, totalTaxableOutRequested - drawCash));
    totalTaxableDrawn = drawCash + drawBrokerage;

    if (drawBrokerage > 0) {
      const basisRatio = taxableBrokerageBal > 0 ? Math.min(1, Math.max(0, taxableBrokerageCostBasis) / taxableBrokerageBal) : 1;
      const basisWithdrawn = drawBrokerage * basisRatio;
      realizedCapGains = Math.max(0, Math.round(drawBrokerage - basisWithdrawn));
      taxableBrokerageBal = Math.max(0, taxableBrokerageBal - drawBrokerage);
      taxableBrokerageCostBasis = Math.max(0, taxableBrokerageCostBasis - basisWithdrawn);
    }
    if (drawCash > 0) {
      cashBal = Math.max(0, cashBal - drawCash);
    }
  }

  // Actual executed taxable spending withdrawal
  const actualTaxableWd = Math.min(reqTaxableWd, totalTaxableDrawn);

  const conversionTaxPortfolioOutflow =
    taxPaymentSource === 'taxable_brokerage'
      ? Math.max(0, Math.round(totalTaxableDrawn - actualTaxableWd))
      : taxPaymentSource === 'conversion_proceeds'
      ? Math.min(Math.round(conversionTaxPaid), Math.round(reqRothConversion))
      : 0;

  const taxableBal = taxableBrokerageBal + cashBal;

  // Pre-tax withdrawal execution
  const actualRothConversion = Math.min(preTaxBal, reqRothConversion);
  const preTaxAvailAfterConv = preTaxBal - actualRothConversion;
  const actualPreTaxWd = Math.min(preTaxAvailAfterConv, reqPreTaxWd);
  preTaxBal = preTaxAvailAfterConv - actualPreTaxWd;

  // Post-tax (Roth) withdrawal execution
  let netRothAdded = actualRothConversion;
  if (taxPaymentSource === 'conversion_proceeds') {
    const conversionTaxDeducted = Math.min(Math.round(conversionTaxPaid), Math.round(actualRothConversion));
    netRothAdded = Math.max(0, actualRothConversion - conversionTaxDeducted);
  }
  const availPostTax = postTaxBal + netRothAdded;
  const actualPostTaxWd = Math.min(availPostTax, reqPostTaxWd);
  postTaxBal = availPostTax - actualPostTaxWd;

  const totalWithdrawals = Math.round(actualTaxableWd + actualPreTaxWd + actualPostTaxWd);

  return {
    realizedCapGains,
    cashBal,
    taxableBrokerageBal,
    taxableBrokerageCostBasis,
    taxableBal,
    preTaxBal,
    postTaxBal,
    taxableWd: actualTaxableWd,
    preTaxWd: actualPreTaxWd,
    postTaxWd: actualPostTaxWd,
    totalWithdrawals,
    conversionTaxPortfolioOutflow,
  };
}
