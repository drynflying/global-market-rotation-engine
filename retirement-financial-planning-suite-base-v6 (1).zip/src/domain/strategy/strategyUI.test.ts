import { describe, it, expect } from 'vitest';
import { DEFAULT_PLAN } from '../../constants/defaultPlan';
import { resolveRetirementStrategy } from './strategyResolver';
import { WITHDRAWAL_POLICIES } from './strategyTypes';
import { getSimulation } from '../simulation/simulationCache';

describe('Strategy UI & Contract Binding Tests', () => {
  it('resolves default plan to authoritative Taxable First strategy', () => {
    const strategy = resolveRetirementStrategy(DEFAULT_PLAN);
    expect(strategy.withdrawal.policyId).toBe('taxable_first');
    expect(strategy.withdrawal.order).toEqual(WITHDRAWAL_POLICIES.taxable_first.order);
    expect(strategy.rothConversion.type).toBe('manual');
    expect(strategy.taxPayment.conversionTaxSource).toBe('taxable_brokerage');
  });

  it('correctly maps plan spendingAssumptions updates to resolved strategy', () => {
    const updatedPlan = {
      ...DEFAULT_PLAN,
      spendingAssumptions: {
        ...DEFAULT_PLAN.spendingAssumptions!,
        withdrawalPolicy: 'pretax_first' as const,
        conversionStrategy: 'fill_12' as const,
        rothConversionStartAge: 62,
        rothConversionEndAge: 72,
        taxPaymentSource: 'conversion_proceeds' as const,
      },
    };

    const strategy = resolveRetirementStrategy(updatedPlan);
    expect(strategy.withdrawal.policyId).toBe('pretax_first');
    expect(strategy.withdrawal.order).toEqual(['cash', 'pre_tax', 'taxable_brokerage', 'post_tax']);
    expect(strategy.rothConversion.type).toBe('fill_bracket');
    if (strategy.rothConversion.type === 'fill_bracket') {
      expect(strategy.rothConversion.bracket).toBe(0.12);
      expect(strategy.rothConversion.targetBracketName).toBe('fill_12');
      expect(strategy.rothConversion.startAge).toBe(62);
      expect(strategy.rothConversion.endAge).toBe(72);
    }
    expect(strategy.taxPayment.conversionTaxSource).toBe('conversion_proceeds');
  });

  it('runs simulation with fill_12 strategy and produces conversion explainability fields', () => {
    const fill12Plan = {
      ...DEFAULT_PLAN,
      spendingAssumptions: {
        ...DEFAULT_PLAN.spendingAssumptions!,
        conversionStrategy: 'fill_12' as const,
        rothConversionStartAge: 60,
        rothConversionEndAge: 65,
      },
    };

    const sim = getSimulation(fill12Plan);
    expect(sim.rows.length).toBeGreaterThan(0);

    const conversionWindowRows = sim.rows.filter((r) => r.age >= 60 && r.age <= 65);
    expect(conversionWindowRows.length).toBe(6);

    for (const row of conversionWindowRows) {
      expect(row.preTaxAvailableBeforeConversion).toBeDefined();
      expect(row.rothConversion).toBeGreaterThanOrEqual(0);
      expect(row.conversionTaxPaid).toBeGreaterThanOrEqual(0);
    }
  });

  it('computes lifetime metrics accurately without mixing nominal and real', () => {
    const sim = getSimulation(DEFAULT_PLAN);
    expect(sim.lifetimeConversionTaxPaidNominal).toBeGreaterThanOrEqual(0);
    expect(sim.lifetimeConversionTaxPaidReal).toBeGreaterThanOrEqual(0);
    expect(sim.lifetimeTotalTaxNominal).toBeGreaterThan(0);
    expect(sim.lifetimeTotalTaxReal).toBeGreaterThan(0);
    expect(sim.lifetimeTotalTaxNominal).toBeGreaterThanOrEqual(sim.lifetimeTotalTaxReal);
  });

  it('runs deterministic scenario comparison between Plan A (taxable_first, manual) and Plan B (pretax_first, fill_22)', () => {
    const planA = {
      ...DEFAULT_PLAN,
      id: 'plan-a',
      name: 'Plan A: Taxable First Manual',
      spendingAssumptions: {
        ...DEFAULT_PLAN.spendingAssumptions!,
        withdrawalPolicy: 'taxable_first' as const,
        conversionStrategy: 'manual' as const,
        annualRothConversionTarget: 30000,
        rothConversionStartAge: 60,
        rothConversionEndAge: 70,
      },
    };

    const planB = {
      ...DEFAULT_PLAN,
      id: 'plan-b',
      name: 'Plan B: Pretax First Fill 22',
      spendingAssumptions: {
        ...DEFAULT_PLAN.spendingAssumptions!,
        withdrawalPolicy: 'pretax_first' as const,
        conversionStrategy: 'fill_22' as const,
        annualRothConversionTarget: 0,
        rothConversionStartAge: 60,
        rothConversionEndAge: 70,
      },
    };

    const simA = getSimulation(planA);
    const simB = getSimulation(planB);
    const simABaseline = getSimulation(planA, { strategyOverride: { rothConversion: { type: 'none' } } });

    // Verify simulations are distinct and truthful
    expect(simA.lifetimeConversionTaxPaidNominal).not.toBe(simB.lifetimeConversionTaxPaidNominal);
    expect(simB.lifetimeConversionTaxPaidNominal).toBeGreaterThan(0);
    expect(simA.lifetimeTotalTaxNominal).not.toBe(simB.lifetimeTotalTaxNominal);

    // Verify Plan B's simulation results are driven by its own strategy
    const stratB = resolveRetirementStrategy(planB);
    expect(stratB.withdrawal.policyId).toBe('pretax_first');
    expect(stratB.rothConversion.type).toBe('fill_bracket');
    if (stratB.rothConversion.type === 'fill_bracket') {
      expect(stratB.rothConversion.bracket).toBe(0.22);
    }

    // Verify baseline for Plan A is separate from Plan B
    expect(simABaseline.lifetimeConversionTaxPaidNominal).toBe(0);
  });

  it('ensures simulation rows have strictly increasing calendarYear matching plan age timeline', () => {
    const sim = getSimulation(DEFAULT_PLAN);
    expect(sim.rows.length).toBeGreaterThan(0);
    const startYear = sim.rows[0].calendarYear;
    expect(startYear).toBeGreaterThan(2000);

    for (let i = 0; i < sim.rows.length; i++) {
      expect(sim.rows[i].calendarYear).toBe(startYear + i);
      expect(sim.rows[i].age).toBe(DEFAULT_PLAN.primaryPerson.currentAge + i);
    }
  });
});
