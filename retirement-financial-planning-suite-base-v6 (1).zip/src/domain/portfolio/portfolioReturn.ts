import { AccountItem, CapitalMarketAssumptions } from '../../types';

export interface PortfolioCategoryGrowthRates {
  growthPreTax: number;
  growthPostTax: number;
  growthTaxableBrokerage: number;
  growthCash: number;
}

export interface DefaultAssetAllocation {
  usEq: number;
  intlEq: number;
  gold: number;
  bonds: number;
  cash: number;
}

/**
 * Computes weighted return for an account category given CMA asset returns and fee drag.
 */
export function getCategoryReturn(
  accs: AccountItem[],
  defaultAlloc: DefaultAssetAllocation,
  cma: CapitalMarketAssumptions,
  feeDrag: number
): number {
  const calcAllocReturn = (alloc: { usEquityPct: number; intlEquityPct: number; goldPct?: number; bondsPct: number; cashPct: number }) => {
    return (
      (alloc.usEquityPct / 100) * (cma.usLargeEquity.derivedGeometric / 100) +
      (alloc.intlEquityPct / 100) * (cma.intlEquity.derivedGeometric / 100) +
      ((alloc.goldPct || 0) / 100) * ((cma.gold?.derivedGeometric || 3.0) / 100) +
      (alloc.bondsPct / 100) * (cma.intermediateBonds.derivedGeometric / 100) +
      (alloc.cashPct / 100) * (cma.cashEquivalents.derivedGeometric / 100)
    ) - feeDrag;
  };

  if (accs.length === 0) {
    return calcAllocReturn({
      usEquityPct: defaultAlloc.usEq,
      intlEquityPct: defaultAlloc.intlEq,
      goldPct: defaultAlloc.gold,
      bondsPct: defaultAlloc.bonds,
      cashPct: defaultAlloc.cash,
    });
  }

  let totalBal = 0;
  let weightedRet = 0;

  accs.forEach(a => {
    if (a.balance <= 0) return;
    const bal = a.balance;
    totalBal += bal;
    const alloc = a.allocation || {
      usEquityPct: defaultAlloc.usEq,
      intlEquityPct: defaultAlloc.intlEq,
      goldPct: defaultAlloc.gold,
      bondsPct: defaultAlloc.bonds,
      cashPct: defaultAlloc.cash,
    };

    const ret = calcAllocReturn(alloc);
    weightedRet += bal * ret;
  });

  return totalBal > 0 ? weightedRet / totalBal : calcAllocReturn({
    usEquityPct: defaultAlloc.usEq,
    intlEquityPct: defaultAlloc.intlEq,
    goldPct: defaultAlloc.gold,
    bondsPct: defaultAlloc.bonds,
    cashPct: defaultAlloc.cash,
  });
}

/**
 * Computes category growth rates for pre-tax, post-tax, taxable brokerage, and cash buckets.
 */
export function calculateCategoryGrowthRates(
  preTaxAccs: AccountItem[],
  postTaxAccs: AccountItem[],
  taxableBrokerageAccs: AccountItem[],
  cashAccs: AccountItem[],
  cma: CapitalMarketAssumptions,
  feeDrag: number
): PortfolioCategoryGrowthRates {
  return {
    growthPreTax: getCategoryReturn(preTaxAccs, { usEq: 50, intlEq: 0, gold: 0, bonds: 50, cash: 0 }, cma, feeDrag),
    growthPostTax: getCategoryReturn(postTaxAccs, { usEq: 70, intlEq: 30, gold: 0, bonds: 0, cash: 0 }, cma, feeDrag),
    growthTaxableBrokerage: getCategoryReturn(taxableBrokerageAccs, { usEq: 40, intlEq: 0, gold: 0, bonds: 40, cash: 20 }, cma, feeDrag),
    growthCash: getCategoryReturn(cashAccs, { usEq: 0, intlEq: 0, gold: 0, bonds: 0, cash: 100 }, cma, feeDrag),
  };
}

/**
 * Computes annual blended return percentage based on beginning-of-year balances.
 */
export function calculateBlendedReturnPct(
  preTaxBal: number,
  postTaxBal: number,
  taxableBrokerageBal: number,
  cashBal: number,
  growth: PortfolioCategoryGrowthRates
): number {
  const total = preTaxBal + postTaxBal + taxableBrokerageBal + cashBal;
  if (total <= 0) return 0;
  return (
    (preTaxBal * growth.growthPreTax +
      postTaxBal * growth.growthPostTax +
      taxableBrokerageBal * growth.growthTaxableBrokerage +
      cashBal * growth.growthCash) /
    total
  ) * 100;
}
