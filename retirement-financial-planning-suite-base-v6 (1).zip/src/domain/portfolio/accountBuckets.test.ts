import { describe, it, expect } from 'vitest';
import { initializeAccountBuckets } from './accountBuckets';
import { Plan, AccountItem } from '../../types';

describe('accountBuckets', () => {
  it('groups pre-tax, post-tax (Roth), taxable brokerage, and cash accounts correctly', () => {
    const mockAccounts: AccountItem[] = [
      { id: '1', name: '401k', owner: 'primary', type: 'pre-tax', balance: 500000, annualContribution: 20000 },
      { id: '2', name: 'Roth IRA', owner: 'primary', type: 'post-tax', balance: 200000, annualContribution: 6000 },
      { id: '3', name: 'Brokerage', owner: 'primary', type: 'taxable', balance: 150000, annualContribution: 10000 },
      { id: '4', name: 'High Yield Savings', owner: 'primary', type: 'cash', balance: 50000, annualContribution: 5000 },
    ];

    const plan: Partial<Plan> = {
      accounts: mockAccounts,
    };

    const buckets = initializeAccountBuckets(plan as Plan);

    expect(buckets.preTaxBal).toBe(500000);
    expect(buckets.postTaxBal).toBe(200000);
    expect(buckets.taxableBrokerageBal).toBe(150000);
    expect(buckets.cashBal).toBe(50000);
    expect(buckets.taxableBal).toBe(200000);
    expect(buckets.initialCashTarget).toBe(50000);
    expect(buckets.taxableBrokerageCostBasis).toBe(150000);

    expect(buckets.preTaxAccs).toHaveLength(1);
    expect(buckets.postTaxAccs).toHaveLength(1);
    expect(buckets.taxableBrokerageAccs).toHaveLength(1);
    expect(buckets.cashAccs).toHaveLength(1);
  });

  it('excludes non-modeled accounts like real_estate or hsa if accountCapabilities marks them non-modeled', () => {
    const mockAccounts: AccountItem[] = [
      { id: '1', name: 'Primary Residence', owner: 'primary', type: 'real_estate' as unknown as AccountItem['type'], balance: 800000, annualContribution: 0 },
      { id: '2', name: 'HSA', owner: 'primary', type: 'hsa' as unknown as AccountItem['type'], balance: 30000, annualContribution: 3000 },
      { id: '3', name: '401k', owner: 'primary', type: 'pre-tax', balance: 100000, annualContribution: 0 },
    ];

    const plan: Partial<Plan> = {
      accounts: mockAccounts,
    };

    const buckets = initializeAccountBuckets(plan as Plan);

    expect(buckets.preTaxBal).toBe(100000);
    expect(buckets.postTaxBal).toBe(0);
    expect(buckets.taxableBrokerageBal).toBe(0);
    expect(buckets.cashBal).toBe(0);
  });

  it('handles empty account lists gracefully', () => {
    const plan: Partial<Plan> = { accounts: [] };
    const buckets = initializeAccountBuckets(plan as Plan);

    expect(buckets.preTaxBal).toBe(0);
    expect(buckets.postTaxBal).toBe(0);
    expect(buckets.taxableBrokerageBal).toBe(0);
    expect(buckets.cashBal).toBe(0);
    expect(buckets.initialCashTarget).toBe(0);
    expect(buckets.taxableBrokerageCostBasis).toBe(0);
  });
});
