import { describe, it, expect } from 'vitest';
import { getCategoryReturn, calculateCategoryGrowthRates, calculateBlendedReturnPct } from './portfolioReturn';
import { AccountItem, CapitalMarketAssumptions } from '../../types';

describe('portfolioReturn', () => {
  const mockCma = {
    usLargeEquity: { derivedGeometric: 8.0 },
    intlEquity: { derivedGeometric: 6.0 },
    gold: { derivedGeometric: 3.0 },
    intermediateBonds: { derivedGeometric: 4.0 },
    cashEquivalents: { derivedGeometric: 2.0 },
  } as unknown as CapitalMarketAssumptions;

  const defaultAlloc = { usEq: 60, intlEq: 20, gold: 0, bonds: 20, cash: 0 };

  it('computes weighted return using funded accounts only and ignores zero-balance accounts', () => {
    const accs: AccountItem[] = [
      {
        id: '1',
        name: 'Acc 1',
        owner: 'primary',
        type: 'pre-tax',
        balance: 100000,
        annualContribution: 0,
        allocation: { usEquityPct: 100, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 0 },
      },
      {
        id: '2',
        name: 'Acc 2',
        owner: 'primary',
        type: 'pre-tax',
        balance: 0, // Zero balance - should be ignored
        annualContribution: 0,
        allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 100 },
      },
    ];

    const feeDrag = 0.005; // 0.5%
    const ret = getCategoryReturn(accs, defaultAlloc, mockCma, feeDrag);

    // 100% US Eq (8.0% / 100 = 0.08) - 0.005 = 0.075
    expect(ret).toBeCloseTo(0.075, 5);
  });

  it('uses default allocation when account list is empty or all balances are zero', () => {
    const feeDrag = 0.002; // 0.2%
    const retEmpty = getCategoryReturn([], defaultAlloc, mockCma, feeDrag);

    // Default: 60% US Eq (8.0%), 20% Intl Eq (6.0%), 20% Bonds (4.0%)
    // (0.6 * 0.08 + 0.2 * 0.06 + 0.2 * 0.04) - 0.002 = 0.048 + 0.012 + 0.008 - 0.002 = 0.066
    expect(retEmpty).toBeCloseTo(0.066, 5);

    const zeroAccs: AccountItem[] = [
      { id: '1', name: 'Zero', owner: 'primary', type: 'cash', balance: 0, annualContribution: 0 },
    ];
    const retZero = getCategoryReturn(zeroAccs, defaultAlloc, mockCma, feeDrag);
    expect(retZero).toBeCloseTo(0.066, 5);
  });

  it('applies fee drag exactly once per account calculation', () => {
    const accs: AccountItem[] = [
      {
        id: '1',
        name: 'Cash Acc',
        owner: 'primary',
        type: 'cash',
        balance: 10000,
        annualContribution: 0,
        allocation: { usEquityPct: 0, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 100 },
      },
    ];
    const feeDrag = 0.001; // 0.1%
    const ret = getCategoryReturn(accs, defaultAlloc, mockCma, feeDrag);

    // 100% cash (2.0%) - 0.001 = 0.019
    expect(ret).toBeCloseTo(0.019, 5);
  });

  it('calculateCategoryGrowthRates calculates growth rates for all 4 asset buckets', () => {
    const preTaxAccs: AccountItem[] = [{ id: '1', name: '401k', owner: 'primary', type: 'pre-tax', balance: 100, annualContribution: 0, allocation: { usEquityPct: 100, intlEquityPct: 0, goldPct: 0, bondsPct: 0, cashPct: 0 } }];
    const postTaxAccs: AccountItem[] = [];
    const taxableBrokerageAccs: AccountItem[] = [];
    const cashAccs: AccountItem[] = [];

    const rates = calculateCategoryGrowthRates(preTaxAccs, postTaxAccs, taxableBrokerageAccs, cashAccs, mockCma, 0);

    expect(rates.growthPreTax).toBeCloseTo(0.08, 5);
    expect(rates.growthPostTax).toBeGreaterThan(0);
    expect(rates.growthTaxableBrokerage).toBeGreaterThan(0);
    expect(rates.growthCash).toBeCloseTo(0.02, 5); // 100% cash default
  });

  it('blended return weights category balances correctly', () => {
    const growth = {
      growthPreTax: 0.10, // 10%
      growthPostTax: 0.08, // 8%
      growthTaxableBrokerage: 0.06, // 6%
      growthCash: 0.02, // 2%
    };

    const preTaxBal = 500000;
    const postTaxBal = 200000;
    const taxableBrokerageBal = 200000;
    const cashBal = 100000;
    // Total = 1,000,000
    // Weighted return = 500k*0.10 + 200k*0.08 + 200k*0.06 + 100k*0.02 = 50k + 16k + 12k + 2k = 80k
    // Blended return pct = (80k / 1,000,000) * 100 = 8.0%

    const blended = calculateBlendedReturnPct(preTaxBal, postTaxBal, taxableBrokerageBal, cashBal, growth);
    expect(blended).toBeCloseTo(8.0, 5);
  });

  it('returns 0 blended return when total portfolio balance is zero', () => {
    const growth = { growthPreTax: 0.10, growthPostTax: 0.08, growthTaxableBrokerage: 0.06, growthCash: 0.02 };
    expect(calculateBlendedReturnPct(0, 0, 0, 0, growth)).toBe(0);
  });
});
