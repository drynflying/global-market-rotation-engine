import { Plan, AccountItem } from '../../types';
import { isAccountModeledInProjection } from '../accounts/accountCapabilities';

export interface InitialAccountBuckets {
  initialCashTarget: number;
  preTaxBal: number;
  postTaxBal: number;
  taxableBrokerageBal: number;
  cashBal: number;
  taxableBal: number;
  taxableBrokerageCostBasis: number;
  preTaxAccs: AccountItem[];
  postTaxAccs: AccountItem[];
  taxableBrokerageAccs: AccountItem[];
  cashAccs: AccountItem[];
}

/**
 * Initializes portfolio account bucket balances and grouped account arrays
 * for modeable accounts in the simulation projection.
 */
export function initializeAccountBuckets(plan: Plan): InitialAccountBuckets {
  const accounts = plan.accounts || [];

  const preTaxAccs = accounts.filter(a => a.type === 'pre-tax' && isAccountModeledInProjection(a.type));
  const postTaxAccs = accounts.filter(a => a.type === 'post-tax' && isAccountModeledInProjection(a.type));
  const taxableBrokerageAccs = accounts.filter(a => a.type === 'taxable' && isAccountModeledInProjection(a.type));
  const cashAccs = accounts.filter(a => a.type === 'cash' && isAccountModeledInProjection(a.type));

  const preTaxBal = preTaxAccs.reduce((s, a) => s + a.balance, 0);
  const postTaxBal = postTaxAccs.reduce((s, a) => s + a.balance, 0);
  const taxableBrokerageBal = taxableBrokerageAccs.reduce((s, a) => s + a.balance, 0);
  const cashBal = cashAccs.reduce((s, a) => s + a.balance, 0);
  const initialCashTarget = cashBal;
  const taxableBal = taxableBrokerageBal + cashBal;
  const taxableBrokerageCostBasis = taxableBrokerageBal;

  return {
    initialCashTarget,
    preTaxBal,
    postTaxBal,
    taxableBrokerageBal,
    cashBal,
    taxableBal,
    taxableBrokerageCostBasis,
    preTaxAccs,
    postTaxAccs,
    taxableBrokerageAccs,
    cashAccs,
  };
}
