/**
 * Statutory & Assumption Registry
 *
 * Centralized, authoritative source of statutory facts, rules, tables, and limits
 * for US federal tax, state tax, Medicare/IRMAA, Social Security, ACA, and SECURE 2.0 RMDs.
 *
 * Distinguishes official statutory constants from plan-level scenario overrides,
 * providing explicit provenance for calculations and user UI display.
 */

import {
  TAX_BASE_YEAR,
  BRACKET_CEILINGS_2026,
  LTCG_CEILINGS_2026,
  LTCG_RATES,
  NIIT_RATE,
  NIIT_THRESHOLD,
  FICA,
  ADDL_STD_DEDUCTION_65,
  STANDARD_DEDUCTION_2026,
  bracketCeilingsFor,
  ltcgCeilingsFor,
} from '../tax/taxConstants';

import {
  STATE_TAX_RULES,
  findStateRule,
  calculateStateTax,
  subtractionCapForAge,
  calculateRetirementSubtraction,
} from '../tax/stateTaxConstants';

import {
  ACA_BASE_YEAR,
  AGE_RATING_CURVE,
  FPL_BASE_YEAR,
  FPL_FIRST_PERSON,
  FPL_EACH_ADDITIONAL,
  federalPovertyLevel,
  fplIndexFactor,
  subsidyCliffIncome,
  ageRatingFactor,
} from '../health/acaConstants';

import {
  IRMAA_THRESHOLDS,
  ordinaryBracketHeadroom,
  ltcgHeadroom,
  irmaaHeadroom,
} from '../tax/headroom';

export type ProvenanceKind = 'STATUTORY_OFFICIAL' | 'SCENARIO_OVERRIDE';

export interface ResolvedParameter<T> {
  value: T;
  provenance: ProvenanceKind;
  description?: string;
}

/**
 * Resolves a statutory parameter, applying an optional user scenario override
 * and tagging the result with explicit provenance.
 */
export function resolveStatutoryParameter<T>(
  officialValue: T,
  userOverride?: T | null,
  overrideDescription?: string
): ResolvedParameter<T> {
  if (
    userOverride !== undefined &&
    userOverride !== null &&
    (typeof userOverride !== 'number' || (Number.isFinite(userOverride) && userOverride > 0))
  ) {
    return {
      value: userOverride,
      provenance: 'SCENARIO_OVERRIDE',
      description: overrideDescription || 'User scenario override applied',
    };
  }
  return {
    value: officialValue,
    provenance: 'STATUTORY_OFFICIAL',
  };
}

// ---------------------------------------------------------------------------
// 1. SECURE 2.0 & RMD REGISTRY
// ---------------------------------------------------------------------------

export const SECURE_20_RMD_RULES = {
  statutoryStartAge(birthYear: number): number {
    if (birthYear >= 1960) return 75;
    if (birthYear >= 1951) return 73;
    return 72;
  },

  uniformLifetimeFactors: {
    72: 27.4, 73: 26.5, 74: 25.5, 75: 24.6, 76: 23.7, 77: 22.9,
    78: 22.0, 79: 21.1, 80: 20.2, 81: 19.4, 82: 18.5,
    83: 17.7, 84: 16.8, 85: 16.0, 86: 15.2, 87: 14.4,
    88: 13.7, 89: 12.9, 90: 12.2, 91: 11.5, 92: 10.8,
    93: 10.1, 94: 9.5, 95: 8.9, 96: 8.4, 97: 7.8,
    98: 7.3, 99: 6.8, 100: 6.4
  } as Record<number, number>,

  getDivisorFactor(age: number, rmdStartAge: number = 73): number {
    if (age < rmdStartAge) return 0;
    if (SECURE_20_RMD_RULES.uniformLifetimeFactors[age]) {
      return SECURE_20_RMD_RULES.uniformLifetimeFactors[age];
    }
    return Math.max(5.0, 6.4 - (age - 100) * 0.4);
  }
};

// ---------------------------------------------------------------------------
// 2. MEDICARE & IRMAA REGISTRY
// ---------------------------------------------------------------------------

export interface IrmaaResolutionInput {
  premiumYear?: number;
  lookbackTaxYear?: number;
  lookbackMagi: number;
  isJoint: boolean;
  deflator?: number;
  isMedicareEligible?: boolean;
  enrolledCount?: number;
}

export interface IrmaaContext {
  premiumYear: number;
  lookbackTaxYear: number;
  isJoint: boolean;
  lookbackMagi: number;
  thresholds: number[];
  tier: string;
  tierNumber: number;
  annualSurchargePerPerson: number;
  totalAnnualSurcharge: number;
  headroomToNextTier: number | null;
  isMedicareEligible: boolean;
  enrolledCount: number;
}

/**
 * Resolves authoritative IRMAA tier, surcharges, and headroom from lookback MAGI (Tax Year N-2).
 * Ensures tier calculation, premium surcharges, headroom, and validation all derive from
 * the same authoritative inputs and inflation scaling.
 */
export function resolveIrmaaContext(input: IrmaaResolutionInput): IrmaaContext {
  const {
    premiumYear = 2026,
    lookbackTaxYear = (input.premiumYear ?? 2026) - 2,
    lookbackMagi,
    isJoint,
    deflator = 1.0,
    isMedicareEligible = true,
    enrolledCount = isMedicareEligible ? 1 : 0,
  } = input;

  const baseThresholds = isJoint ? IRMAA_THRESHOLDS.joint : IRMAA_THRESHOLDS.single;
  const thresholds = baseThresholds.map((t) => t * deflator);
  const [t0, t1, t2, t3, t4] = thresholds;

  if (!isMedicareEligible || enrolledCount <= 0) {
    return {
      premiumYear,
      lookbackTaxYear,
      isJoint,
      lookbackMagi,
      thresholds: thresholds.map((t) => Math.round(t)),
      tier: 'Tier 0',
      tierNumber: 0,
      annualSurchargePerPerson: 0,
      totalAnnualSurcharge: 0,
      headroomToNextTier: 0,
      isMedicareEligible: false,
      enrolledCount: 0,
    };
  }

  let tier = 'Tier 0';
  let tierNumber = 0;
  let surchargePerPerson = 0;
  let headroomToNextTier: number | null = null;

  if (lookbackMagi >= t4) {
    tier = 'Tier 5 (Max)';
    tierNumber = 5;
    surchargePerPerson = IRMAA_REGISTRY.surchargesPerPerson2026.tier5 * deflator;
    headroomToNextTier = null;
  } else if (lookbackMagi > t3) {
    tier = 'Tier 4';
    tierNumber = 4;
    surchargePerPerson = IRMAA_REGISTRY.surchargesPerPerson2026.tier4 * deflator;
    headroomToNextTier = Math.max(0, Math.round(t4 - lookbackMagi));
  } else if (lookbackMagi > t2) {
    tier = 'Tier 3';
    tierNumber = 3;
    surchargePerPerson = IRMAA_REGISTRY.surchargesPerPerson2026.tier3 * deflator;
    headroomToNextTier = Math.max(0, Math.round(t3 - lookbackMagi));
  } else if (lookbackMagi > t1) {
    tier = 'Tier 2';
    tierNumber = 2;
    surchargePerPerson = IRMAA_REGISTRY.surchargesPerPerson2026.tier2 * deflator;
    headroomToNextTier = Math.max(0, Math.round(t2 - lookbackMagi));
  } else if (lookbackMagi > t0) {
    tier = 'Tier 1';
    tierNumber = 1;
    surchargePerPerson = IRMAA_REGISTRY.surchargesPerPerson2026.tier1 * deflator;
    headroomToNextTier = Math.max(0, Math.round(t1 - lookbackMagi));
  } else {
    tier = 'Tier 0';
    tierNumber = 0;
    surchargePerPerson = 0;
    headroomToNextTier = Math.max(0, Math.round(t0 - Math.max(0, lookbackMagi)));
  }

  const roundedSurchargePerPerson = Math.round(surchargePerPerson);
  const totalAnnualSurcharge = roundedSurchargePerPerson * enrolledCount;

  return {
    premiumYear,
    lookbackTaxYear,
    isJoint,
    lookbackMagi,
    thresholds: thresholds.map((t) => Math.round(t)),
    tier,
    tierNumber,
    annualSurchargePerPerson: roundedSurchargePerPerson,
    totalAnnualSurcharge,
    headroomToNextTier,
    isMedicareEligible,
    enrolledCount,
  };
}

export const IRMAA_REGISTRY = {
  /** Base Year IRMAA Thresholds (MAGI) */
  thresholds: IRMAA_THRESHOLDS,

  /** Surcharge amounts per person per year by tier (nominal dollars) */
  surchargesPerPerson2026: {
    tier1: 1148,
    tier2: 2885,
    tier3: 4620,
    tier4: 6355,
    tier5: 6936,
  },

  resolveContext: resolveIrmaaContext,

  calculateTier(
    magi: number,
    isJoint: boolean,
    deflator: number = 1.0,
    isMedicareEligible: boolean = true
  ): { tier: string; surcharge: number } {
    const ctx = resolveIrmaaContext({
      lookbackMagi: magi,
      isJoint,
      deflator,
      isMedicareEligible,
      enrolledCount: 1,
    });
    return { tier: ctx.tier, surcharge: ctx.annualSurchargePerPerson };
  },

  ordinaryBracketHeadroom,
  ltcgHeadroom,
  irmaaHeadroom,
};

// ---------------------------------------------------------------------------
// 3. SOCIAL SECURITY REGISTRY
// ---------------------------------------------------------------------------

export const SOCIAL_SECURITY_REGISTRY = {
  delayedCreditMaxAge: 70,
  delayedCreditRate: 0.08,

  earlyClaimReduction(monthsEarly: number): number {
    if (monthsEarly <= 0) return 0;
    return monthsEarly <= 36
      ? (monthsEarly * (5 / 9)) / 100
      : 0.20 + ((monthsEarly - 36) * (5 / 12)) / 100;
  },

  provisionalIncomeTaxability: {
    baseThreshold: { joint: 32000, single: 25000 },
    upperThreshold: { joint: 44000, single: 34000 },
    baseCap: { joint: 6000, single: 4500 },
  },

  calculateTaxableSs(grossSs: number, magiOther: number, isJoint: boolean): number {
    if (grossSs <= 0) return 0;
    const provisionalIncome = magiOther + 0.5 * grossSs;
    const { baseThreshold: base, upperThreshold: upper, baseCap: cap } = SOCIAL_SECURITY_REGISTRY.provisionalIncomeTaxability;
    const baseThreshold = isJoint ? base.joint : base.single;
    const upperThreshold = isJoint ? upper.joint : upper.single;
    const baseCap = isJoint ? cap.joint : cap.single;

    if (provisionalIncome <= baseThreshold) {
      return 0;
    } else if (provisionalIncome <= upperThreshold) {
      return Math.min(0.5 * grossSs, 0.5 * (provisionalIncome - baseThreshold));
    } else {
      const tier1 = Math.min(0.5 * grossSs, baseCap);
      const tier2 = 0.85 * (provisionalIncome - upperThreshold);
      return Math.min(0.85 * grossSs, tier1 + tier2);
    }
  }
};

// ---------------------------------------------------------------------------
// 4. FEDERAL TAX REGISTRY EXPORTS
// ---------------------------------------------------------------------------

export const FEDERAL_TAX_REGISTRY = {
  baseYear: TAX_BASE_YEAR,
  bracketCeilings: BRACKET_CEILINGS_2026,
  ltcgCeilings: LTCG_CEILINGS_2026,
  ltcgRates: LTCG_RATES,
  niitRate: NIIT_RATE,
  niitThreshold: NIIT_THRESHOLD,
  fica: FICA,
  addlStdDeduction65: ADDL_STD_DEDUCTION_65,
  standardDeduction: STANDARD_DEDUCTION_2026,
  bracketCeilingsFor,
  ltcgCeilingsFor,
};

// ---------------------------------------------------------------------------
// 5. HEALTHCARE & ACA REGISTRY EXPORTS
// ---------------------------------------------------------------------------

export const ACA_REGISTRY = {
  baseYear: ACA_BASE_YEAR,
  fplBaseYear: FPL_BASE_YEAR,
  fplFirstPerson: FPL_FIRST_PERSON,
  fplEachAdditional: FPL_EACH_ADDITIONAL,
  ageRatingCurve: AGE_RATING_CURVE,
  federalPovertyLevel,
  fplIndexFactor,
  subsidyCliffIncome,
  ageRatingFactor,
};

// ---------------------------------------------------------------------------
// 6. STATE TAX REGISTRY EXPORTS
// ---------------------------------------------------------------------------

export {
  findStateRule,
  calculateStateTax,
  subtractionCapForAge,
  calculateRetirementSubtraction,
};

export const STATE_TAX_REGISTRY = {
  rules: STATE_TAX_RULES,
  findRule: findStateRule,
  calculateStateTax,
  subtractionCapForAge,
  calculateRetirementSubtraction,
};

// ---------------------------------------------------------------------------
// 7. CONTRIBUTION LIMITS REGISTRY EXPORTS
// ---------------------------------------------------------------------------

export type ContributionProvenance = 'STATUTORY_OFFICIAL' | 'SCENARIO_OVERRIDE';

export interface EffectiveContributionLimits {
  deferralLimit401k: number;
  catchUpLimit401k: number;
  catchUpLimit401kSpecial60to63: number;
  iraLimit: number;
  iraCatchUpLimit: number;
  hsaFamilyLimit: number;
  hsaSingleLimit: number;
  hsaCatchUpLimit: number;
  provenance: {
    deferralLimit401k: ContributionProvenance;
    catchUpLimit401k: ContributionProvenance;
    catchUpLimit401kSpecial60to63: ContributionProvenance;
    iraLimit: ContributionProvenance;
    iraCatchUpLimit: ContributionProvenance;
    hsaFamilyLimit: ContributionProvenance;
    hsaSingleLimit: ContributionProvenance;
    hsaCatchUpLimit: ContributionProvenance;
  };
}

export const BASE_CONTRIBUTION_LIMITS = {
  taxYear: 2026,
  deferralLimit401k: 24500,
  catchUpLimit401k: 8000,
  catchUpLimit401kSpecial60to63: 11250,
  iraLimit: 7500,
  iraCatchUpLimit: 1100,
  hsaFamilyLimit: 8750,
  hsaSingleLimit: 4400,
  hsaCatchUpLimit: 1000,
};

export function resolveContributionLimits(overrides?: {
  deferralLimit401k?: number;
  catchUpLimit401k?: number;
  iraLimit?: number;
  iraCatchUpLimit?: number;
  hsaFamilyLimit?: number;
  hsaSingleLimit?: number;
  hsaCatchUpLimit?: number;
}): EffectiveContributionLimits {
  const resolveField = (
    overrideVal: number | undefined,
    officialVal: number
  ): { value: number; provenance: ContributionProvenance } => {
    if (typeof overrideVal === 'number' && Number.isFinite(overrideVal) && overrideVal > 0) {
      return {
        value: overrideVal,
        provenance: overrideVal === officialVal ? 'STATUTORY_OFFICIAL' : 'SCENARIO_OVERRIDE',
      };
    }
    return { value: officialVal, provenance: 'STATUTORY_OFFICIAL' };
  };

  const def401k = resolveField(overrides?.deferralLimit401k, BASE_CONTRIBUTION_LIMITS.deferralLimit401k);
  const catch401k = resolveField(overrides?.catchUpLimit401k, BASE_CONTRIBUTION_LIMITS.catchUpLimit401k);
  const ira = resolveField(overrides?.iraLimit, BASE_CONTRIBUTION_LIMITS.iraLimit);
  const catchIra = resolveField(overrides?.iraCatchUpLimit, BASE_CONTRIBUTION_LIMITS.iraCatchUpLimit);
  const hsaFam = resolveField(overrides?.hsaFamilyLimit, BASE_CONTRIBUTION_LIMITS.hsaFamilyLimit);
  const hsaSing = resolveField(overrides?.hsaSingleLimit, BASE_CONTRIBUTION_LIMITS.hsaSingleLimit);
  const catchHsa = resolveField(overrides?.hsaCatchUpLimit, BASE_CONTRIBUTION_LIMITS.hsaCatchUpLimit);

  return {
    deferralLimit401k: def401k.value,
    catchUpLimit401k: catch401k.value,
    catchUpLimit401kSpecial60to63: BASE_CONTRIBUTION_LIMITS.catchUpLimit401kSpecial60to63,
    iraLimit: ira.value,
    iraCatchUpLimit: catchIra.value,
    hsaFamilyLimit: hsaFam.value,
    hsaSingleLimit: hsaSing.value,
    hsaCatchUpLimit: catchHsa.value,
    provenance: {
      deferralLimit401k: def401k.provenance,
      catchUpLimit401k: catch401k.provenance,
      catchUpLimit401kSpecial60to63: 'STATUTORY_OFFICIAL',
      iraLimit: ira.provenance,
      iraCatchUpLimit: catchIra.provenance,
      hsaFamilyLimit: hsaFam.provenance,
      hsaSingleLimit: hsaSing.provenance,
      hsaCatchUpLimit: catchHsa.provenance,
    },
  };
}

/**
 * Calculates the statutory/guideline 401(k)/403(b) elective deferral maximum for a given age.
 * Includes SECURE 2.0 special enhanced catch-up for ages 60 to 63, and standard catch-up for age 50+.
 */
export function get401kContributionLimit(age: number, limits: EffectiveContributionLimits = resolveContributionLimits()): number {
  if (age >= 60 && age <= 63) {
    return limits.deferralLimit401k + limits.catchUpLimit401kSpecial60to63;
  }
  if (age >= 50) {
    return limits.deferralLimit401k + limits.catchUpLimit401k;
  }
  return limits.deferralLimit401k;
}

/**
 * Calculates the statutory/guideline IRA contribution maximum for a given age.
 * Includes age 50+ catch-up allowance.
 */
export function getIraContributionLimit(age: number, limits: EffectiveContributionLimits = resolveContributionLimits()): number {
  if (age >= 50) {
    return limits.iraLimit + limits.iraCatchUpLimit;
  }
  return limits.iraLimit;
}

/**
 * Calculates the statutory/guideline HSA contribution maximum for a coverage type and age.
 * Includes age 55+ catch-up allowance ($1,000).
 */
export function getHsaContributionLimit(isFamily: boolean, age: number, limits: EffectiveContributionLimits = resolveContributionLimits()): number {
  const base = isFamily ? limits.hsaFamilyLimit : limits.hsaSingleLimit;
  if (age >= 55) {
    return base + limits.hsaCatchUpLimit;
  }
  return base;
}

export const CONTRIBUTION_LIMITS_REGISTRY = {
  ...BASE_CONTRIBUTION_LIMITS,
  resolveContributionLimits,
  get401kContributionLimit,
  getIraContributionLimit,
  getHsaContributionLimit,
};

export const STATUTORY_REGISTRY = {
  secure20: SECURE_20_RMD_RULES,
  irmaa: IRMAA_REGISTRY,
  socialSecurity: SOCIAL_SECURITY_REGISTRY,
  federalTax: FEDERAL_TAX_REGISTRY,
  aca: ACA_REGISTRY,
  stateTax: STATE_TAX_REGISTRY,
  contributionLimits: CONTRIBUTION_LIMITS_REGISTRY,
};

