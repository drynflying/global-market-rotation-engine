import { describe, it, expect } from 'vitest';
import {
  resolveStatutoryParameter,
  SECURE_20_RMD_RULES,
  IRMAA_REGISTRY,
  SOCIAL_SECURITY_REGISTRY,
  FEDERAL_TAX_REGISTRY,
  ACA_REGISTRY,
  STATE_TAX_REGISTRY,
  BASE_CONTRIBUTION_LIMITS,
  resolveContributionLimits,
  get401kContributionLimit,
  getIraContributionLimit,
  getHsaContributionLimit,
} from './statutoryRegistry';
import { getSsAnnualBenefit } from '../kernel/incomeKernel';
import { getRmdStartAge } from '../kernel/rmdKernel';
import { runStep2Validations, runStep4Validations } from '../validation/validations';
import { createDefaultPlan } from '../../constants/defaultPlan';
import { Plan } from '../../types';

describe('Statutory & Assumption Registry', () => {
  describe('Contribution Limits SSOT & Resolvers', () => {
    it('provides 2026 base statutory contribution limits as official SSOT', () => {
      expect(BASE_CONTRIBUTION_LIMITS.taxYear).toBe(2026);
      expect(BASE_CONTRIBUTION_LIMITS.deferralLimit401k).toBe(24500);
      expect(BASE_CONTRIBUTION_LIMITS.catchUpLimit401k).toBe(8000);
      expect(BASE_CONTRIBUTION_LIMITS.iraLimit).toBe(7500);
      expect(BASE_CONTRIBUTION_LIMITS.iraCatchUpLimit).toBe(1100);
      expect(BASE_CONTRIBUTION_LIMITS.hsaSingleLimit).toBe(4400);
      expect(BASE_CONTRIBUTION_LIMITS.hsaFamilyLimit).toBe(8750);
      expect(BASE_CONTRIBUTION_LIMITS.hsaCatchUpLimit).toBe(1000);
    });

    it('resolves official limits with STATUTORY_OFFICIAL provenance when no overrides are passed', () => {
      const resolved = resolveContributionLimits();
      expect(resolved.deferralLimit401k).toBe(24500);
      expect(resolved.provenance.deferralLimit401k).toBe('STATUTORY_OFFICIAL');
      expect(resolved.catchUpLimit401k).toBe(8000);
      expect(resolved.provenance.catchUpLimit401k).toBe('STATUTORY_OFFICIAL');
      expect(resolved.iraLimit).toBe(7500);
      expect(resolved.iraCatchUpLimit).toBe(1100);
      expect(resolved.hsaFamilyLimit).toBe(8750);
      expect(resolved.hsaSingleLimit).toBe(4400);
      expect(resolved.hsaCatchUpLimit).toBe(1000);
    });

    it('resolves scenario overrides with SCENARIO_OVERRIDE provenance', () => {
      const resolved = resolveContributionLimits({
        deferralLimit401k: 26000,
        iraLimit: 8000,
        hsaFamilyLimit: 9000,
      });
      expect(resolved.deferralLimit401k).toBe(26000);
      expect(resolved.provenance.deferralLimit401k).toBe('SCENARIO_OVERRIDE');
      expect(resolved.iraLimit).toBe(8000);
      expect(resolved.provenance.iraLimit).toBe('SCENARIO_OVERRIDE');
      expect(resolved.hsaFamilyLimit).toBe(9000);
      expect(resolved.provenance.hsaFamilyLimit).toBe('SCENARIO_OVERRIDE');

      // Un-overridden fields retain statutory defaults
      expect(resolved.catchUpLimit401k).toBe(8000);
      expect(resolved.provenance.catchUpLimit401k).toBe('STATUTORY_OFFICIAL');
    });

    it('computes 401(k) limits with age 50+ catch-up addition correctly', () => {
      expect(get401kContributionLimit(45)).toBe(24500);
      expect(get401kContributionLimit(49)).toBe(24500);
      expect(get401kContributionLimit(50)).toBe(32500); // 24500 + 8000
      expect(get401kContributionLimit(55)).toBe(32500); // 24500 + 8000
      expect(get401kContributionLimit(62)).toBe(35750); // 24500 + 11250 (SECURE 2.0 enhanced catch-up for ages 60-63)
      expect(get401kContributionLimit(64)).toBe(32500); // 24500 + 8000
    });

    it('computes IRA limits with age 50+ catch-up addition correctly', () => {
      expect(getIraContributionLimit(40)).toBe(7500);
      expect(getIraContributionLimit(50)).toBe(8600); // 7500 + 1100
      expect(getIraContributionLimit(65)).toBe(8600);
    });

    it('computes HSA limits with coverage tier and age 55+ catch-up addition correctly', () => {
      // Single coverage
      expect(getHsaContributionLimit(false, 40)).toBe(4400);
      expect(getHsaContributionLimit(false, 54)).toBe(4400);
      expect(getHsaContributionLimit(false, 55)).toBe(5400); // 4400 + 1000
      expect(getHsaContributionLimit(false, 60)).toBe(5400);

      // Family coverage
      expect(getHsaContributionLimit(true, 40)).toBe(8750);
      expect(getHsaContributionLimit(true, 54)).toBe(8750);
      expect(getHsaContributionLimit(true, 55)).toBe(9750); // 8750 + 1000
      expect(getHsaContributionLimit(true, 65)).toBe(9750);
    });
  });
  describe('resolveStatutoryParameter', () => {
    it('returns official statutory parameter when no override provided', () => {
      const resolved = resolveStatutoryParameter(75);
      expect(resolved.value).toBe(75);
      expect(resolved.provenance).toBe('STATUTORY_OFFICIAL');
    });

    it('returns scenario override when override is set', () => {
      const resolved = resolveStatutoryParameter(75, 73, 'Scenario early RMD age test');
      expect(resolved.value).toBe(73);
      expect(resolved.provenance).toBe('SCENARIO_OVERRIDE');
      expect(resolved.description).toBe('Scenario early RMD age test');
    });

    it('falls back to official statutory parameter if override is undefined or invalid', () => {
      const resolvedNull = resolveStatutoryParameter(75, null);
      expect(resolvedNull.value).toBe(75);
      expect(resolvedNull.provenance).toBe('STATUTORY_OFFICIAL');

      const resolvedZero = resolveStatutoryParameter(75, 0);
      expect(resolvedZero.value).toBe(75);
      expect(resolvedZero.provenance).toBe('STATUTORY_OFFICIAL');
    });
  });

  describe('SECURE_20_RMD_RULES', () => {
    it('correctly determines statutory start age by birth year cohort', () => {
      expect(SECURE_20_RMD_RULES.statutoryStartAge(1965)).toBe(75);
      expect(SECURE_20_RMD_RULES.statutoryStartAge(1955)).toBe(73);
      expect(SECURE_20_RMD_RULES.statutoryStartAge(1948)).toBe(72);
    });

    it('provides uniform lifetime factors', () => {
      expect(SECURE_20_RMD_RULES.getDivisorFactor(72, 72)).toBe(27.4);
      expect(SECURE_20_RMD_RULES.getDivisorFactor(75, 75)).toBe(24.6);
      expect(SECURE_20_RMD_RULES.getDivisorFactor(70, 73)).toBe(0);
    });
  });

  describe('Requirement A: Registry values drive IRMAA calculation', () => {
    it('calculates IRMAA tiers using registry thresholds', () => {
      const t0 = IRMAA_REGISTRY.thresholds.joint[0];
      const jointTier0 = IRMAA_REGISTRY.calculateTier(t0 - 10000, true);
      expect(jointTier0.tier).toBe('Tier 0');
      expect(jointTier0.surcharge).toBe(0);

      const jointTier1 = IRMAA_REGISTRY.calculateTier(t0 + 1000, true);
      expect(jointTier1.tier).toBe('Tier 1');
      expect(jointTier1.surcharge).toBe(1148);

      const singleMaxThreshold = IRMAA_REGISTRY.thresholds.single[4];
      const singleTierMax = IRMAA_REGISTRY.calculateTier(singleMaxThreshold + 1000, false);
      expect(singleTierMax.tier).toBe('Tier 5 (Max)');
      expect(singleTierMax.surcharge).toBe(6936);
    });
  });

  describe('Requirement B: Registry values drive SS taxable-benefit calculation', () => {
    it('calculates taxable social security income using registry thresholds', () => {
      const baseJoint = SOCIAL_SECURITY_REGISTRY.provisionalIncomeTaxability.baseThreshold.joint;
      // Below base threshold -> $0 taxable
      expect(SOCIAL_SECURITY_REGISTRY.calculateTaxableSs(20000, baseJoint - 10000, true)).toBe(0);
      // Above base threshold -> positive taxable benefit
      expect(SOCIAL_SECURITY_REGISTRY.calculateTaxableSs(40000, baseJoint + 10000, true)).toBeGreaterThan(0);
    });
  });

  describe('Requirement C: Registry values drive delayed credits', () => {
    it('applies delayed credits from Social Security registry settings', () => {
      const person = {
        name: 'Test',
        currentAge: 60,
        retirementAge: 65,
        lifeExpectancy: 90,
        ssMonthlyBenefit: 2000,
        ssClaimAge: 70, // 3 years delayed past FRA 67
        includeSsProjectedReduction: false,
        ssProjectedReductionPct: 21,
      };

      // Evaluate at claim age 70
      const benefitAtClaim = getSsAnnualBenefit(person, 70, {
        standardDeductionJoint: 32200,
        standardDeductionSingle: 16100,
        deferralLimit401k: 23500,
        catchUpLimit401k: 7500,
        iraLimit: 7000,
        iraCatchUpLimit: 1000,
        hsaFamilyLimit: 8550,
        hsaSingleLimit: 4300,
        hsaCatchUpLimit: 1000,
        rmdStartAge: 75,
        fullRetirementAge: 67,
        ssColaRate: 0, // Disable COLA for direct factor test
      }, false);

      const expected = Math.round(2000 * 12 * (1 + 3 * SOCIAL_SECURITY_REGISTRY.delayedCreditRate));
      expect(benefitAtClaim).toBe(expected);
    });
  });

  describe('Requirement D: Scenario override takes precedence where supported', () => {
    it('honors scenario override for RMD start age and statutory parameters', () => {
      const defaultAge = getRmdStartAge(1976);
      expect(defaultAge).toBe(75);

      const overrideAge = getRmdStartAge(1976, 73);
      expect(overrideAge).toBe(73);

      const person = {
        name: 'Test',
        currentAge: 60,
        retirementAge: 65,
        lifeExpectancy: 90,
        ssMonthlyBenefit: 1000,
        ssClaimAge: 67,
        includeSsProjectedReduction: false,
        ssProjectedReductionPct: 21,
      };

      // Evaluate at age 70 (after claim age 67)
      const benefitBaseCola = getSsAnnualBenefit(person, 70, {
        standardDeductionJoint: 32200,
        standardDeductionSingle: 16100,
        deferralLimit401k: 23500,
        catchUpLimit401k: 7500,
        iraLimit: 7000,
        iraCatchUpLimit: 1000,
        hsaFamilyLimit: 8550,
        hsaSingleLimit: 4300,
        hsaCatchUpLimit: 1000,
        rmdStartAge: 75,
        fullRetirementAge: 67,
        ssColaRate: 2.5,
      });

      const benefitHighColaOverride = getSsAnnualBenefit(person, 70, {
        standardDeductionJoint: 32200,
        standardDeductionSingle: 16100,
        deferralLimit401k: 23500,
        catchUpLimit401k: 7500,
        iraLimit: 7000,
        iraCatchUpLimit: 1000,
        hsaFamilyLimit: 8550,
        hsaSingleLimit: 4300,
        hsaCatchUpLimit: 1000,
        rmdStartAge: 75,
        fullRetirementAge: 67,
        ssColaRate: 5.0, // Override COLA rate
      });

      expect(benefitHighColaOverride).toBeGreaterThan(benefitBaseCola);
    });
  });

  describe('Requirement E: Changing a registry test fixture changes calculations predictably', () => {
    it('adapts calculations when registry thresholds are adjusted', () => {
      const origThreshold = IRMAA_REGISTRY.thresholds.joint[0];
      try {
        // Temporarily adjust threshold in fixture
        const jointThresholds = IRMAA_REGISTRY.thresholds.joint as unknown as number[];
        jointThresholds[0] = 300000;
        const resultWithNewThreshold = IRMAA_REGISTRY.calculateTier(250000, true);
        expect(resultWithNewThreshold.tier).toBe('Tier 0'); // MAGI 250k is below modified threshold 300k
      } finally {
        (IRMAA_REGISTRY.thresholds.joint as unknown as number[])[0] = origThreshold;
      }
    });
  });

  describe('Requirement F: Validation consumes authoritative registry values', () => {
    it('uses registry IRMAA threshold in Step 4 validation checks', () => {
      const plan = createDefaultPlan();
      plan.filingStatus = 'joint';
      plan.primaryPerson.currentAge = 64;
      plan.primaryPerson.retirementAge = 65;
      if (plan.spousePerson) {
        plan.spousePerson.currentAge = 64;
        plan.spousePerson.retirementAge = 65;
      }
      plan.spendingAssumptions!.desiredAnnualLivingExpenses = 220000;
      plan.spendingAssumptions!.conversionStrategy = 'manual';
      plan.spendingAssumptions!.annualRothConversionTarget = 40000;
      if (plan.accounts[0]) {
        plan.accounts[0].balance = 3000000;
      }

      const testPlan: Plan = JSON.parse(JSON.stringify(plan));
      const valResults = runStep4Validations(testPlan);
      const irmaaResult = valResults.find(v => v.id === 'val-step4-irmaa-cliff');
      expect(irmaaResult).toBeDefined();
      expect(irmaaResult?.description).toMatch(/IRMAA|lookback/);
    });

    it('resolves statutory defaults when statutoryParams is omitted in plan validations', () => {
      const plan = createDefaultPlan();
      delete plan.statutoryParams; // Ensure validations resolve via default fallback cleanly
      const valResults = runStep2Validations(plan);
      expect(valResults.length).toBeGreaterThan(0);
    });
  });

  describe('Sub-registries exports', () => {
    it('exposes federal, aca, and state tax rules cleanly', () => {
      expect(FEDERAL_TAX_REGISTRY.baseYear).toBe(2026);
      expect(ACA_REGISTRY.fplFirstPerson).toBe(15650);
      expect(STATE_TAX_REGISTRY.rules.length).toBeGreaterThan(0);
    });
  });
});
