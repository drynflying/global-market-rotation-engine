/**
 * @file projectRetirementYear.ts
 *
 * ARCHITECTURAL ROLE: Retirement-Year Coordinator / Orchestrator
 *
 * projectRetirementYear orchestrates the sequence of events during a deaccumulation (retirement) year:
 *  - RMD evaluation
 *  - Roth conversion evaluation & tax delta
 *  - Cash need solving (solveRetirementCashNeed)
 *  - Withdrawal sequence execution (executeWithdrawalSequence)
 *  - Final MAGI, tax reconciliation, and effective rate calculation
 *  - Portfolio growth application & cash surplus reinvestment
 *  - SimulationRow construction and milestone annotation
 *
 * Pure, formula-heavy or independently reusable logic MUST live below this coordinator
 * in domain kernel, solver, or strategy modules. Do not re-introduce inline tax/financial
 * formula definitions directly inside this coordinator.
 */

import { MacroeconomicAssumptions, UserProfile as PersonProfile, Plan, SpendingAssumptions } from '../../types';
import { SimulationRow } from '../simulation/simulationTypes';
import { StateTaxRule, calculateStateTax, NO_STATE_TAX_RULE } from '../tax/stateTaxConstants';
import { ordinaryBracketHeadroom, ltcgHeadroom } from '../tax/headroom';
import { resolveIrmaaContext } from '../registry/statutoryRegistry';
import { BracketCeilings, ADDL_STD_DEDUCTION_65 } from '../tax/taxConstants';
import {
  calculateFederalTax,
  calculateFicaTax,
  calculateCapGainsTax,
  calculateTaxableSs,
  getMarginalTaxBracket,
  getRmdFactor,
  resolveFederalDeduction,
} from '../kernel';
import { buildMilestoneAnnotation } from '../analysis/simulationSummary';
import { solveRetirementCashNeed } from '../solver/solveRetirementCashNeed';
import { executeWithdrawalSequence } from '../strategy/withdrawalSequence';
import { RetirementStrategy } from '../strategy/strategyTypes';
import { resolveRetirementStrategy } from '../strategy/strategyResolver';
import { determineRothConversionTarget, RothConversionContext } from '../strategy/rothConversionPolicy';

export interface ProjectRetirementYearInput {
  plan: Plan;
  strategy?: RetirementStrategy;
  age: number;
  calendarYear: number;
  yearsFromStart: number;
  deflator: number;
  primaryRetAge: number;
  spouseAge?: number;
  isJoint: boolean;
  stdDeduction: number;
  bracketCeilings: BracketCeilings;
  macro: MacroeconomicAssumptions;
  spending: SpendingAssumptions;
  rmdStartAge: number;
  convTarget: number;
  primary: PersonProfile;
  spouse?: PersonProfile;
  preTaxBal: number;
  postTaxBal: number;
  taxableBrokerageBal: number;
  cashBal: number;
  taxableBrokerageCostBasis: number;
  taxableBal: number;
  growthPreTax: number;
  growthPostTax: number;
  growthTaxableBrokerage: number;
  growthCash: number;
  blendedReturnPct: number;
  beginningPortfolio: number;
  annualSalaryIncome: number;
  primarySalaryIncome?: number;
  spouseSalaryIncome?: number;
  pensionIncome: number;
  otherGuaranteedIncome: number;
  totalSs: number;
  primarySs: number;
  spouseSs: number;
  guaranteedIncome: number;
  baseLiving: number;
  essentialPct: number;
  healthExpenseExAca: number;
  specialEssentialNominal: number;
  specialDiscretionaryNominal: number;
  totalSpecialNominal: number;
  expenseNeedExAca: number;
  initialCashTarget: number;
  irmaaSurcharge: number;
  acaPremiumFor: (magi: number) => number;
  stateRule?: StateTaxRule;
  customStateRatePct?: number;
  magiHistory: Record<number, number>;
  previousRows: SimulationRow[];
}

export interface ProjectRetirementYearResult {
  row: SimulationRow;
  preTaxBal: number;
  postTaxBal: number;
  taxableBrokerageBal: number;
  cashBal: number;
  taxableBrokerageCostBasis: number;
  taxableBal: number;
}

/**
 * Projects a single deaccumulation (retirement) year, processing mandatory RMDs,
 * Roth conversions, iterative cash-need solving, portfolio withdrawals, asset growth,
 * tax reconciliations, surplus reinvestment, and row creation.
 */
export function projectRetirementYear(input: ProjectRetirementYearInput): ProjectRetirementYearResult {
  const {
    plan,
    age,
    calendarYear,
    deflator,
    primaryRetAge,
    spouseAge,
    isJoint,
    stdDeduction,
    bracketCeilings,
    macro,
    spending,
    rmdStartAge,
    convTarget,
    primary,
    spouse,
    growthPreTax,
    growthPostTax,
    growthTaxableBrokerage,
    growthCash,
    blendedReturnPct,
    beginningPortfolio,
    annualSalaryIncome,
    pensionIncome,
    otherGuaranteedIncome,
    totalSs,
    primarySs,
    spouseSs,
    guaranteedIncome,
    baseLiving,
    essentialPct,
    healthExpenseExAca,
    specialEssentialNominal,
    specialDiscretionaryNominal,
    totalSpecialNominal,
    expenseNeedExAca,
    initialCashTarget,
    irmaaSurcharge,
    acaPremiumFor,
    stateRule = NO_STATE_TAX_RULE,
    customStateRatePct,
    magiHistory,
    previousRows,
  } = input;

  const statutory = plan.statutoryParams;

  const strategy = input.strategy ?? resolveRetirementStrategy(plan, { overrideConversionTarget: convTarget });

  let preTaxBal = input.preTaxBal;
  let postTaxBal = input.postTaxBal;
  let taxableBrokerageBal = input.taxableBrokerageBal;
  let cashBal = input.cashBal;
  let taxableBrokerageCostBasis = input.taxableBrokerageCostBasis;
  let taxableBal = input.taxableBal;

  // 1. Mandatory RMDs
  const rmdEligibleBalance = preTaxBal;
  const rmdFactor = getRmdFactor(age, rmdStartAge);
  const rmdAmount = rmdFactor > 0 ? Math.round(preTaxBal / rmdFactor) : 0;
  const rmdDraw = Math.min(preTaxBal, rmdAmount);

  // 2. Roth Conversions (Incremental Tax Calculation)
  let rothConversion = 0;
  let conversionTaxPaid = 0;
  const availPreTaxForConv = Math.max(0, preTaxBal - rmdDraw);
  const preTaxAvailableBeforeConversion = availPreTaxForConv;

  const baseOtherMagi = pensionIncome + annualSalaryIncome + otherGuaranteedIncome + rmdDraw;
  const baseTaxableSs = calculateTaxableSs(totalSs, baseOtherMagi, isJoint);

  const convContext: RothConversionContext = {
    age,
    spouseAge,
    hasSpouse: plan.hasSpouse,
    isJoint,
    calendarYear,
    availablePreTaxBalance: availPreTaxForConv,
    ordinaryIncomeBeforeConversion: baseOtherMagi,
    totalSs,
    taxableSocialSecurityBeforeConversion: baseTaxableSs,
    standardDeduction: stdDeduction,
    statutoryStandardDeductionJoint: statutory?.standardDeductionJoint,
    statutoryStandardDeductionSingle: statutory?.standardDeductionSingle,
    statutoryAddlStdDeduction65Joint: ADDL_STD_DEDUCTION_65.joint,
    statutoryAddlStdDeduction65Single: ADDL_STD_DEDUCTION_65.single,
    deflator,
    rmdAmount: rmdDraw,
    bracketCeilings,
  };

  const convDecision = determineRothConversionTarget(strategy.rothConversion, convContext);
  rothConversion = convDecision.actualConversion;

  if (rothConversion > 0) {
    // Tax WITHOUT conversion
    const baseMagi = Math.round(baseOtherMagi + baseTaxableSs);
    const baseDeduction = resolveFederalDeduction({
      taxYear: calendarYear,
      isJoint,
      primaryAge: age,
      spouseAge: plan.hasSpouse ? spouseAge : undefined,
      magi: baseMagi,
      deflator,
      statutoryStandardDeductionJoint: statutory?.standardDeductionJoint,
      statutoryStandardDeductionSingle: statutory?.standardDeductionSingle,
      statutoryAddlStdDeduction65Joint: ADDL_STD_DEDUCTION_65.joint,
      statutoryAddlStdDeduction65Single: ADDL_STD_DEDUCTION_65.single,
    });
    const baseNetTaxable = Math.max(0, baseMagi - baseDeduction.totalDeduction);
    const baseFedTax = calculateFederalTax(baseNetTaxable, bracketCeilings);
    const baseStateTax = calculateStateTax({
      ordinaryTaxable: baseNetTaxable,
      realizedCapGains: 0,
      taxableSocialSecurity: baseTaxableSs,
      rule: stateRule,
      customRatePct: customStateRatePct,
      primaryAge: age,
      pensionIncome,
      preTaxWithdrawals: rmdDraw,
      agi: baseMagi,
      isJoint,
    });
    const primaryW2 = input.primarySalaryIncome ?? annualSalaryIncome;
    const spouseW2 = input.spouseSalaryIncome ?? 0;
    const baseFica = calculateFicaTax({
      primaryWages: primaryW2,
      spouseWages: spouseW2,
      isJoint,
      deflator,
    }).totalFicaTax;

    // Tax WITH conversion
    const convOtherMagi = baseOtherMagi + rothConversion;
    const convTaxableSs = calculateTaxableSs(totalSs, convOtherMagi, isJoint);
    const convMagi = Math.round(convOtherMagi + convTaxableSs);
    const convDeduction = resolveFederalDeduction({
      taxYear: calendarYear,
      isJoint,
      primaryAge: age,
      spouseAge: plan.hasSpouse ? spouseAge : undefined,
      magi: convMagi,
      deflator,
      statutoryStandardDeductionJoint: statutory?.standardDeductionJoint,
      statutoryStandardDeductionSingle: statutory?.standardDeductionSingle,
      statutoryAddlStdDeduction65Joint: ADDL_STD_DEDUCTION_65.joint,
      statutoryAddlStdDeduction65Single: ADDL_STD_DEDUCTION_65.single,
    });
    const convNetTaxable = Math.max(0, convMagi - convDeduction.totalDeduction);
    const convFedTax = calculateFederalTax(convNetTaxable, bracketCeilings);
    const convStateTax = calculateStateTax({
      ordinaryTaxable: convNetTaxable,
      realizedCapGains: 0,
      taxableSocialSecurity: convTaxableSs,
      rule: stateRule,
      customRatePct: customStateRatePct,
      primaryAge: age,
      pensionIncome,
      preTaxWithdrawals: rmdDraw + rothConversion,
      agi: convMagi,
      isJoint,
    });

    conversionTaxPaid = Math.max(0, (convFedTax + convStateTax + baseFica) - (baseFedTax + baseStateTax + baseFica));
  }

  // 3. Living Expense & Tax Gross-up Withdrawal Engine
  const conversionTaxSource = strategy.taxPayment.conversionTaxSource;
  const preTaxBalAvail = Math.max(0, preTaxBal - rmdDraw - rothConversion);
  const taxableBalAvail = Math.max(0, taxableBal - (conversionTaxSource === 'taxable_brokerage' ? conversionTaxPaid : 0));
  const postTaxBalAvail = postTaxBal + (conversionTaxSource === 'conversion_proceeds' ? Math.max(0, rothConversion - conversionTaxPaid) : rothConversion);

  const solverResult = solveRetirementCashNeed({
    rmdDraw,
    rothConversion,
    preTaxBalAvail,
    taxableBalAvail,
    postTaxBalAvail,
    pensionIncome,
    annualSalaryIncome,
    primarySalaryIncome: input.primarySalaryIncome,
    spouseSalaryIncome: input.spouseSalaryIncome,
    otherGuaranteedIncome,
    totalSs,
    age,
    spouseAge,
    hasSpouse: plan.hasSpouse,
    isJoint,
    calendarYear,
    deflator,
    stdDeduction,
    statutoryStandardDeductionJoint: statutory?.standardDeductionJoint,
    statutoryStandardDeductionSingle: statutory?.standardDeductionSingle,
    statutoryAddlStdDeduction65Joint: ADDL_STD_DEDUCTION_65.joint,
    statutoryAddlStdDeduction65Single: ADDL_STD_DEDUCTION_65.single,
    bracketCeilings,
    cashBal,
    taxableBrokerageBal,
    taxableBrokerageCostBasis,
    spending,
    strategy,
    conversionTaxPaid,
    stateRule,
    customStateRatePct,
    expenseNeedExAca,
    guaranteedIncome,
    acaPremiumFor,
  });

  const {
    iteratedPreTaxWdExtra,
    iteratedTaxableWd,
    iteratedPostTaxWd,
    acaNetPremium,
  } = solverResult;

  const reqPreTaxWd = rmdDraw + iteratedPreTaxWdExtra;
  const reqTaxableWd = iteratedTaxableWd;
  const reqPostTaxWd = iteratedPostTaxWd;

  const sequenceResult = executeWithdrawalSequence({
    taxableWd: reqTaxableWd,
    preTaxWd: reqPreTaxWd,
    postTaxWd: reqPostTaxWd,
    rothConversion,
    conversionTaxPaid,
    spending,
    strategy,
    cashBal,
    taxableBrokerageBal,
    taxableBrokerageCostBasis,
    preTaxBal,
    postTaxBal,
  });

  const {
    realizedCapGains,
    totalWithdrawals,
    taxableWd: actualTaxableWd,
    preTaxWd: actualPreTaxWd,
    postTaxWd: actualPostTaxWd,
  } = sequenceResult;
  cashBal = sequenceResult.cashBal;
  taxableBrokerageBal = sequenceResult.taxableBrokerageBal;
  taxableBrokerageCostBasis = sequenceResult.taxableBrokerageCostBasis;
  taxableBal = sequenceResult.taxableBal;
  preTaxBal = sequenceResult.preTaxBal;
  postTaxBal = sequenceResult.postTaxBal;

  // Final MAGI and Tax calculations
  const finalOtherMagi = pensionIncome + annualSalaryIncome + otherGuaranteedIncome + actualPreTaxWd + rothConversion;
  const finalTaxableSs = calculateTaxableSs(totalSs, finalOtherMagi, isJoint);
  const provisionalIncome = finalOtherMagi + 0.5 * totalSs;
  const estimatedMagi = Math.round(finalOtherMagi + finalTaxableSs);
  magiHistory[age] = estimatedMagi + realizedCapGains;

  const deductionBreakdown = resolveFederalDeduction({
    taxYear: calendarYear,
    isJoint,
    primaryAge: age,
    spouseAge: plan.hasSpouse ? spouseAge : undefined,
    magi: estimatedMagi,
    deflator,
    statutoryStandardDeductionJoint: statutory?.standardDeductionJoint,
    statutoryStandardDeductionSingle: statutory?.standardDeductionSingle,
    statutoryAddlStdDeduction65Joint: ADDL_STD_DEDUCTION_65.joint,
    statutoryAddlStdDeduction65Single: ADDL_STD_DEDUCTION_65.single,
  });
  const netTaxableIncome = Math.max(0, estimatedMagi - deductionBreakdown.totalDeduction);
  const fedTax = calculateFederalTax(netTaxableIncome, bracketCeilings);
  const capGainsTax = calculateCapGainsTax(realizedCapGains, netTaxableIncome, isJoint, deflator);
  const stateTax = calculateStateTax({
    ordinaryTaxable: netTaxableIncome,
    realizedCapGains,
    taxableSocialSecurity: finalTaxableSs,
    rule: stateRule,
    customRatePct: customStateRatePct,
    primaryAge: age,
    pensionIncome,
    preTaxWithdrawals: actualPreTaxWd,
    agi: estimatedMagi,
    isJoint,
  });
  const ficaTax = calculateFicaTax({
    primaryWages: input.primarySalaryIncome ?? annualSalaryIncome,
    spouseWages: input.spouseSalaryIncome ?? 0,
    isJoint,
    deflator,
  }).totalFicaTax;
  const totalEstimatedTax = Math.round(fedTax + capGainsTax + stateTax + ficaTax);
  const totalIncomeForRate = estimatedMagi + realizedCapGains;
  const effectiveTaxRate = totalIncomeForRate > 0 ? (totalEstimatedTax / totalIncomeForRate) * 100 : 0;
  const taxBracket = getMarginalTaxBracket(netTaxableIncome, bracketCeilings);

  // Portfolio Growth Application
  const preTaxGrowth = preTaxBal * growthPreTax;
  const postTaxGrowth = postTaxBal * growthPostTax;
  const taxableBrokerageGrowth = taxableBrokerageBal * growthTaxableBrokerage;
  const cashGrowth = cashBal * growthCash;
  const portfolioGrowth = Math.round(preTaxGrowth + postTaxGrowth + taxableBrokerageGrowth + cashGrowth);

  preTaxBal = Math.round(preTaxBal + preTaxGrowth);
  postTaxBal = Math.round(postTaxBal + postTaxGrowth);
  taxableBrokerageBal = Math.round(taxableBrokerageBal + taxableBrokerageGrowth);
  cashBal = Math.round(cashBal + cashGrowth);

  const healthExpense = healthExpenseExAca + acaNetPremium;
  const totalExpenseNeed = Math.round(expenseNeedExAca + acaNetPremium);
  const essentialExpense = Math.round(baseLiving * essentialPct + healthExpense + specialEssentialNominal);
  const discretionaryExpense = Math.round(baseLiving * (1 - essentialPct) + specialDiscretionaryNominal);

  // Cash Flow Reconciliation & Leakage Prevention
  const totalCashInflow = Math.round(guaranteedIncome + annualSalaryIncome + totalWithdrawals);
  const totalCashOutflow = Math.round(totalExpenseNeed + totalEstimatedTax);
  let netCashFlow = totalCashInflow - totalCashOutflow;
  let surplusReinvested = 0;

  if (netCashFlow > 0) {
    surplusReinvested = Math.round(netCashFlow);
    const cashDeficit = Math.max(0, initialCashTarget - cashBal);
    const refillCash = Math.min(cashDeficit, surplusReinvested);
    const toBrokerage = surplusReinvested - refillCash;

    cashBal = Math.round(cashBal + refillCash);
    taxableBrokerageBal = Math.round(taxableBrokerageBal + toBrokerage);
    taxableBrokerageCostBasis = Math.round(taxableBrokerageCostBasis + toBrokerage);
    netCashFlow = 0;
  }

  taxableBal = Math.round(taxableBrokerageBal + cashBal);

  const endPortfolio = Math.round(preTaxBal + postTaxBal + taxableBal);
  let unfundedShortfall = Math.max(0, totalCashOutflow - totalCashInflow);
  if (unfundedShortfall <= 1) unfundedShortfall = 0;
  if (Math.abs(netCashFlow) <= 1) netCashFlow = 0;

  let solvencyStatus: 'Solvent' | 'Insolvent' | 'Depleted' = 'Solvent';
  if (endPortfolio === 0 && unfundedShortfall > 0) {
    solvencyStatus = 'Insolvent';
  } else if (endPortfolio === 0) {
    solvencyStatus = 'Depleted';
  }

  const { annotation } = buildMilestoneAnnotation({
    age,
    primaryRetAge,
    primarySsClaimAge: primary.ssClaimAge,
    primarySs,
    spouseSs,
    spouseSsClaimAge: spouse?.ssClaimAge,
    spouseAge,
    hasSpouse: plan.hasSpouse,
    rmdStartAge,
    solvencyStatus,
    firstNonSolventAlreadyAnnotated: previousRows.some(r => r.solvencyStatus !== 'Solvent'),
  });

  let yearRmdTax = 0;
  const rmdDrawAmount = rmdAmount > 0 ? Math.min(rmdAmount, actualPreTaxWd) : 0;
  if (rmdDrawAmount > 0) {
    const magiWithoutRmd = Math.max(0, estimatedMagi - rmdDrawAmount);
    const deductionWithoutRmd = resolveFederalDeduction({
      taxYear: calendarYear,
      isJoint,
      primaryAge: age,
      spouseAge: plan.hasSpouse ? spouseAge : undefined,
      magi: magiWithoutRmd,
      deflator,
      statutoryStandardDeductionJoint: statutory?.standardDeductionJoint,
      statutoryStandardDeductionSingle: statutory?.standardDeductionSingle,
    });
    const netTaxableWithoutRmd = Math.max(0, magiWithoutRmd - deductionWithoutRmd.totalDeduction);
    const fedTaxWithoutRmd = calculateFederalTax(netTaxableWithoutRmd, bracketCeilings);
    yearRmdTax = Math.max(0, fedTax - fedTaxWithoutRmd);
  }

  const withdrawalRatePct = beginningPortfolio > 0 ? Number(((totalWithdrawals / beginningPortfolio) * 100).toFixed(2)) : 0;

  const isPrimaryEligible = age >= 65;
  const isSpouseEligible = Boolean(spouse && spouseAge && spouseAge >= 65);
  const isMedicareEligible = isPrimaryEligible || isSpouseEligible;
  const enrolledCount = (isJoint && isPrimaryEligible && isSpouseEligible) ? 2 : (isMedicareEligible ? 1 : 0);
  const lookbackMagi = magiHistory[age - 2] ?? 0;
  const lookbackTaxYear = calendarYear - 2;

  const irmaaContext = resolveIrmaaContext({
    premiumYear: calendarYear,
    lookbackTaxYear,
    lookbackMagi,
    isJoint,
    deflator,
    isMedicareEligible,
    enrolledCount,
  });

  const row: SimulationRow = {
    age,
    calendarYear,
    isRetired: true,
    baseLiving: Math.round(baseLiving),
    essentialExpense,
    discretionaryExpense,
    healthExpense: Math.round(healthExpense),
    specialExpense: Math.round(totalSpecialNominal),
    debtService: 0,
    totalExpenseNeed,
    w2Income: Math.round(annualSalaryIncome),
    guaranteedIncome,
    primarySs: Math.round(primarySs),
    spouseSs: Math.round(spouseSs),
    pensionIncome: Math.round(pensionIncome),
    rmdAmount,
    rothConversion,
    rothConversionDecision: {
      policy: convDecision.policy,
      requestedConversion: convDecision.requestedConversion,
      actualConversion: convDecision.requestedConversion,
      bracketRate: convDecision.bracketRate,
      bracketCeiling: convDecision.bracketCeiling,
      taxableIncomeBeforeConversion: convDecision.taxableIncomeBeforeConversion,
      remainingBracketCapacity: convDecision.remainingBracketCapacity,
      availablePreTaxBeforeConversion: convDecision.availablePreTaxBeforeConversion,
      limitedByAvailablePreTax: convDecision.limitedByAvailablePreTax,
    },
    taxableWd: Math.round(actualTaxableWd),
    preTaxWd: Math.round(actualPreTaxWd),
    postTaxWd: Math.round(actualPostTaxWd),
    totalWithdrawals: Math.round(totalWithdrawals),
    preTaxContrib: 0,
    postTaxContrib: 0,
    taxableContrib: 0,
    beginningPortfolio,
    portfolioGrowth,
    preTaxBal,
    postTaxBal,
    taxableBal,
    totalPortfolio: endPortfolio,
    provisionalIncome: Math.round(provisionalIncome),
    taxableSs: Math.round(finalTaxableSs),
    taxableMagi: estimatedMagi,
    taxBracket,
    irmaaBracket: irmaaContext.tier,
    effectiveTaxRate,
    fedTaxPaid: fedTax,
    capGainsTaxPaid: capGainsTax,
    inflationRatePct: macro.generalInflation,
    inflationDeflator: deflator,
    portfolioReturnPct: Math.round(blendedReturnPct * 1000) / 1000,
    standardDeductionUsed: deductionBreakdown.totalDeduction,
    taxableIncomeAfterDeduction: Math.round(netTaxableIncome),
    totalPortfolioReal: Math.round(endPortfolio / deflator),
    ordinaryHeadroom: ordinaryBracketHeadroom(netTaxableIncome, bracketCeilings),
    ltcgHeadroom: ltcgHeadroom(netTaxableIncome, realizedCapGains, isJoint, deflator),
    irmaaHeadroom: irmaaContext.headroomToNextTier ?? 0,
    stateTaxPaid: stateTax,
    ficaTaxPaid: ficaTax,
    conversionTaxPaid: Math.round(conversionTaxPaid),
    conversionTaxPortfolioOutflow: Math.round(sequenceResult.conversionTaxPortfolioOutflow),
    rmdEligibleBalance: Math.round(rmdEligibleBalance),
    preTaxAvailableBeforeConversion: Math.round(preTaxAvailableBeforeConversion),
    rmdTaxPaid: Math.round(yearRmdTax),
    totalEstimatedTax,
    totalCashInflow,
    totalCashOutflow,
    netCashFlow,
    unfundedShortfall: Math.round(unfundedShortfall),
    surplusReinvested: Math.round(surplusReinvested),
    withdrawalRatePct,
    spouseAge: plan.hasSpouse ? spouseAge : undefined,
    irmaaSurcharge: Math.round(irmaaContext.totalAnnualSurcharge),
    irmaaLookbackYear: irmaaContext.lookbackTaxYear,
    irmaaLookbackMagi: irmaaContext.lookbackMagi,
    realizedCapGains,
    taxableCostBasis: Math.round(taxableBrokerageCostBasis),
    solvencyStatus,
    annotation,
  };

  return {
    row,
    preTaxBal,
    postTaxBal,
    taxableBrokerageBal,
    cashBal,
    taxableBrokerageCostBasis,
    taxableBal,
  };
}
