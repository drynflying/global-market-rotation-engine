import { describe, it, expect } from 'vitest';
import { projectWorkingYear, ProjectWorkingYearInput } from './projectWorkingYear';
import { MacroeconomicAssumptions, Plan, SpendingAssumptions } from '../../types';
import { BRACKET_CEILINGS_2026 } from '../tax/taxConstants';
import { NO_STATE_TAX_RULE } from '../tax/stateTaxConstants';

describe('projectWorkingYear', () => {
  const basePlan = {
    hasSpouse: false,
    accounts: [],
  } as unknown as Plan;

  const baseMacro = {
    generalInflation: 2.5,
    nationalWageGrowth: 3.0,
  } as unknown as MacroeconomicAssumptions;

  const baseSpending = {
    preRetirementAnnualSpending: 50000,
  } as unknown as SpendingAssumptions;

  const baseInput: ProjectWorkingYearInput = {
    plan: basePlan,
    age: 40,
    calendarYear: 2026,
    yearsFromStart: 0,
    deflator: 1.0,
    startAge: 40,
    primaryRetAge: 65,
    isJoint: false,
    stdDeduction: 15000,
    bracketCeilings: BRACKET_CEILINGS_2026.single,
    stateRule: NO_STATE_TAX_RULE,
    macro: baseMacro,
    spending: baseSpending,
    preTaxAccs: [{ id: '1', name: '401k', owner: 'primary', type: 'pre-tax', balance: 100000, annualContribution: 10000 }],
    postTaxAccs: [{ id: '2', name: 'Roth IRA', owner: 'primary', type: 'post-tax', balance: 50000, annualContribution: 5000 }],
    taxableBrokerageAccs: [{ id: '3', name: 'Brokerage', owner: 'primary', type: 'taxable', balance: 50000, annualContribution: 5000 }],
    cashAccs: [{ id: '4', name: 'Savings', owner: 'primary', type: 'cash', balance: 20000, annualContribution: 2000 }],
    preTaxBal: 100000,
    postTaxBal: 50000,
    taxableBrokerageBal: 50000,
    cashBal: 20000,
    taxableBrokerageCostBasis: 40000, // 80% basis
    growthPreTax: 0.07,
    growthPostTax: 0.07,
    growthTaxableBrokerage: 0.05,
    growthCash: 0.02,
    blendedReturnPct: 6.0,
    beginningPortfolio: 220000,
    annualSalaryIncome: 120000,
    pensionIncome: 0,
    otherGuaranteedIncome: 0,
    totalSpecialNominal: 0,
    magiHistory: {},
  };

  it('projects a normal working year with contributions and updates balances', () => {
    const res = projectWorkingYear(baseInput);

    // Check row
    expect(res.row.isRetired).toBe(false);
    expect(res.row.preTaxContrib).toBe(10000);
    expect(res.row.postTaxContrib).toBe(5000);
    expect(res.row.taxableContrib).toBe(7000); // 5000 brokerage + 2000 cash

    // Growth + contributions added to balances
    expect(res.preTaxBal).toBeGreaterThan(100000);
    expect(res.postTaxBal).toBeGreaterThan(50000);
    expect(res.taxableBrokerageBal).toBeGreaterThan(50000);
    expect(res.cashBal).toBeGreaterThan(20000);
  });

  it('adds Plan Start annotation for age == startAge', () => {
    const res = projectWorkingYear({ ...baseInput, age: 40, startAge: 40 });
    expect(res.row.annotation).toBe('Plan Start');
  });

  it('adds Final Working Year annotation for age == primaryRetAge - 1', () => {
    const res = projectWorkingYear({ ...baseInput, age: 64, primaryRetAge: 65 });
    expect(res.row.annotation).toBe('Final Working Year');
  });

  it('handles working-year deficit requiring cash draw and taxable brokerage sale with capital gains tax', () => {
    // Low income, high expense -> deficit
    const deficitInput: ProjectWorkingYearInput = {
      ...baseInput,
      annualSalaryIncome: 30000,
      spending: { preRetirementAnnualSpending: 80000 } as unknown as SpendingAssumptions,
      cashBal: 10000,
      taxableBrokerageBal: 100000,
      taxableBrokerageCostBasis: 50000, // 50% basis
    };

    const res = projectWorkingYear(deficitInput);

    expect(res.row.unfundedShortfall).toBe(0); // Covered by liquid assets
    expect(res.row.taxableWd).toBeGreaterThan(0);
    expect(res.row.realizedCapGains).toBeGreaterThan(0);
    expect(res.row.capGainsTaxPaid).toBeGreaterThanOrEqual(0);
  });

  it('calculates unfundedShortfall when liquid assets cannot cover deficit', () => {
    const brokeInput: ProjectWorkingYearInput = {
      ...baseInput,
      annualSalaryIncome: 20000,
      spending: { preRetirementAnnualSpending: 200000 } as unknown as SpendingAssumptions,
      cashBal: 1000,
      taxableBrokerageBal: 2000,
      taxableBrokerageCostBasis: 2000,
      preTaxAccs: [],
      postTaxAccs: [],
      taxableBrokerageAccs: [],
      cashAccs: [],
    };

    const res = projectWorkingYear(brokeInput);

    expect(res.row.unfundedShortfall).toBeGreaterThan(0);
  });

  it('includes special expenses in total expense need', () => {
    const res = projectWorkingYear({ ...baseInput, totalSpecialNominal: 15000 });
    expect(res.row.specialExpense).toBe(15000);
  });

  it('correctly calculates FICA tax separately per worker for two-earner household', () => {
    const twoEarnerInput: ProjectWorkingYearInput = {
      ...baseInput,
      isJoint: true,
      annualSalaryIncome: 400000,
      primarySalaryIncome: 200000,
      spouseSalaryIncome: 200000,
      bracketCeilings: BRACKET_CEILINGS_2026.joint,
    };

    const res = projectWorkingYear(twoEarnerInput);
    // Primary SS: min(200k, 184.5k) * 6.2% = 11,439
    // Spouse SS: min(200k, 184.5k) * 6.2% = 11,439
    // Total SS = 22,878
    // Combined Medicare = 400k * 1.45% = 5,800
    // Additional Medicare = (400k - 250k) * 0.9% = 1,350
    // Total FICA = 22,878 + 5,800 + 1,350 = 30,028
    expect(res.row.ficaTaxPaid).toBe(30028);
  });

  it('uses gross W-2 wages for FICA without deducting employee 401(k) pre-tax deferral', () => {
    const res = projectWorkingYear({
      ...baseInput,
      annualSalaryIncome: 100000,
      primarySalaryIncome: 100000,
      spouseSalaryIncome: 0,
      preTaxAccs: [{ id: '1', name: '401k', owner: 'primary', type: 'pre-tax', balance: 100000, annualContribution: 20000 }],
    });

    // FICA applies to full 100,000 gross wage ($7,650), not (100k - 20k) = 80k ($6,120)
    expect(res.row.ficaTaxPaid).toBe(7650);
  });

  it('correctly calculates percentage employer match and reduces taxable MAGI only by employee pre-tax deferrals', () => {
    // Primary W-2 = $100,000, Employee pre-tax = $20,000, Employer match = 3% ($3,000)
    const testPlan: Plan = {
      hasSpouse: false,
      incomeStreams: [
        { id: '1', name: 'W2 Job', owner: 'primary', type: 'salary', amount: 100000, startAge: 40, endAge: 65, growthRatePct: 0 },
      ],
      accounts: [],
    } as unknown as Plan;

    const res = projectWorkingYear({
      ...baseInput,
      plan: testPlan,
      annualSalaryIncome: 100000,
      primarySalaryIncome: 100000,
      spouseSalaryIncome: 0,
      preTaxAccs: [
        {
          id: '1',
          name: '401k',
          owner: 'primary',
          type: 'pre-tax',
          balance: 100000,
          annualContribution: 20000,
          employerMatchType: '%',
          employerMatchValue: 3.0, // 3% of $100k = $3,000
        },
      ],
      postTaxAccs: [],
      taxableBrokerageAccs: [],
      cashAccs: [],
      preTaxBal: 100000,
      growthPreTax: 0, // 0 growth for clear math
    });

    // Account inflow = $20,000 employee + $3,000 employer = $23,000
    expect(res.row.preTaxContrib).toBe(23000);
    expect(res.preTaxBal).toBe(123000); // $100,000 + $23,000

    // Taxable W-2 MAGI = $100,000 - $20,000 (employee pre-tax) = $80,000 (NOT $77,000!)
    expect(res.row.taxableMagi).toBe(80000);
  });

  it('handles fixed-dollar employer match and owner-specific spouse percentage match', () => {
    const testPlan: Plan = {
      hasSpouse: true,
      incomeStreams: [
        { id: '1', name: 'Primary Salary', owner: 'primary', type: 'salary', amount: 100000, startAge: 40, endAge: 65, growthRatePct: 0 },
        { id: '2', name: 'Spouse Salary', owner: 'spouse', type: 'salary', amount: 80000, startAge: 38, endAge: 65, growthRatePct: 0 },
      ],
      accounts: [],
    } as unknown as Plan;

    const res = projectWorkingYear({
      ...baseInput,
      plan: testPlan,
      annualSalaryIncome: 180000,
      primarySalaryIncome: 100000,
      spouseSalaryIncome: 80000,
      isJoint: true,
      spouseAge: 38,
      preTaxAccs: [
        {
          id: 'acc-p',
          name: 'Primary 401k',
          owner: 'primary',
          type: 'pre-tax',
          balance: 50000,
          annualContribution: 10000,
          employerMatchType: '$',
          employerMatchValue: 5000, // Fixed $5,000 match
        },
        {
          id: 'acc-s',
          name: 'Spouse 401k',
          owner: 'spouse',
          type: 'pre-tax',
          balance: 40000,
          annualContribution: 8000,
          employerMatchType: '%',
          employerMatchValue: 4.0, // 4% of $80,000 spouse salary = $3,200
        },
      ],
      postTaxAccs: [],
      taxableBrokerageAccs: [],
      cashAccs: [],
      preTaxBal: 90000,
      growthPreTax: 0,
    });

    // Primary pre-tax inflow = $10,000 + $5,000 = $15,000
    // Spouse pre-tax inflow = $8,000 + $3,200 = $11,200
    // Total pre-tax contrib = $26,200
    expect(res.row.preTaxContrib).toBe(26200);

    // Taxable W-2 MAGI = $180,000 - ($10,000 + $8,000) employee pre-tax = $162,000
    expect(res.row.taxableMagi).toBe(162000);
  });

  it('does not reduce taxable MAGI for employee Roth contributions while still including employer match', () => {
    const testPlan: Plan = {
      hasSpouse: false,
      incomeStreams: [
        { id: '1', name: 'W2 Job', owner: 'primary', type: 'salary', amount: 100000, startAge: 40, endAge: 65, growthRatePct: 0 },
      ],
      accounts: [],
    } as unknown as Plan;

    const res = projectWorkingYear({
      ...baseInput,
      plan: testPlan,
      annualSalaryIncome: 100000,
      primarySalaryIncome: 100000,
      spouseSalaryIncome: 0,
      preTaxAccs: [],
      postTaxAccs: [
        {
          id: '1',
          name: 'Roth 401k',
          owner: 'primary',
          type: 'post-tax',
          balance: 50000,
          annualContribution: 10000,
          employerMatchType: '%',
          employerMatchValue: 3.0, // $3,000 employer match
        },
      ],
      taxableBrokerageAccs: [],
      cashAccs: [],
      postTaxBal: 50000,
      growthPostTax: 0,
    });

    // Post-tax inflow = $10,000 employee + $3,000 employer match = $13,000
    expect(res.row.postTaxContrib).toBe(13000);
    expect(res.postTaxBal).toBe(63000);

    // Taxable MAGI is full $100,000 because Roth employee contributions do NOT reduce taxable wages
    expect(res.row.taxableMagi).toBe(100000);
  });
});
