/**
 * @file projectWorkingYear.ts
 *
 * ARCHITECTURAL ROLE: Accumulation (Working) Year Coordinator / Orchestrator
 *
 * projectWorkingYear orchestrates the sequence of events during an accumulation (working) year:
 *  - Savings contributions scaling & account additions
 *  - Tax estimation for active W2 / earned income
 *  - Asset growth application across pre-tax, Roth, taxable brokerage, and cash buckets
 *  - Deficit resolution via liquid withdrawals (cash then taxable brokerage) when net cash flow is negative
 *  - SimulationRow output construction
 *
 * Pure, formula-heavy or independently reusable logic MUST live below this coordinator
 * in domain kernel, solver, or strategy modules. Do not re-introduce inline tax/financial
 * formula definitions directly inside this coordinator.
 */

import { AccountItem, MacroeconomicAssumptions, Plan, SpendingAssumptions } from '../../types';
import { SimulationRow } from '../simulation/simulationTypes';
import { StateTaxRule, calculateStateTax, NO_STATE_TAX_RULE } from '../tax/stateTaxConstants';
import { ordinaryBracketHeadroom, ltcgHeadroom } from '../tax/headroom';
import { resolveIrmaaContext } from '../registry/statutoryRegistry';
import { BracketCeilings } from '../tax/taxConstants';
import {
  calculateFederalTax,
  calculateFicaTax,
  calculateCapGainsTax,
  getMarginalTaxBracket,
  resolveFederalDeduction,
} from '../kernel';
import { resolveWorkingYearContributions } from '../contributions/contributionResolver';

export interface ProjectWorkingYearInput {
  plan: Plan;
  age: number;
  calendarYear: number;
  yearsFromStart: number;
  deflator: number;
  startAge: number;
  primaryRetAge: number;
  spouseAge?: number;
  isJoint: boolean;
  stdDeduction: number;
  bracketCeilings: BracketCeilings;
  macro: MacroeconomicAssumptions;
  spending: SpendingAssumptions;
  preTaxAccs: AccountItem[];
  postTaxAccs: AccountItem[];
  taxableBrokerageAccs: AccountItem[];
  cashAccs: AccountItem[];
  preTaxBal: number;
  postTaxBal: number;
  taxableBrokerageBal: number;
  cashBal: number;
  taxableBrokerageCostBasis: number;
  growthPreTax: number;
  growthPostTax: number;
  growthTaxableBrokerage: number;
  growthCash: number;
  blendedReturnPct: number;
  beginningPortfolio: number;
  annualSalaryIncome: number;
  primarySalaryIncome?: number;
  spouseSalaryIncome?: number;
  pensionIncome: number;
  otherGuaranteedIncome: number;
  totalSpecialNominal: number;
  stateRule?: StateTaxRule;
  customStateRatePct?: number;
  magiHistory: Record<number, number>;
}

export interface ProjectWorkingYearResult {
  row: SimulationRow;
  preTaxBal: number;
  postTaxBal: number;
  taxableBrokerageBal: number;
  cashBal: number;
  taxableBrokerageCostBasis: number;
  taxableBal: number;
}

/**
 * Projects a single accumulation (working) year, computing savings contributions,
 * asset growth, tax liabilities, deficit resolution via liquid withdrawals, and row output.
 */
export function projectWorkingYear(input: ProjectWorkingYearInput): ProjectWorkingYearResult {
  const {
    plan,
    age,
    calendarYear,
    yearsFromStart,
    deflator,
    startAge,
    primaryRetAge,
    spouseAge,
    isJoint,
    stdDeduction,
    bracketCeilings,
    macro,
    spending,
    preTaxAccs,
    postTaxAccs,
    taxableBrokerageAccs,
    cashAccs,
    growthPreTax,
    growthPostTax,
    growthTaxableBrokerage,
    growthCash,
    blendedReturnPct,
    beginningPortfolio,
    annualSalaryIncome,
    pensionIncome,
    otherGuaranteedIncome,
    totalSpecialNominal,
    stateRule = NO_STATE_TAX_RULE,
    customStateRatePct,
    magiHistory,
  } = input;

  const statutory = plan.statutoryParams;

  let preTaxBal = input.preTaxBal;
  let postTaxBal = input.postTaxBal;
  let taxableBrokerageBal = input.taxableBrokerageBal;
  let cashBal = input.cashBal;
  let taxableBrokerageCostBasis = input.taxableBrokerageCostBasis;

  const contributionScale = Math.pow(1 + (macro.nationalWageGrowth || 3.0) / 100, yearsFromStart);
  const contributions = resolveWorkingYearContributions({
    plan,
    preTaxAccs,
    postTaxAccs,
    taxableBrokerageAccs,
    cashAccs,
    primaryAge: age,
    spouseAge,
    yearsFromStart,
    contributionScale,
  });

  const annualSavePreTax = contributions.annualSavePreTax;
  const annualSavePostTax = contributions.annualSavePostTax;
  const annualSaveTaxableBrokerage = contributions.annualSaveTaxableBrokerage;
  const annualSaveCash = contributions.annualSaveCash;
  const annualSaveTaxable = contributions.annualSaveTaxable;
  const totalEmployeeSavings = contributions.totalEmployeeSavings;

  let primaryW2 = input.primarySalaryIncome;
  let spouseW2 = input.spouseSalaryIncome;

  if (primaryW2 === undefined || spouseW2 === undefined) {
    let pW2 = 0;
    let sW2 = 0;
    if (plan.incomeStreams && plan.incomeStreams.length > 0) {
      plan.incomeStreams.forEach((stream) => {
        if (stream.type === 'salary') {
          const streamOwner = stream.owner || 'primary';
          const personAge = streamOwner === 'spouse' && typeof spouseAge === 'number' ? spouseAge : age;
          const startAge = typeof stream.startAge === 'number' ? stream.startAge : 0;
          const endAge = typeof stream.endAge === 'number' ? stream.endAge : 100;
          if (personAge >= startAge && personAge <= endAge) {
            const growthRate = stream.growthRatePct ?? 3.0;
            const streamGrowth = Math.pow(1 + growthRate / 100, yearsFromStart);
            const amt = (stream.amount || 0) * streamGrowth;
            if (streamOwner === 'spouse') {
              sW2 += amt;
            } else if (streamOwner === 'joint') {
              pW2 += amt / 2;
              sW2 += amt / 2;
            } else {
              pW2 += amt;
            }
          }
        }
      });
    }
    if (pW2 === 0 && sW2 === 0 && annualSalaryIncome > 0) {
      pW2 = annualSalaryIncome;
    }
    primaryW2 = primaryW2 ?? pW2;
    spouseW2 = spouseW2 ?? sW2;
  }

  const w2Income = Math.round(annualSalaryIncome);
  // Authoritative taxable wage reduction: only employee pre-tax elective deferrals reduce taxable wages.
  const taxableMagi = Math.max(0, w2Income - Math.round(contributions.taxableWageReduction));
  const deductionBreakdown = resolveFederalDeduction({
    taxYear: calendarYear,
    isJoint,
    primaryAge: age,
    spouseAge: plan.hasSpouse ? spouseAge : undefined,
    magi: taxableMagi,
    deflator,
    statutoryStandardDeductionJoint: statutory?.standardDeductionJoint,
    statutoryStandardDeductionSingle: statutory?.standardDeductionSingle,
  });
  const netTaxableIncome = Math.max(0, taxableMagi - deductionBreakdown.totalDeduction);
  const fedTax = calculateFederalTax(netTaxableIncome, bracketCeilings);
  const ficaTaxBreakdown = calculateFicaTax({
    primaryWages: primaryW2,
    spouseWages: spouseW2,
    isJoint,
    deflator,
  });
  const ficaTax = ficaTaxBreakdown.totalFicaTax;
  let workingRealizedCapGains = 0;
  let workingCapGainsTax = 0;
  let stateTax = calculateStateTax({
    ordinaryTaxable: netTaxableIncome,
    realizedCapGains: 0,
    taxableSocialSecurity: 0,
    rule: stateRule,
    customRatePct: customStateRatePct,
    primaryAge: age,
    agi: taxableMagi,
    isJoint,
  });
  let totalEstimatedTax = fedTax + ficaTax + stateTax;
  const taxBracket = getMarginalTaxBracket(netTaxableIncome, bracketCeilings);

  magiHistory[age] = taxableMagi;

  const preTaxGrowth = preTaxBal * growthPreTax;
  const postTaxGrowth = postTaxBal * growthPostTax;
  const taxableBrokerageGrowth = taxableBrokerageBal * growthTaxableBrokerage;
  const cashGrowth = cashBal * growthCash;
  const portfolioGrowth = Math.round(preTaxGrowth + postTaxGrowth + taxableBrokerageGrowth + cashGrowth);

  preTaxBal = Math.round(preTaxBal + preTaxGrowth + annualSavePreTax);
  postTaxBal = Math.round(postTaxBal + postTaxGrowth + annualSavePostTax);
  taxableBrokerageBal = Math.round(taxableBrokerageBal + taxableBrokerageGrowth + annualSaveTaxableBrokerage);
  cashBal = Math.round(cashBal + cashGrowth + annualSaveCash);
  taxableBrokerageCostBasis = Math.round(taxableBrokerageCostBasis + annualSaveTaxableBrokerage);
  let taxableBal = taxableBrokerageBal + cashBal;
  let endPortfolio = preTaxBal + postTaxBal + taxableBal;

  let workingUnfundedShortfall = 0;
  let totalCashInflow = Math.round(w2Income + pensionIncome + otherGuaranteedIncome);
  const workingExpenseBase =
    typeof spending.preRetirementAnnualSpending === 'number'
      ? Math.round(spending.preRetirementAnnualSpending * deflator)
      : Math.max(0, totalCashInflow - totalEstimatedTax - Math.round(totalEmployeeSavings));
  const workingExpenseNeed = Math.round(workingExpenseBase + totalSpecialNominal);
  let totalCashOutflow = workingExpenseNeed + totalEstimatedTax + Math.round(totalEmployeeSavings);
  let netCashFlow = totalCashInflow - totalCashOutflow;
  if (Math.abs(netCashFlow) <= 1) netCashFlow = 0;

  let workingCashDrawn = 0;
  let workingBrokerageDrawn = 0;

  if (netCashFlow < 0) {
    const baseDeficit = -netCashFlow;
    const drawCash = Math.min(cashBal, baseDeficit);
    cashBal = Math.round(cashBal - drawCash);
    workingCashDrawn = drawCash;
    const remainingNeeded = baseDeficit - drawCash;

    if (remainingNeeded > 0 && taxableBrokerageBal > 0) {
      const basisRatio = taxableBrokerageBal > 0 ? Math.min(1, Math.max(0, taxableBrokerageCostBasis) / taxableBrokerageBal) : 1;

      let targetDraw = remainingNeeded;
      let iter = 0;
      while (iter < 10) {
        iter++;
        const candidateDraw = Math.min(taxableBrokerageBal, targetDraw);
        const candidateBasis = candidateDraw * basisRatio;
        const candidateGains = Math.max(0, Math.round(candidateDraw - candidateBasis));

        const candidateCgTax = calculateCapGainsTax(candidateGains, netTaxableIncome, isJoint, deflator);
        const candidateStateTax = calculateStateTax({
          ordinaryTaxable: netTaxableIncome,
          realizedCapGains: candidateGains,
          taxableSocialSecurity: 0,
          rule: stateRule,
          customRatePct: customStateRatePct,
          primaryAge: age,
          agi: taxableMagi,
          isJoint,
        });

        const extraTax = (candidateCgTax + candidateStateTax) - stateTax;
        const newTarget = remainingNeeded + Math.max(0, extraTax);

        if (Math.abs(newTarget - targetDraw) < 1 || candidateDraw >= taxableBrokerageBal) {
          workingBrokerageDrawn = candidateDraw;
          workingRealizedCapGains = candidateGains;
          workingCapGainsTax = candidateCgTax;
          stateTax = candidateStateTax;
          break;
        }
        targetDraw = newTarget;
      }

      const basisWithdrawn = workingBrokerageDrawn * basisRatio;
      taxableBrokerageBal = Math.max(0, Math.round(taxableBrokerageBal - workingBrokerageDrawn));
      taxableBrokerageCostBasis = Math.max(0, Math.round(taxableBrokerageCostBasis - basisWithdrawn));
    }

    totalEstimatedTax = Math.round(fedTax + workingCapGainsTax + stateTax + ficaTax);
    totalCashOutflow = workingExpenseNeed + totalEstimatedTax + Math.round(totalEmployeeSavings);
    netCashFlow = totalCashInflow - totalCashOutflow;
    workingUnfundedShortfall = Math.max(0, Math.round((totalCashOutflow - totalCashInflow) - (workingCashDrawn + workingBrokerageDrawn)));
    if (workingRealizedCapGains > 0) {
      magiHistory[age] = taxableMagi + workingRealizedCapGains;
    }
  }
  taxableBal = taxableBrokerageBal + cashBal;
  endPortfolio = preTaxBal + postTaxBal + taxableBal;

  const workingTaxableWd = Math.round(workingCashDrawn + workingBrokerageDrawn);
  totalCashInflow = Math.round(w2Income + pensionIncome + otherGuaranteedIncome + workingTaxableWd);

  let annotation: string | undefined = undefined;
  if (age === startAge) annotation = 'Plan Start';
  else if (age === primaryRetAge - 1) annotation = 'Final Working Year';

  const isPrimaryEligible = age >= 65;
  const isSpouseEligible = Boolean(plan.hasSpouse && spouseAge && spouseAge >= 65);
  const isMedicareEligible = isPrimaryEligible || isSpouseEligible;
  const enrolledCount = (isJoint && isPrimaryEligible && isSpouseEligible) ? 2 : (isMedicareEligible ? 1 : 0);
  const lookbackMagi = magiHistory[age - 2] ?? 0;
  const lookbackTaxYear = calendarYear - 2;

  const irmaaContext = resolveIrmaaContext({
    premiumYear: calendarYear,
    lookbackTaxYear,
    lookbackMagi,
    isJoint,
    deflator,
    isMedicareEligible,
    enrolledCount,
  });

  const row: SimulationRow = {
    age,
    calendarYear,
    isRetired: false,
    baseLiving: 0,
    essentialExpense: 0,
    discretionaryExpense: 0,
    healthExpense: 0,
    specialExpense: Math.round(totalSpecialNominal),
    debtService: 0,
    totalExpenseNeed: workingExpenseNeed,
    w2Income,
    guaranteedIncome: 0,
    primarySs: 0,
    spouseSs: 0,
    pensionIncome: 0,
    rmdAmount: 0,
    rothConversion: 0,
    taxableWd: workingTaxableWd,
    preTaxWd: 0,
    postTaxWd: 0,
    totalWithdrawals: workingTaxableWd,
    preTaxContrib: Math.round(annualSavePreTax),
    postTaxContrib: Math.round(annualSavePostTax),
    taxableContrib: Math.round(annualSaveTaxable),
    beginningPortfolio,
    portfolioGrowth,
    preTaxBal,
    postTaxBal,
    taxableBal,
    totalPortfolio: endPortfolio,
    provisionalIncome: 0,
    taxableSs: 0,
    taxableMagi: taxableMagi + workingRealizedCapGains,
    taxBracket,
    irmaaBracket: irmaaContext.tier,
    effectiveTaxRate: w2Income > 0 ? (totalEstimatedTax / w2Income) * 100 : 0,
    fedTaxPaid: fedTax,
    capGainsTaxPaid: Math.round(workingCapGainsTax),
    inflationRatePct: macro.generalInflation,
    inflationDeflator: deflator,
    portfolioReturnPct: Math.round(blendedReturnPct * 1000) / 1000,
    standardDeductionUsed: deductionBreakdown.totalDeduction,
    taxableIncomeAfterDeduction: Math.round(netTaxableIncome),
    totalPortfolioReal: Math.round(endPortfolio / deflator),
    ordinaryHeadroom: ordinaryBracketHeadroom(netTaxableIncome, bracketCeilings),
    ltcgHeadroom: ltcgHeadroom(netTaxableIncome, workingRealizedCapGains, isJoint, deflator),
    irmaaHeadroom: irmaaContext.headroomToNextTier ?? 0,
    stateTaxPaid: stateTax,
    ficaTaxPaid: ficaTax,
    conversionTaxPaid: 0,
    conversionTaxPortfolioOutflow: 0,
    rmdEligibleBalance: Math.round(input.preTaxBal),
    preTaxAvailableBeforeConversion: Math.round(input.preTaxBal),
    rmdTaxPaid: 0,
    totalEstimatedTax,
    totalCashInflow,
    totalCashOutflow,
    netCashFlow,
    unfundedShortfall: workingUnfundedShortfall,
    surplusReinvested: 0,
    withdrawalRatePct: 0,
    spouseAge: plan.hasSpouse ? spouseAge : undefined,
    irmaaSurcharge: Math.round(irmaaContext.totalAnnualSurcharge),
    irmaaLookbackYear: irmaaContext.lookbackTaxYear,
    irmaaLookbackMagi: irmaaContext.lookbackMagi,
    realizedCapGains: workingRealizedCapGains,
    taxableCostBasis: Math.round(taxableBrokerageCostBasis),
    solvencyStatus: 'Solvent',
    annotation,
  };

  return {
    row,
    preTaxBal,
    postTaxBal,
    taxableBrokerageBal,
    cashBal,
    taxableBrokerageCostBasis,
    taxableBal,
  };
}
