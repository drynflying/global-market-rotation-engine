import { describe, it, expect } from 'vitest';
import { projectRetirementYear, ProjectRetirementYearInput } from './projectRetirementYear';
import { MacroeconomicAssumptions, UserProfile as PersonProfile, Plan, SpendingAssumptions } from '../../types';
import { BRACKET_CEILINGS_2026 } from '../tax/taxConstants';
import { NO_STATE_TAX_RULE } from '../tax/stateTaxConstants';

describe('projectRetirementYear', () => {
  const basePerson = {
    ssClaimAge: 67,
    lifeExpectancy: 90,
  } as unknown as PersonProfile;

  const basePlan = {
    hasSpouse: false,
    accounts: [],
  } as unknown as Plan;

  const baseMacro = {
    generalInflation: 2.5,
  } as unknown as MacroeconomicAssumptions;

  const baseSpending = {
    rothConversionStartAge: 60,
    rothConversionEndAge: 70,
    taxPaymentSource: 'taxable_brokerage',
  } as unknown as SpendingAssumptions;

  const baseInput: ProjectRetirementYearInput = {
    plan: basePlan,
    age: 65,
    calendarYear: 2031,
    yearsFromStart: 5,
    deflator: 1.1,
    primaryRetAge: 65,
    isJoint: false,
    stdDeduction: 16000,
    bracketCeilings: BRACKET_CEILINGS_2026.single,
    stateRule: NO_STATE_TAX_RULE,
    macro: baseMacro,
    spending: baseSpending,
    rmdStartAge: 73,
    convTarget: 0,
    primary: basePerson,
    preTaxBal: 500000,
    postTaxBal: 100000,
    taxableBrokerageBal: 100000,
    cashBal: 30000,
    taxableBrokerageCostBasis: 80000,
    taxableBal: 130000,
    growthPreTax: 0.05,
    growthPostTax: 0.05,
    growthTaxableBrokerage: 0.04,
    growthCash: 0.02,
    blendedReturnPct: 4.8,
    beginningPortfolio: 730000,
    annualSalaryIncome: 0,
    pensionIncome: 0,
    otherGuaranteedIncome: 0,
    totalSs: 24000,
    primarySs: 24000,
    spouseSs: 0,
    guaranteedIncome: 24000,
    baseLiving: 40000,
    essentialPct: 0.7,
    healthExpenseExAca: 6000,
    specialEssentialNominal: 0,
    specialDiscretionaryNominal: 0,
    totalSpecialNominal: 0,
    expenseNeedExAca: 46000,
    initialCashTarget: 30000,
    irmaaSurcharge: 0,
    acaPremiumFor: () => 0,
    magiHistory: {},
    previousRows: [],
  };

  it('projects a normal retirement year accurately', () => {
    const res = projectRetirementYear(baseInput);

    expect(res.row.isRetired).toBe(true);
    expect(res.row.guaranteedIncome).toBe(24000);
    expect(res.row.totalExpenseNeed).toBe(46000);
    expect(res.row.solvencyStatus).toBe('Solvent');
  });

  it('calculates mandatory RMDs when age >= rmdStartAge', () => {
    const rmdInput: ProjectRetirementYearInput = {
      ...baseInput,
      age: 75,
      preTaxBal: 500000,
    };

    const res = projectRetirementYear(rmdInput);

    expect(res.row.rmdAmount).toBeGreaterThan(0);
    expect(res.row.preTaxWd).toBeGreaterThanOrEqual(res.row.rmdAmount);
  });

  it('executes Roth conversions with conversion tax source = taxable_brokerage', () => {
    const convInput: ProjectRetirementYearInput = {
      ...baseInput,
      convTarget: 20000,
      spending: { ...baseSpending, taxPaymentSource: 'taxable_brokerage' },
    };

    const res = projectRetirementYear(convInput);

    expect(res.row.rothConversion).toBe(20000);
    expect(res.row.conversionTaxPaid).toBeGreaterThan(0);
  });

  it('executes Roth conversions with conversion tax source = conversion_proceeds', () => {
    const convInput: ProjectRetirementYearInput = {
      ...baseInput,
      convTarget: 20000,
      spending: { ...baseSpending, taxPaymentSource: 'conversion_proceeds' },
    };

    const res = projectRetirementYear(convInput);

    expect(res.row.rothConversion).toBe(20000);
    expect(res.row.conversionTaxPaid).toBeGreaterThan(0);
  });

  it('evaluates ACA health premiums when under age 65', () => {
    const acaInput: ProjectRetirementYearInput = {
      ...baseInput,
      age: 62,
      acaPremiumFor: (magi) => (magi < 50000 ? 3000 : 8000),
    };

    const res = projectRetirementYear(acaInput);

    expect(res.row.healthExpense).toBeGreaterThan(6000);
  });

  it('reinvests cash flow surplus when total cash inflows exceed total outflows', () => {
    const surplusInput: ProjectRetirementYearInput = {
      ...baseInput,
      pensionIncome: 100000,
      guaranteedIncome: 124000,
      baseLiving: 30000,
      expenseNeedExAca: 30000,
    };

    const res = projectRetirementYear(surplusInput);

    expect(res.row.surplusReinvested).toBeGreaterThan(0);
  });

  it('handles depletion and insolvency cases when portfolio is 0 and shortfall exists', () => {
    const brokeInput: ProjectRetirementYearInput = {
      ...baseInput,
      preTaxBal: 0,
      postTaxBal: 0,
      taxableBrokerageBal: 0,
      cashBal: 0,
      taxableBal: 0,
      beginningPortfolio: 0,
      guaranteedIncome: 10000,
      totalSs: 10000,
      primarySs: 10000,
      baseLiving: 50000,
      expenseNeedExAca: 50000,
    };

    const res = projectRetirementYear(brokeInput);

    expect(res.row.totalPortfolio).toBe(0);
    expect(res.row.unfundedShortfall).toBeGreaterThan(0);
    expect(res.row.solvencyStatus).toBe('Insolvent');
  });
});
