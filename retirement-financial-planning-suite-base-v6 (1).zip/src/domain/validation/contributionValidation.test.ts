import { describe, it, expect } from 'vitest';
import { runStep1Validations } from './validations';
import { createDefaultPlan } from '../../constants/defaultPlan';
import { BASE_CONTRIBUTION_LIMITS } from '../registry/statutoryRegistry';

describe('Contribution Limit Validations & Account Wrapper Honesty', () => {
  it('verifies DEFAULT_PLAN uses authoritative 2026 statutory contribution limits', () => {
    const plan = createDefaultPlan();
    expect(plan.statutoryParams?.deferralLimit401k).toBe(BASE_CONTRIBUTION_LIMITS.deferralLimit401k);
    expect(plan.statutoryParams?.catchUpLimit401k).toBe(BASE_CONTRIBUTION_LIMITS.catchUpLimit401k);
    expect(plan.statutoryParams?.iraLimit).toBe(BASE_CONTRIBUTION_LIMITS.iraLimit);
    expect(plan.statutoryParams?.iraCatchUpLimit).toBe(BASE_CONTRIBUTION_LIMITS.iraCatchUpLimit);
    expect(plan.statutoryParams?.hsaFamilyLimit).toBe(BASE_CONTRIBUTION_LIMITS.hsaFamilyLimit);
    expect(plan.statutoryParams?.hsaSingleLimit).toBe(BASE_CONTRIBUTION_LIMITS.hsaSingleLimit);
    expect(plan.statutoryParams?.hsaCatchUpLimit).toBe(BASE_CONTRIBUTION_LIMITS.hsaCatchUpLimit);
  });

  it('passes when elective pre-tax contributions are within 2026 401(k) limit for under-50', () => {
    const plan = createDefaultPlan();
    plan.primaryPerson.currentAge = 40;
    // Set 401(k) pre-tax contribution to $24,500
    const primaryPreTax = plan.accounts.find(a => a.owner === 'primary' && a.type === 'pre-tax');
    if (primaryPreTax) {
      primaryPreTax.annualContribution = 24500;
    }

    const results = runStep1Validations(plan);
    const pretaxResult = results.find(r => r.id === 'val-irs-primary-ok');
    expect(pretaxResult).toBeDefined();
    expect(pretaxResult?.status).toBe('pass');
    expect(pretaxResult?.description).toContain('$24,500/yr');
  });

  it('warns with account wrapper honesty note when elective pre-tax contributions exceed limit', () => {
    const plan = createDefaultPlan();
    plan.primaryPerson.currentAge = 40;
    const primaryPreTax = plan.accounts.find(a => a.owner === 'primary' && a.type === 'pre-tax');
    if (primaryPreTax) {
      primaryPreTax.annualContribution = 30000;
    }

    const results = runStep1Validations(plan);
    const pretaxResult = results.find(r => r.id === 'val-irs-primary-pretax');
    expect(pretaxResult).toBeDefined();
    expect(pretaxResult?.status).toBe('warning');
    expect(pretaxResult?.title).toContain('Pre-Tax Contributions Exceed Workplace Deferral Guideline');
    // Confirms wrapper honesty note
    expect(pretaxResult?.description).toContain('Current account categorization does not separate 401(k) from Traditional IRA or 457(b) wrappers');
  });

  it('allows higher pre-tax contributions up to age 50+ catch-up limit without warning', () => {
    const plan = createDefaultPlan();
    plan.primaryPerson.currentAge = 55;
    const primaryPreTax = plan.accounts.find(a => a.owner === 'primary' && a.type === 'pre-tax');
    if (primaryPreTax) {
      // 24500 + 8000 = 32500
      primaryPreTax.annualContribution = 32500;
    }

    const results = runStep1Validations(plan);
    const pretaxResult = results.find(r => r.id === 'val-irs-primary-ok');
    expect(pretaxResult).toBeDefined();
    expect(pretaxResult?.status).toBe('pass');
    expect(pretaxResult?.description).toContain('$32,500/yr');
  });

  it('honors scenario overrides in plan.statutoryParams during validation', () => {
    const plan = createDefaultPlan();
    plan.primaryPerson.currentAge = 40;
    // User overrides 401(k) limit to $30,000 in statutoryParams
    plan.statutoryParams = {
      ...plan.statutoryParams!,
      deferralLimit401k: 30000,
    };
    const primaryPreTax = plan.accounts.find(a => a.owner === 'primary' && a.type === 'pre-tax');
    if (primaryPreTax) {
      primaryPreTax.annualContribution = 29000;
    }

    const results = runStep1Validations(plan);
    const pretaxResult = results.find(r => r.id === 'val-irs-primary-ok');
    expect(pretaxResult).toBeDefined();
    expect(pretaxResult?.status).toBe('pass');
    expect(pretaxResult?.description).toContain('$30,000/yr');
  });

  it('does not count employer match toward employee elective deferral limits', () => {
    const plan = createDefaultPlan();
    plan.primaryPerson.currentAge = 40;
    const primaryPreTax = plan.accounts.find(a => a.owner === 'primary' && a.type === 'pre-tax');
    if (primaryPreTax) {
      primaryPreTax.annualContribution = 24500; // max employee deferral
      primaryPreTax.employerMatchType = '$';
      primaryPreTax.employerMatchValue = 10000; // $10k employer match
    }

    const results = runStep1Validations(plan);
    // Employee deferral is exactly $24,500, so it passes
    const pretaxResult = results.find(r => r.id === 'val-irs-primary-ok');
    expect(pretaxResult).toBeDefined();
    expect(pretaxResult?.status).toBe('pass');
  });

  it('validates HSA contributions against individual and family limits with age 55+ catch-up', () => {
    const plan = createDefaultPlan();
    plan.hasSpouse = false; // Single
    plan.acaAssumptions = {
      ...plan.acaAssumptions!,
      householdSize: 1,
    };
    plan.primaryPerson.currentAge = 45;
    
    // Add HSA account
    plan.accounts.push({
      id: 'acc-hsa-test',
      name: 'Health Savings Account',
      type: 'hsa',
      owner: 'primary',
      balance: 10000,
      annualContribution: 5000, // Exceeds single limit $4,400
      isCatchUpEligible: false,
    });

    let results = runStep1Validations(plan);
    let hsaResult = results.find(r => r.id === 'val-hsa-primary-limit');
    expect(hsaResult).toBeDefined();
    expect(hsaResult?.status).toBe('warning');
    expect(hsaResult?.description).toContain('individual HDHP limit ($4,400/yr)');

    // Now age 55+ (catch-up adds $1,000 -> $5,400 limit)
    plan.primaryPerson.currentAge = 56;
    results = runStep1Validations(plan);
    hsaResult = results.find(r => r.id === 'val-hsa-primary-ok');
    expect(hsaResult).toBeDefined();
    expect(hsaResult?.status).toBe('pass');
    expect(hsaResult?.description).toContain('$5,400/yr');
  });

  it('detects catch-up flags enabled before age 50 for retirement and age 55 for HSA', () => {
    const plan = createDefaultPlan();
    plan.primaryPerson.currentAge = 45;
    
    // Retirement account with catchup enabled at 45
    const pretax = plan.accounts.find(a => a.owner === 'primary' && a.type === 'pre-tax');
    if (pretax) {
      pretax.isCatchUpEligible = true;
    }

    // HSA account with catchup enabled at 45
    plan.accounts.push({
      id: 'acc-hsa-young',
      name: 'HSA Young',
      type: 'hsa',
      owner: 'primary',
      balance: 5000,
      annualContribution: 3000,
      isCatchUpEligible: true,
    });

    const results = runStep1Validations(plan);
    
    const retCatchup = results.find(r => r.id === `val-catchup-age-${pretax?.id}`);
    expect(retCatchup).toBeDefined();
    expect(retCatchup?.status).toBe('warning');
    expect(retCatchup?.description).toContain('age 50+');

    const hsaCatchup = results.find(r => r.id === 'val-catchup-age-acc-hsa-young');
    expect(hsaCatchup).toBeDefined();
    expect(hsaCatchup?.status).toBe('warning');
    expect(hsaCatchup?.description).toContain('age 55+');
  });
});
