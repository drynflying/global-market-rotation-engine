import { Plan, ValidationResult } from '../../types';
import { DEFAULT_PLAN } from '../../constants/defaultPlan';
import { isAccountModeledInProjection } from '../accounts/accountCapabilities';
import { 
  SOCIAL_SECURITY_REGISTRY, 
  resolveContributionLimits,
  get401kContributionLimit,
  getHsaContributionLimit,
  findStateRule,
} from '../registry/statutoryRegistry';
import { getActiveW2Compensation, resolveAccountContribution } from '../contributions/contributionResolver';
import { resolveRetirementStrategy, getRothConversionPolicyLabel } from '../strategy';
import { getSimulation } from '../simulation/simulationCache';

export function runStep1Validations(plan: Plan): ValidationResult[] {
  const results: ValidationResult[] = [];

  // --- 1. Primary Profile Checks ---
  const p = plan.primaryPerson;
  if (!p.name || p.name.trim() === '') {
    results.push({
      id: 'val-p-name',
      step: 1,
      stepName: 'Persona Profile & Accounts',
      title: 'Primary Owner Name Missing',
      category: 'Profile',
      status: 'warning',
      description: 'Primary owner name is empty.',
      recommendation: 'Provide a name for primary persona identification.',
      targetTab: 'profile',
    });
  } else {
    results.push({
      id: 'val-p-name',
      step: 1,
      stepName: 'Persona Profile & Accounts',
      title: `Primary Profile Defined (${p.name})`,
      category: 'Profile',
      status: 'pass',
      description: `Primary profile configured with Current Age ${p.currentAge}, Retirement Age ${p.retirementAge}, Life Expectancy ${p.lifeExpectancy}.`,
      targetTab: 'profile',
    });
  }

  if (p.retirementAge < p.currentAge) {
    results.push({
      id: 'val-p-ret-age',
      step: 1,
      stepName: 'Persona Profile & Accounts',
      title: 'Primary Retirement Age Conflict',
      category: 'Profile',
      status: 'fail',
      description: `Primary retirement age (${p.retirementAge}) cannot be less than current age (${p.currentAge}).`,
      recommendation: 'Set primary retirement age equal to or greater than current age.',
      targetTab: 'profile',
    });
  }

  if (p.lifeExpectancy <= p.retirementAge) {
    results.push({
      id: 'val-p-life-exp',
      step: 1,
      stepName: 'Persona Profile & Accounts',
      title: 'Primary Life Expectancy Warning',
      category: 'Profile',
      status: 'warning',
      description: `Primary life expectancy (${p.lifeExpectancy}) should be greater than retirement age (${p.retirementAge}).`,
      recommendation: 'Increase life expectancy for a realistic retirement cash flow horizon.',
      targetTab: 'profile',
    });
  }

  if (p.ssClaimAge < 62 || p.ssClaimAge > 70) {
    results.push({
      id: 'val-p-ss-age',
      step: 1,
      stepName: 'Persona Profile & Accounts',
      title: 'Primary Social Security Claim Age Bounds',
      category: 'Profile',
      status: 'warning',
      description: `Primary Social Security claim age is set to ${p.ssClaimAge}. Standard claim window is 62 to 70.`,
      recommendation: 'Adjust claim age between 62 (Early) and 70 (Delayed Credits).',
      targetTab: 'profile',
    });
  }

  // Social Security FRA Benefit & Reduction validation
  results.push({
    id: 'val-p-ss-fra',
    step: 1,
    stepName: 'Persona Profile & Accounts',
    title: `Primary SS Benefit at FRA ($${p.ssMonthlyBenefit.toLocaleString()}/mo)`,
    category: 'Profile',
    status: 'pass',
    description: p.includeSsProjectedReduction 
      ? `Primary modeling includes projected ~21% SSA trust fund reduction ($${(p.ssMonthlyBenefit * 0.79).toFixed(0)}/mo net payable).`
      : `Primary modeling assumes 100% full scheduled benefit ($${p.ssMonthlyBenefit.toLocaleString()}/mo at FRA).`,
    recommendation: 'Source reference: SSA Board of Trustees OASDI Annual Report (https://www.ssa.gov/oact/TR/)',
    targetTab: 'profile',
  });

  // --- 2. Spouse Profile Checks (if spouse active) ---
  if (plan.hasSpouse) {
    const s = plan.spousePerson;
    if (!s.name || s.name.trim() === '') {
      results.push({
        id: 'val-s-name',
        step: 1,
        stepName: 'Persona Profile & Accounts',
        title: 'Spouse Name Missing',
        category: 'Profile',
        status: 'warning',
        description: 'Spouse persona name is blank.',
        recommendation: 'Enter spouse name.',
        targetTab: 'profile',
      });
    } else {
      results.push({
        id: 'val-s-name',
        step: 1,
        stepName: 'Persona Profile & Accounts',
        title: `Spouse Profile Defined (${s.name})`,
        category: 'Profile',
        status: 'pass',
        description: `Spouse profile configured with Current Age ${s.currentAge}, Retirement Age ${s.retirementAge}, Life Expectancy ${s.lifeExpectancy}.`,
        targetTab: 'profile',
      });
    }

    if (s.retirementAge < s.currentAge) {
      results.push({
        id: 'val-s-ret-age',
        step: 1,
        stepName: 'Persona Profile & Accounts',
        title: 'Spouse Retirement Age Conflict',
        category: 'Profile',
        status: 'fail',
        description: `Spouse retirement age (${s.retirementAge}) cannot be lower than spouse current age (${s.currentAge}).`,
        recommendation: 'Adjust spouse retirement age.',
        targetTab: 'profile',
      });
    }

    if (s.lifeExpectancy <= s.retirementAge) {
      results.push({
        id: 'val-s-life-exp',
        step: 1,
        stepName: 'Persona Profile & Accounts',
        title: 'Spouse Life Expectancy Warning',
        category: 'Profile',
        status: 'warning',
        description: `Spouse life expectancy (${s.lifeExpectancy}) should exceed spouse retirement age (${s.retirementAge}).`,
        recommendation: 'Extend spouse planning horizon.',
        targetTab: 'profile',
      });
    }
  }

  // --- 3. Accounts & IRS Limits Checks ---
  if (plan.accounts.length === 0) {
    results.push({
      id: 'val-no-accounts',
      step: 1,
      stepName: 'Persona Profile & Accounts',
      title: 'No Assets or Accounts Configured',
      category: 'Accounts',
      status: 'warning',
      description: 'You have not added any savings, pre-tax, Roth, or taxable accounts yet.',
      recommendation: 'Add at least one account to simulate future retirement growth and withdrawals.',
      targetTab: 'profile',
    });
  } else {
    results.push({
      id: 'val-accounts-count',
      step: 1,
      stepName: 'Persona Profile & Accounts',
      title: `Account Register Configured (${plan.accounts.length} accounts)`,
      category: 'Accounts',
      status: 'pass',
      description: `Total account balances mapped across Taxable, Pre-Tax, Roth, Cash, and Real Estate.`,
      targetTab: 'profile',
    });

    // Check negative balances
    const negAccs = plan.accounts.filter(a => a.balance < 0);
    if (negAccs.length > 0) {
      results.push({
        id: 'val-neg-balance',
        step: 1,
        stepName: 'Persona Profile & Accounts',
        title: 'Negative Asset Balance Detected',
        category: 'Accounts',
        status: 'fail',
        description: `Account(s): ${negAccs.map(a => a.name).join(', ')} have negative balance values.`,
        recommendation: 'Ensure account balances are non-negative ($0 or greater).',
        targetTab: 'profile',
      });
    }

    // Authoritative Statutory Contribution Limits & Account-Wrapper Guidance Audit
    const resolvedLimits = resolveContributionLimits(plan.statutoryParams);

    const checkContributionGuidelines = (ownerKey: 'primary' | 'spouse', personObj: typeof p) => {
      const ownerName = ownerKey === 'primary' ? p.name : plan.spousePerson.name;
      const ownerAge = personObj.currentAge;
      
      const ownerAccounts = plan.accounts.filter(a => a.owner === ownerKey);
      const w2Comp = getActiveW2Compensation(plan, ownerKey, p.currentAge, plan.hasSpouse ? plan.spousePerson.currentAge : undefined);

      const preTaxAccounts = ownerAccounts.filter(a => a.type === 'pre-tax');
      const employeePreTax = preTaxAccounts.reduce((sum, a) => {
        return sum + resolveAccountContribution(a, { ownerW2Compensation: w2Comp }).employeeContribution;
      }, 0);

      const max401k = get401kContributionLimit(ownerAge, resolvedLimits);

      // Pre-tax workplace/IRA deferral guideline
      if (employeePreTax > max401k) {
        results.push({
          id: `val-irs-${ownerKey}-pretax`,
          step: 1,
          stepName: 'Persona Profile & Accounts',
          title: `${ownerName} Pre-Tax Contributions Exceed Workplace Deferral Guideline`,
          category: 'Contributions',
          status: 'warning',
          description: `Total elective pre-tax contributions ($${employeePreTax.toLocaleString()}/yr) exceed the standard 401(k)/403(b) elective deferral limit ($${max401k.toLocaleString()}/yr). Note: Current account categorization does not separate 401(k) from Traditional IRA or 457(b) wrappers; if contributions span multiple independent statutory plan types, higher totals may be permissible.`,
          recommendation: 'Verify whether pre-tax savings are split across independent employer plans or include non-deferral amounts.',
          targetTab: 'profile',
        });
      } else {
        results.push({
          id: `val-irs-${ownerKey}-ok`,
          step: 1,
          stepName: 'Persona Profile & Accounts',
          title: `${ownerName} Pre-Tax Savings within Guideline Deferral Bounds`,
          category: 'Contributions',
          status: 'pass',
          description: `Annual elective pre-tax contributions ($${employeePreTax.toLocaleString()}/yr) are within the $${max401k.toLocaleString()}/yr workplace deferral guideline.`,
          targetTab: 'profile',
        });
      }

      // HSA statutory check
      const hsaAccounts = plan.accounts.filter(a => (a.owner === ownerKey || (ownerKey === 'primary' && a.owner === 'joint')) && a.type === 'hsa');
      if (hsaAccounts.length > 0) {
        const hsaContrib = hsaAccounts.reduce((sum, a) => sum + a.annualContribution, 0);
        const isFamily = plan.hasSpouse || ((plan.acaAssumptions?.householdSize ?? 1) > 1);
        const maxHsa = getHsaContributionLimit(isFamily, ownerAge, resolvedLimits);
        if (hsaContrib > maxHsa) {
          results.push({
            id: `val-hsa-${ownerKey}-limit`,
            step: 1,
            stepName: 'Persona Profile & Accounts',
            title: `${ownerName} HSA Contributions Exceed Statutory Limit`,
            category: 'Contributions',
            status: 'warning',
            description: `Annual HSA contributions ($${hsaContrib.toLocaleString()}/yr) exceed the statutory ${isFamily ? 'family' : 'individual'} HDHP limit ($${maxHsa.toLocaleString()}/yr).`,
            recommendation: 'Confirm HDHP enrollment tier (self-only vs family) and annual statutory maximum.',
            targetTab: 'profile',
          });
        } else {
          results.push({
            id: `val-hsa-${ownerKey}-ok`,
            step: 1,
            stepName: 'Persona Profile & Accounts',
            title: `${ownerName} HSA Contributions within Statutory Bounds`,
            category: 'Contributions',
            status: 'pass',
            description: `Annual HSA contributions ($${hsaContrib.toLocaleString()}/yr) comply with the statutory ${isFamily ? 'family' : 'individual'} limit ($${maxHsa.toLocaleString()}/yr).`,
            targetTab: 'profile',
          });
        }
      }
    };

    checkContributionGuidelines('primary', p);
    if (plan.hasSpouse) {
      checkContributionGuidelines('spouse', plan.spousePerson);
    }

    // Catch-up contribution age eligibility check
    plan.accounts.forEach(acc => {
      const ownerPerson = acc.owner === 'spouse' ? plan.spousePerson : p;
      if (acc.isCatchUpEligible) {
        if (acc.type === 'hsa' && ownerPerson.currentAge < 55) {
          results.push({
            id: `val-catchup-age-${acc.id}`,
            step: 1,
            stepName: 'Persona Profile & Accounts',
            title: `HSA Catch-Up Enabled Before Age 55 (${acc.name})`,
            category: 'Contributions',
            status: 'warning',
            description: `${acc.name} has catch-up contributions enabled, but owner age is ${ownerPerson.currentAge} (IRS Sec. 223 limits HSA catch-ups to age 55+).`,
            recommendation: 'HSA catch-up allowances ($1,000) activate when owner reaches age 55.',
            targetTab: 'profile',
          });
        } else if (acc.type !== 'hsa' && ownerPerson.currentAge < 50) {
          results.push({
            id: `val-catchup-age-${acc.id}`,
            step: 1,
            stepName: 'Persona Profile & Accounts',
            title: `Catch-Up Flag Enabled Before Age 50 (${acc.name})`,
            category: 'Contributions',
            status: 'warning',
            description: `${acc.name} (${acc.owner}) has catch-up contributions enabled, but current age is ${ownerPerson.currentAge} (IRS limits retirement catch-ups to age 50+).`,
            recommendation: 'Catch-up allowances will automatically activate when owner reaches age 50.',
            targetTab: 'profile',
          });
        }
      }
    });
  }

  // State Tax Modeling Status Validation
  const stateRule = findStateRule(plan.stateOfResidence);
  if (stateRule.kind === 'unsupported' || stateRule.supported === false) {
    results.push({
      id: 'val-step1-unsupported-state',
      step: 1,
      stepName: 'Persona Profile & Accounts',
      title: `State Income Tax Not Modeled (${plan.stateOfResidence || 'Unknown'})`,
      category: 'Tax & Compliance',
      status: 'warning',
      description: `State tax rules for "${plan.stateOfResidence}" are not modeled in the projection engine ($0 state tax modeled).`,
      recommendation: 'Use "Custom Rate" in Persona & Profile to specify an estimated effective state tax rate.',
      targetTab: 'profile',
    });
  } else {
    results.push({
      id: 'val-step1-supported-state',
      step: 1,
      stepName: 'Persona Profile & Accounts',
      title: `State Tax Residence Modeled (${stateRule.name})`,
      category: 'Tax & Compliance',
      status: 'pass',
      description: stateRule.kind === 'none'
        ? `${stateRule.name}: No state income tax is applied ($0 state tax).`
        : stateRule.kind === 'custom'
        ? `Custom effective state rate of ${plan.customStateRatePct ?? 0}% is applied.`
        : `${stateRule.name}: Flat rate of ${stateRule.ratePct}% on state-taxable income is applied.`,
      targetTab: 'profile',
    });
  }

  return results;
}

export function runStep2Validations(plan: Plan): ValidationResult[] {
  const results: ValidationResult[] = [];
  const macro = plan.macroAssumptions || {
    generalInflation: 2.50,
    medicalInflation: 4.50,
    educationInflation: 4.00,
    realEstateAppreciation: 3.00,
    cashYield: 3.50,
    preRetirementEquityReturn: 7.50,
    postRetirementEquityReturn: 6.00,
    bondYield: 4.25,
  };

  const stat = plan.statutoryParams || DEFAULT_PLAN.statutoryParams!;

  // --- 1. General Inflation Bounds ---
  if (macro.generalInflation < 1.0 || macro.generalInflation > 6.0) {
    results.push({
      id: 'val-step2-inflation-bounds',
      step: 2,
      stepName: 'Assumptions & Statutory',
      title: 'General Inflation Out of Historical Norms',
      category: 'Tax & Compliance',
      status: 'warning',
      description: `Baseline CPI inflation set to ${macro.generalInflation.toFixed(2)}%. Historical 30-year average is 2.2% - 3.5%.`,
      recommendation: 'Consider setting general CPI inflation between 2.0% and 4.0% for long-term modeling stability.',
      targetTab: 'assumptions',
    });
  } else {
    results.push({
      id: 'val-step2-inflation-ok',
      step: 2,
      stepName: 'Assumptions & Statutory',
      title: `General Inflation Baseline (${macro.generalInflation.toFixed(2)}%)`,
      category: 'Tax & Compliance',
      status: 'pass',
      description: `CPI inflation rate of ${macro.generalInflation.toFixed(2)}% matches BLS long-term historical trajectory expectations.`,
      targetTab: 'assumptions',
    });
  }

  // --- 2. Healthcare Inflation Spread ---
  if (macro.medicalInflation < macro.generalInflation) {
    results.push({
      id: 'val-step2-medical-inflation',
      step: 2,
      stepName: 'Assumptions & Statutory',
      title: 'Medical Inflation Set Below General CPI Inflation',
      category: 'Tax & Compliance',
      status: 'warning',
      description: `Medical inflation (${macro.medicalInflation.toFixed(2)}%) is lower than CPI (${macro.generalInflation.toFixed(2)}%). Healthcare historically grows 1.5% - 2.5% faster than baseline CPI.`,
      recommendation: 'Increase medical inflation assumption to at least equal or exceed general inflation.',
      targetTab: 'assumptions',
    });
  } else {
    results.push({
      id: 'val-step2-medical-ok',
      step: 2,
      stepName: 'Assumptions & Statutory',
      title: `Medical Inflation Premium Tracked (${macro.medicalInflation.toFixed(2)}%)`,
      category: 'Tax & Compliance',
      status: 'pass',
      description: `Healthcare inflation incorporates a +${(macro.medicalInflation - macro.generalInflation).toFixed(2)}% real cost growth rate above baseline CPI.`,
      targetTab: 'assumptions',
    });
  }

  // --- 3. Pre-Retirement Real Return (Fisher Relation) ---
  const realEquityReturn = (((1 + macro.preRetirementEquityReturn / 100) / (1 + macro.generalInflation / 100)) - 1) * 100;
  if (realEquityReturn <= 1.0) {
    results.push({
      id: 'val-step2-real-return',
      step: 2,
      stepName: 'Assumptions & Statutory',
      title: 'Low Pre-Retirement Real Equity Return',
      category: 'Tax & Compliance',
      status: 'warning',
      description: `Pre-retirement nominal equity return (${macro.preRetirementEquityReturn.toFixed(2)}%) yields only ${realEquityReturn.toFixed(2)}% real return after inflation.`,
      recommendation: 'Verify if investment growth rate adequately supports portfolio accumulation targets.',
      targetTab: 'assumptions',
    });
  } else {
    results.push({
      id: 'val-step2-real-return-ok',
      step: 2,
      stepName: 'Assumptions & Statutory',
      title: `Pre-Retirement Real Capital Growth (${realEquityReturn.toFixed(2)}% Real)`,
      category: 'Tax & Compliance',
      status: 'pass',
      description: `Nominal equity growth (${macro.preRetirementEquityReturn.toFixed(2)}%) provides a net positive capital growth above inflation.`,
      targetTab: 'assumptions',
    });
  }

  // --- 4. SECURE 2.0 Statutory RMD Age ---
  if (stat.rmdStartAge !== 73 && stat.rmdStartAge !== 75) {
    results.push({
      id: 'val-step2-rmd-age',
      step: 2,
      stepName: 'Assumptions & Statutory',
      title: 'RMD Start Age Deviates from SECURE Act 2.0',
      category: 'Tax & Compliance',
      status: 'warning',
      description: `RMD start age is configured to ${stat.rmdStartAge}. SECURE Act 2.0 sets mandatory RMD age to 73 (born 1951-1959) or 75 (born 1960+).`,
      recommendation: 'Adjust RMD start age to 73 or 75 per IRS statutory guidelines.',
      targetTab: 'assumptions',
    });
  } else {
    results.push({
      id: 'val-step2-rmd-ok',
      step: 2,
      stepName: 'Assumptions & Statutory',
      title: `SECURE 2.0 Statutory RMD Compliance (Age ${stat.rmdStartAge})`,
      category: 'Tax & Compliance',
      status: 'pass',
      description: `Required Minimum Distribution (RMD) rules set to age ${stat.rmdStartAge} in accordance with current statutory tables.`,
      targetTab: 'assumptions',
    });
  }

  // --- 5. Verifiable Source Table Rules ---
  const asmSources = plan.assumptions || [];
  if (asmSources.length === 0) {
    results.push({
      id: 'val-step2-no-sources',
      step: 2,
      stepName: 'Assumptions & Statutory',
      title: 'No Verifiable Source References Recorded',
      category: 'Tax & Compliance',
      status: 'warning',
      description: 'Zero verifiable reference data source URLs logged in the step 2 table.',
      recommendation: 'Add official BLS, IRS, or SSA source citations to validate plan assumptions.',
      targetTab: 'assumptions',
    });
  } else {
    results.push({
      id: 'val-step2-sources-ok',
      step: 2,
      stepName: 'Assumptions & Statutory',
      title: `Verifiable Source Citations Logged (${asmSources.length} References)`,
      category: 'Tax & Compliance',
      status: 'pass',
      description: `Plan parameters backed by official agency citations (BLS, IRS, SSA, CMS).`,
      targetTab: 'assumptions',
    });
  }

  // --- 6. Asset Allocation Presets 100% Total Check ---
  const defaultPresets = DEFAULT_PLAN.allocationPresets || [];
  const storedPresets = plan.allocationPresets;
  const hasAllWeatherInStored = storedPresets?.some(p => p.id === 'preset-allweather');
  const activeStoredPresets = (storedPresets && hasAllWeatherInStored) ? storedPresets : undefined;

  const presets = defaultPresets.map(defP => {
    const found = activeStoredPresets?.find(p => p.id === defP.id);
    return found ? { ...found } : { ...defP };
  });
  const invalidPresets = presets.filter(p => {
    const total = p.usEquityPct + p.intlEquityPct + (p.goldPct || 0) + p.bondsPct + p.cashPct;
    return total !== 100;
  });

  if (invalidPresets.length > 0) {
    results.push({
      id: 'val-step2-presets-sum',
      step: 2,
      stepName: 'Assumptions & Statutory',
      title: 'Allocation Preset Weights Do Not Sum to 100%',
      category: 'Tax & Compliance',
      status: 'fail',
      description: `Preset(s): ${invalidPresets.map(p => p.name).join(', ')} do not sum to exactly 100%.`,
      recommendation: 'Adjust asset class target percentages (US Equity, Intl Equity, Gold, Bonds, Cash) so total equals 100%.',
      targetTab: 'assumptions',
    });
  } else if (presets.length > 0) {
    results.push({
      id: 'val-step2-presets-sum-ok',
      step: 2,
      stepName: 'Assumptions & Statutory',
      title: `Asset Allocation Target Weights Valid (${presets.length} Presets)`,
      category: 'Tax & Compliance',
      status: 'pass',
      description: `All asset allocation presets sum to 100% across US Equity, Intl Equity, Gold ETF, Bonds, and Cash.`,
      targetTab: 'assumptions',
    });
  }

  // --- 7. Individual Account Allocation 100% Total Check ---
  const invalidAccountAllocations = plan.accounts.filter(acc => {
    const alloc = acc.allocation || { usEquityPct: 30, intlEquityPct: 15, goldPct: 7.5, bondsPct: 40, cashPct: 7.5 };
    const total = (alloc.usEquityPct || 0) + (alloc.intlEquityPct || 0) + (alloc.goldPct || 0) + (alloc.bondsPct || 0) + (alloc.cashPct || 0);
    return total !== 100;
  });

  if (invalidAccountAllocations.length > 0) {
    results.push({
      id: 'val-accounts-allocation-sum',
      step: 1,
      stepName: 'Profile & Accounts',
      title: 'Asset Account Allocation Weights Do Not Sum to 100%',
      category: 'Profile',
      status: 'fail',
      description: `Account(s): ${invalidAccountAllocations.map(a => a.name).join(', ')} target asset class weights do not sum to 100%.`,
      recommendation: 'Edit the asset account in Step 1 and ensure US Eq + Intl Eq + Gold + Bonds + Cash = 100%.',
      targetTab: 'profile',
    });
  } else if (plan.accounts.length > 0) {
    results.push({
      id: 'val-accounts-allocation-sum-ok',
      step: 1,
      stepName: 'Profile & Accounts',
      title: `Asset Account Allocations Valid (${plan.accounts.length} Accounts)`,
      category: 'Profile',
      status: 'pass',
      description: `All asset accounts have target class weights summing to 100% (US/Intl Equities, Gold ETF, Bonds, Cash).`,
      targetTab: 'profile',
    });
  }

  return results;
}

export function runStep3Validations(plan: Plan): ValidationResult[] {
  const results: ValidationResult[] = [];
  const allAccounts = plan.accounts || [];
  const modeledAccounts = allAccounts.filter(a => isAccountModeledInProjection(a.type));

  if (modeledAccounts.length === 0) {
    results.push({
      id: 'val-step3-no-accounts',
      step: 3,
      stepName: 'Investments & Allocations',
      title: 'No Modeled Asset Accounts Configured',
      category: 'Accounts',
      status: 'warning',
      description: 'Zero modeled investment accounts registered to analyze asset class allocation.',
      recommendation: 'Add pre-tax, post-tax, or taxable accounts in Step 1 to map asset allocations.',
      targetTab: 'investments',
    });
    return results;
  }

  // --- 1. Account Allocation Sums (100% check for modeled accounts) ---
  const invalidAllocAccounts = modeledAccounts.filter(acc => {
    const alloc = acc.allocation || { usEquityPct: 30, intlEquityPct: 15, goldPct: 7.5, bondsPct: 40, cashPct: 7.5 };
    const sum = (alloc.usEquityPct || 0) + (alloc.intlEquityPct || 0) + (alloc.goldPct || 0) + (alloc.bondsPct || 0) + (alloc.cashPct || 0);
    return sum !== 100;
  });

  if (invalidAllocAccounts.length > 0) {
    results.push({
      id: 'val-step3-alloc-sum',
      step: 3,
      stepName: 'Investments & Allocations',
      title: 'Account Asset Allocations Do Not Sum to 100%',
      category: 'Accounts',
      status: 'fail',
      description: `Modeled account(s) with invalid allocation sum: ${invalidAllocAccounts.map(a => a.name).join(', ')}.`,
      recommendation: 'Adjust asset class target percentages (US Eq, Intl Eq, Gold, Bonds, Cash) so total equals 100%.',
      targetTab: 'investments',
    });
  } else {
    results.push({
      id: 'val-step3-alloc-sum-ok',
      step: 1,
      stepName: 'Investments & Savings',
      title: `All Account Allocations Sum to 100% (${modeledAccounts.length} Modeled Accounts)`,
      category: 'Accounts',
      status: 'pass',
      description: 'Every modeled asset account has fully allocated asset class target weights summing to 100%.',
      targetTab: 'investments',
    });
  }

  // --- Portfolio Level Totals ---
  const totalBalance = modeledAccounts.reduce((sum, acc) => sum + (acc.balance || 0), 0);
  if (totalBalance > 0) {
    const totalUsEquity = modeledAccounts.reduce((sum, acc) => {
      const alloc = acc.allocation || { usEquityPct: 30, intlEquityPct: 15, goldPct: 7.5, bondsPct: 40, cashPct: 7.5 };
      return sum + (acc.balance * (alloc.usEquityPct || 0) / 100);
    }, 0);

    const totalIntlEquity = modeledAccounts.reduce((sum, acc) => {
      const alloc = acc.allocation || { usEquityPct: 30, intlEquityPct: 15, goldPct: 7.5, bondsPct: 40, cashPct: 7.5 };
      return sum + (acc.balance * (alloc.intlEquityPct || 0) / 100);
    }, 0);

    const totalCash = modeledAccounts.reduce((sum, acc) => {
      const alloc = acc.allocation || { usEquityPct: 30, intlEquityPct: 15, goldPct: 7.5, bondsPct: 40, cashPct: 7.5 };
      return sum + (acc.balance * (alloc.cashPct || 0) / 100);
    }, 0);

    const usEquityPct = (totalUsEquity / totalBalance) * 100;
    const intlEquityPct = (totalIntlEquity / totalBalance) * 100;
    const totalEquityPct = usEquityPct + intlEquityPct;
    const cashPct = (totalCash / totalBalance) * 100;

    // --- 2. Portfolio Cash Drag Check ---
    if (cashPct > 15 && totalBalance > 50000) {
      results.push({
        id: 'val-step3-cash-drag',
        step: 3,
        stepName: 'Investments & Allocations',
        title: `Excess Portfolio Cash Drag (${cashPct.toFixed(1)}% Cash)`,
        category: 'Accounts',
        status: 'warning',
        description: `High cash allocation (${cashPct.toFixed(1)}% / $${Math.round(totalCash).toLocaleString()}) reduces real purchasing power over long investment horizons due to inflation drag.`,
        recommendation: 'Consider deploying idle cash above emergency reserves into bonds, equities, or gold commodities.',
        targetTab: 'investments',
      });
    } else {
      results.push({
        id: 'val-step3-cash-drag-ok',
        step: 1,
        stepName: 'Investments & Savings',
        title: `Portfolio Cash Drag Controlled (${cashPct.toFixed(1)}% Cash)`,
        category: 'Accounts',
        status: 'pass',
        description: `Cash balance ($${Math.round(totalCash).toLocaleString()}) maintains adequate liquid reserves without creating excess long-term inflation drag.`,
        targetTab: 'investments',
      });
    }

    // --- 3. International Diversification Check ---
    if (totalEquityPct > 30 && intlEquityPct === 0) {
      results.push({
        id: 'val-step3-intl-diversification',
        step: 3,
        stepName: 'Investments & Allocations',
        title: 'Zero International Equity Exposure (Home Country Bias)',
        category: 'Accounts',
        status: 'warning',
        description: `Portfolio equity holds 0% international equities despite total equity exposure of ${totalEquityPct.toFixed(1)}%.`,
        recommendation: 'Allocating 15-30% of equities to global/international markets reduces single-country geopolitical risk.',
        targetTab: 'investments',
      });
    } else if (totalEquityPct > 0) {
      results.push({
        id: 'val-step3-intl-diversification-ok',
        step: 1,
        stepName: 'Investments & Savings',
        title: `Global Equity Diversification Active (${intlEquityPct.toFixed(1)}% Intl)`,
        category: 'Accounts',
        status: 'pass',
        description: `International equity representation (${intlEquityPct.toFixed(1)}% of total portfolio) provides global market diversification.`,
        targetTab: 'investments',
      });
    }

    // --- 4. Equity Concentration Horizon Check ---
    const primaryAge = plan.primaryPerson.currentAge;
    const retirementAge = plan.primaryPerson.retirementAge;
    const yearsToRetirement = retirementAge - primaryAge;

    if (yearsToRetirement <= 5 && totalEquityPct > 80) {
      results.push({
        id: 'val-step3-equity-horizon',
        step: 3,
        stepName: 'Investments & Allocations',
        title: `High Equity Exposure Near Retirement (${totalEquityPct.toFixed(1)}% Equity)`,
        category: 'Accounts',
        status: 'warning',
        description: `Primary age (${primaryAge}) is within ${yearsToRetirement} years of retirement, but portfolio holds ${totalEquityPct.toFixed(1)}% equities, elevating sequence-of-returns risk.`,
        recommendation: 'Evaluate shifting a portion of equities into short-to-intermediate bonds or cash buffers before retirement.',
        targetTab: 'investments',
      });
    } else {
      results.push({
        id: 'val-step3-equity-horizon-ok',
        step: 1,
        stepName: 'Investments & Savings',
        title: `Equity Exposure Horizon Aligned (${totalEquityPct.toFixed(1)}% Equity)`,
        category: 'Accounts',
        status: 'pass',
        description: `Equity allocation (${totalEquityPct.toFixed(1)}%) aligns with time horizon (${yearsToRetirement} years until target retirement age).`,
        targetTab: 'investments',
      });
    }
  }

  // --- 5. Expense Ratio Drag Check ---
  const feeDrag = plan.cmaAssumptions?.annualPortfolioFeeDrag ?? 0.10;
  if (feeDrag > 0.50) {
    results.push({
      id: 'val-step3-fee-drag',
      step: 1,
      stepName: 'Investments & Savings',
      title: `High Annual Portfolio Fee Friction (${(feeDrag * 100).toFixed(0)} bps)`,
      category: 'Accounts',
      status: 'warning',
      description: `Annual portfolio fee drag is set to ${(feeDrag * 100).toFixed(0)} bps (${feeDrag.toFixed(2)}%), which compounds significantly over 20-30 year horizons.`,
      recommendation: 'Utilize low-cost index ETFs or institutional mutual funds to keep fee friction under 20-30 bps.',
      targetTab: 'investments',
    });
  } else {
    results.push({
      id: 'val-step3-fee-drag-ok',
      step: 1,
      stepName: 'Investments & Savings',
      title: `Low-Cost Index Fee Benchmark (${(feeDrag * 100).toFixed(0)} bps)`,
      category: 'Accounts',
      status: 'pass',
      description: `Annual expense friction of ${(feeDrag * 100).toFixed(0)} bps preserves compounding growth potential.`,
      targetTab: 'investments',
    });
  }

  return results;
}

export function runStep4Validations(plan: Plan): ValidationResult[] {
  const results: ValidationResult[] = [];
  const accounts = plan.accounts || [];
  const spending = plan.spendingAssumptions || DEFAULT_PLAN.spendingAssumptions!;
  const primary = plan.primaryPerson;
  const statutory = plan.statutoryParams || DEFAULT_PLAN.statutoryParams!;

  // --- 1. Pre-Tax RMD Tax Spike Warning ---
  const preTaxBalance = accounts
    .filter(a => a.type === 'pre-tax')
    .reduce((sum, a) => sum + (a.balance || 0), 0);

  const gapYears = Math.max(0, statutory.rmdStartAge - primary.retirementAge);
  const activeStrategy = resolveRetirementStrategy(plan);
  const sim = getSimulation(plan);
  const totalConversionsProjected = sim.rows.reduce((sum, r) => sum + r.rothConversion, 0);
  const hasActiveConversions = totalConversionsProjected > 0;
  const policyLabel = getRothConversionPolicyLabel(activeStrategy.rothConversion);

  if (preTaxBalance > 750000 && gapYears >= 3 && !hasActiveConversions) {
    results.push({
      id: 'val-step4-rmd-spike',
      step: 4,
      stepName: 'Cash Flow & Spending',
      title: 'High Pre-Tax Balance Subject to Unmitigated RMD Tax Spikes',
      category: 'Tax & Compliance',
      status: 'warning',
      description: `Pre-tax account balances (${Math.round(preTaxBalance).toLocaleString()}) will force large taxable RMDs starting at age ${statutory.rmdStartAge}. Zero Roth conversions planned during the ${gapYears}-year retirement gap.`,
      recommendation: `Consider utilizing low tax brackets (12% / 22%) between age ${primary.retirementAge} and ${statutory.rmdStartAge} for systematic Roth conversions.`,
      targetTab: 'strategy',
    });
  } else if (preTaxBalance > 0 && hasActiveConversions) {
    results.push({
      id: 'val-step4-rmd-spike-ok',
      step: 4,
      stepName: 'Cash Flow & Spending',
      title: 'Roth Conversion Strategy Mitigates RMD Tax Spikes',
      category: 'Tax & Compliance',
      status: 'pass',
      description: `Active Roth conversion strategy (${policyLabel}) projects ${Math.round(totalConversionsProjected).toLocaleString()} in total conversions to reduce pre-tax balances before mandatory RMDs at age ${statutory.rmdStartAge}.`,
      targetTab: 'income-tax',
    });
  }

  // --- 2. Social Security Early Claiming Reduction ---
  const fra = statutory.fullRetirementAge || 67;
  if (primary.ssClaimAge < fra) {
    const monthsEarly = (fra - primary.ssClaimAge) * 12;
    const reductionPct = Math.round(SOCIAL_SECURITY_REGISTRY.earlyClaimReduction(monthsEarly) * 100);
    results.push({
      id: 'val-step4-ss-early-claim',
      step: 4,
      stepName: 'Cash Flow & Spending',
      title: `Social Security Early Claiming Reduction (${primary.ssClaimAge} vs FRA ${fra})`,
      category: 'Contributions',
      status: 'warning',
      description: `Claiming Social Security at age ${primary.ssClaimAge} permanently reduces monthly benefit payments by ~${reductionPct}%.`,
      recommendation: 'Delaying Social Security claims up to age 70 yields an 8% per year delayed retirement credit growth.',
      targetTab: 'income-tax',
    });
  } else {
    results.push({
      id: 'val-step4-ss-early-claim-ok',
      step: 4,
      stepName: 'Cash Flow & Spending',
      title: `Social Security Claim Age Optimized (${primary.ssClaimAge} >= FRA ${fra})`,
      category: 'Contributions',
      status: 'pass',
      description: `Claiming at or beyond Full Retirement Age (${primary.ssClaimAge}) preserves 100%+ of primary insurance amount (PIA).`,
      targetTab: 'income-tax',
    });
  }

  // --- 3. IRMAA Surcharge Cliff Warning ---
  const hasSpouse = Boolean(plan.spousePerson);

  const medicareRows = sim.rows.filter(
    (r) => r.age >= 65 || (hasSpouse && (r.spouseAge ?? 0) >= 65)
  );

  const surchargeRow = medicareRows.find(
    (r) => r.irmaaSurcharge > 0 || (r.irmaaBracket && r.irmaaBracket !== 'Tier 0')
  );
  const proximityRow = medicareRows.find(
    (r) => r.irmaaHeadroom > 0 && r.irmaaHeadroom <= 10000
  );
  const triggeringRow = surchargeRow || proximityRow;

  if (triggeringRow) {
    const isSurcharged = triggeringRow.irmaaSurcharge > 0 || (triggeringRow.irmaaBracket && triggeringRow.irmaaBracket !== 'Tier 0');
    const lookbackYr = triggeringRow.irmaaLookbackYear ?? (triggeringRow.calendarYear - 2);
    const lookbackMagi = Math.round(triggeringRow.irmaaLookbackMagi ?? triggeringRow.taxableMagi);

    const description = isSurcharged
      ? `Projected Medicare year ${triggeringRow.calendarYear} (age ${triggeringRow.age}) incurs an IRMAA surcharge of $${triggeringRow.irmaaSurcharge.toLocaleString()}/yr (${triggeringRow.irmaaBracket}) based on 2-year lookback Tax Year ${lookbackYr} MAGI ($${lookbackMagi.toLocaleString()}).`
      : `Projected Tax Year ${lookbackYr} lookback MAGI ($${lookbackMagi.toLocaleString()}) is within $${Math.round(triggeringRow.irmaaHeadroom).toLocaleString()} of the next IRMAA surcharge cliff for Medicare Year ${triggeringRow.calendarYear} (age ${triggeringRow.age}).`;

    results.push({
      id: 'val-step4-irmaa-cliff',
      step: 4,
      stepName: 'Cash Flow & Spending',
      title: isSurcharged ? 'Medicare IRMAA Surcharge Incurred' : 'Proximity to Medicare IRMAA Surcharge Cliff',
      category: 'Tax & Compliance',
      status: 'warning',
      description,
      recommendation: 'Fine-tune Roth conversion policy or withdrawal timing in Strategy & Levers to manage 2-year lookback MAGI below IRMAA thresholds.',
      targetTab: 'strategy',
    });
  } else {
    results.push({
      id: 'val-step4-irmaa-cliff-ok',
      step: 4,
      stepName: 'Cash Flow & Spending',
      title: 'Medicare IRMAA Premium Tier Maintained',
      category: 'Tax & Compliance',
      status: 'pass',
      description: `Projected MAGI remains clear of unexpected Medicare Part B/D IRMAA cliff jumps throughout Medicare eligibility.`,
      targetTab: 'income-tax',
    });
  }

  return results;
}

export function runPlanValidations(plan: Plan): ValidationResult[] {
  return [
    ...runStep1Validations(plan),
    ...runStep2Validations(plan),
    ...runStep3Validations(plan),
    ...runStep4Validations(plan),
  ];
}
