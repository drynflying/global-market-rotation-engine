/**
 * ACA premium tax credit calculation.
 *
 * PHASE 1 OF 2: pure functions only. Nothing here is called by the simulation engine
 * yet — this exists so the tables in acaConstants.ts can be reviewed against worked
 * examples before the projection depends on them.
 *
 * FORMULA (26 U.S.C. 36B):
 *   expected contribution = household MAGI x applicable percentage
 *   premium tax credit    = benchmark premium - expected contribution, floored at 0
 *   net premium           = benchmark premium - credit
 *
 * The credit cannot exceed the benchmark premium, and under the standard (2026) regime
 * it is ZERO above 400% FPL — a cliff, not a taper.
 */
import {
  SubsidyRegime,
  federalPovertyLevel,
  fplIndexFactor,
  applicablePercentage,
  householdBenchmarkAnnual,
  hasSubsidyCliff,
  subsidyCliffIncome,
} from './acaConstants';

export interface AcaPremiumInput {
  /** Household MAGI for the coverage year. */
  magi: number;
  /** Ages of everyone on the marketplace policy (exclude anyone on Medicare). */
  coveredAges: readonly number[];
  householdSize: number;
  baseMonthlyPremiumAge21: number;
  regime?: SubsidyRegime;
  /** Years of premium trend to apply from the base year. */
  yearsOfTrend?: number;
  premiumTrendPct?: number;
  /**
   * General inflation used to index the FPL thresholds forward. HHS updates the
   * guidelines against CPI-U, NOT medical CPI — so the cliff rises more slowly than
   * premiums do, and a household drifts over it in real terms.
   */
  fplInflationPct?: number;
}

export interface AcaPremiumResult {
  benchmarkAnnual: number;
  expectedContribution: number;
  premiumTaxCredit: number;
  netAnnualPremium: number;
  fplPercent: number;
  applicablePct: number | null;
  /** True when income exceeds 400% FPL under a regime that has a cliff. */
  overCliff: boolean;
  /** MAGI headroom before the cliff. Zero when already over, or no cliff applies. */
  cliffHeadroom: number;
}

export function calculateAcaPremium(input: AcaPremiumInput): AcaPremiumResult {
  const {
    magi,
    coveredAges,
    householdSize,
    baseMonthlyPremiumAge21,
    regime = 'standard',
    yearsOfTrend = 0,
    premiumTrendPct = 0,
    fplInflationPct = 0,
  } = input;

  const trend = Math.pow(1 + premiumTrendPct / 100, yearsOfTrend);
  const benchmarkAnnual = Math.round(
    householdBenchmarkAnnual(baseMonthlyPremiumAge21, coveredAges) * trend,
  );

  const fplIndex = fplIndexFactor(fplInflationPct, yearsOfTrend);
  const fpl = federalPovertyLevel(householdSize, fplIndex);
  const fplPercent = fpl > 0 ? (magi / fpl) * 100 : 0;
  const pct = applicablePercentage(fplPercent, regime);

  const cliffIncome = subsidyCliffIncome(householdSize, fplIndex);
  const overCliff = hasSubsidyCliff(regime) && magi > cliffIncome;

  if (pct === null || coveredAges.length === 0) {
    return {
      benchmarkAnnual,
      expectedContribution: benchmarkAnnual,
      premiumTaxCredit: 0,
      netAnnualPremium: benchmarkAnnual,
      fplPercent,
      applicablePct: pct,
      overCliff,
      cliffHeadroom: 0,
    };
  }

  const expectedContribution = Math.round(magi * (pct / 100));
  const premiumTaxCredit = Math.max(0, benchmarkAnnual - expectedContribution);
  const netAnnualPremium = benchmarkAnnual - premiumTaxCredit;

  return {
    benchmarkAnnual,
    expectedContribution,
    premiumTaxCredit,
    netAnnualPremium,
    fplPercent,
    applicablePct: pct,
    overCliff,
    cliffHeadroom: hasSubsidyCliff(regime) ? Math.max(0, Math.round(cliffIncome - magi)) : 0,
  };
}

/**
 * Cost of crossing the cliff: what one extra dollar of MAGI costs when it takes the
 * household from just under 400% FPL to just over. This is the number that should
 * discipline Roth conversion sizing before 65.
 */
export function cliffCost(
  input: Omit<AcaPremiumInput, 'magi' | 'regime'>,
): { justUnder: AcaPremiumResult; justOver: AcaPremiumResult; annualCost: number } {
  // Exactly 400% FPL still qualifies; one dollar more does not.
  const cliff = subsidyCliffIncome(
    input.householdSize,
    fplIndexFactor(input.fplInflationPct ?? 0, input.yearsOfTrend ?? 0),
  );
  const justUnder = calculateAcaPremium({ ...input, magi: cliff, regime: 'standard' });
  const justOver = calculateAcaPremium({ ...input, magi: cliff + 1, regime: 'standard' });
  return {
    justUnder,
    justOver,
    annualCost: justOver.netAnnualPremium - justUnder.netAnnualPremium,
  };
}
