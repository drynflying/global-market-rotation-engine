/**
 * ACA marketplace premium and subsidy parameters.
 *
 * PHASE 1 OF 2: this module defines and exposes the tables. NOTHING here is wired into
 * the simulation engine yet — that is deliberate. These figures drive the entire pre-65
 * healthcare cost for an early retiree, so they are reviewed on screen before anything
 * depends on them.
 *
 * LEGISLATIVE STATUS — READ BEFORE TRUSTING OUTPUT.
 * The ARPA/IRA "enhanced" premium tax credits expired 31 December 2025. For 2026 plan
 * years the rules reverted to the original ACA structure: subsidies only between 100%
 * and 400% of the federal poverty level, a HARD CLIFF above 400%, and higher required
 * contributions at every band. A bill restoring the enhancements passed the House in
 * January 2026 but has NOT become law as of this writing. ENHANCED_SUBSIDY_SCHEDULE is
 * provided so both worlds can be modelled.
 *
 * Every table below is a default. All of it is meant to be adjusted by the user — the
 * point of the model is to pull levers, and a locked table is not a lever.
 */

export const ACA_BASE_YEAR = 2026;

// ---------------------------------------------------------------------------
// 1. AGE RATING CURVE
// ---------------------------------------------------------------------------

/**
 * Federal standard age curve (45 CFR 147.102). Premiums are age-rated at up to 3:1
 * between age 64 and age 21, and a single band covers 64 and older.
 *
 * VERIFIED ANCHORS: 21 = 1.000, 40 = 1.278, 50 = 1.786, 55 = 2.230, 59 = 2.603,
 * 64 = 3.000. Ages between anchors are LINEARLY INTERPOLATED and marked below —
 * the true CMS curve rises at an increasing rate, so interpolated mid-band factors
 * are approximate. Replace with published one-year factors when available.
 *
 * Five jurisdictions differ: MA and NJ use narrower 2:1 curves; NY, VT and DC use
 * community rating with no age variation at all.
 */
export interface AgeRatingRow {
  age: number;
  factor: number;
  /** False when the value is interpolated rather than taken from a published anchor. */
  verified: boolean;
}

export const AGE_RATING_CURVE: readonly AgeRatingRow[] = [
  { age: 50, factor: 1.786, verified: true },
  { age: 51, factor: 1.865, verified: false },
  { age: 52, factor: 1.952, verified: false },
  { age: 53, factor: 2.040, verified: false },
  { age: 54, factor: 2.135, verified: false },
  { age: 55, factor: 2.230, verified: true },
  { age: 56, factor: 2.323, verified: false },
  { age: 57, factor: 2.417, verified: false },
  { age: 58, factor: 2.511, verified: false },
  { age: 59, factor: 2.603, verified: true },
  { age: 60, factor: 2.682, verified: false },
  { age: 61, factor: 2.762, verified: false },
  { age: 62, factor: 2.841, verified: false },
  { age: 63, factor: 2.921, verified: false },
  { age: 64, factor: 3.000, verified: true },
] as const;

export function ageRatingFactor(age: number): number {
  if (age <= AGE_RATING_CURVE[0].age) return AGE_RATING_CURVE[0].factor;
  const capped = AGE_RATING_CURVE[AGE_RATING_CURVE.length - 1];
  if (age >= capped.age) return capped.factor; // 64 and older share one band
  return AGE_RATING_CURVE.find((r) => r.age === age)?.factor ?? capped.factor;
}

// ---------------------------------------------------------------------------
// 2. FEDERAL POVERTY LEVEL
// ---------------------------------------------------------------------------

/**
 * 2025 HHS poverty guidelines — these govern 2026 plan-year coverage (the prior year's
 * guidelines always apply). 48 contiguous states and DC. Alaska and Hawaii are higher.
 */
export const FPL_BASE_YEAR = 2025;
export const FPL_FIRST_PERSON = 15650;
export const FPL_EACH_ADDITIONAL = 5500;

export function federalPovertyLevel(householdSize: number, indexFactor: number = 1): number {
  const size = Math.max(1, Math.round(householdSize));
  return (FPL_FIRST_PERSON + (size - 1) * FPL_EACH_ADDITIONAL) * indexFactor;
}

/** Compound the FPL index factor forward at general inflation. */
export function fplIndexFactor(generalInflationPct: number, years: number): number {
  return Math.pow(1 + generalInflationPct / 100, Math.max(0, years));
}

/** Income at which the subsidy cliff bites, when the cliff is in force. */
export function subsidyCliffIncome(householdSize: number, indexFactor: number = 1): number {
  return federalPovertyLevel(householdSize, indexFactor) * 4;
}

// ---------------------------------------------------------------------------
// 3. APPLICABLE PERCENTAGE SCHEDULE
// ---------------------------------------------------------------------------

/**
 * Share of household income the enrollee is expected to contribute toward the benchmark
 * silver plan, by income as a percentage of FPL. Within a band the percentage slides
 * linearly from `startPct` to `endPct`.
 */
export interface ApplicablePercentageBand {
  /** Lower bound, inclusive, as a percentage of FPL. */
  fplFrom: number;
  /** Upper bound, exclusive, as a percentage of FPL. */
  fplTo: number;
  startPct: number;
  endPct: number;
}

/** Rev. Proc. 2025-25 — the reverted schedule in force for 2026 plan years. */
export const STANDARD_SUBSIDY_SCHEDULE: readonly ApplicablePercentageBand[] = [
  { fplFrom: 100, fplTo: 133, startPct: 2.10, endPct: 2.10 },
  { fplFrom: 133, fplTo: 150, startPct: 3.14, endPct: 4.19 },
  { fplFrom: 150, fplTo: 200, startPct: 4.19, endPct: 6.60 },
  { fplFrom: 200, fplTo: 250, startPct: 6.60, endPct: 8.44 },
  { fplFrom: 250, fplTo: 300, startPct: 8.44, endPct: 9.96 },
  { fplFrom: 300, fplTo: 400, startPct: 9.96, endPct: 9.96 },
] as const;

/**
 * ARPA/IRA enhanced schedule (2021-2025). No upper income limit — the contribution is
 * capped at 8.5% however high income goes, so there is no cliff. Retained so the
 * pending restoration bill can be modelled.
 */
export const ENHANCED_SUBSIDY_SCHEDULE: readonly ApplicablePercentageBand[] = [
  { fplFrom: 100, fplTo: 150, startPct: 0, endPct: 0 },
  { fplFrom: 150, fplTo: 200, startPct: 0, endPct: 2.0 },
  { fplFrom: 200, fplTo: 250, startPct: 2.0, endPct: 4.0 },
  { fplFrom: 250, fplTo: 300, startPct: 4.0, endPct: 6.0 },
  { fplFrom: 300, fplTo: 400, startPct: 6.0, endPct: 8.5 },
  { fplFrom: 400, fplTo: Infinity, startPct: 8.5, endPct: 8.5 },
] as const;

export type SubsidyRegime = 'standard' | 'enhanced';

export function subsidySchedule(regime: SubsidyRegime): readonly ApplicablePercentageBand[] {
  return regime === 'enhanced' ? ENHANCED_SUBSIDY_SCHEDULE : STANDARD_SUBSIDY_SCHEDULE;
}

/** True when income above 400% FPL receives no credit at all. */
export function hasSubsidyCliff(regime: SubsidyRegime): boolean {
  return regime === 'standard';
}

/**
 * Applicable percentage for a given income, interpolated within its band.
 * Returns null when no credit is available (below 100% FPL, or above the cliff).
 */
export function applicablePercentage(
  fplPercent: number,
  regime: SubsidyRegime = 'standard',
): number | null {
  if (fplPercent < 100) return null;
  const bands = subsidySchedule(regime);
  // The top band's upper bound is INCLUSIVE: at exactly 400.00% of FPL a household
  // still receives a credit; the cliff bites at 400.01%. An exclusive bound here
  // silently zeroed the subsidy for anyone landing precisely on the line.
  const last = bands[bands.length - 1];
  const band = bands.find(
    (b) =>
      fplPercent >= b.fplFrom &&
      (fplPercent < b.fplTo || (b === last && fplPercent <= b.fplTo)),
  );
  if (!band) {
    // Above the top band: cliff under the standard schedule, capped under enhanced.
    return hasSubsidyCliff(regime) ? null : bands[bands.length - 1].endPct;
  }
  if (band.fplTo === Infinity) return band.endPct;
  const span = band.fplTo - band.fplFrom;
  const progress = span > 0 ? (fplPercent - band.fplFrom) / span : 0;
  return band.startPct + progress * (band.endPct - band.startPct);
}

// ---------------------------------------------------------------------------
// 4. DEFAULT PREMIUM ANCHOR
// ---------------------------------------------------------------------------

/**
 * Monthly benchmark (second-lowest-cost silver) premium for a 21-year-old. Everything
 * scales off this via the age curve, so it is the ONE number worth calibrating from a
 * real quote — see calibrateBasePremium below.
 *
 * This default is a rough national placeholder and WILL be wrong for any specific
 * rating area. Replace it with your own figure before drawing conclusions.
 */
export const DEFAULT_BASE_MONTHLY_PREMIUM_AGE_21 = 400;

/** Annual premium trend, applied on top of general inflation. */
export const DEFAULT_PREMIUM_TREND_PCT = 5.0;

/**
 * Back-solve the age-21 base premium from a real quote.
 * Enter what you were actually quoted at your actual age and the curve does the rest.
 */
export function calibrateBasePremium(quotedMonthlyPremium: number, atAge: number): number {
  const factor = ageRatingFactor(atAge);
  return factor > 0 ? quotedMonthlyPremium / factor : quotedMonthlyPremium;
}

/** Annual benchmark premium for a household, before any subsidy. */
export function householdBenchmarkAnnual(
  baseMonthlyAge21: number,
  ages: readonly number[],
): number {
  const monthly = ages.reduce((sum, age) => sum + baseMonthlyAge21 * ageRatingFactor(age), 0);
  return Math.round(monthly * 12);
}
