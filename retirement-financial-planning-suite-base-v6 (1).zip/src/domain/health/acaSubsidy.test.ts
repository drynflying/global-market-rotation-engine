import { describe, it, expect } from 'vitest';
import { calculateAcaPremium, cliffCost } from './acaSubsidy';
import {
  AGE_RATING_CURVE,
  ageRatingFactor,
  federalPovertyLevel,
  subsidyCliffIncome,
  applicablePercentage,
  householdBenchmarkAnnual,
  calibrateBasePremium,
  STANDARD_SUBSIDY_SCHEDULE,
  ENHANCED_SUBSIDY_SCHEDULE,
} from './acaConstants';

const couple = { coveredAges: [57, 58], householdSize: 2, baseMonthlyPremiumAge21: 400 };

describe('age rating curve', () => {
  it('matches the published anchors', () => {
    expect(ageRatingFactor(50)).toBe(1.786);
    expect(ageRatingFactor(55)).toBe(2.230);
    expect(ageRatingFactor(59)).toBe(2.603);
    expect(ageRatingFactor(64)).toBe(3.000);
  });

  it('rises monotonically with age', () => {
    for (let i = 1; i < AGE_RATING_CURVE.length; i++) {
      expect(AGE_RATING_CURVE[i].factor).toBeGreaterThan(AGE_RATING_CURVE[i - 1].factor);
    }
  });

  it('caps at 3.0 for 64 and older, per the single top age band', () => {
    expect(ageRatingFactor(64)).toBe(3.0);
    expect(ageRatingFactor(70)).toBe(3.0);
  });

  it('flags interpolated rows as unverified', () => {
    const verified = AGE_RATING_CURVE.filter(r => r.verified).map(r => r.age);
    expect(verified).toEqual([50, 55, 59, 64]);
  });

  it('back-solves a base premium from a real quote', () => {
    const base = calibrateBasePremium(1000, 58);
    expect(Math.round(base * ageRatingFactor(58))).toBe(1000);
  });
});

describe('federal poverty level', () => {
  it('uses the 2025 guidelines that govern 2026 coverage', () => {
    expect(federalPovertyLevel(1)).toBe(15650);
    expect(federalPovertyLevel(2)).toBe(21150);
    expect(federalPovertyLevel(4)).toBe(32150);
  });

  it('puts the cliff for a couple at $84,600', () => {
    expect(subsidyCliffIncome(2)).toBe(84600);
  });
});

describe('applicable percentage schedule', () => {
  it('interpolates within a band', () => {
    // 250-300% slides 8.44 -> 9.96; the midpoint is halfway.
    expect(applicablePercentage(275)).toBeCloseTo((8.44 + 9.96) / 2, 2);
  });

  it('is flat at 9.96% across 300-400% FPL', () => {
    expect(applicablePercentage(300)).toBeCloseTo(9.96, 2);
    expect(applicablePercentage(399)).toBeCloseTo(9.96, 2);
  });

  it('includes exactly 400% but excludes anything above', () => {
    // The cliff bites at 400.01%, not at 400.00%.
    expect(applicablePercentage(400)).toBeCloseTo(9.96, 2);
    expect(applicablePercentage(400.01)).toBeNull();
  });

  it('gives no credit below 100% FPL', () => {
    expect(applicablePercentage(99)).toBeNull();
  });

  it('has no cliff under the enhanced regime', () => {
    expect(applicablePercentage(700, 'enhanced')).toBeCloseTo(8.5, 2);
    expect(applicablePercentage(700, 'standard')).toBeNull();
  });

  it('keeps both schedules contiguous', () => {
    for (const schedule of [STANDARD_SUBSIDY_SCHEDULE, ENHANCED_SUBSIDY_SCHEDULE]) {
      for (let i = 1; i < schedule.length; i++) {
        expect(schedule[i].fplFrom).toBe(schedule[i - 1].fplTo);
      }
    }
  });
});

describe('premium and subsidy', () => {
  it('scales the household benchmark by each person age', () => {
    const expected = Math.round((400 * 2.417 + 400 * 2.511) * 12);
    expect(householdBenchmarkAnnual(400, [57, 58])).toBe(expected);
  });

  it('produces a real subsidy below the cliff', () => {
    const r = calculateAcaPremium({ ...couple, magi: 60000 });
    expect(r.premiumTaxCredit).toBeGreaterThan(0);
    expect(r.netAnnualPremium).toBeLessThan(r.benchmarkAnnual);
    expect(r.overCliff).toBe(false);
  });

  it('drops the credit to zero one dollar over the cliff', () => {
    const under = calculateAcaPremium({ ...couple, magi: 84600 });
    const over = calculateAcaPremium({ ...couple, magi: 84601 });
    expect(under.premiumTaxCredit).toBeGreaterThan(0);
    expect(over.premiumTaxCredit).toBe(0);
    expect(over.netAnnualPremium).toBe(over.benchmarkAnnual);
  });

  it('quantifies the cliff — the number that should size a Roth conversion', () => {
    const c = cliffCost(couple);
    expect(c.annualCost).toBeGreaterThan(10000);
    expect(c.justUnder.premiumTaxCredit).toBeGreaterThan(0);
    expect(c.justOver.premiumTaxCredit).toBe(0);
  });

  it('reports headroom to the cliff', () => {
    const r = calculateAcaPremium({ ...couple, magi: 80000 });
    expect(r.cliffHeadroom).toBe(4600);
    expect(calculateAcaPremium({ ...couple, magi: 90000 }).cliffHeadroom).toBe(0);
  });

  it('caps the contribution at 8.5% under the enhanced regime', () => {
    const r = calculateAcaPremium({ ...couple, magi: 150000, regime: 'enhanced' });
    expect(r.premiumTaxCredit).toBeGreaterThan(0);
    expect(r.expectedContribution).toBe(Math.round(150000 * 0.085));
  });

  it('never returns a credit larger than the benchmark premium', () => {
    for (const magi of [20000, 40000, 60000, 84600, 200000]) {
      const r = calculateAcaPremium({ ...couple, magi });
      expect(r.premiumTaxCredit).toBeLessThanOrEqual(r.benchmarkAnnual);
      expect(r.netAnnualPremium).toBeGreaterThanOrEqual(0);
    }
  });

  it('applies premium trend over time', () => {
    const now = calculateAcaPremium({ ...couple, magi: 60000 });
    const later = calculateAcaPremium({ ...couple, magi: 60000, yearsOfTrend: 5, premiumTrendPct: 5 });
    expect(later.benchmarkAnnual).toBeGreaterThan(now.benchmarkAnnual);
  });
});

describe('wired to the engine', () => {
  it('is imported by the simulation engine', async () => {
    const { readFileSync } = await import('fs');
    const src = readFileSync('src/domain/simulation/simulationEngine.ts', 'utf8');
    expect(src).toMatch(/calculateAcaPremium/);
  });
});

describe('ACA assumptions live on the plan', () => {
  it('is seeded on the default plan', async () => {
    const { createDefaultPlan } = await import('../../constants/defaultPlan');
    const aca = createDefaultPlan().acaAssumptions!;
    expect(aca.baseMonthlyPremiumAge21).toBe(400);
    expect(aca.subsidyRegime).toBe('standard');
    expect(aca.useSubsidyModel).toBe(true);
  });

  it('persists through a schema round-trip', async () => {
    const { PlanSchema } = await import('../../schemas/planSchema');
    const { createDefaultPlan } = await import('../../constants/defaultPlan');
    const plan = createDefaultPlan();
    plan.acaAssumptions!.baseMonthlyPremiumAge21 = 512;
    plan.acaAssumptions!.subsidyRegime = 'enhanced';
    const parsed = PlanSchema.safeParse(JSON.parse(JSON.stringify(plan)));
    expect(parsed.success).toBe(true);
    if (parsed.success) {
      expect(parsed.data.acaAssumptions!.baseMonthlyPremiumAge21).toBe(512);
      expect(parsed.data.acaAssumptions!.subsidyRegime).toBe('enhanced');
    }
  });

  it('has a citation row flagged for annual review', async () => {
    const { createDefaultPlan } = await import('../../constants/defaultPlan');
    const row = (createDefaultPlan().assumptions || []).find(r => r.id === 'asm-aca-subsidy');
    expect(row).toBeDefined();
    expect(row!.notes).toMatch(/RE-CHECK BEFORE EACH PLANNING CYCLE/i);
    expect(row!.notes).toMatch(/interpolated/i);
  });

  it('renders inside the Assumptions tab, not a standalone screen', async () => {
    const { readFileSync, existsSync } = await import('fs');
    expect(existsSync('src/components/AcaTableReview.tsx')).toBe(false);
    const src = readFileSync('src/components/AssumptionsStatutoryStep.tsx', 'utf8');
    expect(src).toMatch(/<AcaAssumptionsSection/);
  });
});

describe('the cliff does not destabilise the withdrawal solver', () => {
  it('converges at every spending level either side of the cliff', async () => {
    // The premium depends on MAGI, MAGI depends on withdrawals, withdrawals depend on
    // the cash need that includes the premium. Crossing the 400% FPL cliff raises the
    // premium discontinuously, so the loop could oscillate: draw more, cross the cliff,
    // need more, draw more. ACA_PREMIUM_FREEZE_AFTER is what prevents that; this sweep
    // is what proves it.
    const { runSimulation } = await import('../simulation/simulationEngine');
    const { createDefaultPlan } = await import('../../constants/defaultPlan');

    const failures: string[] = [];
    for (let spend = 40000; spend <= 160000; spend += 5000) {
      const p = createDefaultPlan();
      p.spendingAssumptions!.desiredAnnualLivingExpenses = spend;
      p.acaAssumptions!.baseMonthlyPremiumAge21 = 472;
      for (const r of runSimulation(p).rows) {
        if (!r.isRetired || r.age >= 65 || r.unfundedShortfall !== 0) continue;
        if (Math.abs(r.totalCashInflow - (r.totalCashOutflow + r.surplusReinvested)) > 1) {
          failures.push(`spend ${spend} age ${r.age}`);
        }
      }
    }
    expect(failures).toEqual([]);
  });

  it('charges more when MAGI is higher, and the most above the cliff', () => {
    // Asserted on the pure function: a bigger spending target also changes withdrawal
    // SOURCING, so an end-to-end comparison can move MAGI opposite to spending.
    const args = { coveredAges: [61, 62], householdSize: 2, baseMonthlyPremiumAge21: 472 };
    const low = calculateAcaPremium({ ...args, magi: 50000 });
    const mid = calculateAcaPremium({ ...args, magi: 80000 });
    const over = calculateAcaPremium({ ...args, magi: 120000 });
    expect(mid.netAnnualPremium).toBeGreaterThan(low.netAnnualPremium);
    expect(over.netAnnualPremium).toBeGreaterThan(mid.netAnnualPremium);
    expect(over.overCliff).toBe(true);
  });

  it('indexes the cliff to general inflation, not medical', () => {
    // HHS updates the FPL guidelines against CPI-U. Premiums trend faster, so the
    // household drifts over the cliff in real terms — leaving the threshold frozen in
    // nominal dollars overstated how often a plan is above it in later years.
    const frozen = calculateAcaPremium({
      magi: 95000, coveredAges: [61], householdSize: 2, baseMonthlyPremiumAge21: 472,
    });
    const indexed = calculateAcaPremium({
      magi: 95000, coveredAges: [61], householdSize: 2, baseMonthlyPremiumAge21: 472,
      yearsOfTrend: 10, fplInflationPct: 2,
    });
    expect(frozen.overCliff).toBe(true);   // 95k > 84,600 today
    expect(indexed.overCliff).toBe(false); // but under the indexed 103,131 in 10 years
  });

  it('drops the marketplace premium entirely once both are on Medicare', async () => {
    const { runSimulation } = await import('../simulation/simulationEngine');
    const { createDefaultPlan } = await import('../../constants/defaultPlan');
    const rows = runSimulation(createDefaultPlan()).rows;
    const at64 = rows.find(r => r.age === 64)!;
    const at66 = rows.find(r => r.age === 66)!;
    // Medical inflation would push 66 higher; losing the premium is what drops it.
    expect(at66.healthExpense).toBeLessThan(at64.healthExpense);
  });

  it('honours the useSubsidyModel toggle', async () => {
    const { runSimulation } = await import('../simulation/simulationEngine');
    const { createDefaultPlan } = await import('../../constants/defaultPlan');
    const on = createDefaultPlan();
    const off = createDefaultPlan();
    off.acaAssumptions!.useSubsidyModel = false;
    const rowOn = runSimulation(on).rows.find(r => r.age === 61)!;
    const rowOff = runSimulation(off).rows.find(r => r.age === 61)!;
    expect(rowOn.healthExpense).not.toBe(rowOff.healthExpense);
  });
});

