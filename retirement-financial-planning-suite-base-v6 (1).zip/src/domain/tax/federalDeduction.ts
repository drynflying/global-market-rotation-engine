import {
  STANDARD_DEDUCTION_2026,
  ADDL_STD_DEDUCTION_65,
} from './taxConstants';

/**
 * Statutory effective years for the temporary Enhanced Senior Deduction (2025–2028).
 * Outside this window (e.g. 2024 or 2029+), the enhanced deduction is $0.
 */
export const ENHANCED_SENIOR_EFFECTIVE_START_YEAR = 2025;
export const ENHANCED_SENIOR_EFFECTIVE_END_YEAR = 2028;

/**
 * Statutory values for Enhanced Senior Deduction.
 * NOTE: These are temporary fixed nominal statutory values and are NOT indexed
 * by the general economic inflation/tax deflator, unlike ordinary standard deductions.
 */
export const ENHANCED_SENIOR_DEDUCTION_PER_PERSON = 6000;
export const ENHANCED_SENIOR_DEDUCTION = ENHANCED_SENIOR_DEDUCTION_PER_PERSON;
export const ENHANCED_SENIOR_PHASEOUT_RATE = 0.06;
export const ENHANCED_SENIOR_PHASEOUT_START = { joint: 150000, single: 75000 } as const;

export interface FederalDeductionBreakdown {
  standardDeduction: number;
  additionalAge65Deduction: number;
  enhancedSeniorDeduction: number;
  totalDeduction: number;
}

export interface ResolveFederalDeductionInput {
  taxYear: number;
  isJoint: boolean;
  primaryAge: number;
  spouseAge?: number;
  magi: number;
  deflator?: number;
  statutoryStandardDeductionJoint?: number;
  statutoryStandardDeductionSingle?: number;
  statutoryAddlStdDeduction65Joint?: number;
  statutoryAddlStdDeduction65Single?: number;
}

/**
 * Authoritative Federal Deduction Resolver
 *
 * Distinguishes and orchestrates:
 * 1. Basic Standard Deduction (indexed by deflator)
 * 2. Ordinary Age-65 Additional Standard Deduction (indexed by deflator)
 * 3. Temporary Enhanced Senior Deduction (2025–2028 only; fixed nominal $6k/person, 6% phaseout, NOT deflated)
 */
export function resolveFederalDeduction(input: ResolveFederalDeductionInput): FederalDeductionBreakdown {
  const deflator = input.deflator ?? 1.0;

  // 1. Basic Standard Deduction (indexed)
  const baseStdNominal = input.isJoint
    ? (input.statutoryStandardDeductionJoint ?? STANDARD_DEDUCTION_2026.joint)
    : (input.statutoryStandardDeductionSingle ?? STANDARD_DEDUCTION_2026.single);
  const rawStandardDeduction = baseStdNominal * deflator;

  // 2. Ordinary Age-65 Additional Standard Deduction (indexed)
  const addl65Nominal = input.isJoint
    ? (input.statutoryAddlStdDeduction65Joint ?? ADDL_STD_DEDUCTION_65.joint)
    : (input.statutoryAddlStdDeduction65Single ?? ADDL_STD_DEDUCTION_65.single);

  let rawAddl65 = 0;
  if (input.primaryAge >= 65) {
    rawAddl65 += addl65Nominal * deflator;
  }
  if (input.isJoint && input.spouseAge !== undefined && input.spouseAge >= 65) {
    rawAddl65 += addl65Nominal * deflator;
  }

  // 3. Temporary Enhanced Senior Deduction (2025–2028 only; fixed nominal statutory dollars)
  let rawEnhancedSenior = 0;
  const isWithinEnhancedWindow =
    input.taxYear >= ENHANCED_SENIOR_EFFECTIVE_START_YEAR &&
    input.taxYear <= ENHANCED_SENIOR_EFFECTIVE_END_YEAR;

  if (isWithinEnhancedWindow) {
    let eligibleCount = 0;
    if (input.primaryAge >= 65) eligibleCount += 1;
    if (input.isJoint && input.spouseAge !== undefined && input.spouseAge >= 65) eligibleCount += 1;

    if (eligibleCount > 0) {
      const eligibleBase = eligibleCount * ENHANCED_SENIOR_DEDUCTION_PER_PERSON;
      const phaseoutStart = input.isJoint
        ? ENHANCED_SENIOR_PHASEOUT_START.joint
        : ENHANCED_SENIOR_PHASEOUT_START.single;
      const excess = Math.max(0, input.magi - phaseoutStart);
      const reduction = ENHANCED_SENIOR_PHASEOUT_RATE * excess;
      rawEnhancedSenior = Math.max(0, eligibleBase - reduction);
    }
  }

  const standardDeduction = Math.round(rawStandardDeduction);
  const additionalAge65Deduction = Math.round(rawAddl65);
  const enhancedSeniorDeduction = Math.round(rawEnhancedSenior);
  const totalDeduction = standardDeduction + additionalAge65Deduction + enhancedSeniorDeduction;

  return {
    standardDeduction,
    additionalAge65Deduction,
    enhancedSeniorDeduction,
    totalDeduction,
  };
}

/**
 * Pure helper to calculate taxable ordinary income after subtracting authoritative federal deductions.
 */
export function calculateFederalTaxableOrdinaryIncome(
  ordinaryIncome: number,
  taxableSocialSecurity: number,
  deductionBreakdownOrAmount: FederalDeductionBreakdown | number
): number {
  const totalDeduction =
    typeof deductionBreakdownOrAmount === 'number'
      ? deductionBreakdownOrAmount
      : deductionBreakdownOrAmount.totalDeduction;
  return Math.max(0, Math.round(ordinaryIncome + taxableSocialSecurity - totalDeduction));
}

/**
 * Backward-compatible helper for enhanced senior deduction lookup.
 */
export function calculateEnhancedSeniorDeduction(
  primaryAge: number,
  spouseAge: number | undefined,
  isJoint: boolean,
  magi: number,
  deflator: number = 1.0,
  taxYear: number = 2026
): number {
  return resolveFederalDeduction({
    taxYear,
    isJoint,
    primaryAge,
    spouseAge,
    magi,
    deflator,
  }).enhancedSeniorDeduction;
}
