import { describe, it, expect } from 'vitest';
import {
  resolveFederalDeduction,
  calculateFederalTaxableOrdinaryIncome,
} from './federalDeduction';
import { STANDARD_DEDUCTION_2026, ADDL_STD_DEDUCTION_65 } from './taxConstants';
import { determineRothConversionTarget, RothConversionContext } from '../strategy/rothConversionPolicy';
import { bracketCeilingsFor } from './taxConstants';

describe('Authoritative Federal Deduction Engine (resolveFederalDeduction)', () => {
  describe('Year applicability for Enhanced Senior Deduction (2025–2028)', () => {
    it('returns $0 enhanced deduction for tax years before 2025 (e.g. 2024)', () => {
      const res = resolveFederalDeduction({
        taxYear: 2024,
        isJoint: false,
        primaryAge: 68,
        magi: 50000,
        deflator: 1.0,
      });

      expect(res.enhancedSeniorDeduction).toBe(0);
      expect(res.standardDeduction).toBe(STANDARD_DEDUCTION_2026.single);
      expect(res.additionalAge65Deduction).toBe(ADDL_STD_DEDUCTION_65.single);
      expect(res.totalDeduction).toBe(STANDARD_DEDUCTION_2026.single + ADDL_STD_DEDUCTION_65.single);
    });

    it('applies full enhanced deduction in 2025 (start year)', () => {
      const res = resolveFederalDeduction({
        taxYear: 2025,
        isJoint: false,
        primaryAge: 65,
        magi: 50000,
        deflator: 1.0,
      });

      expect(res.enhancedSeniorDeduction).toBe(6000);
      expect(res.totalDeduction).toBe(STANDARD_DEDUCTION_2026.single + ADDL_STD_DEDUCTION_65.single + 6000);
    });

    it('applies full enhanced deduction in 2028 (end year)', () => {
      const res = resolveFederalDeduction({
        taxYear: 2028,
        isJoint: true,
        primaryAge: 66,
        spouseAge: 67,
        magi: 100000,
        deflator: 1.0,
      });

      expect(res.enhancedSeniorDeduction).toBe(12000);
      expect(res.additionalAge65Deduction).toBe(ADDL_STD_DEDUCTION_65.joint * 2);
      expect(res.totalDeduction).toBe(STANDARD_DEDUCTION_2026.joint + ADDL_STD_DEDUCTION_65.joint * 2 + 12000);
    });

    it('returns $0 enhanced deduction for tax years after 2028 (e.g. 2029 and 2040)', () => {
      const res2029 = resolveFederalDeduction({
        taxYear: 2029,
        isJoint: true,
        primaryAge: 65,
        spouseAge: 65,
        magi: 80000,
        deflator: 1.0,
      });

      expect(res2029.enhancedSeniorDeduction).toBe(0);
      expect(res2029.totalDeduction).toBe(STANDARD_DEDUCTION_2026.joint + ADDL_STD_DEDUCTION_65.joint * 2);

      const res2040 = resolveFederalDeduction({
        taxYear: 2040,
        isJoint: true,
        primaryAge: 70,
        spouseAge: 70,
        magi: 80000,
        deflator: 1.2,
      });

      expect(res2040.enhancedSeniorDeduction).toBe(0);
      expect(res2040.totalDeduction).toBe(Math.round((STANDARD_DEDUCTION_2026.joint + ADDL_STD_DEDUCTION_65.joint * 2) * 1.2));
    });
  });

  describe('Single & Joint age eligibility', () => {
    it('gives 0 enhanced deduction and 0 age-65 addition if below 65', () => {
      const single64 = resolveFederalDeduction({
        taxYear: 2026,
        isJoint: false,
        primaryAge: 64,
        magi: 50000,
        deflator: 1.0,
      });
      expect(single64.additionalAge65Deduction).toBe(0);
      expect(single64.enhancedSeniorDeduction).toBe(0);
      expect(single64.totalDeduction).toBe(STANDARD_DEDUCTION_2026.single);

      const joint64_64 = resolveFederalDeduction({
        taxYear: 2026,
        isJoint: true,
        primaryAge: 64,
        spouseAge: 64,
        magi: 100000,
        deflator: 1.0,
      });
      expect(joint64_64.additionalAge65Deduction).toBe(0);
      expect(joint64_64.enhancedSeniorDeduction).toBe(0);
      expect(joint64_64.totalDeduction).toBe(STANDARD_DEDUCTION_2026.joint);
    });

    it('gives 1 person age-65 and enhanced deduction when one spouse is 65 and one is 64', () => {
      const joint65_64 = resolveFederalDeduction({
        taxYear: 2026,
        isJoint: true,
        primaryAge: 65,
        spouseAge: 64,
        magi: 100000,
        deflator: 1.0,
      });
      expect(joint65_64.additionalAge65Deduction).toBe(ADDL_STD_DEDUCTION_65.joint);
      expect(joint65_64.enhancedSeniorDeduction).toBe(6000);

      const joint64_65 = resolveFederalDeduction({
        taxYear: 2026,
        isJoint: true,
        primaryAge: 64,
        spouseAge: 65,
        magi: 100000,
        deflator: 1.0,
      });
      expect(joint64_65.additionalAge65Deduction).toBe(ADDL_STD_DEDUCTION_65.joint);
      expect(joint64_65.enhancedSeniorDeduction).toBe(6000);
    });

    it('gives 2 persons age-65 and enhanced deduction when both spouses are 65+', () => {
      const joint65_65 = resolveFederalDeduction({
        taxYear: 2026,
        isJoint: true,
        primaryAge: 65,
        spouseAge: 65,
        magi: 100000,
        deflator: 1.0,
      });
      expect(joint65_65.additionalAge65Deduction).toBe(ADDL_STD_DEDUCTION_65.joint * 2);
      expect(joint65_65.enhancedSeniorDeduction).toBe(12000);
    });
  });

  describe('MAGI phaseout mechanics (6% rate)', () => {
    it('phases out single enhanced deduction between $75,000 and $175,000', () => {
      // At or below $75,000: full $6,000
      expect(resolveFederalDeduction({ taxYear: 2026, isJoint: false, primaryAge: 65, magi: 75000 }).enhancedSeniorDeduction).toBe(6000);

      // At $100,000: $6,000 - 0.06 * ($25,000) = $6,000 - $1,500 = $4,500
      expect(resolveFederalDeduction({ taxYear: 2026, isJoint: false, primaryAge: 65, magi: 100000 }).enhancedSeniorDeduction).toBe(4500);

      // At $175,000: $6,000 - 0.06 * ($100,000) = $0
      expect(resolveFederalDeduction({ taxYear: 2026, isJoint: false, primaryAge: 65, magi: 175000 }).enhancedSeniorDeduction).toBe(0);

      // At $200,000: $0 (floored at 0)
      expect(resolveFederalDeduction({ taxYear: 2026, isJoint: false, primaryAge: 65, magi: 200000 }).enhancedSeniorDeduction).toBe(0);
    });

    it('phases out joint enhanced deduction between $150,000 and $350,000 (both 65+)', () => {
      // At $150,000: full $12,000
      expect(resolveFederalDeduction({ taxYear: 2026, isJoint: true, primaryAge: 65, spouseAge: 65, magi: 150000 }).enhancedSeniorDeduction).toBe(12000);

      // At $250,000: $12,000 - 0.06 * ($100,000) = $6,000
      expect(resolveFederalDeduction({ taxYear: 2026, isJoint: true, primaryAge: 65, spouseAge: 65, magi: 250000 }).enhancedSeniorDeduction).toBe(6000);

      // At $350,000: $12,000 - 0.06 * ($200,000) = $0
      expect(resolveFederalDeduction({ taxYear: 2026, isJoint: true, primaryAge: 65, spouseAge: 65, magi: 350000 }).enhancedSeniorDeduction).toBe(0);
    });
  });

  describe('Inflation / Deflator Independence', () => {
    it('inflates standard deduction and age-65 additional deduction but NOT enhanced senior deduction', () => {
      const deflator = 1.10; // 10% inflation
      const res = resolveFederalDeduction({
        taxYear: 2026,
        isJoint: true,
        primaryAge: 65,
        spouseAge: 65,
        magi: 100000,
        deflator,
      });

      expect(res.standardDeduction).toBe(Math.round(STANDARD_DEDUCTION_2026.joint * deflator));
      expect(res.additionalAge65Deduction).toBe(Math.round(ADDL_STD_DEDUCTION_65.joint * 2 * deflator));
      // Enhanced deduction must remain fixed nominal statutory $12,000
      expect(res.enhancedSeniorDeduction).toBe(12000);
      expect(res.totalDeduction).toBe(res.standardDeduction + res.additionalAge65Deduction + res.enhancedSeniorDeduction);
    });
  });

  describe('calculateFederalTaxableOrdinaryIncome helper', () => {
    it('correctly deducts total deduction and floors at 0', () => {
      const breakdown = resolveFederalDeduction({
        taxYear: 2026,
        isJoint: true,
        primaryAge: 65,
        spouseAge: 65,
        magi: 100000,
        deflator: 1.0,
      }); // total deduction = 32200 + 3300 + 12000 = 47500

      expect(calculateFederalTaxableOrdinaryIncome(60000, 20000, breakdown)).toBe(80000 - 47500);
      expect(calculateFederalTaxableOrdinaryIncome(30000, 10000, breakdown)).toBe(0);
    });
  });
});

describe('Roth Conversion Policy Dynamic Federal Deduction Integration', () => {
  it('dynamically computes deduction as MAGI increases from conversion', () => {
    const bracketCeilings = bracketCeilingsFor(false, 1.0);
    const ctx: RothConversionContext = {
      age: 66,
      isJoint: false,
      calendarYear: 2026,
      availablePreTaxBalance: 100000,
      ordinaryIncomeBeforeConversion: 70000,
      totalSs: 0,
      taxableSocialSecurityBeforeConversion: 0,
      rmdAmount: 0,
      bracketCeilings,
    };

    const decision = determineRothConversionTarget(
      { type: 'fill_bracket', bracket: 0.22, targetBracketName: 'fill_22', annualTarget: 0, startAge: 60, endAge: 70 },
      ctx
    );

    expect(decision.actualConversion).toBeGreaterThan(0);
    expect(decision.federalDeductionUsed).toBeDefined();
    // At baseline ($70k), MAGI < $75k, deduction is full $6k enhanced + std + addl65 = 16100 + 2050 + 6000 = 24150
    // After conversion to fill 22% bracket, MAGI > $75k, so federalDeductionUsed will reflect the 6% phaseout!
    expect(decision.federalDeductionUsed).toBeLessThan(24150);
  });
});
