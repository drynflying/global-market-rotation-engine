/**
 * Distance to the next tax threshold, for Roth conversion and gain-harvesting sizing.
 *
 * "Headroom" is not one number. Three different ceilings bind in different years and
 * they are rarely the same distance away:
 *
 *   ordinary  - dollars of ordinary income before the next marginal bracket
 *   ltcg      - dollars of income before long-term gains stop being taxed at 0%, or
 *               before they move from 15% to 20%
 *   irmaa     - dollars of MAGI before the next Medicare surcharge tier
 *
 * IRMAA is a CLIFF, not a ramp: one dollar over a threshold triggers the full tier
 * increase for the year, and it is assessed on MAGI from two years prior. That makes
 * IRMAA headroom the binding constraint far more often than its size suggests, which
 * is why it is reported separately rather than folded into a single figure.
 *
 * A headroom of 0 means the threshold has already been crossed.
 */
import { BracketCeilings, ltcgCeilingsFor } from './taxConstants';

/** Ordinary-income dollars remaining before the next marginal bracket. */
export function ordinaryBracketHeadroom(
  netTaxableIncome: number,
  ceilings: BracketCeilings,
): number {
  const ordered = [
    ceilings.b10,
    ceilings.b12,
    ceilings.b22,
    ceilings.b24,
    ceilings.b32,
    ceilings.b35,
  ];
  const next = ordered.find((c) => netTaxableIncome < c);
  // Above the top ceiling there is no further bracket to cross.
  return next === undefined ? 0 : Math.round(next - Math.max(0, netTaxableIncome));
}

/**
 * Dollars remaining before long-term capital gains leave their current rate band.
 *
 * Gains stack on top of ordinary income, so the relevant measure is how much MORE
 * income (ordinary or gain) fits before the next LTCG ceiling.
 */
export function ltcgHeadroom(
  netTaxableIncome: number,
  realizedCapGains: number,
  isJoint: boolean,
  deflator: number,
): number {
  const c = ltcgCeilingsFor(isJoint, deflator);
  const stacked = Math.max(0, netTaxableIncome) + Math.max(0, realizedCapGains);
  if (stacked < c.zero) return Math.round(c.zero - stacked);
  if (stacked < c.fifteen) return Math.round(c.fifteen - stacked);
  return 0;
}

/** IRMAA tier thresholds in base-year dollars, ascending. */
export const IRMAA_THRESHOLDS = {
  joint: [218000, 274000, 342000, 410000, 750000],
  single: [109000, 137000, 171000, 205000, 500000],
} as const;

/**
 * MAGI dollars remaining before the next IRMAA tier.
 *
 * Returns 0 above the top tier. Not meaningful before Medicare eligibility, so callers
 * should report 0 for those years.
 */
export function irmaaHeadroom(magi: number, isJoint: boolean, deflator: number): number {
  const thresholds = (isJoint ? IRMAA_THRESHOLDS.joint : IRMAA_THRESHOLDS.single).map(
    (t) => t * deflator,
  );
  const next = thresholds.find((t) => magi <= t);
  return next === undefined ? 0 : Math.round(next - Math.max(0, magi));
}
