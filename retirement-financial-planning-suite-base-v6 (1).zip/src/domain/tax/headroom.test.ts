import { describe, it, expect } from 'vitest';
import { ordinaryBracketHeadroom, ltcgHeadroom, irmaaHeadroom, IRMAA_THRESHOLDS } from './headroom';
import { bracketCeilingsFor } from './taxConstants';
import { getSimulation } from '../simulation/simulationCache';
import { createDefaultPlan } from '../../constants/defaultPlan';

const c = bracketCeilingsFor(true, 1.0);

describe('ordinary bracket headroom', () => {
  it('measures the distance to the next ceiling', () => {
    expect(ordinaryBracketHeadroom(0, c)).toBe(c.b10);
    expect(ordinaryBracketHeadroom(c.b10 - 1000, c)).toBe(1000);
    expect(ordinaryBracketHeadroom(c.b10, c)).toBe(Math.round(c.b12 - c.b10));
  });

  it('returns zero above the top ceiling', () => {
    expect(ordinaryBracketHeadroom(c.b35 + 1, c)).toBe(0);
  });

  it('treats negative income as zero', () => {
    expect(ordinaryBracketHeadroom(-5000, c)).toBe(c.b10);
  });
});

describe('LTCG band headroom', () => {
  it('measures room inside the 0% band, stacking gains on ordinary income', () => {
    // Joint 0% ceiling is 98,900 in base-year dollars.
    expect(ltcgHeadroom(50000, 20000, true, 1.0)).toBe(98900 - 70000);
  });

  it('switches to the 15% ceiling once the 0% band is exceeded', () => {
    const h = ltcgHeadroom(100000, 0, true, 1.0);
    expect(h).toBe(613700 - 100000);
  });

  it('returns zero in the 20% band', () => {
    expect(ltcgHeadroom(600000, 100000, true, 1.0)).toBe(0);
  });

  it('scales with the deflator', () => {
    expect(ltcgHeadroom(0, 0, true, 2.0)).toBe(98900 * 2);
  });
});

describe('IRMAA tier headroom', () => {
  it('measures the distance to the next cliff', () => {
    const [t0, t1] = IRMAA_THRESHOLDS.joint;
    expect(irmaaHeadroom(t0 - 5000, true, 1.0)).toBe(5000);
    expect(irmaaHeadroom(t0 + 1, true, 1.0)).toBe(t1 - t0 - 1);
  });

  it('returns zero above the top tier', () => {
    expect(irmaaHeadroom(1_000_000, true, 1.0)).toBe(0);
  });

  it('uses lower thresholds for single filers', () => {
    expect(irmaaHeadroom(0, false, 1.0)).toBe(IRMAA_THRESHOLDS.single[0]);
    expect(irmaaHeadroom(0, true, 1.0)).toBe(IRMAA_THRESHOLDS.joint[0]);
  });
});

describe('transparency columns on the row', () => {
  const rows = () => getSimulation(createDefaultPlan()).rows;

  it('reports the inflation rate actually applied', () => {
    const plan = createDefaultPlan();
    for (const r of rows()) {
      expect(r.inflationRatePct).toBe(plan.macroAssumptions!.generalInflation);
    }
  });

  it('reports a plausible blended portfolio return while funded', () => {
    // A depleted portfolio correctly reports 0%: there are no balances to weight.
    for (const r of rows()) {
      // Weighted on BEGINNING balances, so a year that starts funded and ends depleted
      // still reports a real return.
      if (r.beginningPortfolio > 0) {
        expect(r.portfolioReturnPct).toBeGreaterThan(0);
        expect(r.portfolioReturnPct).toBeLessThan(15);
      } else {
        expect(r.portfolioReturnPct).toBe(0);
      }
    }
  });

  it('inflates the standard deduction year over year', () => {
    const all = rows();
    expect(all[0].standardDeductionUsed).toBe(32200);
    expect(all[10].standardDeductionUsed).toBeGreaterThan(all[0].standardDeductionUsed);
  });

  it('equates real and nominal in the first year, and diverges after', () => {
    const all = rows();
    expect(all[0].totalPortfolioReal).toBe(all[0].totalPortfolio);
    const later = all[10];
    expect(later.totalPortfolioReal).toBeLessThan(later.totalPortfolio);
  });

  it('discounts the real value by exactly the compounded inflation rate', () => {
    const all = rows();
    const r = all[10];
    const deflator = Math.pow(1 + r.inflationRatePct / 100, 10);
    expect(r.totalPortfolioReal).toBe(Math.round(r.totalPortfolio / deflator));
  });

  it('reports IRMAA headroom only once Medicare eligible', () => {
    for (const r of rows()) {
      if (r.age < 65) expect(r.irmaaHeadroom).toBe(0);
    }
    expect(rows().find(r => r.age === 65)!.irmaaHeadroom).toBeGreaterThan(0);
  });

  it('never reports negative headroom', () => {
    for (const r of rows()) {
      expect(r.ordinaryHeadroom).toBeGreaterThanOrEqual(0);
      expect(r.ltcgHeadroom).toBeGreaterThanOrEqual(0);
      expect(r.irmaaHeadroom).toBeGreaterThanOrEqual(0);
    }
  });
});

describe('the bracket is computed from taxable income, not MAGI', () => {
  const rows = () => {
    const plan = createDefaultPlan();
    plan.spendingAssumptions!.desiredAnnualLivingExpenses = 75000;
    plan.spendingAssumptions!.preRetirementAnnualSpending = 75000;
    return getSimulation(plan).rows;
  };

  it('always equals MAGI minus the standard deduction, floored at zero', () => {
    for (const r of rows()) {
      expect(r.taxableIncomeAfterDeduction).toBe(
        Math.max(0, Math.round(r.taxableMagi - r.standardDeductionUsed)),
      );
    }
  });

  it('explains the age 64 to 65 bracket drop', () => {
    // At age 65 Medicare starts, so the ACA premium drops off and the additional
    // standard deduction kicks in. Taxable income drops and bracket stays low or falls.
    const at64 = rows().find(r => r.age === 64)!;
    const at65 = rows().find(r => r.age === 65)!;

    expect(at65.taxableMagi).toBeLessThan(at64.taxableMagi);
    expect(at65.standardDeductionUsed - at64.standardDeductionUsed).toBeGreaterThan(4000);
    expect(at65.taxableIncomeAfterDeduction).toBeLessThan(at64.taxableIncomeAfterDeduction);
  });

  it('leaves headroom consistent with the bracket shown', () => {
    // Headroom is measured from taxable income, so a row in the 12% bracket must have
    // positive room before the next ceiling.
    const at65 = rows().find(r => r.age === 65)!;
    expect(at65.ordinaryHeadroom).toBeGreaterThan(0);
    expect(at65.taxableIncomeAfterDeduction + at65.ordinaryHeadroom).toBeGreaterThan(
      at65.taxableIncomeAfterDeduction,
    );
  });
});
