/**
 * Guards the single-source-of-truth property of the tax tables.
 *
 * Step4CashFlowStep previously carried its own hardcoded copy of the bracket ceilings,
 * so the chart's reference lines could disagree with the tax computed in the table
 * beneath them. These tests fail if a second copy reappears anywhere.
 */
import { describe, it, expect } from 'vitest';
import { readFileSync, readdirSync, statSync } from 'fs';
import { join } from 'path';
import { bracketCeilingsFor, BRACKET_CEILINGS_2026, TAX_BASE_YEAR, calculateEnhancedSeniorDeduction } from './taxConstants';

describe('tax constants', () => {
  it('scales every ceiling by the deflator', () => {
    const base = bracketCeilingsFor(true, 1.0);
    const inflated = bracketCeilingsFor(true, 1.5);
    for (const k of ['b10', 'b12', 'b22', 'b24', 'b32', 'b35'] as const) {
      expect(inflated[k]).toBeCloseTo(base[k] * 1.5, 6);
    }
  });

  it('keeps ceilings strictly ascending for both filing statuses', () => {
    for (const joint of [true, false]) {
      const c = bracketCeilingsFor(joint, 1.0);
      const vals = [c.b10, c.b12, c.b22, c.b24, c.b32, c.b35];
      for (let i = 1; i < vals.length; i++) {
        expect(vals[i]).toBeGreaterThan(vals[i - 1]);
      }
    }
  });

  it('puts joint ceilings above single ceilings', () => {
    const j = bracketCeilingsFor(true, 1.0);
    const s = bracketCeilingsFor(false, 1.0);
    for (const k of ['b10', 'b12', 'b22', 'b24', 'b32', 'b35'] as const) {
      expect(j[k]).toBeGreaterThan(s[k]);
    }
  });

  it('declares a single base year', () => {
    expect(TAX_BASE_YEAR).toBe(2026);
  });
});

describe('no duplicate bracket tables', () => {
  const walk = (dir: string): string[] =>
    readdirSync(dir).flatMap(entry => {
      const full = join(dir, entry);
      if (statSync(full).isDirectory()) return walk(full);
      return /\.(ts|tsx)$/.test(entry) ? [full] : [];
    });

  it('defines the bracket ceilings in exactly one place', () => {
    const offenders = walk('src')
      .filter(f => !f.endsWith('taxConstants.ts') && !f.includes('.test.'))
      .filter(f => {
        const src = readFileSync(f, 'utf8');
        // A literal object with b10/b12 keys is a second copy of the table.
        return /b10\s*:\s*\d/.test(src) && /b12\s*:\s*\d/.test(src);
      });
    expect(offenders).toEqual([]);
  });

  it('does not hardcode bracket dollar amounts in chart labels', () => {
    const offenders = walk('src')
      .filter(f => !f.includes('.test.'))
      .filter(f => /Bracket \(\$[\d.]+k\)/.test(readFileSync(f, 'utf8')));
    expect(offenders).toEqual([]);
  });

  it('exposes the 2026 joint table with a 37% boundary', () => {
    expect(BRACKET_CEILINGS_2026.joint.b35).toBeGreaterThan(
      BRACKET_CEILINGS_2026.joint.b32,
    );
  });
});

describe('enhanced senior deduction phaseout logic', () => {
  it('handles single eligible taxpayer across MAGI phaseout thresholds', () => {
    // MAGI 75,000 -> 6,000
    expect(calculateEnhancedSeniorDeduction(65, undefined, false, 75000)).toBe(6000);
    // MAGI 75,001 -> 6,000 (5,999.94 rounded)
    expect(calculateEnhancedSeniorDeduction(65, undefined, false, 75001)).toBe(6000);
    // MAGI 100,000 -> 4,500
    expect(calculateEnhancedSeniorDeduction(65, undefined, false, 100000)).toBe(4500);
    // MAGI 175,000 -> 0
    expect(calculateEnhancedSeniorDeduction(65, undefined, false, 175000)).toBe(0);
    // MAGI above 175,000 -> 0
    expect(calculateEnhancedSeniorDeduction(65, undefined, false, 200000)).toBe(0);
  });

  it('handles joint return with one spouse eligible', () => {
    // MAGI 150,000 -> 6,000
    expect(calculateEnhancedSeniorDeduction(65, 60, true, 150000)).toBe(6000);
    // MAGI 200,000 -> 3,000
    expect(calculateEnhancedSeniorDeduction(65, 60, true, 200000)).toBe(3000);
    // MAGI 250,000 -> 0
    expect(calculateEnhancedSeniorDeduction(65, 60, true, 250000)).toBe(0);
  });

  it('handles joint return with both spouses eligible', () => {
    // MAGI 150,000 -> 12,000
    expect(calculateEnhancedSeniorDeduction(65, 65, true, 150000)).toBe(12000);
    // MAGI 250,000 -> 6,000
    expect(calculateEnhancedSeniorDeduction(65, 65, true, 250000)).toBe(6000);
    // MAGI 350,000 -> 0
    expect(calculateEnhancedSeniorDeduction(65, 65, true, 350000)).toBe(0);
  });

  it('evaluates age combinations correctly', () => {
    // neither spouse age 65 -> 0
    expect(calculateEnhancedSeniorDeduction(64, 64, true, 100000)).toBe(0);
    // only primary age 65 -> 1 eligible
    expect(calculateEnhancedSeniorDeduction(65, 64, true, 100000)).toBe(6000);
    // only spouse age 65 -> 1 eligible
    expect(calculateEnhancedSeniorDeduction(64, 65, true, 100000)).toBe(6000);
    // both age 65 -> 2 eligible
    expect(calculateEnhancedSeniorDeduction(65, 65, true, 100000)).toBe(12000);
  });
});

describe('standard deduction matches the 2026 statutory values', () => {
  it('seeds statutoryParams from the verified constants', async () => {
    const { STD_DEDUCTION_2026 } = await import('./taxConstants');
    const { createDefaultPlan } = await import('../../constants/defaultPlan');
    const stat = createDefaultPlan().statutoryParams!;
    // Previously 30000/15000 - the 2025 pre-OBBBA figures - which no test caught
    // because the deduction lives in statutoryParams rather than taxConstants.
    expect(stat.standardDeductionJoint).toBe(STD_DEDUCTION_2026.joint);
    expect(stat.standardDeductionSingle).toBe(STD_DEDUCTION_2026.single);
  });
});
