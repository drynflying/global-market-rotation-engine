import { describe, it, expect } from 'vitest';
import { DEFAULT_PLAN, createDefaultPlan } from '../../constants/defaultPlan';
import { PlanSchema } from '../../schemas/planSchema';
import { findStateRule, subtractionCapForAge, calculateRetirementSubtraction, calculateStateTax } from './stateTaxConstants';

describe('State Tax Rules and Helpers', () => {
  it('finds rules by code', () => {
    expect(findStateRule('CO').code).toBe('CO');
    expect(findStateRule('CO').ratePct).toBe(4.4);
    expect(findStateRule('CO').supported).toBe(true);
    expect(findStateRule('NONE').kind).toBe('none');
    expect(findStateRule('CUSTOM').kind).toBe('custom');
  });

  it('maps supported no-income-tax states to NONE', () => {
    const tx = findStateRule('TX');
    expect(tx.kind).toBe('none');
    expect(tx.ratePct).toBe(0);
    expect(tx.supported).toBe(true);
    expect(calculateStateTax({
      ordinaryTaxable: 100000,
      realizedCapGains: 10000,
      taxableSocialSecurity: 20000,
      rule: tx,
    })).toBe(0);

    const fl = findStateRule('FL');
    expect(fl.kind).toBe('none');
    expect(fl.ratePct).toBe(0);
  });

  it('returns explicit unsupported rule for unknown state codes instead of falling back to Colorado', () => {
    const unknownRule = findStateRule('UNKNOWN');
    expect(unknownRule.kind).toBe('unsupported');
    expect(unknownRule.supported).toBe(false);
    expect(unknownRule.ratePct).toBe(0);
    expect(unknownRule.code).toBe('UNKNOWN');

    const xxRule = findStateRule('XX');
    expect(xxRule.kind).toBe('unsupported');
    expect(xxRule.supported).toBe(false);
    expect(xxRule.ratePct).toBe(0);

    // Verify calculateStateTax does NOT charge Colorado tax
    const tax = calculateStateTax({
      ordinaryTaxable: 100000,
      realizedCapGains: 10000,
      taxableSocialSecurity: 20000,
      rule: xxRule,
    });
    expect(tax).toBe(0);
  });

  it('defaults to Colorado when state code is undefined (default baseline plan)', () => {
    expect(findStateRule(undefined).code).toBe('CO');
    expect(findStateRule(undefined).supported).toBe(true);
  });
});

describe('State Tax Architecture & Schema Boundaries', () => {
  it('enforces stateOfResidence on root plan, NOT in statutoryParams', () => {
    const plan = createDefaultPlan();
    expect(plan.stateOfResidence).toBe('CO');
    expect((plan.statutoryParams as unknown as Record<string, unknown>).stateOfResidence).toBeUndefined();
  });

  it('preserves stateOfResidence across round-trip serialization', () => {
    const plan = createDefaultPlan();
    plan.stateOfResidence = 'CUSTOM';
    plan.customStateRatePct = 5.25;
    const json = JSON.stringify(plan);
    const parsed = PlanSchema.parse(JSON.parse(json));
    expect(parsed.stateOfResidence).toBe('CUSTOM');
    expect(parsed.customStateRatePct).toBe(5.25);
  });

  it('defaults stateOfResidence to CO when parsed from an object lacking it', () => {
    const plan = createDefaultPlan();
    delete (plan as Partial<typeof plan>).stateOfResidence;
    const parsed = PlanSchema.parse(plan);
    expect(parsed.stateOfResidence).toBe('CO');
  });

  it('includes the state tax citation row in DEFAULT_PLAN.assumptions', () => {
    const row = DEFAULT_PLAN.assumptions?.find(a => a.id === 'asm-state-income-tax');
    expect(row).toBeDefined();
    expect(row?.category).toBe('Statutory Tax');
    expect(row?.currentValue).toContain('Colorado');
    expect(row?.sourceUrl).toContain('tax.colorado.gov');
  });
});

describe('retirement income subtraction', () => {
  const co = findStateRule('CO');
  const base = {
    ordinaryTaxable: 200000,
    realizedCapGains: 0,
    taxableSocialSecurity: 0,
    rule: co,
    isJoint: true,
  };

  it('caps at $20,000 for ages 55-64 and $24,000 from 65', () => {
    expect(subtractionCapForAge(co.retirementSubtraction!, 54)).toBe(0);
    expect(subtractionCapForAge(co.retirementSubtraction!, 55)).toBe(20000);
    expect(subtractionCapForAge(co.retirementSubtraction!, 64)).toBe(20000);
    expect(subtractionCapForAge(co.retirementSubtraction!, 65)).toBe(24000);
    expect(subtractionCapForAge(co.retirementSubtraction!, 90)).toBe(24000);
  });

  it('grants no subtraction below the youngest band', () => {
    expect(calculateRetirementSubtraction({
      ...base, primaryAge: 50, pensionIncome: 50000,
    })).toBe(0);
  });

  it('treats pre-tax IRA and 401(k) withdrawals as pension income', () => {
    expect(co.retirementSubtraction!.includesPreTaxWithdrawals).toBe(true);
    expect(calculateRetirementSubtraction({
      ...base, primaryAge: 60, preTaxWithdrawals: 50000, agi: 200000,
    })).toBe(20000);
  });

  it('lets Social Security consume the cap first below 65', () => {
    // AGI above the HB24-1142 threshold, so SS is inside the cap.
    const result = calculateRetirementSubtraction({
      ...base, primaryAge: 60, taxableSocialSecurity: 15000, pensionIncome: 50000, agi: 200000,
    });
    expect(result).toBe(20000); // 15k SS + 5k of pension
  });

  it('fully subtracts Social Security from 65, outside the cap', () => {
    const result = calculateRetirementSubtraction({
      ...base, primaryAge: 65, taxableSocialSecurity: 40000, pensionIncome: 50000, agi: 200000,
    });
    expect(result).toBe(40000 + 24000);
  });

  it('fully subtracts Social Security below 65 when AGI is under the threshold', () => {
    const result = calculateRetirementSubtraction({
      ...base, primaryAge: 60, taxableSocialSecurity: 15000, pensionIncome: 50000, agi: 80000, isJoint: true,
    });
    expect(result).toBe(15000 + 20000);
  });
});
