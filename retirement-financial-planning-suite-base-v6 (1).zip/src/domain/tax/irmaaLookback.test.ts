import { describe, it, expect } from 'vitest';
import { resolveIrmaaContext, IRMAA_REGISTRY } from '../registry/statutoryRegistry';
import { getSimulation } from '../simulation/simulationCache';
import { createDefaultPlan } from '../../constants/defaultPlan';

describe('IRMAA 2-Year Lookback & Surcharge Consistency', () => {
  describe('resolveIrmaaContext pure resolver', () => {
    it('returns Tier 0 and $0 surcharge when lookback MAGI is below Tier 1', () => {
      const res = resolveIrmaaContext({
        premiumYear: 2028,
        lookbackTaxYear: 2026,
        lookbackMagi: 150000,
        isJoint: true,
        deflator: 1.0,
        isMedicareEligible: true,
        enrolledCount: 2,
      });

      expect(res.tier).toBe('Tier 0');
      expect(res.tierNumber).toBe(0);
      expect(res.annualSurchargePerPerson).toBe(0);
      expect(res.totalAnnualSurcharge).toBe(0);
      expect(res.headroomToNextTier).toBe(218000 - 150000);
      expect(res.premiumYear).toBe(2028);
      expect(res.lookbackTaxYear).toBe(2026);
    });

    it('accurately resolves exact threshold boundaries (threshold, threshold + 1)', () => {
      const [t0, t1, , , t4] = IRMAA_REGISTRY.thresholds.joint;

      // Exactly at Tier 1 threshold (218,000) -> Still Tier 0
      const atT0 = resolveIrmaaContext({
        lookbackMagi: t0,
        isJoint: true,
      });
      expect(atT0.tier).toBe('Tier 0');
      expect(atT0.headroomToNextTier).toBe(0);

      // $1 above Tier 1 threshold (218,001) -> Tier 1
      const aboveT0 = resolveIrmaaContext({
        lookbackMagi: t0 + 1,
        isJoint: true,
      });
      expect(aboveT0.tier).toBe('Tier 1');
      expect(aboveT0.annualSurchargePerPerson).toBe(IRMAA_REGISTRY.surchargesPerPerson2026.tier1);
      expect(aboveT0.headroomToNextTier).toBe(t1 - (t0 + 1));

      // At Tier 5 Max threshold (750,000) -> Tier 5 (Max)
      const atT4 = resolveIrmaaContext({
        lookbackMagi: t4,
        isJoint: true,
      });
      expect(atT4.tier).toBe('Tier 5 (Max)');
      expect(atT4.tierNumber).toBe(5);
      expect(atT4.annualSurchargePerPerson).toBe(IRMAA_REGISTRY.surchargesPerPerson2026.tier5);
      expect(atT4.headroomToNextTier).toBeNull();
    });

    it('multiplies surcharge by enrolled Medicare count (1 vs 2 individuals)', () => {
      const [t0] = IRMAA_REGISTRY.thresholds.joint;
      const resSingleEnrollee = resolveIrmaaContext({
        lookbackMagi: t0 + 5000,
        isJoint: true,
        enrolledCount: 1,
      });
      expect(resSingleEnrollee.totalAnnualSurcharge).toBe(IRMAA_REGISTRY.surchargesPerPerson2026.tier1);

      const resBothEnrolled = resolveIrmaaContext({
        lookbackMagi: t0 + 5000,
        isJoint: true,
        enrolledCount: 2,
      });
      expect(resBothEnrolled.totalAnnualSurcharge).toBe(IRMAA_REGISTRY.surchargesPerPerson2026.tier1 * 2);
    });

    it('returns zero surcharge and headroom when not Medicare eligible', () => {
      const res = resolveIrmaaContext({
        lookbackMagi: 500000,
        isJoint: false,
        isMedicareEligible: false,
      });
      expect(res.tier).toBe('Tier 0');
      expect(res.totalAnnualSurcharge).toBe(0);
      expect(res.headroomToNextTier).toBe(0);
    });

    it('adjusts thresholds and surcharges by the inflation deflator', () => {
      const [t0] = IRMAA_REGISTRY.thresholds.joint;
      const deflator = 1.10;
      const scaledT0 = Math.round(t0 * deflator);

      const res = resolveIrmaaContext({
        lookbackMagi: scaledT0 + 100,
        isJoint: true,
        deflator,
      });

      expect(res.tier).toBe('Tier 1');
      expect(res.annualSurchargePerPerson).toBe(Math.round(IRMAA_REGISTRY.surchargesPerPerson2026.tier1 * deflator));
    });
  });

  describe('Simulation 2-Year Lookback Integration', () => {
    it('applies N-2 lookback MAGI to determine Year N IRMAA tier, surcharge, and headroom', () => {
      const plan = createDefaultPlan();
      plan.filingStatus = 'joint';
      plan.primaryPerson.currentAge = 63;
      plan.primaryPerson.retirementAge = 63;
      if (plan.spousePerson) {
        plan.spousePerson.currentAge = 63;
        plan.spousePerson.retirementAge = 63;
      }
      plan.spendingAssumptions!.desiredAnnualLivingExpenses = 100000;
      plan.spendingAssumptions!.preRetirementAnnualSpending = 100000;

      // Spike Year 1 (Age 63) income via a large manual Roth conversion
      plan.spendingAssumptions!.conversionStrategy = 'manual';
      plan.spendingAssumptions!.annualRothConversionTarget = 250000;
      if (plan.accounts[0]) {
        plan.accounts[0].balance = 2000000;
      }

      const sim = getSimulation(plan);
      const rowAge63 = sim.rows.find((r) => r.age === 63)!;
      const rowAge64 = sim.rows.find((r) => r.age === 64)!;
      const rowAge65 = sim.rows.find((r) => r.age === 65)!;

      // In Year 1 (Age 63), MAGI is high (> 250k)
      expect(rowAge63.taxableMagi).toBeGreaterThan(250000);

      // In Year 1 (Age 63) & Year 2 (Age 64), primary is not 65 yet, so IRMAA surcharge is 0
      expect(rowAge63.irmaaSurcharge).toBe(0);
      expect(rowAge64.irmaaSurcharge).toBe(0);

      // In Year 3 (Age 65, Medicare eligible), IRMAA evaluates Tax Year N-2 (Age 63 MAGI)
      expect(rowAge65.irmaaLookbackYear).toBe(rowAge65.calendarYear - 2);
      expect(rowAge65.irmaaLookbackMagi).toBe(rowAge63.taxableMagi);
      expect(rowAge65.irmaaBracket).not.toBe('Tier 0');
      expect(rowAge65.irmaaSurcharge).toBeGreaterThan(0);
    });

    it('ensures irmaaBracket, irmaaSurcharge, and irmaaHeadroom on the row derive from the exact same lookback context', () => {
      const plan = createDefaultPlan();
      const sim = getSimulation(plan);
      const medicareRows = sim.rows.filter((r) => r.age >= 65);

      for (const row of medicareRows) {
        expect(row.irmaaLookbackYear).toBe(row.calendarYear - 2);
        expect(typeof row.irmaaLookbackMagi).toBe('number');

        const resolved = resolveIrmaaContext({
          premiumYear: row.calendarYear,
          lookbackTaxYear: row.irmaaLookbackYear,
          lookbackMagi: row.irmaaLookbackMagi!,
          isJoint: plan.filingStatus === 'joint',
          deflator: row.inflationDeflator,
          isMedicareEligible: true,
          enrolledCount: plan.hasSpouse && (row.spouseAge ?? 0) >= 65 ? 2 : 1,
        });

        expect(row.irmaaBracket).toBe(resolved.tier);
        expect(row.irmaaSurcharge).toBe(Math.round(resolved.totalAnnualSurcharge));
        expect(row.irmaaHeadroom).toBe(resolved.headroomToNextTier ?? 0);
      }
    });
  });
});
