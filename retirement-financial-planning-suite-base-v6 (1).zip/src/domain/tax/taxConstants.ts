/**
 * Federal tax constants, single source of truth.
 *
 * BASE YEAR: 2026. Every figure here is a 2026 statutory value, and every figure here
 * is inflated by the same deflator at the same point in the projection.
 *
 * Previously bracket ceilings and the FICA wage base were 2024 figures while the
 * standard deduction came from statutoryParams (2026), so a single year's tax mixed
 * two different tax years. Adding a constant here rather than inline in the engine is
 * what keeps that from recurring.
 *
 * VERIFY THESE AGAINST IRS Rev. Proc. BEFORE RELYING ON OUTPUT.
 */

export const TAX_BASE_YEAR = 2026;

export interface BracketCeilings {
  b10: number;
  b12: number;
  b22: number;
  b24: number;
  b32: number;
  b35: number;
}

export const BRACKET_CEILINGS_2026 = {
  joint: { b10: 24800, b12: 100800, b22: 211400, b24: 403550, b32: 512450, b35: 768700 },
  single: { b10: 12400, b12: 50400, b22: 105700, b24: 201775, b32: 256225, b35: 640600 },
} as const;

/** Long-term capital gains ceilings (taxable income), 2026 nominal dollars. */
export const LTCG_CEILINGS_2026 = {
  joint: { zero: 98900, fifteen: 613700 },
  single: { zero: 49450, fifteen: 545500 },
} as const;

export const LTCG_RATES = { zero: 0.0, fifteen: 0.15, twenty: 0.20 } as const;

/** Net Investment Income Tax (IRC 1411). Thresholds are NOT inflation indexed. */
export const NIIT_RATE = 0.038;
export const NIIT_THRESHOLD = { joint: 250000, single: 200000 } as const;

/** FICA, 2026 nominal dollars. */
export const FICA = {
  ssWageBase: 184500,
  ssRate: 0.062,
  medicareRate: 0.0145,
  addMedicareRate: 0.009,
  addMedicareThreshold: { joint: 250000, single: 200000 },
} as const;

/** Additional standard deduction for age 65+, 2026 nominal dollars. */
export const ADDL_STD_DEDUCTION_65 = { joint: 1650, single: 2050 } as const;

export {
  ENHANCED_SENIOR_EFFECTIVE_START_YEAR,
  ENHANCED_SENIOR_EFFECTIVE_END_YEAR,
  ENHANCED_SENIOR_DEDUCTION_PER_PERSON,
  ENHANCED_SENIOR_DEDUCTION,
  ENHANCED_SENIOR_PHASEOUT_RATE,
  ENHANCED_SENIOR_PHASEOUT_START,
  resolveFederalDeduction,
  calculateFederalTaxableOrdinaryIncome,
  calculateEnhancedSeniorDeduction,
} from './federalDeduction';

export type {
  FederalDeductionBreakdown,
  ResolveFederalDeductionInput,
} from './federalDeduction';

/** Basic standard deduction, 2026 statutory nominal dollars (IRS Rev. Proc. 2025-32). */
export const STANDARD_DEDUCTION_2026 = {
  joint: 32200,
  single: 16100,
} as const;

export const STD_DEDUCTION_2026 = STANDARD_DEDUCTION_2026;

export function bracketCeilingsFor(isJoint: boolean, deflator: number): BracketCeilings {
  const b = isJoint ? BRACKET_CEILINGS_2026.joint : BRACKET_CEILINGS_2026.single;
  return {
    b10: b.b10 * deflator,
    b12: b.b12 * deflator,
    b22: b.b22 * deflator,
    b24: b.b24 * deflator,
    b32: b.b32 * deflator,
    b35: b.b35 * deflator,
  };
}

export function ltcgCeilingsFor(isJoint: boolean, deflator: number) {
  const c = isJoint ? LTCG_CEILINGS_2026.joint : LTCG_CEILINGS_2026.single;
  return { zero: c.zero * deflator, fifteen: c.fifteen * deflator };
}
