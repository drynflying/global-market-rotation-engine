/**
 * Age-banded subtraction for retirement income, e.g. Colorado's pension and annuity
 * subtraction. Bands are matched on the PRIMARY person's age (see the combined-cap
 * simplification note on RetirementSubtraction).
 */
export interface SubtractionBand {
  minAge: number;
  /** Inclusive upper bound; omit for "and older". */
  maxAge?: number;
  /** Maximum subtraction in nominal dollars. */
  cap: number;
}

/**
 * Retirement-income subtraction rules.
 *
 * SIMPLIFICATION — COMBINED HOUSEHOLD CAP. Colorado applies its cap per taxpayer, with
 * Social Security apportioned between spouses. This model applies ONE cap to the
 * household, selected by the PRIMARY person's age. For a couple close in age the
 * difference is small; for a couple spanning an age band (one 63, one 66) it will
 * understate the subtraction and therefore OVERSTATE state tax. Erring toward more tax
 * is the safer direction for planning.
 */
export interface RetirementSubtraction {
  /** Caps by primary-person age band. */
  bands: readonly SubtractionBand[];
  /**
   * When true, federally taxable Social Security consumes the cap before pension and
   * IRA/401(k) income does.
   */
  socialSecurityConsumesCap: boolean;
  /** Age from which Social Security is fully subtracted regardless of the cap. */
  fullSsFromAge?: number;
  /**
   * Below these AGI thresholds, Social Security is fully subtracted from this age
   * (Colorado HB24-1142, ages 55-64).
   */
  fullSsBelowAgi?: { fromAge: number; single: number; joint: number };
  /**
   * Whether pre-tax IRA and 401(k) withdrawals count as "pension or annuity" income
   * eligible for the subtraction. True in Colorado (form DR 0104AD line 4).
   */
  includesPreTaxWithdrawals: boolean;
}

export interface StateTaxRule {
  code: string;
  name: string;
  kind: 'flat' | 'none' | 'custom' | 'progressive' | 'unsupported';
  ratePct: number;
  supported?: boolean;
  progressiveNotModelled?: boolean;
  taxesSocialSecurity?: boolean;
  taxesCapitalGainsAsOrdinary?: boolean;
  /** Age- and income-conditional subtraction for retirement income, if any. */
  retirementSubtraction?: RetirementSubtraction;
  notes?: string;
}

export const NO_STATE_TAX_RULE: StateTaxRule = {
  code: 'NONE',
  name: 'No State Tax',
  kind: 'none',
  ratePct: 0,
  supported: true,
};

export const UNSUPPORTED_STATE_TAX_RULE: StateTaxRule = {
  code: 'UNSUPPORTED',
  name: 'Unsupported State',
  kind: 'unsupported',
  ratePct: 0,
  supported: false,
  notes: 'State income tax is not modeled for this state ($0 state tax modeled). Use Custom Rate to specify an estimated effective state rate.',
};

export const STATE_TAX_RULES: StateTaxRule[] = [
  {
    code: 'CO',
    name: 'Colorado',
    kind: 'flat',
    ratePct: 4.4,
    supported: true,
    taxesSocialSecurity: true,
    taxesCapitalGainsAsOrdinary: true,
    retirementSubtraction: {
      // C.R.S. 39-22-104(4)(f). Caps are NOT inflation indexed.
      bands: [
        { minAge: 55, maxAge: 64, cap: 20000 },
        { minAge: 65, cap: 24000 },
      ],
      socialSecurityConsumesCap: true,
      fullSsFromAge: 65,
      // HB24-1142, effective tax year 2025.
      fullSsBelowAgi: { fromAge: 55, single: 75000, joint: 95000 },
      includesPreTaxWithdrawals: true,
    },
    notes: 'Pension/annuity subtraction is capped at $20,000 (ages 55-64) and $24,000 (65+), with Social Security consuming the cap first. Caps are applied once to the household using the primary person age, not per taxpayer. SB25-136, which would have removed the caps from 2026, was postponed indefinitely on 2025-02-27 and is NOT law. Verify against form DR 0104AD.',
  },
  { code: 'NONE', name: 'No State Tax (AK, FL, NV, SD, TN, TX, WA, WY)', kind: 'none', ratePct: 0, supported: true },
  { code: 'CUSTOM', name: 'Custom Rate', kind: 'custom', ratePct: 0, supported: true },
  {
    code: 'CA',
    name: 'California (Progressive ~6.0% approx)',
    kind: 'progressive',
    ratePct: 6.0,
    supported: true,
    progressiveNotModelled: true,
    notes: 'California uses progressive tax brackets (1% to 13.3%). Modeled as an estimated flat rate.',
  },
  {
    code: 'NY',
    name: 'New York (Progressive ~6.5% approx)',
    kind: 'progressive',
    ratePct: 6.5,
    supported: true,
    progressiveNotModelled: true,
    notes: 'New York uses progressive tax brackets (4% to 10.9%). Modeled as an estimated flat rate.',
  },
  {
    code: 'NJ',
    name: 'New Jersey (Progressive ~5.5% approx)',
    kind: 'progressive',
    ratePct: 5.5,
    supported: true,
    progressiveNotModelled: true,
    notes: 'New Jersey uses progressive tax brackets (1.4% to 10.75%). Modeled as an estimated flat rate.',
  },
  { code: 'IL', name: 'Illinois (4.95% flat)', kind: 'flat', ratePct: 4.95, supported: true },
  { code: 'PA', name: 'Pennsylvania (3.07% flat)', kind: 'flat', ratePct: 3.07, supported: true },
  { code: 'IN', name: 'Indiana (3.05% flat)', kind: 'flat', ratePct: 3.05, supported: true },
  { code: 'NC', name: 'North Carolina (4.5% flat)', kind: 'flat', ratePct: 4.5, supported: true },
  { code: 'AZ', name: 'Arizona (2.5% flat)', kind: 'flat', ratePct: 2.5, supported: true },
  { code: 'MI', name: 'Michigan (4.25% flat)', kind: 'flat', ratePct: 4.25, supported: true },
  { code: 'GA', name: 'Georgia (5.49% flat)', kind: 'flat', ratePct: 5.49, supported: true },
];

export function findStateRule(code?: string): StateTaxRule {
  if (!code) return STATE_TAX_RULES[0]; // Documented default baseline CO
  const upper = code.toUpperCase();
  const found = STATE_TAX_RULES.find(r => r.code === upper);
  if (found) return found;
  // If user passed AK, FL, NV, SD, TN, TX, WA, WY directly
  if (['AK', 'FL', 'NV', 'SD', 'TN', 'TX', 'WA', 'WY'].includes(upper)) {
    return STATE_TAX_RULES.find(r => r.code === 'NONE')!;
  }
  // Unknown or unmodeled state: return explicit unsupported state rule (NOT Colorado!)
  return {
    ...UNSUPPORTED_STATE_TAX_RULE,
    code: upper,
    name: `Unsupported State (${upper})`,
  };
}

export interface StateTaxInput {
  ordinaryTaxable: number;
  realizedCapGains: number;
  taxableSocialSecurity: number;
  rule: StateTaxRule;
  customRatePct?: number;
  // --- Inputs for retirement-income subtractions. Optional so callers that cannot
  // --- supply them (e.g. accumulation years) get the pre-subtraction behaviour. ---
  /** Primary person's age at the close of the tax year. */
  primaryAge?: number;
  /** Pension and annuity income included in federal taxable income. */
  pensionIncome?: number;
  /** Pre-tax IRA/401(k) withdrawals, which Colorado treats as pension income. */
  preTaxWithdrawals?: number;
  /** Household AGI, for income-tested subtractions. */
  agi?: number;
  isJoint?: boolean;
}

/** Cap applying to the primary person's age, or 0 when no band matches. */
export function subtractionCapForAge(
  subtraction: RetirementSubtraction,
  age: number,
): number {
  const band = subtraction.bands.find(
    (b) => age >= b.minAge && (b.maxAge === undefined || age <= b.maxAge),
  );
  return band?.cap ?? 0;
}

/**
 * Retirement-income subtraction for the year.
 *
 * ORDERING (Colorado): Social Security is considered first, then other pension and
 * annuity income including pre-tax IRA/401(k) withdrawals. From age 65 Social Security
 * is subtracted in full regardless of the cap, and the cap then applies to the
 * remaining pension income. Below 65 the cap covers both, unless AGI is under the
 * HB24-1142 thresholds in which case Social Security is again fully subtracted.
 *
 * NOTE: sources differ on whether the 65+ full Social Security subtraction sits outside
 * the cap or consumes it. This implements "outside the cap", following the statutory
 * "notwithstanding the caps" language. If your DR 0104AD worksheet says otherwise, this
 * is the single place to change it.
 */
export function calculateRetirementSubtraction(input: StateTaxInput): number {
  const { rule, primaryAge, taxableSocialSecurity, pensionIncome = 0, preTaxWithdrawals = 0, agi, isJoint } = input;
  const sub = rule.retirementSubtraction;
  if (!sub || primaryAge === undefined) return 0;

  const cap = subtractionCapForAge(sub, primaryAge);
  if (cap <= 0) return 0;

  const eligiblePension =
    pensionIncome + (sub.includesPreTaxWithdrawals ? preTaxWithdrawals : 0);

  // Is Social Security fully subtractable outside the cap this year?
  let ssOutsideCap = false;
  if (sub.fullSsFromAge !== undefined && primaryAge >= sub.fullSsFromAge) {
    ssOutsideCap = true;
  } else if (sub.fullSsBelowAgi && primaryAge >= sub.fullSsBelowAgi.fromAge) {
    const threshold = isJoint ? sub.fullSsBelowAgi.joint : sub.fullSsBelowAgi.single;
    if ((agi ?? Infinity) <= threshold) ssOutsideCap = true;
  }

  if (ssOutsideCap) {
    return taxableSocialSecurity + Math.min(cap, eligiblePension);
  }

  // Cap covers Social Security first, then pension income.
  if (!sub.socialSecurityConsumesCap) {
    return Math.min(cap, eligiblePension);
  }
  const ssPortion = Math.min(cap, taxableSocialSecurity);
  const remaining = Math.max(0, cap - ssPortion);
  return ssPortion + Math.min(remaining, eligiblePension);
}

export function calculateStateTax(input: StateTaxInput): number {
  const { rule, customRatePct, ordinaryTaxable, realizedCapGains, taxableSocialSecurity } = input;
  const ratePct =
    rule.kind === 'none' || rule.kind === 'unsupported' || rule.supported === false
      ? 0
      : rule.kind === 'custom'
      ? (customRatePct ?? 0)
      : rule.ratePct;

  if (ratePct === 0) {
    return 0;
  }

  let base = ordinaryTaxable;

  if (rule.retirementSubtraction) {
    // States with an explicit subtraction handle Social Security through it, so the
    // blanket taxesSocialSecurity flag is not applied as well.
    base -= calculateRetirementSubtraction(input);
  } else if (!rule.taxesSocialSecurity) {
    // The federally taxable SS is already inside ordinaryTaxable; remove it.
    base -= taxableSocialSecurity;
  }

  if (rule.taxesCapitalGainsAsOrdinary) {
    base += realizedCapGains;
  }

  return Math.round(Math.max(0, base) * (ratePct / 100));
}
