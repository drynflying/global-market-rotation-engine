import { describe, it, expect } from 'vitest';
import { syncSocialSecurityStreams, ssStreamsAreStale } from './ssStreamSync';
import { DEFAULT_PLAN } from '../../constants/defaultPlan';

describe('syncSocialSecurityStreams', () => {
  it('updates SS stream amount and ages when person profile changes', () => {
    const plan = JSON.parse(JSON.stringify(DEFAULT_PLAN));
    const primary = { ...plan.primaryPerson, ssClaimAge: 70 };

    const synced = syncSocialSecurityStreams(plan.incomeStreams, primary, plan.spousePerson);
    const ssStream = synced.find(s => s.type === 'social_security' && s.owner === 'primary')!;

    expect(ssStream.startAge).toBe(70);
    // Benefit claiming at 70 vs 67 FRA should be higher than standard FRA amount ($36,000)
    expect(ssStream.amount).toBeGreaterThan(36000);
  });

  it('detects stale streams', () => {
    const plan = JSON.parse(JSON.stringify(DEFAULT_PLAN));
    expect(ssStreamsAreStale(plan)).toBe(false);

    plan.primaryPerson.ssClaimAge = 70;
    expect(ssStreamsAreStale(plan)).toBe(true);
  });
});
