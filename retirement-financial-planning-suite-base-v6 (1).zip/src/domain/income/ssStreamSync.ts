import type { IncomeStream, Plan, UserProfile } from '../../types';
import { getSsAnnualBenefit } from '../kernel';

/**
 * Returns true if any social_security stream on the plan differs from what the primary
 * or spouse profile currently produces for age, startAge, endAge, or calculated benefit.
 */
export function ssStreamsAreStale(plan: Plan): boolean {
  const primary = plan.primaryPerson;
  const spouse = plan.hasSpouse ? plan.spousePerson : undefined;

  for (const stream of plan.incomeStreams || []) {
    if (stream.type !== 'social_security') continue;

    const profile = stream.owner === 'spouse' ? spouse : primary;
    if (!profile) continue;

    const expectedAnnual = getSsAnnualBenefit(profile, profile.ssClaimAge, plan.statutoryParams, false);
    const expectedStart = profile.ssClaimAge;
    const expectedEnd = profile.lifeExpectancy;

    if (
      stream.amount !== expectedAnnual ||
      stream.startAge !== expectedStart ||
      stream.endAge !== expectedEnd
    ) {
      return true;
    }
  }

  return false;
}

/**
 * Recalculates every social_security IncomeStream from the current primary and spouse
 * profiles (claiming age, benefit at FRA, life expectancy) and returns a updated
 * IncomeStream array. Non-SS streams are left untouched.
 */
export function syncSocialSecurityStreams(
  streams: IncomeStream[],
  primary: UserProfile,
  spouse?: UserProfile
): IncomeStream[] {
  return streams.map(stream => {
    if (stream.type !== 'social_security') return stream;

    const profile = stream.owner === 'spouse' ? spouse : primary;
    if (!profile) return stream;

    return {
      ...stream,
      amount: getSsAnnualBenefit(profile, profile.ssClaimAge, undefined, false),
      startAge: profile.ssClaimAge,
      endAge: profile.lifeExpectancy,
    };
  });
}
