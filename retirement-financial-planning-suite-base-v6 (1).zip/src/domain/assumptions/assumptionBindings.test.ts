import { describe, it, expect } from 'vitest';
import { ASSUMPTION_BINDINGS, findBinding } from './assumptionBindings';
import { createDefaultPlan } from '../../constants/defaultPlan';

describe('ASSUMPTION_BINDINGS', () => {
  it('round-trips format and parse for every binding', () => {
    const testValues: Record<string, number> = {
      'asm-cpi-inflation': 2.5,
      'asm-medical-cpi': 5.0,
      'asm-nawi-wage-growth': 3.0,
      'asm-401k-limit': 24500,
      'asm-hsa-limits': 8750,
      'asm-tax-brackets': 32200,
      'asm-medicare-irmaa-rmd': 75,
    };

    for (const binding of ASSUMPTION_BINDINGS) {
      const val = testValues[binding.id];
      expect(val).toBeDefined();
      const formatted = binding.format(val);
      const parsed = binding.parse(formatted);
      expect(parsed).toBe(val);
    }
  });

  it('matches each display string against the value in defaultPlan', () => {
    const plan = createDefaultPlan();
    const assumptions = plan.assumptions || [];

    for (const binding of ASSUMPTION_BINDINGS) {
      const item = assumptions.find(a => a.id === binding.id);
      expect(item).toBeDefined();

      const parsed = binding.parse(item!.currentValue);
      expect(parsed).not.toBeNull();

      const macroRecord = plan.macroAssumptions as unknown as Record<string, number>;
      const statutoryRecord = plan.statutoryParams as unknown as Record<string, number>;

      const expectedVal =
        binding.target === 'macro'
          ? macroRecord[binding.field]
          : statutoryRecord[binding.field];

      expect(parsed).toBe(expectedVal);
    }
  });
});

describe('display strings agree with the stored plan values', () => {
  it('parses each default assumption string back to its stored field value', () => {
    const plan = createDefaultPlan();
    const macro = plan.macroAssumptions as unknown as Record<string, number>;
    const stat = plan.statutoryParams as unknown as Record<string, number>;

    for (const item of plan.assumptions || []) {
      const binding = findBinding(item.id);
      if (!binding) continue;
      const parsed = binding.parse(item.currentValue);
      const stored = binding.target === 'macro' ? macro[binding.field] : stat[binding.field];
      expect(
        parsed,
        `assumption "${item.id}" disagrees with ${binding.target}.${binding.field}`,
      ).toBe(stored);
    }
  });

  it('anchors dollar parsing to its label, not the first amount in the string', () => {
    const b = findBinding('asm-401k-limit')!;
    expect(b.parse('IRA: $7,000 first; 401(k) Deferral: $23,500 later')).toBe(23500);
  });
});

