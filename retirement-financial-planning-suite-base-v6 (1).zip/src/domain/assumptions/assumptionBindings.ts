/**
 * Bindings between the assumptions table (display strings) and the typed plan fields.
 *
 * The assumptions table stores each value as a human-readable sentence, e.g.
 * "2.00% Long-Term Annual Inflation". The component previously formatted those strings
 * in one place and recovered the numbers with ad-hoc regexes in another, so the two
 * directions could disagree and nothing detected it.
 *
 * One live example: the RMD row read "RMD Age 73" while statutoryParams.rmdStartAge was
 * 75. Because the sync handler re-parses EVERY row whenever ANY row is edited, editing
 * an unrelated assumption silently reset the RMD age back to 73.
 *
 * Declaring format and parse together as a pair makes that class of drift testable:
 * see assumptionBindings.test.ts, which round-trips every binding and checks each one
 * against the value actually stored in the default plan.
 */

import { IRMAA_REGISTRY } from '../registry/statutoryRegistry';

export type BindingTarget = 'macro' | 'statutory';

export interface AssumptionBinding {
  /** PlanAssumptionResource.id this binding applies to. */
  id: string;
  target: BindingTarget;
  /** Field name on macroAssumptions or statutoryParams. */
  field: string;
  /** Render the typed value as the display string. */
  format: (value: number) => string;
  /** Recover the typed value, or null when the string does not match. */
  parse: (display: string) => number | null;
}

const pct = (suffix: string) => ({
  format: (v: number) => `${v.toFixed(2)}% ${suffix}`,
  parse: (s: string) => {
    const m = s.match(/^([\d.]+)\s*%/);
    return m ? parseFloat(m[1]) : null;
  },
});

const money = (re: RegExp) => (s: string) => {
  const m = s.match(re);
  return m ? parseInt(m[1].replace(/,/g, ''), 10) : null;
};

const usd = (n: number) => `$${n.toLocaleString('en-US')}`;

export const ASSUMPTION_BINDINGS: readonly AssumptionBinding[] = [
  {
    id: 'asm-cpi-inflation',
    target: 'macro',
    field: 'generalInflation',
    ...pct('Long-Term Annual Inflation'),
  },
  {
    id: 'asm-medical-cpi',
    target: 'macro',
    field: 'medicalInflation',
    ...pct('Medical Inflation Rate'),
  },
  {
    id: 'asm-nawi-wage-growth',
    target: 'macro',
    field: 'nationalWageGrowth',
    ...pct('Annual Wage Growth Rate'),
  },
  {
    id: 'asm-401k-limit',
    target: 'statutory',
    field: 'deferralLimit401k',
    format: (v) => `401(k) Deferral: ${usd(v)} + $8,000 Catch-up; IRA: $7,500 + $1,100 Catch-up`,
    parse: money(/401\(k\)[^$]*\$([\d,]+)/i),
  },
  {
    id: 'asm-hsa-limits',
    target: 'statutory',
    field: 'hsaFamilyLimit',
    format: (v) => `HSA Family: ${usd(v)}; HSA Single: $4,400; Catch-up (55+): $1,000`,
    parse: money(/HSA Family:\s*\$([\d,]+)/),
  },
  {
    id: 'asm-tax-brackets',
    target: 'statutory',
    field: 'standardDeductionJoint',
    format: (v) => `${usd(v)} Joint (MFJ) / ${usd(Math.round(v / 2))} Single`,
    parse: money(/\$([\d,]+)/),
  },
  {
    id: 'asm-medicare-irmaa-rmd',
    target: 'statutory',
    field: 'rmdStartAge',
    format: (v) => `RMD Age ${v}; Joint IRMAA Tier 1 Threshold: ${usd(IRMAA_REGISTRY.thresholds.joint[0])} MAGI`,
    parse: (s) => {
      const m = s.match(/RMD Age (\d+)/i);
      return m ? parseInt(m[1], 10) : null;
    },
  },
];

export const findBinding = (id: string): AssumptionBinding | undefined =>
  ASSUMPTION_BINDINGS.find(b => b.id === id);
