import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, signInAnonymously, onAuthStateChanged, User } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

const dbId = firebaseConfig.firestoreDatabaseId && firebaseConfig.firestoreDatabaseId !== '(default)'
  ? firebaseConfig.firestoreDatabaseId
  : undefined;

export const db = dbId ? getFirestore(app, dbId) : getFirestore(app);
export const auth = getAuth(app);

/**
 * Resolves once anonymous auth has completed and a uid is available.
 *
 * signInAnonymously was previously fired and forgotten, so any Firestore call made
 * during startup could execute with auth.currentUser still null. Under the old
 * permissive rules that silently succeeded; under per-user rules it would fail. Every
 * data access must await this first.
 *
 * Resolves to null rather than rejecting when auth is unavailable, so the app degrades
 * to local-only storage instead of breaking.
 */
export const authReady: Promise<User | null> = new Promise((resolve) => {
  const unsubscribe = onAuthStateChanged(auth, (user) => {
    if (user) {
      unsubscribe();
      resolve(user);
    }
  });

  signInAnonymously(auth).catch((err) => {
    console.warn('Firebase anonymous auth unavailable; cloud sync disabled:', err);
    unsubscribe();
    resolve(null);
  });
});

/** Current uid, or null if auth has not completed or is unavailable. */
export async function getUid(): Promise<string | null> {
  const user = await authReady;
  return user?.uid ?? null;
}
