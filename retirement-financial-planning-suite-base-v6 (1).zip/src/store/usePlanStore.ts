import { create } from 'zustand';
import { Plan, ValidationResult } from '../types';
import { TabId, resolveTabId } from '../constants/tabs';
import { createDefaultPlan } from '../constants/defaultPlan';
import { planRepository } from '../services/planRepository';
import { cloudSyncManager, SyncStatus } from '../services/cloudSyncManager';
import { runPlanValidations } from '../domain/validation/validations';
import { migratePlan } from '../utils/planMigration';
import { CURRENT_PLAN_SCHEMA_VERSION } from '../schemas/planSchema';
import { resolvePlanSync, applySyncResolution } from '../services/planSyncResolver';

/**
 * Feature flag for the Firestore snapshot merge on load.
 * CRITICAL GUARD: Multi-device merge MUST NOT be enabled until deletion/tombstone semantics
 * (e.g. `deletedAt` metadata / explicit tombstone tracking) are implemented to prevent stale
 * secondary devices from resurrecting deleted local plans.
 */
export const ENABLE_CLOUD_MERGE = false;

/**
 * Undo history depth. Each entry is a whole Plan object; twenty is a few megabytes at
 * most and covers far more than anyone reaches back for in practice.
 */
const UNDO_DEPTH = 20;

/**
 * Options for updatePlan.
 *
 * `label` names the change for the undo affordance ("Undo: reset CMA assumptions").
 * `coalesce` is for multi-field operations — a reset that clears forty values must be
 * ONE undo entry, not forty. Scenario operations (create/duplicate/remove) deliberately
 * do NOT record history: they change which plans exist rather than the contents of one,
 * and resurrecting a deleted plan via the same keystroke that reverts a typo would be
 * surprising. Deletion gets its own confirmation instead.
 */
export interface UpdateOptions {
  label?: string;
  /** When true, replaces the top history entry instead of pushing a new one. */
  coalesce?: boolean;
  /** Skip history entirely (used by internal reconciliation, not user edits). */
  skipHistory?: boolean;
}

interface PlanStoreState {
  plans: Plan[];
  activePlanId: string;
  activePlan: Plan | null;
  activeTab: TabId;
  validations: ValidationResult[];
  validationSummary: { pass: number; warning: number; fail: number };
  syncStatus: SyncStatus;
  isCloudSynced: boolean;

  /** Previous states of the ACTIVE plan, newest last. Cleared when switching plans. */
  undoStack: { plan: Plan; label: string }[];
  /** Monotonic counter bumped on every successful write; drives the saved indicator. */
  lastSavedAt: number;
  lastSavedLabel: string;

  // Actions
  loadPlans: () => void;
  selectPlan: (id: string) => void;
  updatePlan: (updated: Plan, options?: UpdateOptions) => void;
  undo: () => void;
  canUndo: () => boolean;
  peekUndoLabel: () => string | null;
  createPlan: (name: string, description?: string) => Plan;
  duplicatePlan: (p: Plan, newName?: string) => Plan;
  removePlan: (id: string) => void;
  resetSample: () => void;
  exportPlan: () => void;
  importPlan: (jsonStr: string) => boolean;
  setActiveTab: (tab: TabId) => void;
  flushCloudSync: () => Promise<void>;
}

const computeValidations = (plan: Plan | null) => {
  if (!plan) {
    return {
      validations: [],
      summary: { pass: 0, warning: 0, fail: 0 }
    };
  }
  const valList = runPlanValidations(plan);
  const summary = {
    pass: valList.filter(v => v.status === 'pass').length,
    warning: valList.filter(v => v.status === 'warning').length,
    fail: valList.filter(v => v.status === 'fail').length,
  };
  return { validations: valList, summary };
};

export const usePlanStore = create<PlanStoreState>((set, get) => ({
  plans: [],
  activePlanId: '',
  activePlan: null,
  // Migrated through resolveTabId so a persisted legacy id ('step4' and friends) lands
  // on the renamed tab rather than a blank screen.
  activeTab: resolveTabId(
    typeof localStorage !== 'undefined' ? localStorage.getItem('meridian_active_tab') : null,
  ),
  validations: [],
  validationSummary: { pass: 0, warning: 0, fail: 0 },
  syncStatus: 'local-only',
  isCloudSynced: false,
  undoStack: [],
  lastSavedAt: 0,
  lastSavedLabel: '',

  flushCloudSync: async () => {
    await cloudSyncManager.flush();
  },

  loadPlans: () => {
    // 1. Initial local load from repository
    const loadedPlans = planRepository.getPlans();
    const activeId = planRepository.getActivePlanId();
    const current = loadedPlans.find(p => p.id === activeId) || loadedPlans[0] || null;
    const { validations, summary } = computeValidations(current);

    set({
      plans: loadedPlans,
      activePlanId: activeId,
      activePlan: current,
      validations,
      validationSummary: summary
    });

    // 2. Initialize cloud sync lifecycle idempotently
    cloudSyncManager.initialize((status) => {
      set({
        syncStatus: status,
        isCloudSynced: status === 'synced',
      });
    });

    // 3. Queue initial sync for current plan
    if (current) {
      cloudSyncManager.enqueueSync(current);
    }

    // 4. Subscription to cloud updates (if merge enabled)
    if (!ENABLE_CLOUD_MERGE) {
      return;
    }

    planRepository.subscribeToCloudPlans((cloudPlans) => {
      const localPlans = planRepository.getPlans();
      const currentActiveId = get().activePlanId || planRepository.getActivePlanId();

      // Resolve sync conflicts before mutating localStorage or state
      const syncResult = resolvePlanSync(localPlans, cloudPlans, currentActiveId);

      // Apply persistent storage side-effects asynchronously
      void applySyncResolution(syncResult);

      const active = syncResult.mergedPlans.find(p => p.id === syncResult.activePlanIdToKeep) || syncResult.mergedPlans[0] || null;

      if (active) {
        planRepository.setActivePlanId(active.id);
      }

      const valRes = computeValidations(active);

      set({
        plans: syncResult.mergedPlans,
        activePlanId: active ? active.id : '',
        activePlan: active,
        validations: valRes.validations,
        validationSummary: valRes.summary,
        syncStatus: 'synced',
        isCloudSynced: true,
      });
    });
  },

  selectPlan: (id: string) => {
    /**
     * Initiates flush of pending cloud changes for the previous plan while
     * allowing the local UI to switch immediately. Any pending write for the
     * previous plan remains independently queued in CloudSyncManager and will
     * complete asynchronously without being lost or overwritten.
     */
    void cloudSyncManager.flush();

    set({ undoStack: [] });
    planRepository.setActivePlanId(id);
    const plans = get().plans;
    const selected = plans.find(p => p.id === id) || null;
    const { validations, summary } = computeValidations(selected);

    set({
      activePlanId: id,
      activePlan: selected,
      validations,
      validationSummary: summary
    });
  },

  updatePlan: (updated: Plan, options: UpdateOptions = {}) => {
    const { label = 'change', coalesce = false, skipHistory = false } = options;
    const prev = get().activePlan;

    const now = new Date().toISOString();
    const savedPlan: Plan = {
      ...updated,
      schemaVersion: CURRENT_PLAN_SCHEMA_VERSION,
      createdAt: updated.createdAt || (prev?.id === updated.id ? prev.createdAt : now),
      updatedAt: now,
    };

    void planRepository.savePlan(savedPlan);

    const updatedPlans = get().plans.map(p => (p.id === savedPlan.id ? savedPlan : p));
    const { validations, summary } = computeValidations(savedPlan);

    let undoStack = get().undoStack;
    if (!skipHistory && prev && prev.id === savedPlan.id) {
      if (coalesce && undoStack.length > 0) {
        undoStack = [...undoStack.slice(0, -1), { plan: undoStack[undoStack.length - 1].plan, label }];
      } else {
        undoStack = [...undoStack, { plan: prev, label }].slice(-UNDO_DEPTH);
      }
    }

    set({
      activePlan: savedPlan,
      plans: updatedPlans.length ? updatedPlans : planRepository.getPlans(),
      validations,
      validationSummary: summary,
      undoStack,
      lastSavedAt: Date.now(),
      lastSavedLabel: label,
    });
  },

  undo: () => {
    const stack = get().undoStack;
    if (stack.length === 0) return;
    const { plan: restored } = stack[stack.length - 1];

    const now = new Date().toISOString();
    const savedPlan: Plan = {
      ...restored,
      updatedAt: now,
    };

    void planRepository.savePlan(savedPlan);
    const updatedPlans = get().plans.map(p => (p.id === savedPlan.id ? savedPlan : p));
    const { validations, summary } = computeValidations(savedPlan);

    set({
      activePlan: savedPlan,
      plans: updatedPlans,
      validations,
      validationSummary: summary,
      undoStack: stack.slice(0, -1),
      lastSavedAt: Date.now(),
      lastSavedLabel: 'undo',
    });
  },

  canUndo: () => get().undoStack.length > 0,

  peekUndoLabel: () => {
    const stack = get().undoStack;
    return stack.length ? stack[stack.length - 1].label : null;
  },

  createPlan: (name: string, description?: string) => {
    const template: Plan = createDefaultPlan();
    const now = new Date().toISOString();
    const newPlan: Plan = {
      ...template,
      id: `plan-${Date.now()}`,
      planKind: 'user',
      name: name || 'New Financial Plan',
      description: description || 'Custom retirement and wealth accumulation scenario',
      createdAt: now,
      updatedAt: now,
    };

    void planRepository.savePlan(newPlan);
    planRepository.setActivePlanId(newPlan.id);
    const updatedPlans = planRepository.getPlans();
    const { validations, summary } = computeValidations(newPlan);

    set({
      plans: updatedPlans,
      activePlanId: newPlan.id,
      activePlan: newPlan,
      validations,
      validationSummary: summary
    });
    return newPlan;
  },

  duplicatePlan: (p: Plan, newName?: string) => {
    const now = new Date().toISOString();
    const cloned: Plan = {
      ...JSON.parse(JSON.stringify(p)),
      id: `plan-${Date.now()}`,
      planKind: 'user',
      name: newName || `${p.name} (Copy)`,
      createdAt: now,
      updatedAt: now,
    };

    void planRepository.savePlan(cloned);
    planRepository.setActivePlanId(cloned.id);
    const updatedPlans = planRepository.getPlans();
    const { validations, summary } = computeValidations(cloned);

    set({
      plans: updatedPlans,
      activePlanId: cloned.id,
      activePlan: cloned,
      validations,
      validationSummary: summary
    });
    return cloned;
  },

  removePlan: (id: string) => {
    void cloudSyncManager.flush().then(() => {
      planRepository.deletePlan(id).then(remaining => {
        const activeId = planRepository.getActivePlanId();
        const nextActive = remaining.find(p => p.id === activeId) || remaining[0] || null;
        const { validations, summary } = computeValidations(nextActive);

        set({
          plans: remaining,
          activePlanId: nextActive ? nextActive.id : '',
          activePlan: nextActive,
          validations,
          validationSummary: summary
        });
      });
    });
  },

  resetSample: () => {
    void cloudSyncManager.flush().then(() => {
      const activePlanId = get().activePlanId;
      planRepository.resetSamplePlan(activePlanId).then(resetP => {
        const updatedPlans = planRepository.getPlans();
        const { validations, summary } = computeValidations(resetP);

        set({
          plans: updatedPlans,
          activePlanId: resetP.id,
          activePlan: resetP,
          validations,
          validationSummary: summary
        });
      });
    });
  },

  exportPlan: () => {
    const activePlan = get().activePlan;
    if (!activePlan) return;
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(activePlan, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `${activePlan.name.toLowerCase().replace(/\s+/g, '_')}_plan.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  },

  importPlan: (jsonStr: string) => {
    try {
      const parsed = JSON.parse(jsonStr);
      const validPlan = migratePlan(parsed);
      const now = new Date().toISOString();
      const importedPlan: Plan = {
        ...validPlan,
        id: `plan-imported-${Date.now()}`,
        planKind: 'user',
        createdAt: now,
        updatedAt: now,
      };

      void planRepository.savePlan(importedPlan);
      planRepository.setActivePlanId(importedPlan.id);

      const updatedPlans = planRepository.getPlans();
      const { validations, summary } = computeValidations(importedPlan);

      set({
        plans: updatedPlans,
        activePlanId: importedPlan.id,
        activePlan: importedPlan,
        validations,
        validationSummary: summary
      });
      return true;
    } catch {
      if (typeof window !== 'undefined' && typeof window.alert === 'function') {
        window.alert('Invalid plan structure or failed to parse JSON file.');
      }
      return false;
    }
  },

  setActiveTab: (tab: TabId) => {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('meridian_active_tab', tab);
    }
    set({ activeTab: tab });
  },
}));

/**
 * Idempotently initialize cloud persistence lifecycle handlers and status subscription.
 * Returns a disposer function to clean up listeners when needed.
 */
export const initializeCloudSyncLifecycle = (): (() => void) => {
  return cloudSyncManager.initialize((status) => {
    usePlanStore.setState({
      syncStatus: status,
      isCloudSynced: status === 'synced',
    });
  });
};
