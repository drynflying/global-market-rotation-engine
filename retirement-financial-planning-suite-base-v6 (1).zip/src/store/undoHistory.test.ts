import { describe, it, expect, beforeEach } from 'vitest';

// In-memory localStorage mock for node test environment
if (typeof globalThis.localStorage === 'undefined') {
  const store = new Map<string, string>();
  globalThis.localStorage = {
    getItem: (key: string) => store.get(key) ?? null,
    setItem: (key: string, value: string) => store.set(key, String(value)),
    removeItem: (key: string) => store.delete(key),
    clear: () => store.clear(),
    get length() {
      return store.size;
    },
    key: (index: number) => Array.from(store.keys())[index] ?? null,
  } as Storage;
}

import { usePlanStore } from './usePlanStore';
import { createDefaultPlan } from '../constants/defaultPlan';
import { planRepository } from '../services/planRepository';

describe('usePlanStore undo history', () => {
  beforeEach(() => {
    // Reset Zustand store state
    const defaultPlan = createDefaultPlan();
    defaultPlan.id = 'plan-test-1';
    defaultPlan.name = 'Test Plan';
    planRepository.savePlan(defaultPlan);
    planRepository.setActivePlanId(defaultPlan.id);

    usePlanStore.setState({
      plans: [defaultPlan],
      activePlanId: defaultPlan.id,
      activePlan: defaultPlan,
      undoStack: [],
      lastSavedAt: 0,
      lastSavedLabel: '',
    });
  });

  it('records history on updatePlan and enables undo', () => {
    const store = usePlanStore.getState();
    const initialPlan = store.activePlan!;

    expect(usePlanStore.getState().canUndo()).toBe(false);
    expect(usePlanStore.getState().peekUndoLabel()).toBeNull();

    const updatedPlan = {
      ...initialPlan,
      name: 'Updated Plan Name',
    };

    usePlanStore.getState().updatePlan(updatedPlan, { label: 'edit plan name' });

    expect(usePlanStore.getState().canUndo()).toBe(true);
    expect(usePlanStore.getState().peekUndoLabel()).toBe('edit plan name');
    expect(usePlanStore.getState().activePlan?.name).toBe('Updated Plan Name');

    // Perform undo
    usePlanStore.getState().undo();

    expect(usePlanStore.getState().activePlan?.name).toBe('Test Plan');
    expect(usePlanStore.getState().canUndo()).toBe(false);
    expect(usePlanStore.getState().lastSavedLabel).toBe('undo');
  });

  it('coalesces updates when coalesce flag is true', () => {
    const initialPlan = usePlanStore.getState().activePlan!;

    const edit1 = { ...initialPlan, name: 'Edit 1' };
    usePlanStore.getState().updatePlan(edit1, { label: 'first edit' });

    expect(usePlanStore.getState().undoStack.length).toBe(1);

    const edit2 = { ...initialPlan, name: 'Edit 2 Coalesced' };
    usePlanStore.getState().updatePlan(edit2, { label: 'coalesced edit', coalesce: true });

    // Length should remain 1, holding initial plan state before the multi-field operation
    expect(usePlanStore.getState().undoStack.length).toBe(1);
    expect(usePlanStore.getState().peekUndoLabel()).toBe('coalesced edit');

    usePlanStore.getState().undo();
    expect(usePlanStore.getState().activePlan?.name).toBe('Test Plan');
  });

  it('skips history when skipHistory is true', () => {
    const initialPlan = usePlanStore.getState().activePlan!;
    const edit = { ...initialPlan, name: 'Internal Edit' };

    usePlanStore.getState().updatePlan(edit, { skipHistory: true });

    expect(usePlanStore.getState().canUndo()).toBe(false);
    expect(usePlanStore.getState().activePlan?.name).toBe('Internal Edit');
  });

  it('clears undo stack on plan selection switch', () => {
    const initialPlan = usePlanStore.getState().activePlan!;
    usePlanStore.getState().updatePlan({ ...initialPlan, name: 'Edited Plan' }, { label: 'edit' });

    expect(usePlanStore.getState().canUndo()).toBe(true);

    const plan2 = { ...createDefaultPlan(), id: 'plan-test-2', name: 'Plan 2' };
    usePlanStore.setState({ plans: [...usePlanStore.getState().plans, plan2] });

    usePlanStore.getState().selectPlan(plan2.id);

    expect(usePlanStore.getState().canUndo()).toBe(false);
    expect(usePlanStore.getState().activePlanId).toBe('plan-test-2');
  });

  it('caps undo stack depth at 20 entries', () => {
    const initialPlan = usePlanStore.getState().activePlan!;

    for (let i = 1; i <= 25; i++) {
      const updated = { ...initialPlan, name: `Edit ${i}` };
      usePlanStore.getState().updatePlan(updated, { label: `edit ${i}` });
    }

    expect(usePlanStore.getState().undoStack.length).toBe(20);
    expect(usePlanStore.getState().peekUndoLabel()).toBe('edit 25');
  });
});
