# Financial Engine Architecture & Automated Dependency Enforcement

This repository implements a deterministic financial projection engine for retirement planning with automated architectural dependency boundary enforcement.

## System Layer Boundaries & Dependency Rules

Automated enforcement is active via ESLint (`no-restricted-imports`, `no-restricted-globals`) and `scripts/check-architecture.ts` (`npm run check:arch`).

### Layer Rules Summary

1. **`domain/kernel`** (`src/domain/kernel`):
   - Pure statutory calculation kernels (tax, income, RMD, spending).
   - **Forbidden**: React (`react`, `react-dom`), components (`src/components`), Zustand/store (`src/store`), services (`src/services`), Firebase (`firebase`), `localStorage`/`sessionStorage`.

2. **`domain/registry`** (`src/domain/registry`):
   - Centralized statutory rules, constants, and parameter resolution.
   - **Forbidden**: UI/components, store, Firebase, upward dependencies on `domain/simulation` or `domain/analysis`.

3. **`domain/analysis`** (`src/domain/analysis`):
   - Post-simulation reporting and summary metrics.
   - **May depend on**: Domain result types (`SimulationRow`, `SimulationResult`).
   - **Forbidden**: UI/components, Firebase, persistence (`services`), store.

4. **`domain/simulation` & `domain/projection`** (`src/domain/simulation`, `src/domain/projection`):
   - Annual engine projection loops and roll-forward reconciliation.
   - **May depend on**: `domain/registry`, `domain/kernel`, `domain/strategy`.
   - **Forbidden**: Firebase, React, UI/components.

5. **`services/repositories`** (`src/services`):
   - Persistence layer isolating Firestore and local caching.
   - **Forbidden**: Direct re-implementation of statutory financial formulas (must delegate to `domain`).

6. **`components`** (`src/components`):
   - React UI layer.
   - **Forbidden**: Duplication of statutory financial formulas (must consume `src/domain` APIs and `STATUTORY_REGISTRY`).

## Validation Commands

```bash
# Check architectural dependency enforcement
npm run check:arch

# Run full verification suite (arch check + typecheck + lint + vitest)
npm run verify

# Individual checks
npm run typecheck
npm run lint
npm test
```
