# Strategy Layer Phase 2 Implementation Report: Configurable Withdrawal Ordering

## Executive Summary
Phase 2 of the Retirement Strategy Layer introduces configurable withdrawal ordering policies without introducing financial drift or breaking current projection baseline guarantees.

The application now supports three explicit, user-configurable withdrawal sequence policies:
1. **Taxable First** (`taxable_first`) — Default baseline: Cash -> Taxable Brokerage -> Pre-Tax -> Roth / Post-Tax.
2. **Pre-Tax First** (`pretax_first`) — Cash -> Pre-Tax -> Taxable Brokerage -> Roth / Post-Tax.
3. **Roth First** (`roth_first`) — Cash -> Roth / Post-Tax -> Taxable Brokerage -> Pre-Tax.

---

## Key Achievements & Deliverables

### 1. Schema & Data Pipeline Integration
* Extended `SpendingAssumptionsSchema` in `src/schemas/planSchema.ts` with `withdrawalPolicy?: z.enum(['taxable_first', 'pretax_first', 'roth_first'])`.
* Set default `withdrawalPolicy: 'taxable_first'` in `DEFAULT_PLAN` (`src/constants/defaultPlan.ts`).

### 2. Strategy Contracts & Resolver
* Defined `WithdrawalPolicyId`, `WithdrawalPolicyDefinition`, and `WITHDRAWAL_POLICIES` in `src/domain/strategy/strategyTypes.ts`.
* Updated `resolveRetirementStrategy()` (`src/domain/strategy/strategyResolver.ts`) to read `spending.withdrawalPolicy` and select the appropriate policy definition.

### 3. Solver & Executor Alignment
* Refactored `solveRetirementCashNeed()` in `src/domain/solver/solveRetirementCashNeed.ts` to iterate through `strategy.withdrawal.order` for cash gap draws and `reverseOrder` for cash excess trimming.
* Verified that `executeWithdrawalSequence()` in `src/domain/strategy/withdrawalSequence.ts` uses the exact same asset draw sequence, ensuring solver convergence matches actual execution.

### 4. Preservation of Invariants
* **RMD Precedence**: Mandatory RMDs are calculated and taken prior to discretionary withdrawals regardless of the selected policy.
* **Cost-Basis Accounting**: Proportional cost-basis and realized taxable capital gain math are preserved when drawing from taxable brokerage accounts.
* **Depletion Safety**: Exhausted account buckets fall back to subsequent buckets in the active policy order.

---

## Verification & Compliance

1. **Unit Test Suite**: Created `src/domain/strategy/withdrawalPolicy.test.ts` with 12 targeted tests covering:
   * Policy resolver correctness and invalid input fallbacks.
   * Solver and executor sequence ordering across all 3 policies.
   * Account depletion handling and tax gross-up convergence.
   * Full multi-year simulation zero-drift validation for `taxable_first`.
2. **Regression & Full Suite**: Ran 35 test files (421 total tests) — 100% passed.
3. **Architecture Verification**: `scripts/check-architecture.ts` passed with 0 violations.
4. **Type Check**: `npx tsc --noEmit` passed with 0 errors.
5. **Linter**: `npm run lint` passed with 0 errors.
6. **Production Build**: `npm run build` compiled successfully.
