# Prompt 12 Finalization Report: Financial Engine Reconciliation & Invariant Architecture

## 1. Overview & Summary
This document reports on the Prompt 12 finalization pass for the financial projection engine. The objectives of Prompt 12 were to resolve account withdrawal boundary edge cases (specifically the phantom taxable-brokerage withdrawal defect and executed-vs-requested withdrawal discrepancies), establish a single deterministic portfolio roll-forward equation across all projection paths, enforce authoritative audit fields without fallback reconstruction in row invariants, expand the invariant suite with deliberate negative tests for all 13 invariant codes, and confirm test suite integrity.

---

## 2. Defects Identified & Corrected

### 2.1 Phantom Taxable Brokerage Withdrawal Defect & Executed Withdrawal Accounting
* **Root Cause**:
  1. In `executeWithdrawalSequence` (`src/domain/strategy/withdrawalSequence.ts`), when a user requested a taxable withdrawal or tax payment that exceeded available cash + taxable brokerage balances, `drawBrokerage` was previously not capped at `taxableBrokerageBal`. This caused `taxableBrokerageBal` to go negative and created phantom taxable portfolio outflows.
  2. Additionally, `totalWithdrawals` (and the returned `taxableWd`, `preTaxWd`, `postTaxWd`) were computed directly from requested inputs rather than actual executed withdrawals. In asset-depletion years, this caused `SimulationRow` to report withdrawals that never actually occurred.
* **Correction**:
  - `drawBrokerage` is strictly capped at `taxableBrokerageBal` via `Math.min(taxableBrokerageBal, Math.max(0, totalTaxableOut - drawCash))`.
  - `actualTaxableWd` is explicitly calculated as `Math.min(reqTaxableWd, totalTaxableDrawn)`.
  - `actualPreTaxWd` is explicitly calculated as `Math.min(preTaxBal - actualRothConversion, reqPreTaxWd)`.
  - `actualPostTaxWd` is explicitly calculated as `Math.min(availPostTax, reqPostTaxWd)`.
  - `totalWithdrawals` is strictly calculated as `actualTaxableWd + actualPreTaxWd + actualPostTaxWd`.
  - `projectRetirementYear` populates `SimulationRow` (`taxableWd`, `preTaxWd`, `postTaxWd`, `totalWithdrawals`) exclusively from actual executed withdrawal results.
  - `conversionTaxPortfolioOutflow` when funded from taxable accounts is strictly calculated as `Math.max(0, Math.round(totalTaxableDrawn - actualTaxableWd))`, preventing phantom conversion tax portfolio outflows when taxable funds are exhausted.
  - Cost basis is reduced proportionally against actual brokerage drawn and is clamped at zero, ensuring `taxableBrokerageCostBasis >= 0`.
* **Regression Tests**: Verified via unit tests in `src/domain/strategy/withdrawalSequence.test.ts` covering requested taxable, pre-tax, Roth, and mixed insufficient-asset scenarios, ensuring reported source withdrawals equal actual asset reduction and depletion rows report zero withdrawals.

---

## 3. Deterministic Portfolio Roll-Forward Accounting Equation

The financial engine now operates under a single, non-ambiguous deterministic portfolio roll-forward accounting identity across working years, retirement years, and depletion years:

$$\text{totalPortfolio} = \text{beginningPortfolio} + \text{portfolioGrowth} + \text{totalContributions} - \text{totalWithdrawals} - \text{conversionTaxPortfolioOutflow} + \text{portfolioSurplus}$$

### Field Definitions & Semantics
1. **$\text{totalContributions}$**: $\text{preTaxContrib} + \text{postTaxContrib} + \text{taxableContrib}$. Captures all inbound savings contributions.
2. **$\text{totalWithdrawals}$**: $\text{taxableWd} + \text{preTaxWd} + \text{postTaxWd}$. Captures all standard portfolio cash distributions (actual executed values).
3. **$\text{conversionTaxPortfolioOutflow}$**: Represents conversion tax paid directly from taxable portfolio accounts outside of standard spending withdrawals.
4. **$\text{portfolioSurplus}$**: Reinvested cash flow surplus in retirement years ($\text{surplusReinvested}$). In working years, net cash flow is routed via contributions.

---

## 4. Authoritative Audit Fields & Removal of Fallback Reconstruction

### 4.1 Authoritative Engine Audit Fields
To prevent silent corruption or ambiguous reconstruction, `SimulationRow` explicitly includes:
* `rmdEligibleBalance`: Authoritative pre-tax account balance available at the beginning of RMD calculations.
* `preTaxAvailableBeforeConversion`: Authoritative pre-tax account balance available immediately prior to Roth conversion execution.
* `conversionTaxPortfolioOutflow`: Authoritative conversion tax paid directly from taxable portfolio assets.

### 4.2 Invariant Reconstruction Fallback Removal
In `src/domain/simulation/rowReconciliation.ts`:
* `INV_RMD_BOUNDS` evaluates `r.rmdEligibleBalance` directly without fallback arithmetic.
* `INV_ROTH_CONVERSION` evaluates `r.preTaxAvailableBeforeConversion` directly without fallback arithmetic.
* `INV_PORTFOLIO_ROLLFORWARD` evaluates `r.conversionTaxPortfolioOutflow` directly without fallback (`?? 0`).
* Any corrupted or non-finite value in these audit fields is flagged immediately by `INV_FINITE_NUMBERS` rather than being hidden by fallback arithmetic.

---

## 5. Non-Negative Field Contract & Enforcement Boundaries

### 5.1 Non-Negative Field Contract
All balance sheet, cash flow, tax, income, expense, and contribution fields must satisfy $x \ge 0$.
A threshold tolerance of $-0.01$ is enforced to accommodate minor IEEE 754 floating-point rounding.

### 5.2 Diagnostic vs. Runtime Enforcement
* **Runtime Layer**: Domain calculators (e.g. `executeWithdrawalSequence`, `projectWorkingYear`, `projectRetirementYear`) enforce non-negativity at runtime using exact availability bounds.
* **Diagnostic Layer**: `rowReconciliation.ts` executes `INV_NON_NEGATIVE` post-projection to verify that no downstream calculation or mutation introduced negative balances.

---

## 6. Comprehensive Invariant Suite & Deliberate Negative Tests

The test suite in `src/domain/simulation/invariantEngine.test.ts` includes dedicated negative test cases for every invariant code.

| Invariant Code | Accounting / Identity Formula Tested | Corruption Method in Negative Test | Test Result |
| :--- | :--- | :--- | :--- |
| `INV_PORTFOLIO_BUCKETS` | $\text{preTaxBal} + \text{postTaxBal} + \text{taxableBal} = \text{totalPortfolio}$ | $\text{totalPortfolio} \gets \text{totalPortfolio} + 100{,}000$ | **PASS** (Violation Detected) |
| `INV_TAX_COMPONENTS` | $\sum \text{taxComponents} = \text{totalEstimatedTax}$ | $\text{fedTaxPaid} \gets \text{fedTaxPaid} + 5{,}000$ | **PASS** (Violation Detected) |
| `INV_WITHDRAWAL_SOURCES` | $\text{taxableWd} + \text{preTaxWd} + \text{postTaxWd} = \text{totalWithdrawals}$ | $\text{taxableWd} \gets \text{taxableWd} + 5{,}000$ | **PASS** (Violation Detected) |
| `INV_GUARANTEED_INCOME` | $\text{primarySs} + \text{spouseSs} + \text{pension} = \text{guaranteedIncome}$ | $\text{primarySs} \gets \text{primarySs} + 5{,}000$ | **PASS** (Violation Detected) |
| `INV_EXPENSE_SPLIT` | $\text{essentialExpense} + \text{discretionaryExpense} = \text{totalExpenseNeed}$ | $\text{essentialExpense} \gets \text{essentialExpense} + 5{,}000$ (in retired row) | **PASS** (Violation Detected) |
| `INV_CASH_FLOW` | $\text{inflow} + \text{shortfall} = \text{outflow} + \text{surplus}$ | $\text{totalCashInflow} \gets \text{totalCashInflow} + 5{,}000$ | **PASS** (Violation Detected) |
| `INV_PORTFOLIO_ROLLFORWARD` (A) | Deterministic Roll-Forward Equation | Corrupt ending $\text{totalPortfolio}$ and $\text{preTaxBal}$ equally so bucket check passes but roll-forward fails | **PASS** (Violation Detected) |
| `INV_PORTFOLIO_ROLLFORWARD` (B) | Conversion Tax Outflow Accounting | Corrupt $\text{conversionTaxPortfolioOutflow} \gets +5{,}000$ in Roth conversion row | **PASS** (Violation Detected) |
| `INV_NON_NEGATIVE` | $\forall x \in \text{numericFields}, x \ge -0.01$ | $\text{preTaxBal} \gets -100$ | **PASS** (Violation Detected) |
| `INV_SURPLUS_CONSISTENCY` | $\text{surplus} > 0 \implies \text{shortfall} = 0$ | $\text{surplusReinvested} = 5{,}000, \text{unfundedShortfall} = 5{,}000$ | **PASS** (Violation Detected) |
| `INV_RMD_BOUNDS` | $\text{rmdAmount} \le \text{rmdEligibleBalance}$ | $\text{rmdAmount} \gets \text{rmdEligibleBalance} + 10{,}000$ | **PASS** (Violation Detected) |
| `INV_ROTH_CONVERSION` | $\text{rothConversion} \le \text{preTaxAvailableBeforeConversion}$ | $\text{rothConversion} \gets \text{preTaxAvailableBeforeConversion} + 10{,}000$ | **PASS** (Violation Detected) |
| `INV_FINITE_NUMBERS` | $\text{val} \neq \text{NaN}, \pm\infty$ | Test $\text{NaN}$, $\infty$, $-\infty$, including `rmdEligibleBalance`, `preTaxAvailableBeforeConversion`, & `conversionTaxPortfolioOutflow` | **PASS** (Violation Detected) |
| `INV_DEFLATION_CONSISTENCY` | $\text{totalPortfolioReal} = \text{totalPortfolio} / \text{deflator}$ | Test deflator $=1, >1, =0, <0$, and corrupted real total | **PASS** (Violation Detected) |

---

## 7. Edge Case Coverage & Deflator Validation

* **Deflator $= 1$**: Real portfolio equals nominal portfolio.
* **Deflator $> 1$**: Real portfolio equals $\text{round}(\text{totalPortfolio} / \text{deflator})$.
* **Deflator $= 0$ or $< 0$**: Handled gracefully by `INV_DEFLATION_CONSISTENCY` reporting an invariant violation without causing zero-division exceptions or `NaN` outputs.

---

## 8. Verification & Test Suite Metrics

All verification steps executed successfully with zero unexplained characterization changes:

* **Vitest Suite**: `386/386` tests passed across `32` test files.
* **TypeScript Typecheck (`tsc --noEmit`)**: Clean (0 errors).
* **Linter (`npm run lint`)**: Clean (0 errors, 73 benign warnings).
* **Production Build (`compile_applet`)**: Compiled successfully.
