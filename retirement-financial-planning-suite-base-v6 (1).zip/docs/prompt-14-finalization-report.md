# Prompt 14 Finalization Report: Debounced Cloud Persistence & Architecture Standardization

## 1. Local-First Persistence Architecture

The persistent state architecture follows a strict local-first model where local responsiveness and durability are never compromised by remote cloud operations:

```text
User Edit (UI Event)
   ↓
Zustand State Immediately (In-Memory React State)
   ↓
localStorage Synchronously (Immediate Client Durability)
   ↓
CloudSyncManager Enqueue
   ↓
Debounced Cloud Synchronization (Eventual Remote Firestore Sync)
```

### Core Guarantees & Semantics:
1. **Immediate Local Durability**: Every keystroke or state modification immediately updates Zustand memory and writes synchronously to `localStorage`. Local edits never block or wait on cloud network calls.
2. **Debounced Latest-Write-Wins Sync**: `CloudSyncManager` batches rapid keystrokes (e.g. 20 consecutive updates during typing) over a default 1000ms debounce window. When the timer expires or an explicit flush occurs, only the latest plan snapshot is synced to Firestore.
3. **Per-Plan Pending Queue Isolation**: `CloudSyncManager` maintains pending writes in a per-plan key map (`Map<string, Plan>`). Edits to Plan A and Plan B remain independent in the pending queue without overwriting or cancelling each other.
4. **Non-Blocking Plan Switching Contract**: When `usePlanStore.selectPlan(id)` is invoked, it initiates an asynchronous `void cloudSyncManager.flush()` for any pending changes on the previous plan while immediately updating `activePlanId` and `activePlan` in Zustand state and `localStorage`. The local UI switches instantaneously; Firestore synchronization completes asynchronously in the background.

---

## 2. Centralized Lifecycle & Subscription Architecture

### Idempotent Lifecycle Management
`CloudSyncManager` provides centralized, idempotent lifecycle methods:
- `initialize(onStatusChange?: (status: SyncStatus) => void): () => void`: Installs window event listeners (`online`, `beforeunload`, `pagehide`) and registers status subscribers. Repeated invocations are idempotent and return the existing cleanup disposer without adding duplicate listeners or accumulating subscriptions.
- `dispose(): void`: Unsubscribes status listeners and removes browser window event handlers. Disposing cleans up event listeners without clearing pending writes or mutating local persistence queues.
- `initializeCloudSyncLifecycle()`: Exported helper function from `usePlanStore.ts` that initializes cloud sync lifecycle handlers and binds `CloudSyncManager` status directly to Zustand store state (`syncStatus`, `isCloudSynced`).

### Unload Semantics Policy
- Browser lifecycle handlers (`beforeunload`, `pagehide`) trigger best-effort `cloudSyncManager.flush()` calls.
- **Policy Standard**: `beforeunload` and `pagehide` initiate best-effort cloud flushes and do not guarantee remote persistence before browser termination. Local `localStorage` persistence remains the primary durability guarantee across session terminations.

### Authoritative Single-Path Status Synchronization
- Prior duplicate status subscriptions (e.g. module top-level + store initialization) were consolidated into a single authoritative subscription path.
- State transitions (`local-only` → `pending` → `syncing` → `synced` / `error`) flow strictly: `CloudSyncManager` → Zustand `syncStatus` → UI `SaveIndicator`.

---

## 3. Architecture Rules: Machine-Enforced vs. Code-Review Policies

To maintain codebase health without over-promising automated checks, architectural rules are strictly delineated into machine-enforced AST scanner rules and design code-review policies:

### A. Machine-Enforced Architectural Rules (`npm run check:arch`)
Enforced automatically via `scripts/check-architecture.ts` and AST linting:
1. **Financial Engine Independence**: Files inside `src/domain/kernel/` MUST NOT import React, UI components, Zustand stores, Firebase/Firestore, or browser storage APIs (`localStorage`/`sessionStorage`).
2. **Statutory Registry Pureness**: Files inside `src/domain/registry/` MUST NOT import UI, store, Firebase, or depend upward on simulation or analysis modules.
3. **Layer Separation**: `src/domain/simulation/`, `src/domain/projection/`, and `src/domain/analysis/` MUST NOT import React or UI components.

### B. Code-Review & Design Policies
Enforced through developer guidelines, pull request reviews, and test suite conventions:
1. **Single Authoritative Calculation Source**: Domain logic (e.g., tax constants, ACA subsidies, withdrawal sequencing) should be defined once in `src/domain/` and consumed by UI components rather than re-implemented in components.
2. **Read-Only Engine Files during Styling**: UI layout or visual modifications MUST NOT touch domain files or formulas unless financial specification changes are explicitly requested.

---

## 4. Verification Results

All required automated checks, tests, and build verifications have passed cleanly:

- **Architectural Boundary Scanner (`npm run check:arch`)**:
  `0 violations` across all domain modules.
- **Automated Test Suite (`npm test`)**:
  `395 / 395 tests passed` (32 test files) 100% green.
  Includes new regression tests for non-blocking plan switching contract, idempotent lifecycle initialization, network failure recovery, and disposer cleanup.
- **Linter (`npm run lint`)**:
  `0 errors` (73 minor formatting/unused-var warnings).
- **Production Build (`npm run build`)**:
  Compiled successfully with Vite & esbuild into `dist/`.
