# Strategy Layer Specification & Roadmap

This document outlines the architecture, current contract state, and future capabilities of the Meridian Strategy Layer.

---

## 1. Implemented Capabilities

### Phase 1: Strategy Contracts & Baseline Preservation
* **Explicit Effective Strategy Contract**: Standardized `RetirementStrategy` contract interface (`src/domain/strategy/strategyTypes.ts`) combining withdrawal, Roth conversion, and tax payment policies.
* **Effective Strategy Resolver**: Pure `resolveRetirementStrategy()` function (`src/domain/strategy/strategyResolver.ts`) converting persisted Plan inputs into an authoritative runtime strategy without mutating Plan objects.
* **Roth Conversion Policy**: `RothConversionStrategy` encapsulating conversion age window (`startAge`, `endAge`) and manual annual dollar targets.
* **Conversion-Tax Payment Strategy**: `TaxPaymentStrategy` defining tax source selection (`taxable_brokerage` vs. `conversion_proceeds`).

### Phase 2: Configurable Withdrawal Ordering
* **First-Class Policy Types**: Added `WithdrawalPolicyId` (`taxable_first`, `pretax_first`, `roth_first`) and `WITHDRAWAL_POLICIES` registry defining explicit withdrawal asset draw orderings.
* **Plan Schema Persistence**: Extended `SpendingAssumptionsSchema` with `withdrawalPolicy` (defaulting to `'taxable_first'`), enabling user persistence in saved plans.
* **Solver & Execution Alignment**: Refactored `solveRetirementCashNeed` and `executeWithdrawalSequence` to dynamically consume `strategy.withdrawal.order`, guaranteeing identical ordering between estimated gross-up and actual execution.
* **RMD Precedence Invariant**: Standardized execution and solver logic so mandatory RMDs are satisfied before discretionary asset draws regardless of policy.
* **Cost-Basis & Gain Tracking**: Preserved proportional cost-basis accounting for taxable brokerage draws regardless of order position.
* **Zero Financial Drift**: The default strategy (`taxable_first`) produces 100% bit-for-bit identical projection output compared to pre-Phase 2 baselines.

---

## 2. Represented But Not Yet Optimized

These strategy variants are supported in the contract type system and UI selections, but currently fall back to resolved manual annual targets until Phase 3 optimizations:

* **Fill 12% Bracket** (`fill_12`): Represented as `type: 'fill_bracket'`, `bracket: 0.12`.
* **Fill 22% Bracket** (`fill_22`): Represented as `type: 'fill_bracket'`, `bracket: 0.22`.
* **Fill 24% Bracket** (`fill_24`): Represented as `type: 'fill_bracket'`, `bracket: 0.24`.

---

## 3. Future Strategy Capabilities (Phases 3+)

* **Dynamic Tax-Efficient Bracket Filling**: Multi-year dynamic conversion optimization targeting specific tax bracket ceilings.
* **ACA-Aware Conversion Strategy**: Multi-year conversion optimization that caps MAGI under the 400% FPL ACA subsidy phaseouts.
* **IRMAA-Aware Conversion Strategy**: Multi-year conversion optimization avoiding Medicare Part B/D surcharge tiers (2-year lookback).
* **Capital Gains Harvesting Strategy**: Systematic harvesting of 0% LTCG tax bracket headroom in low-income years.
* **Dynamic Guardrails**: Guyton-Klinger spending adjustment rules during portfolio drawdowns.
* **Survivor Strategy Modeling**: Single-filer tax bracket compression upon spouse passing.
* **Stochastic Strategy Evaluation**: Testing strategy robustness against Monte Carlo return paths and sequence-of-returns risks.
