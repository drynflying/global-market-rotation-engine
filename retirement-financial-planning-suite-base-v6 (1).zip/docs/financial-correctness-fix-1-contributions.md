# Financial Correctness Fix 1 — Authoritative Contribution & Employer Match Engine

## 1. Overview & Objective

This patch corrects the contribution and employer match modeling defects identified in the v6 retirement engine audit. Prior to this fix:
- Percentage-based employer matches (`employerMatchType: '%'`) were erroneously treated as literal dollar amounts (e.g., `3%` was added as `$3.00` rather than `3% of W-2 salary`).
- Employer contributions were conflated with employee elective deferrals in tax calculations, resulting in either incorrect taxable wage deductions or distorted cash flow constraints.
- Employer matching lacked owner-specificity, ignoring individual W-2 salary streams.

This update establishes **one authoritative contribution resolver module** (`src/domain/contributions/contributionResolver.ts`) that strictly distinguishes:
1. **Employee Elective Contributions**: Pre-tax deferrals, post-tax (Roth) contributions, taxable brokerage savings, and cash deposits.
2. **Employer Contributions / Matches**: Fixed dollar matches (`$`) and percentage-of-compensation matches (`%`), computed strictly against the account owner's active W-2 salary.
3. **Taxable Wage Reduction**: Exclusively reduced by the *employee's pre-tax elective deferral*; employer contributions never reduce employee taxable wages.
4. **Account Cash Inflows**: The full sum of employee elective contributions plus employer contributions added into the respective account balance.

---

## 2. Mathematical & Financial Rules

### 2.1 Single Account Resolution
For an account $i$ belonging to owner $O \in \{\text{primary}, \text{spouse}, \text{joint}\}$ in projection year $t$:

$$\text{EmployeeContrib}_i(t) = \text{annualContribution}_i \times \text{wageScale}(t)$$

$$\text{EmployerContrib}_i(t) = \begin{cases} 
0 & \text{if account is not retirement (e.g. taxable, cash, real estate, HSA)} \\
0 & \text{if } \text{employerMatchValue}_i \le 0 \\
\text{employerMatchValue}_i \times \text{wageScale}(t) & \text{if } \text{employerMatchType}_i = '\$' \\
\text{W2Compensation}_O(t) \times \frac{\text{employerMatchValue}_i}{100} & \text{if } \text{employerMatchType}_i = '\%' 
\end{cases}$$

$$\text{TotalAccountInflow}_i(t) = \text{EmployeeContrib}_i(t) + \text{EmployerContrib}_i(t)$$

### 2.2 Taxable Wage Reduction
$$\text{TaxableWageReduction}_i(t) = \begin{cases}
\text{EmployeeContrib}_i(t) & \text{if account type is 'pre-tax'} \\
0 & \text{otherwise (Roth, Taxable, Cash)}
\end{cases}$$

### 2.3 Working Year Aggregations
For projection year $t$:
- $\text{AnnualSavePreTax}(t) = \sum_{i \in \text{PreTax}} \text{TotalAccountInflow}_i(t)$
- $\text{AnnualSavePostTax}(t) = \sum_{i \in \text{PostTax}} \text{TotalAccountInflow}_i(t)$
- $\text{AnnualSaveTaxable}(t) = \sum_{i \in \text{Taxable} \cup \text{Cash}} \text{TotalAccountInflow}_i(t)$
- $\text{TotalEmployeeSavings}(t) = \sum_{i} \text{EmployeeContrib}_i(t)$
- $\text{TotalEmployerContributions}(t) = \sum_{i} \text{EmployerContrib}_i(t)$
- $\text{TotalAccountAdditions}(t) = \text{TotalEmployeeSavings}(t) + \text{TotalEmployerContributions}(t)$

### 2.4 Household Cash Flow & Tax Integration
- **Taxable MAGI**: Reduced strictly by $\sum_{i \in \text{PreTax}} \text{EmployeeContrib}_i(t)$.
- **Cash Outflow**: Working-year cash outflow includes living expenses, taxes, and $\text{TotalEmployeeSavings}(t)$. Employer contributions are non-cash benefits from the employer directly into the retirement fund and do not consume household net take-home cash flow.

---

## 3. Architecture & Key Files

1. **`src/domain/contributions/contributionResolver.ts`** *(New Authoritative Module)*
   - Pure domain logic without external UI or persistence dependencies.
   - Exports `resolveAccountContribution`, `getActiveW2Compensation`, and `resolveWorkingYearContributions`.
2. **`src/domain/projection/projectWorkingYear.ts`**
   - Refactored to delegate all contribution math and wage reduction to `resolveWorkingYearContributions`.
   - Uses `totalEmployeeSavings` for household cash outflow and `taxableWageReduction` for MAGI adjustments.
3. **`src/domain/accounts/accountCapabilities.ts`**
   - Refactored `calculateAccountTotals` to accept the `plan` parameter and use `resolveAccountContribution`.
4. **`src/components/Step3InvestmentsStep.tsx`** & **`src/components/ProfileStep.tsx`**
   - Updated UI tables and modals to display and edit both `employerMatchValue` and `employerMatchType` (`$` vs `%`).
   - Integrated authoritative contribution breakdowns into portfolio visualizers.
5. **`src/domain/contributions/contributionResolver.test.ts`**
   - Comprehensive test suite covering percentage matches, dollar matches, owner-specific compensation filtering, and working-year aggregations.

---

## 4. Verification

- All 34 characterization tests pass with updated baselines representing mathematically sound employer match compounding.
- All unit tests across `src/domain/` pass cleanly.
