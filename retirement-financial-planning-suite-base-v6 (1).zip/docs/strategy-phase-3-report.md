# Strategy Layer — Phase 3 Implementation Report: Authoritative Roth Conversion Policy Engine

## Summary

Phase 3 of the Strategy Layer establishes authoritative annual Roth conversion policies for financial projections. Building on Phase 1 (First-Class Strategy Contracts) and Phase 2 (Configurable Withdrawal Ordering), Phase 3 converts annual strategy choices (`manual`, `fill_12`, `fill_22`, `fill_24`) into pure, deterministic annual decision functions.

The manual strategy remains the exact zero-drift baseline, preserving historical projection output. The bracket-fill policies (`fill_12`, `fill_22`, `fill_24`) compute the maximum allowable Roth conversion in whole dollars such that net taxable ordinary income after standard deduction does not exceed the upper ceiling of the target federal marginal tax bracket.

---

## Architectural Changes & Layer Isolation

In strict accordance with domain architecture rules, the strategy layer determines **WHAT** conversion target to attempt, while the projection coordinator (`projectRetirementYear.ts`) evaluates the year's financial context and tax implications:

1. **Pure Decision Engine (`src/domain/strategy/rothConversionPolicy.ts`)**:
   - Contains `determineRothConversionTarget(strategy, context): RothConversionDecision`.
   - Pure, deterministic function with zero state mutation, zero DOM/UI imports, and zero side effects.
   - Computes conversion targets using exact federal tax bracket ceilings and IRS Social Security taxability formulas.

2. **Coordinator Integration (`src/domain/projection/projectRetirementYear.ts`)**:
   - Replaced inline legacy conversion logic with `determineRothConversionTarget`.
   - Passes age, pre-tax available balance, prior ordinary income, Social Security, RMD amount, and bracket ceilings to the policy engine.
   - Evaluates baseline tax (without conversion) vs. total tax (with conversion) to compute incremental conversion tax.

3. **Summary & Simulation Context (`src/domain/simulation/simulationTypes.ts` & `src/domain/analysis/simulationSummary.ts`)**:
   - Added `effectiveStrategy` field to `SimulationResult`.
   - Updated `computeSimulationSummary` to attach the executed `RetirementStrategy` to the final summary structure.

---

## Conversion Policies Implemented

| Strategy Name | Policy Key | Annual Target Determination Method |
| :--- | :--- | :--- |
| **Manual** | `manual` | Converts configured whole-dollar `annualTarget`, bounded by age window `[startAge, endAge]` and available pre-tax assets. |
| **Fill 12% Bracket** | `fill_12` | Solves for conversion $C$ such that $\text{NetTaxable}(C) \le \text{Ceiling}_{12\%}$ ($100,800 MFJ / $50,400 Single for 2026). |
| **Fill 22% Bracket** | `fill_22` | Solves for conversion $C$ such that $\text{NetTaxable}(C) \le \text{Ceiling}_{22\%}$ ($211,400 MFJ / $105,700 Single for 2026). |
| **Fill 24% Bracket** | `fill_24` | Solves for conversion $C$ such that $\text{NetTaxable}(C) \le \text{Ceiling}_{24\%}$ ($401,600 MFJ / $201,775 Single for 2026). |

---

## Monotonic Solver & Tax Interactions

### 1. Social Security Tax-Torpedo Resolution
The proportion of Social Security benefits subject to federal income tax (0%, 50%, or 85%) increases monotonically as MAGI + 50% SS increases. A simple linear headroom subtraction ($\text{Bracket Ceiling} - \text{Current Ordinary Income}$) undercounts ordinary income because each dollar converted can make additional Social Security dollars taxable.

To guarantee precision, `determineRothConversionTarget` employs a monotonic binary search solver over whole-dollar conversion amounts $[0, \text{Available Pre-Tax}]$. For each trial conversion $C$, it evaluates:
$$\text{Provisional Income} = \text{Ordinary Income} + C + 0.5 \times \text{Gross SS}$$
$$\text{Taxable SS} = \text{IRS\_SS\_Taxability}(\text{Provisional Income})$$
$$\text{Net Taxable Income} = \max(0, \text{Ordinary Income} + C + \text{Taxable SS} - \text{Standard Deduction})$$

The solver identifies the exact whole-dollar maximum $C$ satisfying $\text{Net Taxable Income}(C) \le \text{Bracket Ceiling}$.

### 2. RMD Precedence
Required Minimum Distributions (RMDs) are legally mandated and cannot be converted directly to Roth accounts. RMDs are satisfied prior to conversion evaluation. The RMD amount is included in ordinary income before conversion, consuming lower bracket capacity and reducing the available pre-tax balance eligible for discretionary conversion.

---

## Non-Optimization Explicit Scope Boundaries

As required by strategy contracts, Phase 3 implements deterministic annual decision policies without introducing unrequested complexity:

* **Monte Carlo**: NOT implemented.
* **Survivor Modeling**: NOT implemented.
* **Generalized Tax Optimizer**: NOT implemented (uses single-year bracket-fill decision rules).
* **ACA Optimization**: NOT implemented. Conversions increase MAGI naturally; ACA subsidies and premiums adapt without artificial caps.
* **IRMAA Optimization**: NOT implemented. Conversions increase MAGI naturally; Medicare Part B/D surcharges adapt without artificial caps.

---

## Verification & Quality Gates

1. **Unit & Characterization Test Suite (`src/domain/strategy/rothConversionPolicy.test.ts`)**:
   - Covers manual strategy within/outside age windows and asset bounds.
   - Covers `fill_12`, `fill_22`, `fill_24` with zero income, partial fill, full bracket, and above bracket cases.
   - Verifies Social Security tax-torpedo non-overshoot invariant.
   - Verifies RMD precedence and bracket capacity consumption.
   - Verifies tax payment source independence for initial conversion targets.
   - Verifies zero-drift backward compatibility for `manual` default strategy.
   - Verifies financial engine invariants across all policies.

2. **Full Regression Test Suite**:
   - 36 test files passed cleanly (438 total tests).
   - Zero failures or unexpected output drift.

3. **Architectural Enforcement (`npm run check:arch`)**:
   - Passed with 0 violations.

4. **TypeScript Verification (`npx tsc --noEmit`)**:
   - Clean pass with 0 type errors.

5. **Linter Gate (`lint_applet`)**:
   - Clean pass with 0 linter errors.

6. **Production Build (`compile_applet`)**:
   - Succeeded cleanly.
