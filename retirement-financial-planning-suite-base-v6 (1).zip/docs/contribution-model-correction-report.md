# Financial Correctness Patch 1 — Contribution Model Correction Report

## 1. Defect Description
Prior to Patch 1, account contributions and employer matching suffered from two primary financial defects:
1. **Uninterpreted Percentage Employer Match**: Accounts with `employerMatchType: '%'` (e.g. 3%) were not calculating 3% of the account owner's eligible W-2 salary. Instead, `employerMatchValue` was evaluated without proper percentage scaling or treated as a nominal scalar dollar figure.
2. **Incorrect Taxable Wage Reduction**: Employer contributions were improperly included in the pre-tax savings aggregate that reduced W-2 taxable income (`taxableMagi`). Under US tax law, employer matching contributions increase employee retirement asset balances but do NOT reduce employee W-2 taxable gross wages in the manner of an employee elective deferral.

## 2. Files Changed
- `src/domain/contributions/contributionResolver.ts`: Authoritative domain module establishing `resolveAccountContribution`, `getActiveW2Compensation`, and `resolveWorkingYearContributions`.
- `src/domain/contributions/contributionResolver.test.ts`: Direct unit tests covering percentage match, fixed dollar match, owner W-2 compensation, zero-salary/match, and DEFAULT_PLAN regression.
- `src/domain/projection/projectWorkingYear.ts`: Updated working-year projection engine coordinator to utilize `resolveWorkingYearContributions`, applying `taxableWageReduction` (employee pre-tax deferrals only) to taxable MAGI while adding total contributions (employee + employer) to retirement portfolio balances.
- `src/domain/projection/projectWorkingYear.test.ts`: Added deterministic projection tests verifying percentage/fixed matches, asset balance accumulation, and taxable MAGI reduction.
- `src/domain/accounts/accountCapabilities.ts`: Integrated authoritative contribution resolver into `calculateAccountTotals`.
- `src/domain/accounts/accountCapabilities.test.ts`: Added test verifying 3% employer match resolution in account totals.
- `src/domain/validation/validations.ts`: Verified elective deferral guideline checks evaluate employee deferrals separately from employer matches.
- `src/components/ProfileStep.tsx`: Updated account list table display to render resolved total account contributions and matching breakdown using the contribution resolver.
- `src/components/Step3InvestmentsStep.tsx`: Updated portfolio flow calculations to use authoritative account contribution resolution.

## 3. Contribution Resolver Contract
```ts
export interface AccountContributionBreakdown {
  employeeContribution: number;
  employerContribution: number;
  totalAccountContribution: number;
  employeePreTaxContribution: number;
  employeePostTaxContribution: number;
  taxableWageReduction: number;
}

export interface ContributionContext {
  ownerW2Compensation: number;
  contributionScale?: number;
}
```

## 4. Percentage-Match Semantics
When `employerMatchType === '%'`, the employer match is computed as:
$$\text{Employer Contribution} = \left(\frac{\text{employerMatchValue}}{100}\right) \times \text{ownerW2Compensation}$$
Example: Primary owner W-2 salary = $100,000, `employerMatchValue = 3`, `employerMatchType = '%'` $\rightarrow$ Employer contribution = $3,000.

## 5. Fixed-Dollar Semantics
When `employerMatchType === '$'`, the employer match is computed as an annual fixed dollar amount (scaled by wage indexation `contributionScale` if active):
$$\text{Employer Contribution} = \text{employerMatchValue} \times \text{contributionScale}$$
Example: `employerMatchValue = 5000`, `employerMatchType = '$'` $\rightarrow$ Employer contribution = $5,000.

## 6. Owner Salary Resolution
Employer percentage matches evaluate strictly against the account owner's eligible W-2 salary streams (`getActiveW2Compensation`):
- Primary account $\rightarrow$ Primary W-2 salary streams.
- Spouse account $\rightarrow$ Spouse W-2 salary streams.
- Joint/household streams are split deterministically. Non-salary income streams (pensions, Social Security, rental, dividends) are excluded from eligible compensation.

## 7. Employee Pre-Tax Contribution Treatment
Employee pre-tax elective deferrals (e.g. Traditional 401(k) / 403(b) contributions):
- Increase pre-tax retirement account asset balances.
- Reduce taxable W-2 income (`taxableWageReduction`).

## 8. Employee Post-Tax Contribution Treatment
Employee post-tax contributions (e.g. Roth 401(k) / Roth IRA):
- Increase Roth retirement account asset balances.
- Do NOT reduce taxable W-2 income (`taxableWageReduction = 0`).

## 9. Employer Contribution Treatment
Employer contributions (matching or non-elective pre-tax contributions):
- Increase retirement account asset balances (pre-tax portfolio roll-forward).
- Do NOT reduce employee taxable W-2 income.

## 10. Taxable-Wage Correction
The working-year MAGI calculation in `projectWorkingYear.ts` now uses:
$$\text{taxableMagi} = \max(0, \text{w2Income} - \text{taxableWageReduction})$$
where `taxableWageReduction` is strictly equal to employee pre-tax elective deferrals across pre-tax account buckets.

## 11. Default-Plan Impact
In `DEFAULT_PLAN`:
- Primary 401(k) (`acc-1`): Primary salary = $75,000, 3% match $\rightarrow$ **$2,250** employer contribution + $11,400 employee contribution = **$13,650** total.
- Spouse 401(k) (`acc-2`): Spouse salary = $50,000, 3% match $\rightarrow$ **$1,500** employer contribution + $3,800 employee contribution = **$5,300** total.
- Household Roth IRA (`acc-3`): $3,800 employee contribution = **$3,800** total.
- Total household employee savings = **$19,000**.
- Total household employer match = **$3,750**.
- Total household account inflow = **$22,750**.
- Taxable MAGI reduction = **$15,200** (Primary $11,400 + Spouse $3,800 pre-tax employee deferrals).

## 12. UI & Account-Total Changes
Account summary cards and account tables in `ProfileStep.tsx` and `Step3InvestmentsStep.tsx` use the authoritative contribution resolver rather than raw configuration values or ad hoc additions.

## 13. Tests Added
- `contributionResolver.test.ts`: Fixed-dollar match, percentage match, wage growth scaling, post-tax non-reduction, zero-salary, zero-match, owner-specific salary resolution, multi-account aggregation, and DEFAULT_PLAN regression.
- `projectWorkingYear.test.ts`: Percentage match resolution, fixed-dollar match, spouse percentage match, Roth contributions, taxable MAGI deduction verification.
- `accountCapabilities.test.ts`: 3% employer match dollar resolution in account totals.

## 14. Characterization Changes
The simulation characterization test suite (`simulationEngine.characterization.test.ts`) passes 100% cleanly (34/34 tests). All financial differences stem directly from the correct calculation of percentage employer matches ($3,750 in DEFAULT_PLAN) and proper non-deduction of employer matches from taxable wages.

## 15. Invariant Results
All core simulation accounting invariants (`INV_PORTFOLIO_ROLLFORWARD`, `INV_CASH_FLOW`, `INV_TAX_COMPONENTS`) pass cleanly across all working and retirement years.

## 16. Architecture Check (`check:arch`)
Command: `npm run check:arch`
Result: **0 violations**.

## 17. Typecheck (`typecheck`)
Command: `npm run typecheck`
Result: **0 errors**.

## 18. Lint (`lint`)
Command: `npm run lint`
Result: **0 errors** (74 warnings regarding unused variables/hooks).

## 19. Production Build (`compile_applet`)
Command: `compile_applet`
Result: **Build succeeded - the applet is compiled**.

## 20. Explicit Confirmation
**CONFIRMED**: The separate FICA defect (Social Security wage-base cap handling) was NOT addressed in this patch and will be handled in Patch 2.
