# Financial Correctness Fix 4: Statutory Contribution Limits SSOT & Account-Wrapper Honesty

## 1. Overview & Objectives

This targeted financial-correctness and validation-clarity patch achieves four key goals:
1. **Eliminate Stale Contribution-Limit Copies**: Removed duplicated, hardcoded, and out-of-sync contribution limits across the codebase.
2. **Authoritative Statutory Registry (SSOT)**: Established `statutoryRegistry.ts` (`BASE_CONTRIBUTION_LIMITS` and `CONTRIBUTION_LIMITS_REGISTRY`) as the single source of truth for 2026 IRS contribution limits, with explicit provenance tracking (`STATUTORY_OFFICIAL` vs `SCENARIO_OVERRIDE`).
3. **Consistent Validation Engine**: Refactored validation to consume authoritative registry limits via `resolveContributionLimits()` and age-based resolvers (`get401kContributionLimit`, `getIraContributionLimit`, `getHsaContributionLimit`).
4. **Account-Wrapper Honesty**: Updated validation messages and UI descriptions to avoid implying exact IRS statutory enforcement where the current account model does not distinguish specific account sub-types (e.g., 401(k) vs Traditional IRA vs 457(b) wrappers).

---

## 2. Statutory Values (2026 Tax Year SSOT)

| Parameter | 2026 Official Limit | Catch-up Amount | Age Requirement |
| :--- | :--- | :--- | :--- |
| **401(k) / 403(b) Elective Deferral** | $24,500 | +$8,000 | Age 50+ ($32,500 total) |
| **Traditional & Roth IRA** | $7,500 | +$1,100 | Age 50+ ($8,600 total) |
| **HSA (Self-Only / Individual)** | $4,400 | +$1,000 | Age 55+ ($5,400 total) |
| **HSA (Family HDHP)** | $8,750 | +$1,000 | Age 55+ ($9,750 total) |

---

## 3. Structural Changes

### 3.1 `src/domain/registry/statutoryRegistry.ts`
- Defined `BASE_CONTRIBUTION_LIMITS` containing the official 2026 baseline limits.
- Added `resolveContributionLimits(overrides?)` returning resolved parameters with provenance metadata (`STATUTORY_OFFICIAL` vs `SCENARIO_OVERRIDE`).
- Added helper functions:
  - `get401kContributionLimit(age, resolvedLimits?)`: Calculates elective limit + age 50+ catch-up.
  - `getIraContributionLimit(age, resolvedLimits?)`: Calculates IRA limit + age 50+ catch-up.
  - `getHsaContributionLimit(isFamily, age, resolvedLimits?)`: Calculates HDHP single/family limit + age 55+ catch-up.

### 3.2 `src/constants/defaultPlan.ts`
- Linked `DEFAULT_PLAN.statutoryParams` directly to `BASE_CONTRIBUTION_LIMITS`.
- Updated assumption descriptions (`asm-401k-limit`, `asm-hsa-limits`) to match 2026 official values.

### 3.3 `src/domain/assumptions/assumptionBindings.ts`
- Updated format strings and test fixtures to reflect 2026 statutory limits and catch-up amounts.

### 3.4 `src/domain/validation/validations.ts`
- Updated Step 1 validations to use `resolveContributionLimits`, `get401kContributionLimit`, `getIraContributionLimit`, and `getHsaContributionLimit`.
- Implemented account-wrapper honesty in warning text: clarifying that pre-tax contributions exceeding a single 401(k) limit may be valid if split across independent employer plans or non-deferral structures.
- Added HSA statutory limit validation (self-only vs family, 55+ catch-up).
- Verified age-eligibility for catch-up flags (age 50+ for retirement, age 55+ for HSA).

### 3.5 `src/components/AssumptionsStatutoryStep.tsx`
- Replaced hardcoded fallback literals with references to `BASE_CONTRIBUTION_LIMITS`.
- Standardized reset buttons and default indicators to dynamic strings formatted from `BASE_CONTRIBUTION_LIMITS`.

---

## 4. Verification & Test Suite

- **Unit Tests**:
  - `src/domain/registry/statutoryRegistry.test.ts`: Added tests for `BASE_CONTRIBUTION_LIMITS`, `resolveContributionLimits`, provenance tags, and age-based limit resolution.
  - `src/domain/validation/contributionValidation.test.ts`: Added comprehensive tests for Step 1 validation, employer match exclusion from employee deferral limits, scenario overrides, HSA validation, and catch-up flag eligibility.
- **Full Verification**: Architecture validation (`check:arch`), TypeScript typecheck (`typecheck`), linter (`lint`), and Vitest test suite (`test`) all passed cleanly (41 test files, 485+ tests).
