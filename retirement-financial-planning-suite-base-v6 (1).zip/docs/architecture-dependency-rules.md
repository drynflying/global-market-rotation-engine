# Architectural Dependency Rules & Automated Enforcement Specification

## 1. Overview & Objectives

To preserve financial engine determinism, maintain layer boundaries, and prevent future accidental imports or coupling across architecture layers, automated checks enforce strict dependency boundaries.

The architectural enforcement mechanism operates in CI/lint via:
1. `scripts/check-architecture.ts` (run via `npm run check:arch` and integrated into `npm run lint` and `npm run verify`).
2. ESLint flat configuration in `eslint.config.js` (`no-restricted-imports`, `no-restricted-globals`).

---

## 2. Layer Rules Matrix

| Architecture Layer | Directory Path | Allowed Dependencies | Prohibited Dependencies |
| :--- | :--- | :--- | :--- |
| **Domain Kernel** | `src/domain/kernel` | Pure mathematical types & internal constants | React, components, store/Zustand, services, Firebase, `localStorage`/`sessionStorage` |
| **Domain Registry** | `src/domain/registry` | Statutory tables, constants, tax constants | React, components, store/Zustand, Firebase, upward dependencies on `simulation` or `analysis` |
| **Domain Analysis** | `src/domain/analysis` | `SimulationRow`, `SimulationResult` domain types | UI/components, Firebase, persistence (`services`), store/Zustand |
| **Domain Simulation & Projection** | `src/domain/simulation`, `src/domain/projection` | `registry`, `kernel`, `strategy`, domain types | Firebase, React, UI/components |
| **Services & Repositories** | `src/services` | Firebase, local caching, plan storage | Implementation or duplication of financial statutory formulas |
| **UI Components** | `src/components` | React, domain APIs, `STATUTORY_REGISTRY` | Duplication of statutory financial formulas |

---

## 3. Enforcement Commands

```bash
# Execute standalone architecture check
npm run check:arch

# Execute full repository verification (architecture check, typecheck, linting, unit tests)
npm run verify
```

---

## 4. Verification & Testing Procedure

Rule violations are verified using intentional prohibited test imports:
1. Intentionally adding a prohibited import (e.g. `import React from 'react'` inside `src/domain/kernel/taxKernel.ts`).
2. Running `npm run check:arch` or `npm run lint`.
3. Confirming that the runner fails immediately with explicit file, line, and rule violation details.
4. Removing the test import and confirming clean pass (`0 violations`).
