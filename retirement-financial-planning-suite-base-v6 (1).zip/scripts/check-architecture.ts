import fs from 'fs';
import path from 'path';
import ts from 'typescript';

interface RuleViolation {
  file: string;
  line: number;
  rule: string;
  message: string;
}

const violations: RuleViolation[] = [];

function getLineAndColumn(sourceFile: ts.SourceFile, pos: number) {
  const { line } = sourceFile.getLineAndCharacterOfPosition(pos);
  return line + 1;
}

function resolveImportPath(importPath: string, currentFilePath: string): string {
  if (importPath.startsWith('.')) {
    return path.normalize(path.join(path.dirname(currentFilePath), importPath));
  }
  return importPath;
}

function scanFile(filePath: string) {
  const code = fs.readFileSync(filePath, 'utf-8');
  const sourceFile = ts.createSourceFile(filePath, code, ts.ScriptTarget.Latest, true);
  const relPath = path.relative(process.cwd(), filePath).replace(/\\/g, '/');
  const isTestFile = relPath.endsWith('.test.ts') || relPath.endsWith('.test.tsx') || relPath.endsWith('.spec.ts');

  // Skip test files for architectural boundaries unless inspecting core logic
  if (isTestFile) {
    return;
  }

  function visit(node: ts.Node) {
    let moduleSpecifier: string | null = null;
    const importPos = node.getStart(sourceFile);

    if (ts.isImportDeclaration(node) && ts.isStringLiteral(node.moduleSpecifier)) {
      moduleSpecifier = node.moduleSpecifier.text;
    } else if (
      ts.isCallExpression(node) &&
      node.expression.kind === ts.SyntaxKind.ImportKeyword &&
      node.arguments.length > 0 &&
      ts.isStringLiteral(node.arguments[0])
    ) {
      moduleSpecifier = node.arguments[0].text;
    }

    if (moduleSpecifier) {
      const resolved = resolveImportPath(moduleSpecifier, relPath).replace(/\\/g, '/');
      const lowerImport = moduleSpecifier.toLowerCase();
      const lowerResolved = resolved.toLowerCase();
      const line = getLineAndColumn(sourceFile, importPos);

      // --- RULE 1: domain/kernel ---
      if (relPath.startsWith('src/domain/kernel/')) {
        if (lowerImport === 'react' || lowerImport === 'react-dom' || lowerImport.startsWith('react/')) {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/kernel',
            message: `Forbidden React import '${moduleSpecifier}' in domain/kernel`,
          });
        }
        if (lowerResolved.includes('/components/')) {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/kernel',
            message: `Forbidden components import '${moduleSpecifier}' in domain/kernel`,
          });
        }
        if (lowerImport === 'zustand' || lowerResolved.includes('/store/')) {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/kernel',
            message: `Forbidden store/Zustand import '${moduleSpecifier}' in domain/kernel`,
          });
        }
        if (lowerResolved.includes('/services/')) {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/kernel',
            message: `Forbidden services import '${moduleSpecifier}' in domain/kernel`,
          });
        }
        if (lowerImport.includes('firebase')) {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/kernel',
            message: `Forbidden Firebase import '${moduleSpecifier}' in domain/kernel`,
          });
        }
      }

      // --- RULE 2: domain/registry ---
      if (relPath.startsWith('src/domain/registry/')) {
        if (lowerImport === 'react' || lowerImport === 'react-dom' || lowerResolved.includes('/components/')) {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/registry',
            message: `Forbidden UI/components import '${moduleSpecifier}' in domain/registry`,
          });
        }
        if (lowerImport === 'zustand' || lowerResolved.includes('/store/')) {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/registry',
            message: `Forbidden store import '${moduleSpecifier}' in domain/registry`,
          });
        }
        if (lowerImport.includes('firebase')) {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/registry',
            message: `Forbidden Firebase import '${moduleSpecifier}' in domain/registry`,
          });
        }
        if (lowerResolved.includes('/domain/simulation/') || lowerResolved.includes('/domain/analysis/')) {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/registry',
            message: `Forbidden upward dependency '${moduleSpecifier}' (simulation/analysis) in domain/registry`,
          });
        }
      }

      // --- RULE 3: domain/analysis ---
      if (relPath.startsWith('src/domain/analysis/')) {
        if (lowerImport === 'react' || lowerImport === 'react-dom' || lowerResolved.includes('/components/')) {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/analysis',
            message: `Forbidden UI/components import '${moduleSpecifier}' in domain/analysis`,
          });
        }
        if (lowerImport.includes('firebase')) {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/analysis',
            message: `Forbidden Firebase import '${moduleSpecifier}' in domain/analysis`,
          });
        }
        if (lowerResolved.includes('/services/') || lowerResolved.includes('/store/')) {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/analysis',
            message: `Forbidden persistence/store import '${moduleSpecifier}' in domain/analysis`,
          });
        }
      }

      // --- RULE 4: domain/simulation & domain/projection ---
      if (relPath.startsWith('src/domain/simulation/') || relPath.startsWith('src/domain/projection/')) {
        if (lowerImport.includes('firebase')) {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/simulation/projection',
            message: `Forbidden Firebase import '${moduleSpecifier}' in domain/simulation/projection`,
          });
        }
        if (lowerImport === 'react' || lowerImport === 'react-dom') {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/simulation/projection',
            message: `Forbidden React import '${moduleSpecifier}' in domain/simulation/projection`,
          });
        }
        if (lowerResolved.includes('/components/')) {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/simulation/projection',
            message: `Forbidden UI/components import '${moduleSpecifier}' in domain/simulation/projection`,
          });
        }
      }

      // --- RULE 5: domain/strategy ---
      if (relPath.startsWith('src/domain/strategy/')) {
        if (lowerImport.includes('firebase')) {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/strategy',
            message: `Forbidden Firebase import '${moduleSpecifier}' in domain/strategy`,
          });
        }
        if (lowerImport === 'react' || lowerImport === 'react-dom') {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/strategy',
            message: `Forbidden React import '${moduleSpecifier}' in domain/strategy`,
          });
        }
        if (lowerResolved.includes('/components/')) {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/strategy',
            message: `Forbidden UI/components import '${moduleSpecifier}' in domain/strategy`,
          });
        }
        if (lowerImport === 'zustand' || lowerResolved.includes('/store/')) {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/strategy',
            message: `Forbidden store/Zustand import '${moduleSpecifier}' in domain/strategy`,
          });
        }
        if (lowerResolved.includes('/services/')) {
          violations.push({
            file: relPath,
            line,
            rule: 'domain/strategy',
            message: `Forbidden services import '${moduleSpecifier}' in domain/strategy`,
          });
        }
      }
    }

    // AST check for domain/kernel: localStorage / sessionStorage usage
    if (relPath.startsWith('src/domain/kernel/')) {
      if (ts.isIdentifier(node)) {
        if (node.text === 'localStorage' || node.text === 'sessionStorage') {
          const line = getLineAndColumn(sourceFile, node.getStart(sourceFile));
          violations.push({
            file: relPath,
            line,
            rule: 'domain/kernel',
            message: `Forbidden browser infrastructure usage '${node.text}' in domain/kernel`,
          });
        }
      }
    }

    ts.forEachChild(node, visit);
  }

  ts.forEachChild(sourceFile, visit);
}

function getAllFiles(dir: string): string[] {
  const results: string[] = [];
  const list = fs.readdirSync(dir);
  for (const file of list) {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat && stat.isDirectory()) {
      results.push(...getAllFiles(fullPath));
    } else if (fullPath.endsWith('.ts') || fullPath.endsWith('.tsx')) {
      results.push(fullPath);
    }
  }
  return results;
}

function runArchitectureCheck() {
  console.log('🔍 Checking architectural dependency boundaries...');
  const srcDir = path.join(process.cwd(), 'src');
  const files = getAllFiles(srcDir);

  for (const file of files) {
    scanFile(file);
  }

  if (violations.length > 0) {
    console.error('\n❌ Architectural Dependency Violations Found:\n');
    for (const v of violations) {
      console.error(`  - ${v.file}:${v.line} [${v.rule}] ${v.message}`);
    }
    console.error(`\nTotal violations: ${violations.length}`);
    process.exit(1);
  }

  console.log('✅ Architectural dependency enforcement check passed cleanly with 0 violations!\n');
}

runArchitectureCheck();
